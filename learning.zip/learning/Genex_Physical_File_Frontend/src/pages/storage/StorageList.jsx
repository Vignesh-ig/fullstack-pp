import { useState } from "react";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import Pagination from "../../components/ui/common/Pagination";
import { APP_STAGES } from "../../constants/stages";
import { useStampOptions } from "../../hooks/dropdowns/useStampOptions";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import useTransactionFetch from "../../hooks/useTransactionFetch";
import StorageTable from "./components/StorageTable";

/**
 * StorageList
 *
 * Fetches and displays transactions currently in the STORAGE stage.
 */
const StorageList = () => {
  const { stampTypeOptions, loading: loadingStampTypes } = useStampOptions({
    fetchDenominations: false,
  });

  const [stampTypeFilter, setStampTypeFilter] = useState("");
  const { fetchFn } = useTransactionFetch({
    stage: APP_STAGES.STORAGE,
    extraParams: { stampType: stampTypeFilter },
  });

  const {
    data: records,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "likeAppNoOrBarcode");

  const handleRefresh = () => {
    if (stampTypeFilter === "") {
      refetch();
    } else {
      setStampTypeFilter("");
    }
  };

  return (
    <ListContainer>
      <ListHeader
        title="Storage"
        unit="records"
        count={pagination.totalItems}
        loading={loading}
        search={search}
        setSearch={setSearch}
        refetch={handleRefresh}
      >
        <search className="mt-4 grid grid-cols-1 sm:flex sm:flex-row items-start sm:items-center gap-3 sm:gap-5 w-full border-t border-border-subtle pt-4">
          <FilterSelectField
            label="Filter by Stamp Type:"
            name="stampTypeFilter"
            value={stampTypeFilter}
            onChange={(e) => setStampTypeFilter(e.target.value)}
            placeholder={loadingStampTypes ? "Loading types..." : "All Types"}
            options={stampTypeOptions}
            className="w-full sm:w-auto"
            showSearch={true}
            disabled={loadingStampTypes}
          />
        </search>
      </ListHeader>

      {error && (
        <section className="px-6 pt-4">
          <ErrorBanner message={error} onClose={() => setError(null)} />
        </section>
      )}

      <StorageTable
        records={records}
        loading={loading}
        error={error}
        search={search}
        page={page}
        pageSize={pageSize}
      />

      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />
    </ListContainer>
  );
};

StorageList.displayName = "StorageList";
export default StorageList;
