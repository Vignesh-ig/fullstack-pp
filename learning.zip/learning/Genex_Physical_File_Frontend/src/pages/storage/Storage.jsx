import { Route, Routes } from "react-router-dom";
import StorageList from "./StorageList";

/**
 * Storage
 *
 * Renders the Storage module component.
 *
 */
const Storage = () => {
  return (
    <Routes>
      <Route path="/" element={<StorageList />} />
    </Routes>
  );
};

Storage.displayName = "Storage";
export default Storage;
