import {
  FileIcon,
  ServerIcon,
  UserIcon,
} from "../../../components/icons/icons";
import { StatusBadge } from "../../../components/ui/badge/badgeIndex";
import DetailCard from "../../../components/ui/common/DetailCard";
import DetailField from "../../../components/ui/common/DetailField";

/**
 * StorageExpandedRow
 *
 * Renders the full-width expanded detail panel for a storage record.
 */
const StorageExpandedRow = ({ rec, colSpan, isExpanded }) => {
  return (
    <tr className="bg-slate-50/40">
      <td colSpan={colSpan} className="p-0 border-0">
        <div
          className={`expandable-row-wrapper ${isExpanded ? "expanded" : ""}`}
        >
          <div className="expandable-row-inner">
            <div className="px-6 py-4 border-b border-border-subtle">
              <section className="bg-white border border-slate-500/70 rounded-xl p-2 sm:p-5 shadow-xs grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 text-left">
                {/* Section 1: Assigned User Details */}
                <DetailCard title="Assigned User Details" icon={UserIcon}>
                  <dl className="grid min-h-24 grid-rows-[auto_1fr_auto] gap-2">
                    <DetailField
                      label="User"
                      value={
                        rec.assignedUser?.userName
                          ? `${rec.assignedUser.userName}${rec.assignedUser.userEmployeeCode ? ` (${rec.assignedUser.userEmployeeCode})` : ""}`
                          : "—"
                      }
                    />
                    <DetailField
                      label="Email"
                      value={rec.assignedUser?.userEmail}
                    />
                  </dl>
                </DetailCard>

                {/* Section 2: Despatch Details */}
                <DetailCard title="Despatch Details" icon={FileIcon}>
                  <dl className="grid grid-cols-2 gap-4">
                    <DetailField label="Ageing" value={rec.ageingNo} />
                    <DetailField label="Scheme" value={rec.schemaProduct} />
                    <DetailField label="POD No" value={rec.podNo} />
                    <DetailField label="File Type" value={rec.fileType} />
                    <div>
                      <dt className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                        eSign Status
                      </dt>
                      <dd className="mt-1">
                        {typeof rec.isESign === "boolean" ? (
                          <StatusBadge isActive={rec.isESign} />
                        ) : (
                          "—"
                        )}
                      </dd>
                    </div>
                  </dl>
                </DetailCard>

                {/* Section 3: Rack Details */}
                <DetailCard title="Rack Details" icon={ServerIcon}>
                  <dl className="grid grid-cols-3 gap-4">
                    <DetailField
                      label="Vault Name"
                      value={rec.rack?.vaultName}
                    />
                    <DetailField label="Rack Name" value={rec.rack?.rackName} />
                    <DetailField label="Self" value={rec.rack?.rackPosition} />
                    <div>
                      <dt className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                        Rack Status
                      </dt>
                      <dd className="mt-1">
                        {typeof rec.rack?.rackStatus === "boolean" ? (
                          <StatusBadge isActive={rec.rack?.rackStatus} />
                        ) : (
                          "—"
                        )}
                      </dd>
                    </div>
                  </dl>
                </DetailCard>

                {/* Section 4: Additional Loan Details */}
                <DetailCard title="Additional Loan Details" icon={FileIcon}>
                  <dl className="grid grid-cols-3 gap-4">
                    <DetailField label="Loan ID" value={rec.loanId || "N/A"} />
                    <DetailField
                      label="Business Date"
                      value={
                        rec.businessDate
                          ? new Date(rec.businessDate).toLocaleDateString()
                          : "N/A"
                      }
                    />
                    <DetailField
                      label="Sourcing Date"
                      value={
                        rec.sourcingDate
                          ? new Date(rec.sourcingDate).toLocaleDateString()
                          : "N/A"
                      }
                    />
                    <DetailField label="Tenure" value={rec.tenure || "N/A"} />
                    <DetailField label="BIRR" value={rec.birr || "N/A"} />
                    <DetailField
                      label="Registrable Status"
                      value={rec.registrableStatus || "N/A"}
                    />
                    <DetailField
                      label="Udyam Number Status"
                      value={rec.udhayamNumberStatus || "N/A"}
                    />
                    <DetailField
                      label="PAC Amount"
                      value={rec.pacAmount || "N/A"}
                    />
                  </dl>
                </DetailCard>
              </section>
            </div>
          </div>
        </div>
      </td>
    </tr>
  );
};

StorageExpandedRow.displayName = "StorageExpandedRow";
export default StorageExpandedRow;
