import { useSelector } from "react-redux";
import { ChevronRightIcon } from "../../../components/icons/icons";
import { StampTypeBadge } from "../../../components/ui/badge/badgeIndex";
import IconButton from "../../../components/ui/common/IconButton";
import { ROLES } from "../../../constants/roles";
import { STAMP_TYPE } from "../../../constants/stampingConstants";
import { toTitleCase } from "../../../utils/utils";
import StorageExpandedRow from "./StorageExpandedRow";

/**
 * StorageTableRow
 *
 * Renders a single data row inside the Storage table. Includes an expand/collapse toggle.
 */
const StorageTableRow = ({
  rec,
  serialNumber,
  isExpanded,
  onToggle,
  colSpan,
}) => {
  const { roleName } = useSelector((state) => state.user);
  const isCpu = roleName === ROLES.CPU;

  return (
    <>
      <tr
        onClick={onToggle}
        className="hover:bg-slate-200/80 transition-colors cursor-pointer border-b border-border-subtle"
      >
        <td
          className="table-td-center"
          onClick={(e) => {
            e.stopPropagation();
            onToggle();
          }}
        >
          <IconButton
            onClick={(e) => {
              e.stopPropagation();
              onToggle();
            }}
            className="p-1 hover:bg-slate-200 text-text-secondary shadow-none border-none bg-transparent hover:text-text-secondary focus:outline-none"
            ariaLabel={isExpanded ? "Collapse row" : "Expand row"}
            icon={
              <ChevronRightIcon
                className={`w-4 h-4 transition-transform duration-200 ${
                  isExpanded ? "rotate-90" : ""
                }`}
              />
            }
          />
        </td>
        <td className={isCpu ? "table-td-middle-cpu" : "table-td-middle"}>
          {serialNumber}
        </td>
        <td className={isCpu ? "table-td-middle-cpu" : "table-td-middle"}>
          {rec.appNo || "—"}
        </td>
        <td className={isCpu ? "table-td-middle-cpu" : "table-td-middle"}>
          {rec.aggNo || "—"}
        </td>
        <td className={isCpu ? "table-td-middle-cpu" : "table-td-middle"}>
          {rec.barcode || "—"}
        </td>
        <td className="px-6 py-2.5 text-sm text-text-primary font-medium whitespace-nowrap">
          {rec.customerName || "—"}
        </td>
        <td className={isCpu ? "table-td-middle-cpu" : "table-td-middle"}>
          {rec.stateDesc ? toTitleCase(rec.stateDesc) : "—"}
        </td>
        <td className="table-td-center">
          <StampTypeBadge
            stampType={
              rec.stampType
                ? rec.stampType.toUpperCase()
                : STAMP_TYPE.NO_STAMPING
            }
          />
        </td>
      </tr>

      <StorageExpandedRow rec={rec} colSpan={colSpan} isExpanded={isExpanded} />
    </>
  );
};

StorageTableRow.displayName = "StorageTableRow";
export default StorageTableRow;
