import { useState } from "react";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { STORAGE_TABLE_COLUMNS } from "../../../constants/tableHeaders";
import StorageTableRow from "./StorageTableRow";

/**
 * StorageTable
 *
 * Renders the tabular list of Storage transactions.
 */
const StorageTable = ({ records, loading, error, search, page, pageSize }) => {
  const [expandedRowId, setExpandedRowId] = useState(null);

  const handleToggle = (id) => {
    setExpandedRowId((prev) => (prev === id ? null : id));
  };

  const colSpan = STORAGE_TABLE_COLUMNS.length;

  return (
    <Table
      headers={STORAGE_TABLE_COLUMNS}
      headerColorClass="bg-table-header-bg"
    >
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow key={i} columnsCount={colSpan} />
        ))
      ) : records?.length === 0 && !error ? (
        <tr>
          <td colSpan={colSpan} className="h-full">
            <EmptyState
              title="No storage records found"
              description={
                search
                  ? `No results for "${search}". Try a different search.`
                  : "No storage records available."
              }
            />
          </td>
        </tr>
      ) : (
        records?.map((rec, index) => {
          const serialNumber = (page - 1) * pageSize + index + 1;
          const isExpanded = expandedRowId === rec.transactionId;
          return (
            <StorageTableRow
              key={rec.transactionId || index}
              rec={rec}
              serialNumber={serialNumber}
              isExpanded={isExpanded}
              onToggle={() => handleToggle(rec.transactionId)}
              colSpan={colSpan}
            />
          );
        })
      )}
    </Table>
  );
};

StorageTable.displayName = "StorageTable";
export default StorageTable;
