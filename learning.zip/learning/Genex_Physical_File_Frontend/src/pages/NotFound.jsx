import { useNavigate } from "react-router-dom";

/**
 * NotFound
 *
 * Renders the NotFound component.
 *
 */
const NotFound = () => {
  const navigate = useNavigate();
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-surface-tertiary p-6 text-center animate-in fade-in zoom-in-95 duration-500">
      <header className="relative">
        <div className="absolute inset-0 bg-brand-accent blur-3xl opacity-20 rounded-full"></div>
        <h1 className="relative text-[12rem] font-black text-text-primary tracking-tighter leading-none drop-shadow-sm">
          404
        </h1>
      </header>
      <h2 className="text-3xl font-extrabold text-text-primary mt-4 tracking-tight">
        Not Found
      </h2>
      <p className="text-text-secondary mt-2 max-w-md mx-auto mb-10 text-lg">
        You’ve reached an invalid page. Redirecting to login.
      </p>
      <button
        onClick={() => navigate("/")}
        className="bg-surface-secondary hover:bg-surface-primary text-white font-bold py-3 px-8 rounded-xl shadow-xl shadow-surface-dark/20 transition-all transform hover:-translate-y-1 focus:outline-none focus:ring-4 focus:ring-surface-dark/20"
      >
        Click here
      </button>
    </main>
  );
};

NotFound.displayName = "NotFound";
export default NotFound;
