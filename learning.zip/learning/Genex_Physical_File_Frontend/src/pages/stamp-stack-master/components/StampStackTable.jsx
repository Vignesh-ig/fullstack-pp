import StampStackStatusBadge from "../../../components/ui/badge/StampStackStatusBadge";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { STAMP_STACK_MASTER_TABLE_COLUMNS } from "../../../constants/tableHeaders";

/**
 * StampStackTable
 *
 * Displays a list of stamp stack master records in a table format.
 *
 * @param {Array} data - The array of stamp stack records.
 * @param {boolean} loading - Indicates if the data is currently loading.
 * @param {string} error - Any error message from fetching data.
 * @param {number} page - The current page number for index calculation.
 * @param {number} pageSize - The current page size for index calculation.
 */
const StampStackTable = ({ data, loading, error, page, pageSize }) => {
  const colSpan = STAMP_STACK_MASTER_TABLE_COLUMNS.length;

  return (
    <Table
      headers={STAMP_STACK_MASTER_TABLE_COLUMNS}
      headerColorClass="bg-table-header-bg"
    >
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow key={i} columnsCount={colSpan} />
        ))
      ) : data.length === 0 && !error ? (
        <tr>
          <td colSpan={colSpan} className="h-full">
            <EmptyState
              title="No Stamp Stack Records Found"
              description="There are currently no records available."
            />
          </td>
        </tr>
      ) : (
        data.map((stamp, index) => (
          <tr
            key={stamp.stampStackMasterId}
            className="hover:bg-slate-200/80 transition-colors cursor-pointer"
          >
            <td className="table-td">{(page - 1) * pageSize + index + 1}</td>
            <td className="table-td">{stamp.state || "—"}</td>
            <td className="table-td font-medium">
              {stamp.denominationSerialNo || "—"}
            </td>
            <td className="table-td">
              {stamp.denominationAmount ? `₹ ${stamp.denominationAmount}` : "—"}
            </td>
            <td className="table-td">{stamp.usedUserName || "—"}</td>
            <td className="table-td-center">
              <StampStackStatusBadge status={stamp.status} />
            </td>
          </tr>
        ))
      )}
    </Table>
  );
};

StampStackTable.displayName = "StampStackTable";
export default StampStackTable;
