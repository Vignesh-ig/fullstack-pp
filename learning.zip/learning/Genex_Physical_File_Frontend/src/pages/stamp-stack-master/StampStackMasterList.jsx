import { useCallback, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getStampStackMasterApi } from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import Pagination from "../../components/ui/common/Pagination";
import { ADMIN_ROLES } from "../../constants/roles";
import { DENO_STATUS_OPTIONS } from "../../constants/stampingConstants";
import { useStampOptions } from "../../hooks/dropdowns/useStampOptions";
import { useStates } from "../../hooks/dropdowns/useStates";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import { ROUTES } from "../../router/routes";
import StampStackTable from "./components/StampStackTable";

/**
 * StampStackMasterList
 *
 * Fetches and displays stamp stack master records. Supports pagination, search, and refresh.
 * Add action is available for Admin users only.
 */
const StampStackMasterList = () => {
  const navigate = useNavigate();
  const { roleName } = useSelector((state) => state.user);
  const isAdmin = ADMIN_ROLES.includes(roleName);

  const [stateFilter, setStateFilter] = useState("");
  const [denoFilter, setDenoFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");

  // Shared stamp options hook — consumes denomination options for the filter dropdown
  const { stampDenominationOptions: denominationsOptions } = useStampOptions({
    fetchTypes: false,
    fetchDenominations: true,
  });
  const { stateOptions, loading: loadingStates } = useStates();

  const fetchFn = useCallback(
    async (params) => {
      const { _dummySearchParam, ...restParams } = params; // NOSONAR
      const finalParams = {
        ...restParams,
        ...(stateFilter
          ? { state: stateFilter.toUpperCase().replace(/\s/g, "") }
          : {}),
        ...(denoFilter ? { denominationAmount: denoFilter } : {}),
        ...(statusFilter
          ? { status: statusFilter.toUpperCase().replace("-", "_") }
          : {}),
      };
      return getStampStackMasterApi(finalParams);
    },
    [stateFilter, denoFilter, statusFilter],
  );

  const {
    data: stamps,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize: handlePageSizeChange,
    refetch,
    search,
    setSearch,
  } = usePaginatedFetch(fetchFn, 10, "denominationSerialNo");

  const handleRefresh = () => {
    if (
      search === "" &&
      stateFilter === "" &&
      denoFilter === "" &&
      statusFilter === ""
    ) {
      refetch();
    } else {
      setSearch("");
      setStateFilter("");
      setDenoFilter("");
      setStatusFilter("");
    }
  };

  const handleAddClick = () => {
    navigate(ROUTES.FEATURES.MASTER.STAMP_STACK_MASTER.ADD);
  };

  return (
    <ListContainer>
      {/* Header */}
      <ListHeader
        title="Stamp Stack Master"
        unit="records"
        count={pagination.totalItems}
        loading={loading}
        search={search}
        setSearch={setSearch}
        searchPlaceholder="Search serial number"
        refetch={handleRefresh}
        onAddClick={isAdmin ? handleAddClick : undefined}
        addLabel="Add CSV"
      >
        <search className="mt-4 grid grid-cols-1 sm:flex sm:flex-row flex-wrap items-start sm:items-center gap-3 sm:gap-5 w-full">
          <FilterSelectField
            label="Filter by State:"
            name="stateFilter"
            value={stateFilter}
            onChange={(e) => setStateFilter(e.target.value)}
            placeholder={loadingStates ? "Loading states..." : "All States"}
            options={stateOptions}
            className="w-full sm:w-auto"
            showSearch={true}
            disabled={loadingStates}
          />
          <FilterSelectField
            label="Filter by Denomination:"
            name="denoFilter"
            value={denoFilter}
            onChange={(e) => setDenoFilter(e.target.value)}
            placeholder="All Denominations"
            options={denominationsOptions}
            className="w-full sm:w-auto"
          />
          <FilterSelectField
            label="Filter by Status:"
            name="statusFilter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            placeholder="All Statuses"
            options={DENO_STATUS_OPTIONS}
            className="w-full sm:w-auto"
          />
        </search>
      </ListHeader>

      {/* Error banner */}
      {error && (
        <section className="px-6 pt-4">
          <ErrorBanner message={error} onClose={() => setError(null)} />
        </section>
      )}

      {/* Table */}
      <StampStackTable
        data={stamps}
        loading={loading}
        error={error}
        page={page}
        pageSize={pageSize}
      />

      {/* Pagination */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={handlePageSizeChange}
      />
    </ListContainer>
  );
};

StampStackMasterList.displayName = "StampStackMasterList";
export default StampStackMasterList;
