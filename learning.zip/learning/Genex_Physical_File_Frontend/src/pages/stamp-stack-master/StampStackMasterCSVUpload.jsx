import { useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { uploadStampStackMasterCsvApi } from "../../api/apiConfig";
import LandscapeFormContainer from "../../components/layout/LandscapeFormContainer";
import DragDropFileUpload from "../../components/ui/common/DragDropFileUpload";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FormFooter from "../../components/ui/common/FormFooter";
import FormHeader from "../../components/ui/common/FormHeader";
import SuccessBanner from "../../components/ui/common/SuccessBanner";
import Table from "../../components/ui/common/Table";
import { getApiErrorMessage, getCssVar, isValidCSV } from "../../utils/utils";

/**
 * StampStackMasterCSVUpload
 *
 * Handles CSV upload for stamp stack master.
 * Displays upload results — stat cards (Total / Successful / Failed) and a
 * detailed validation-messages table — after the upload completes.
 */
const StampStackMasterCSVUpload = () => {
  const navigate = useNavigate();
  const userId = useSelector((state) => state.user.userId);
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [uploadResult, setUploadResult] = useState(null);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      if (!isValidCSV(selectedFile)) {
        setError("Invalid file format. Please upload a .csv file.");
        setFile(null);
      } else {
        setError(null);
        setFile(selectedFile);
        setUploadResult(null); // Reset result on new file selection
      }
    }
  };

  const handleRemoveFile = () => {
    setFile(null);
    setError(null);
    setUploadResult(null);
  };

  const handleUpload = async () => {
    if (!file) return;

    setLoading(true);
    setError(null);
    setUploadResult(null);

    try {
      const response = await uploadStampStackMasterCsvApi(file, userId);
      setUploadResult(response);
    } catch (err) {
      setError(getApiErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    navigate("..");
  };

  const resultTableHeaders = [
    { label: "Row No" },
    { label: "Denomination Serial No" },
    { label: "Error Message" },
  ];

  // Extract summary counts from the API response
  const resultData = uploadResult?.data ?? {};
  const totalRecords = resultData.totalRecords ?? 0;
  const successfulRecords = resultData.successfulRecords ?? 0;
  const failedRecords = resultData.failedRecords ?? 0;
  const validationMessages = resultData.validationMessages ?? [];

  // Resolve accent colors once from CSS variables — same pattern as DashboardPage
  const csvColors = useMemo(
    () => ({
      total: getCssVar("--color-csv-total"),
      success: getCssVar("--color-csv-success"),
      failed: getCssVar("--color-csv-failed"),
    }),
    [],
  );

  /** Stat cards config for the result view */
  const statCards = [
    {
      label: "Total Records",
      value: totalRecords,
      accentColor: csvColors.total,
      valueClass: "csv-stat-value-total",
    },
    {
      label: "Successful Records",
      value: successfulRecords,
      accentColor: csvColors.success,
      valueClass: "csv-stat-value-success",
    },
    {
      label: "Failed Records",
      value: failedRecords,
      accentColor: csvColors.failed,
      valueClass: "csv-stat-value-failed",
    },
  ];

  return (
    <LandscapeFormContainer className="mb-4">
      <FormHeader title="Add Stamp Stack CSV" onBack={handleCancel} />

      <div className="flex-1 overflow-y-auto pt-2 space-y-6">
        {error && (
          <ErrorBanner message={error} onClose={() => setError(null)} />
        )}

        {!uploadResult && (
          <DragDropFileUpload
            id="csv-upload"
            label="Select CSV file"
            hint="CSV files up to 10MB"
            accept=".csv"
            onChange={handleFileChange}
            onRemove={handleRemoveFile}
            file={file}
          />
        )}

        {uploadResult && (
          <div className="space-y-6">
            {/* Success banner */}
            <SuccessBanner
              message={uploadResult.message || "File processed successfully"}
            />

            {/* Stat cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {statCards.map(({ label, value, accentColor, valueClass }) => (
                <div
                  key={label}
                  className="csv-stat-card"
                  style={{ borderLeft: `4px solid ${accentColor}` }}
                >
                  <span className="csv-stat-label">{label}</span>
                  <span className={`csv-stat-value ${valueClass}`}>
                    {value}
                  </span>
                </div>
              ))}
            </div>

            {/* Validation-messages table (failed records) */}
            {validationMessages.length > 0 && (
              <div className="bg-white border border-border-main shadow-sm rounded-xl overflow-hidden flex flex-col">
                <div className="px-6 py-4 border-b border-border-main bg-surface-tertiary">
                  <h3 className="text-base font-semibold text-text-primary">
                    Failed Records
                  </h3>
                  <p className="text-xs text-text-secondary mt-0.5">
                    The following records could not be inserted due to errors.
                  </p>
                </div>
                <Table
                  headers={resultTableHeaders}
                  headerColorClass="bg-table-header-bg"
                >
                  {validationMessages.map((row, idx) => (
                    <tr
                      key={idx}
                      className="hover:bg-slate-200/80 transition-colors"
                    >
                      <td className="table-td-middle py-2.5">
                        {row.csvRowNo || "—"}
                      </td>
                      <td className="table-td-middle font-medium">
                        {row.denominationSerialNo || "—"}
                      </td>
                      <td className="table-td-middle text-status-error">
                        {row.csvRowMessage ||
                          row.csvColumnMessage ||
                          "Unknown error"}
                      </td>
                    </tr>
                  ))}
                </Table>
              </div>
            )}
          </div>
        )}
      </div>

      <FormFooter
        buttons={[
          uploadResult
            ? {
                label: "Back to List",
                props: {
                  onClick: handleCancel,
                },
              }
            : {
                label: loading ? "Uploading…" : "Upload File",
                props: {
                  onClick: handleUpload,
                  disabled: !file || loading,
                },
              },
        ]}
      />
    </LandscapeFormContainer>
  );
};

StampStackMasterCSVUpload.displayName = "StampStackMasterCSVUpload";
export default StampStackMasterCSVUpload;
