import { useSelector } from "react-redux";
import { Navigate, Route, Routes } from "react-router-dom";
import { ADMIN_ROLES } from "../../constants/roles";
import { ROUTES } from "../../router/routes";
import StampStackMasterCSVUpload from "./StampStackMasterCSVUpload";
import StampStackMasterList from "./StampStackMasterList";

/**
 * StampStackMaster
 *
 * Renders the StampStackMaster component with nested routes.
 *
 */
const StampStackMaster = () => {
  const { roleName } = useSelector((state) => state.user);
  const isAdmin = ADMIN_ROLES.includes(roleName);

  return (
    <Routes>
      <Route path="/" element={<StampStackMasterList />} />
      <Route
        path={ROUTES.FEATURES.MASTER.STAMP_STACK_MASTER.ADD}
        element={
          isAdmin ? <StampStackMasterCSVUpload /> : <Navigate to="." replace />
        }
      />
    </Routes>
  );
};

StampStackMaster.displayName = "StampStackMaster";
export default StampStackMaster;
