import { useSelector } from "react-redux";
import { Navigate, Route, Routes } from "react-router-dom";
import { ADMIN_ROLES } from "../../constants/roles";
import { ROUTES } from "../../router/routes";
import StampMasterForm from "./StampMasterForm";
import StampMasterList from "./StampMasterList";

/**
 * StampMaster
 *
 * Renders the StampMaster component.
 * Add and Edit routes are guarded to Admin users only, matching the UserAllocation pattern.
 *
 */
const StampMaster = () => {
  const { roleName } = useSelector((state) => state.user);
  const isAdmin = ADMIN_ROLES.includes(roleName);

  return (
    <Routes>
      <Route path="/" element={<StampMasterList />} />
      <Route
        path={ROUTES.FEATURES.MASTER.STAMP_MASTER.ADD}
        element={
          isAdmin ? <StampMasterForm mode="add" /> : <Navigate to="." replace />
        }
      />
      <Route
        path={ROUTES.FEATURES.MASTER.STAMP_MASTER.EDIT}
        element={
          isAdmin ? (
            <StampMasterForm mode="edit" />
          ) : (
            <Navigate to="." replace />
          )
        }
      />
    </Routes>
  );
};

StampMaster.displayName = "StampMaster";
export default StampMaster;
