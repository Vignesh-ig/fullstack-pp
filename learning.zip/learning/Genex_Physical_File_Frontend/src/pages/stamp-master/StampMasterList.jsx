import { useCallback, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getStampMasterApi } from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import Pagination from "../../components/ui/common/Pagination";
import { ADMIN_ROLES } from "../../constants/roles";
import { useStampOptions } from "../../hooks/dropdowns/useStampOptions";
import { useStates } from "../../hooks/dropdowns/useStates";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import { ROUTES } from "../../router/routes";
import StampTable from "./components/StampTable";

/**
 * StampMasterList
 *
 * Fetches and displays stamp master records. Supports pagination, search, and refresh.
 * Add and Edit actions are available for Admin users only (same pattern as UserAllocationList).
 *
 */
const StampMasterList = () => {
  const navigate = useNavigate();
  const { roleName } = useSelector((state) => state.user);
  const isAdmin = ADMIN_ROLES.includes(roleName);
  const { stateOptions, loading: loadingStates } = useStates();
  const {
    stampTypeOptions,
    rawTypes,
    loading: loadingStampTypes,
  } = useStampOptions({
    fetchDenominations: false,
  });

  const [stateFilter, setStateFilter] = useState("");
  const [stampTypeFilter, setStampTypeFilter] = useState("");

  const fetchFn = useCallback(
    async (params) => {
      const { _dummySearchParam, ...restParams } = params; // NOSONAR

      const selectedTypeUUID = stampTypeFilter
        ? rawTypes?.find((t) => t.stampTypeName === stampTypeFilter)
            ?.stampTypeId
        : undefined;

      const finalParams = {
        ...restParams,
        ...(stateFilter ? { state: stateFilter.toUpperCase() } : {}),
        ...(selectedTypeUUID ? { stampType: selectedTypeUUID } : {}),
      };
      return getStampMasterApi(finalParams);
    },
    [stateFilter, stampTypeFilter, rawTypes],
  );

  const {
    data: stamps,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize: handlePageSizeChange,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "");

  const handleRefresh = () => {
    if (stateFilter === "" && stampTypeFilter === "") {
      refetch();
    } else {
      setStateFilter("");
      setStampTypeFilter("");
    }
  };

  const handleAddClick = () => {
    navigate(ROUTES.FEATURES.MASTER.STAMP_MASTER.ADD);
  };

  return (
    <ListContainer>
      {/* Header */}
      <ListHeader
        title="Stamp Master"
        unit="stamps"
        count={pagination.totalItems}
        loading={loading}
        refetch={handleRefresh}
        onAddClick={isAdmin ? handleAddClick : undefined}
        addLabel="Add Stamp"
      >
        <search className="mt-4 grid grid-cols-1 sm:flex sm:flex-row items-start sm:items-center gap-3 sm:gap-5 w-full border-t border-border-subtle pt-4">
          <FilterSelectField
            label="Filter by State:"
            name="stateFilter"
            value={stateFilter}
            onChange={(e) => setStateFilter(e.target.value)}
            placeholder={loadingStates ? "Loading states..." : "All States"}
            options={stateOptions}
            className="w-full sm:w-auto"
            showSearch={true}
            disabled={loadingStates}
          />
          <FilterSelectField
            label="Filter by Stamp Type:"
            name="stampTypeFilter"
            value={stampTypeFilter}
            onChange={(e) => setStampTypeFilter(e.target.value)}
            placeholder={loadingStampTypes ? "Loading types..." : "All Types"}
            options={stampTypeOptions}
            className="w-full sm:w-auto"
            showSearch={true}
            disabled={loadingStampTypes}
          />
        </search>
      </ListHeader>

      {/* Error banner */}
      {error && (
        <section className="px-6 pt-4">
          <ErrorBanner message={error} onClose={() => setError(null)} />
        </section>
      )}

      {/* Table */}
      <StampTable
        data={stamps}
        loading={loading}
        error={error}
        page={page}
        pageSize={pageSize}
      />

      {/* Pagination */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={handlePageSizeChange}
      />
    </ListContainer>
  );
};

StampMasterList.displayName = "StampMasterList";
export default StampMasterList;
