import { zodResolver } from "@hookform/resolvers/zod";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import {
  createStampMasterApi,
  getStampMasterApi,
  updateStampMasterApi,
} from "../../api/apiConfig";
import PortraitFormContainer from "../../components/layout/PortraitFormContainer";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FormFooter from "../../components/ui/common/FormFooter";
import FormHeader from "../../components/ui/common/FormHeader";
import SuccessBanner from "../../components/ui/common/SuccessBanner";
import { STAMP_TYPE } from "../../constants/stampingConstants";
import { STATUS } from "../../constants/status";
import { useStampOptions } from "../../hooks/dropdowns/useStampOptions";
import { useApi } from "../../hooks/useApi";
import { stampMasterSchema } from "../../utils/schemas/configSchema";
import StampMasterFormFields from "./components/StampMasterFormFields";

/**
 * StampMasterForm
 *
 * Full-page form for creating and editing stamp master records.
 *
 * @param {"add" | "edit"} props.mode - Controls field visibility & submit behaviour.
 * @param {object} props.defaultValues - Pre-filled stamp data.
 */
const StampMasterForm = ({ mode = "add", defaultValues = {} }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { id } = useParams();
  const { userId: currentUserId } = useSelector((state) => state.user);

  const isEdit = mode === "edit";
  const locationStamp = location.state?.stamp;
  const [fetchedStamp, setFetchedStamp] = useState(null);

  // Fetch current stamp details by ID on edit mode or page refresh
  useEffect(() => {
    if (isEdit && id) {
      getStampMasterApi({ stampMasterId: id })
        .then((res) => {
          const rawItem = Array.isArray(res?.data?.data)
            ? res.data.data[0]
            : (res?.data?.data ??
              (Array.isArray(res?.data) ? res.data[0] : res?.data));
          if (rawItem) {
            setFetchedStamp(rawItem);
          }
        })
        .catch((err) => {
          console.error("Failed to fetch stamp master detail:", err);
        });
    }
  }, [isEdit, id]);

  const activeStamp = fetchedStamp || locationStamp || defaultValues;

  // The API expects an array of stamps for both create and update operations.
  const apiFunction = useCallback(
    (payload) =>
      isEdit ? updateStampMasterApi(payload) : createStampMasterApi(payload),
    [isEdit],
  );

  const {
    execute: submitStamp,
    isLoading: isSubmittingAPI,
    error: submitError,
    setError: setSubmitError,
    isSuccess: submitSuccess,
  } = useApi(apiFunction);

  const resolvedDefaultValues = useMemo(() => {
    // GET response fields: stampDenominationNo (number), stampTypeName (string)
    const denomNo = activeStamp?.stampDenominationNo
      ? String(activeStamp.stampDenominationNo)
      : "";
    const type = activeStamp?.stampTypeName ?? "";

    // Variable type: the multi-select form expects an array
    const denom = type === STAMP_TYPE.VARIABLE && denomNo ? [denomNo] : denomNo;

    return {
      stampMasterId: activeStamp?.stampMasterId ?? id,
      state: activeStamp?.state ?? "",
      stampType: type,
      stampDenomination: denom,
      isActive: activeStamp?.status === STATUS.INACTIVE ? false : true,
    };
  }, [activeStamp, id]);

  const {
    register,
    handleSubmit,
    control,
    watch,
    setValue,
    clearErrors,
    trigger,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: zodResolver(stampMasterSchema),
    defaultValues: resolvedDefaultValues,
    mode: "onTouched",
  });

  // Sync form values when fetchedStamp updates from API (e.g. on page refresh)
  useEffect(() => {
    if (activeStamp && isEdit) {
      const denomNo = activeStamp?.stampDenominationNo
        ? String(activeStamp.stampDenominationNo)
        : "";
      const type = activeStamp?.stampTypeName ?? "";
      const denom =
        type === STAMP_TYPE.VARIABLE && denomNo ? [denomNo] : denomNo;

      setValue("stampMasterId", activeStamp?.stampMasterId ?? id);
      setValue("state", activeStamp?.state ?? "");
      setValue("stampType", type);
      setValue("stampDenomination", denom);
      setValue(
        "isActive",
        activeStamp?.status === STATUS.INACTIVE ? false : true,
      );
    }
  }, [activeStamp, isEdit, id, setValue]);

  const selectedStampType = watch("stampType");
  const shouldFetchDenominations =
    selectedStampType === STAMP_TYPE.FIXED ||
    selectedStampType === STAMP_TYPE.VARIABLE;

  const { stampTypeOptions, stampDenominationOptions, rawTypes, rawDenos } =
    useStampOptions({
      fetchTypes: true,
      fetchDenominations: shouldFetchDenominations,
    });

  const onSubmit = async (data) => {
    setSubmitError(null);

    const selectedTypeRaw = rawTypes.find(
      (t) => t.stampTypeName === data.stampType,
    );
    const resolvedStampTypeMasterId = selectedTypeRaw
      ? selectedTypeRaw.stampTypeId
      : data.stampType;

    const basePayload = {
      state: data.state?.toUpperCase(),
      stampTypeMasterId: resolvedStampTypeMasterId,
      ...(isEdit && {
        status: data.isActive
          ? STATUS.ACTIVE.toUpperCase()
          : STATUS.INACTIVE.toUpperCase(),
      }),
    };

    if (isEdit) {
      basePayload.stampTypeMasterId = data.stampMasterId;
      basePayload.modifiedBy = currentUserId;
    } else {
      basePayload.createdBy = currentUserId;
    }

    let payloads;

    if (
      data.stampType === STAMP_TYPE.NO_STAMPING ||
      data.stampType === STAMP_TYPE.E_STAMPING
    ) {
      // No denomination needed for these types — send without stampDenominationMasterId
      payloads = [{ ...basePayload }];
    } else if (data.stampType === STAMP_TYPE.VARIABLE) {
      // Variable → one payload entry per selected denomination
      const denoms = Array.isArray(data.stampDenomination)
        ? data.stampDenomination
        : [data.stampDenomination].filter(Boolean);

      payloads = denoms.map((d) => {
        const dStr = String(d);
        const selectedDenoRaw = rawDenos.find(
          (rd) => String(rd.stampDenominationNo) === dStr,
        );
        return {
          ...basePayload,
          // Resolve denomination number → stampDenominationMasterId (UUID)
          stampDenominationMasterId: selectedDenoRaw
            ? selectedDenoRaw.stampDenominationId
            : dStr,
        };
      });
    } else {
      // Fixed type
      let mappedDenoId = String(data.stampDenomination || "");
      if (mappedDenoId) {
        const selectedDenoRaw = rawDenos.find(
          (rd) => String(rd.stampDenominationNo) === mappedDenoId,
        );
        if (selectedDenoRaw) mappedDenoId = selectedDenoRaw.stampDenominationId;
      }
      payloads = [{ ...basePayload, stampDenominationMasterId: mappedDenoId }];
    }

    const { error: apiError } = await submitStamp(payloads);
    if (!apiError) {
      setTimeout(() => {
        navigate("..", { state: { savedSuccess: true } });
      }, 1000);
    }
  };

  const handleBack = () => {
    navigate("..", { state: { exitWithoutSave: true } });
  };

  const isLoading = isSubmitting || isSubmittingAPI;

  return (
    <PortraitFormContainer>
      {/* Header with working back button — matches UserAllocationForm pattern */}
      <FormHeader
        title={isEdit ? "Edit Stamp" : "Add Stamp"}
        onBack={handleBack}
      />

      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <div className="space-y-2 py-2">
          {submitSuccess && (
            <SuccessBanner
              message={
                isEdit
                  ? "Stamp updated successfully"
                  : "Stamp created successfully"
              }
            />
          )}

          {submitError && (
            <ErrorBanner
              message={submitError || "Failed to process stamp"}
              onClose={() => setSubmitError(null)}
            />
          )}

          <StampMasterFormFields
            register={register}
            errors={errors}
            control={control}
            watch={watch}
            setValue={setValue}
            clearErrors={clearErrors}
            trigger={trigger}
            isEdit={isEdit}
            stampTypeOptions={stampTypeOptions}
            stampDenominationOptions={stampDenominationOptions}
          />
        </div>

        {/* Footer with save button — uses buttons[] array API matching UserAllocationForm */}
        <FormFooter
          buttons={[
            {
              label: isLoading
                ? isEdit
                  ? "Saving..."
                  : "Creating..."
                : isEdit
                  ? "Save Changes"
                  : "Save Stamp",
              props: {
                type: "submit",
                disabled: isLoading || submitSuccess,
              },
            },
          ]}
        />
      </form>
    </PortraitFormContainer>
  );
};

StampMasterForm.displayName = "StampMasterForm";
export default StampMasterForm;
