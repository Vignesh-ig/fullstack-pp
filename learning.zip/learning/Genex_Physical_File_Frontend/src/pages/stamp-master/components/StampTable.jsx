import {
  StampTypeBadge,
  StatusBadge,
} from "../../../components/ui/badge/badgeIndex";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { STAMP_MASTER_TABLE_COLUMNS } from "../../../constants/tableHeaders";
import { toTitleCase } from "../../../utils/utils";

/**
 * StampTable
 *
 * Renders the paginated list of stamp master records inside a scrollable Table.
 * Shows a skeleton loader while fetching and an EmptyState when no records exist.
 *
 * @param {Array}    data      - Array of stamp records from the API.
 * @param {boolean}  loading   - True while records are being fetched.
 * @param {string}   error     - Error message if the fetch failed; suppresses EmptyState.
 * @param {number}   page      - Current page number (1-based) used to compute S.No.
 * @param {number}   pageSize  - Number of records per page used to compute S.No.
 */
const StampTable = ({
  data = [],
  loading = false,
  error,
  page = 1,
  pageSize = 10,
}) => {
  const colSpan = STAMP_MASTER_TABLE_COLUMNS.length;

  return (
    <Table
      headers={STAMP_MASTER_TABLE_COLUMNS}
      headerColorClass="bg-table-header-bg"
    >
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow key={i} columnsCount={colSpan} />
        ))
      ) : data.length === 0 && !error ? (
        <tr>
          <td colSpan={colSpan} className="h-full">
            <EmptyState
              title="No stamps found"
              description="No stamp records found."
            />
          </td>
        </tr>
      ) : (
        data.map((stamp, index) => (
          <tr
            key={`${stamp.stampMasterId}-${index}`}
            className="hover:bg-slate-200/80 transition-colors cursor-pointer"
          >
            <td className="table-td-middle-cpu">
              {(page - 1) * pageSize + index + 1}
            </td>
            <td className="table-td-middle-cpu">
              {stamp.state ? toTitleCase(stamp.state) : "—"}
            </td>
            <td className="table-td-center">
              <StampTypeBadge stampType={stamp.stampTypeName} />
            </td>
            <td className="table-td-middle-cpu">
              {stamp.stampDenominationNo
                ? `₹ ${stamp.stampDenominationNo}`
                : "—"}
            </td>
            <td className="table-td-center">
              <StatusBadge isActive={stamp.status} />
            </td>
          </tr>
        ))
      )}
    </Table>
  );
};

StampTable.displayName = "StampTable";
export default StampTable;
