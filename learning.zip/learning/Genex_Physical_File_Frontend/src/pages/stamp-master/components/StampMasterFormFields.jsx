import SelectField from "../../../components/ui/common/SelectField";
import SelectFieldWithCheckbox from "../../../components/ui/common/SelectFieldWithCheckbox";
import StatusToggle from "../../../components/ui/common/StatusToggle";
import { STAMP_TYPE } from "../../../constants/stampingConstants";
import { useStates } from "../../../hooks/dropdowns/useStates";

/**
 * StampMasterFormFields
 *
 * Renders the input fields for the stamp master form.
 *
 * @param {object}   errors      - react-hook-form errors object.
 * @param {Function} watch       - react-hook-form watch function.
 * @param {Function} setValue    - react-hook-form setValue function.
 * @param {Function} clearErrors - react-hook-form clearErrors function.
 * @param {boolean}  isEdit      - Whether the form is in edit mode; controls status toggle behaviour.
 * @param {Array}    stampTypeOptions - Options array for stamp types.
 * @param {Array}    stampDenominationOptions - Options array for stamp denominations.
 */
const StampMasterFormFields = ({
  errors,
  watch,
  setValue,
  clearErrors,
  trigger,
  isEdit = false,
  stampTypeOptions = [],
  stampDenominationOptions = [],
}) => {
  const { stateOptions, loading: loadingStates } = useStates();

  const state = watch("state");
  const stampType = watch("stampType");
  const stampDenomination = watch("stampDenomination");
  const isActive = watch("isActive");

  const showDenomination =
    stampType === STAMP_TYPE.FIXED || stampType === STAMP_TYPE.VARIABLE;

  const handleStampTypeChange = (e) => {
    const newType = e.target.value;
    setValue("stampType", newType, { shouldValidate: true });

    // Reset denomination whenever stamp type changes
    setValue("stampDenomination", newType === STAMP_TYPE.VARIABLE ? [] : "", {
      shouldValidate: false,
    });
    clearErrors("stampDenomination");
  };

  return (
    <fieldset className="grid grid-cols-1">
      {/* State — single select, required */}
      <SelectField
        label="State"
        name="state"
        value={state}
        onChange={(e) =>
          setValue("state", e.target.value, { shouldValidate: true })
        }
        onBlur={() => trigger("state")}
        options={stateOptions}
        placeholder={loadingStates ? "Loading states..." : "Select state"}
        error={errors.state?.message}
        required
        disabled={loadingStates}
      />

      {/* Stamp Type — shown by default */}
      <SelectField
        label="Stamp Type"
        name="stampType"
        value={stampType}
        onChange={handleStampTypeChange}
        onBlur={() => trigger("stampType")}
        options={stampTypeOptions}
        placeholder="Select stamp type"
        error={errors.stampType?.message}
        required
      />

      {/* Stamp Denomination
          - Fixed    → single select (required)
          - Variable → multi-select with checkboxes (required)
          - No Stamping / E-Stamping → field completely hidden (not required)
      */}
      {showDenomination &&
        (stampType === STAMP_TYPE.VARIABLE ? (
          <SelectFieldWithCheckbox
            label="Stamp Denomination"
            name="stampDenomination"
            value={Array.isArray(stampDenomination) ? stampDenomination : []}
            onChange={(e) =>
              // SelectFieldWithCheckbox emits { target: { name, value: string[] } }
              setValue("stampDenomination", e.target.value, {
                shouldValidate: true,
              })
            }
            onBlur={() => trigger("stampDenomination")}
            options={stampDenominationOptions}
            placeholder="Select denominations"
            error={errors.stampDenomination?.message}
            required
            showSearch={false}
          />
        ) : (
          <SelectField
            label="Stamp Denomination"
            name="stampDenomination"
            value={stampDenomination || ""}
            onChange={(e) =>
              setValue("stampDenomination", e.target.value, {
                shouldValidate: true,
              })
            }
            onBlur={() => trigger("stampDenomination")}
            options={stampDenominationOptions}
            placeholder="Select denomination"
            error={errors.stampDenomination?.message}
            required
          />
        ))}

      {/* Status Toggle
          - Add mode : disabled toggle + "Active by default" note
          - Edit mode: interactive toggle */}
      <StatusToggle
        label="Status"
        isActive={isActive}
        disabled={!isEdit}
        isEdit={isEdit}
        onChange={() =>
          isEdit && setValue("isActive", !isActive, { shouldValidate: true })
        }
      />
    </fieldset>
  );
};

StampMasterFormFields.displayName = "StampMasterFormFields";
export default StampMasterFormFields;
