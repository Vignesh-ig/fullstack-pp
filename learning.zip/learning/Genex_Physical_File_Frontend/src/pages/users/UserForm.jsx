import { zodResolver } from "@hookform/resolvers/zod";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import {
  createUserApi,
  getGenexUsersApi,
  getUsersApi,
  updateUserApi,
} from "../../api/apiConfig";
import PortraitFormContainer from "../../components/layout/PortraitFormContainer";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FormFooter from "../../components/ui/common/FormFooter";
import FormHeader from "../../components/ui/common/FormHeader";
import SuccessBanner from "../../components/ui/common/SuccessBanner";
import { ROLES } from "../../constants/roles";
import { useBranchHierarchy } from "../../hooks/dropdowns/useBranchHierarchy";
import { useApi } from "../../hooks/useApi";
import { fetchRoles } from "../../redux/slice/rolesSlice";
import { userFormSchema } from "../../utils/schemas/configSchema";
import UserFormFields from "./components/UserFormFields";

/**
 * UserForm
 *
 * Shared form used for both Add User and Edit User.
 *
 * @param {"add" | "edit"} props.mode - Controls field visibility & submit behaviour.
 * @param {object} props.defaultValues - Pre-filled user data when mode === "edit".
 */
const UserForm = ({ mode = "add", defaultValues = {} }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const { id } = useParams();
  const { userId: currentUserId } = useSelector((state) => state.user);
  const {
    roles,
    loading: rolesLoading,
    error: rolesError,
  } = useSelector((state) => state.roles);

  const isEdit = mode === "edit";

  const apiFunction = useCallback(
    (payload) => (isEdit ? updateUserApi(payload) : createUserApi(payload)),
    [isEdit],
  );

  const {
    execute: submitUser,
    isLoading: isSubmittingAPI,
    error: submitError,
    setError: setSubmitError,
    isSuccess: submitSuccess,
  } = useApi(apiFunction);

  const {
    execute: fetchGenexUsers,
    data: genexUsersRes,
    isLoading: genexUsersLoading,
  } = useApi(getGenexUsersApi);

  useEffect(() => {
    if (!isEdit) {
      fetchGenexUsers();
    }
  }, [isEdit, fetchGenexUsers]);

  const genexUserOptions = useMemo(() => {
    if (!genexUsersRes?.data) return [];
    return genexUsersRes.data.map((user) => ({
      value: user.employeeCode,
      label: `${user.employeeName} (${user.employeeCode})`,
      sublabel: user.emailId,
      data: user,
    }));
  }, [genexUsersRes]);

  const [selectedGenexUser, setSelectedGenexUser] = useState("");

  const locationUser = location.state?.user;
  const [fetchedUser, setFetchedUser] = useState(null);

  // Fetch user details by ID on edit mode or page refresh
  useEffect(() => {
    if (isEdit && id) {
      getUsersApi({ userId: id })
        .then((res) => {
          const rawItem = Array.isArray(res?.data?.data)
            ? res.data.data[0]
            : (res?.data?.data ??
              (Array.isArray(res?.data) ? res.data[0] : res?.data));
          if (rawItem) {
            setFetchedUser(rawItem);
          }
        })
        .catch((err) => {
          console.error("Failed to fetch user detail:", err);
        });
    }
  }, [isEdit, id]);

  const activeUser = fetchedUser || locationUser;

  const resolvedDefaultValues = useMemo(
    () =>
      isEdit
        ? {
            userId: defaultValues?.userId ?? activeUser?.userId ?? id,
            userName: defaultValues?.userName ?? activeUser?.userName ?? "",
            userEmail: defaultValues?.userEmail ?? activeUser?.userEmail ?? "",
            userEmployeeCode:
              defaultValues?.userEmployeeCode ??
              activeUser?.userEmployeeCode ??
              "",
            roleId:
              defaultValues?.roleId ??
              activeUser?.roleId ??
              activeUser?.roleDto?.roleId ??
              "",
            isActive: defaultValues?.isActive ?? activeUser?.isActive ?? true,
            branchIds:
              defaultValues?.branchIds ??
              (activeUser?.branchDtos ?? [])
                .filter(Boolean)
                .map((b) => b.branchId),
            branchDtos:
              defaultValues?.branchDtos ??
              (activeUser?.branchDtos ?? []).filter(Boolean),
          }
        : {},
    [defaultValues, id, isEdit, activeUser],
  );

  const formDefaultValues = useMemo(
    () => ({
      mode,
      userName: resolvedDefaultValues?.userName ?? "",
      userEmail: resolvedDefaultValues?.userEmail ?? "",
      userEmployeeCode: resolvedDefaultValues?.userEmployeeCode ?? "",
      roleId: resolvedDefaultValues?.roleId ?? "",
      isActive: resolvedDefaultValues?.isActive ?? true,
      // Branch hierarchy fields — synced into the form so the schema's
      // superRefine can validate them when the role is BRANCH_USER.
      isBranchUser: false,
      selectedZone: "",
      selectedRegion: "",
      selectedArea: "",
      branchIds: resolvedDefaultValues?.branchIds ?? [],
    }),
    [mode, resolvedDefaultValues],
  );

  // Fetch roles on mount
  useEffect(() => {
    if (!rolesLoading && roles.length === 0 && !rolesError) {
      dispatch(fetchRoles());
    }
  }, [dispatch, roles.length, rolesLoading, rolesError]);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    trigger,
    formState: { errors, isValid },
  } = useForm({
    resolver: zodResolver(userFormSchema),
    mode: "onTouched",
    defaultValues: formDefaultValues,
  });

  // Sync form values when fetchedUser updates from API (e.g. on page refresh)
  useEffect(() => {
    if (activeUser && isEdit) {
      const bIds = (activeUser?.branchDtos ?? [])
        .filter(Boolean)
        .map((b) => b.branchId);
      const rId = activeUser?.roleId ?? activeUser?.roleDto?.roleId ?? "";
      setValue("userName", activeUser?.userName ?? "");
      setValue("userEmail", activeUser?.userEmail ?? "");
      setValue("userEmployeeCode", activeUser?.userEmployeeCode ?? "");
      setValue("roleId", rId);
      setValue("isActive", activeUser?.isActive ?? true);
      setValue("branchIds", bIds);
      setSelectedBranches(bIds);
    }
  }, [activeUser, isEdit, setValue]);

  const isActive = watch("isActive");
  const roleId = watch("roleId");

  // Role options for SelectField — memoized to prevent a new array reference
  // on every render, which would cause isBranchUserSelected to re-evaluate
  // continuously and trigger the reset effect unexpectedly.
  const roleOptions = useMemo(
    () =>
      roles.map((r) => ({
        value: r.roleId,
        label: r.roleName.replace(/_/g, " "),
        roleName: r.roleName,
      })),
    [roles],
  );

  // Determine if the selected role is BRANCH_USER.
  // We check the labels because the backend role names might have spaces or underscores.
  const isBranchUserSelected = useMemo(() => {
    const activeLabel =
      roleOptions.find((o) => o.value === roleId)?.label ?? "";
    if (activeLabel) {
      return activeLabel.replace(/\s+/g, "_").toUpperCase() === ROLES.BRANCH;
    }
    // Fallback while roles are loading: check the role name from the initial user data.
    if (rolesLoading && isEdit) {
      const initialRoleName =
        locationUser?.roleDto?.roleName ?? locationUser?.roleName ?? "";
      return (
        initialRoleName.replace(/\s+/g, "_").toUpperCase() === ROLES.BRANCH
      );
    }
    return false;
  }, [roleOptions, roleId, rolesLoading, isEdit, locationUser]);

  // Branch hierarchy: Zone → Region → Area → Branch
  const [selectedBranches, setSelectedBranches] = useState(
    resolvedDefaultValues.branchIds ?? [],
  );

  // Track whether isBranchUserSelected was true on the *previous* render so we
  // only wipe the branch selection when the role genuinely transitions away
  // from BRANCH_USER (true → false), not on the initial mount where roles are
  // still loading and isBranchUserSelected starts as false.
  const wasBranchUserRef = useRef(false);
  // Pre-built option objects for the already-selected branches so that
  // SelectFieldWithCheckbox / useMultiSelect can seed its label cache
  // immediately on first render (edit mode). The API returns branchId + branchName.
  const initialSelectedBranchOptions = useMemo(() => {
    const dtos = resolvedDefaultValues.branchDtos ?? [];
    return dtos
      .filter(Boolean)
      .map((b) => ({ value: b.branchId, label: b.branchName }));
  }, [resolvedDefaultValues.branchDtos]);

  const {
    zoneOptions,
    zoneLoading,
    zoneError,
    selectedZone,
    handleZoneChange,
    regionOptions,
    regionLoading,
    selectedRegion,
    handleRegionChange,
    areaOptions,
    areaLoading,
    selectedArea,
    handleAreaChange,
    branchOptions,
    branchLoading,
    branchError,
    resetHierarchy,
  } = useBranchHierarchy(isBranchUserSelected);

  // Reset hierarchy + branch selection ONLY when the role genuinely transitions
  // away from BRANCH_USER (true → false). Guarding with wasBranchUserRef
  // prevents wiping the pre-seeded branch IDs during the initial render cycle
  // when roles haven't loaded yet (isBranchUserSelected === false from the
  // start, not because the user changed the role).
  useEffect(() => {
    if (wasBranchUserRef.current && !isBranchUserSelected) {
      resetHierarchy();
      setSelectedBranches([]);
    }
    wasBranchUserRef.current = isBranchUserSelected;
  }, [isBranchUserSelected, resetHierarchy]);

  // ── Sync hierarchy state into react-hook-form so superRefine can validate ──
  useEffect(() => {
    setValue("isBranchUser", isBranchUserSelected, { shouldValidate: false });
  }, [isBranchUserSelected, setValue]);

  useEffect(() => {
    setValue("selectedZone", selectedZone, { shouldValidate: false });
  }, [selectedZone, setValue]);

  useEffect(() => {
    setValue("selectedRegion", selectedRegion, { shouldValidate: false });
  }, [selectedRegion, setValue]);

  useEffect(() => {
    setValue("selectedArea", selectedArea, { shouldValidate: false });
  }, [selectedArea, setValue]);

  useEffect(() => {
    setValue("branchIds", selectedBranches, { shouldValidate: false });
  }, [selectedBranches, setValue]);

  const onSubmit = useCallback(
    async (data) => {
      if (isSubmittingAPI) return;

      const payload = {
        userName: data.userName?.trim() || null,
        userEmail: data.userEmail?.trim() || null,
        userEmployeeCode: data.userEmployeeCode?.trim() || null,
        roleId: data.roleId,
        isActive: data.isActive,
        branchIds: isBranchUserSelected ? selectedBranches : [],
      };

      if (isEdit) {
        payload.userId = resolvedDefaultValues.userId;
        payload.modifiedBy = currentUserId;
      } else {
        payload.createdBy = currentUserId;
      }

      const { error } = await submitUser(payload);
      if (!error) {
        setTimeout(() => navigate(".."), 1000);
      }
    },
    [
      currentUserId,
      isBranchUserSelected,
      isEdit,
      navigate,
      resolvedDefaultValues.userId,
      selectedBranches,
      isSubmittingAPI,
      submitUser,
    ],
  );

  return (
    <PortraitFormContainer maxWidth="max-w-3xl">
      <FormHeader
        title={isEdit ? "Edit User" : "Add New User"}
        onBack={() => navigate("..")}
      />

      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <input type="hidden" {...register("mode")} />
        <ErrorBanner
          message={submitError ?? zoneError}
          onClose={() => setSubmitError(null)}
        />

        <SuccessBanner
          message={
            submitSuccess
              ? `User ${isEdit ? "updated" : "created"} successfully!!!`
              : null
          }
        />

        <UserFormFields
          register={register}
          errors={errors}
          setValue={setValue}
          roleId={roleId}
          isActive={isActive}
          rolesLoading={rolesLoading}
          roleOptions={roleOptions}
          isEdit={isEdit}
          // Zone → Region → Area → Branch hierarchy
          zoneOptions={zoneOptions}
          zoneLoading={zoneLoading}
          selectedZone={selectedZone}
          onZoneChange={handleZoneChange}
          regionOptions={regionOptions}
          regionLoading={regionLoading}
          selectedRegion={selectedRegion}
          onRegionChange={handleRegionChange}
          areaOptions={areaOptions}
          areaLoading={areaLoading}
          selectedArea={selectedArea}
          onAreaChange={handleAreaChange}
          branchOptions={branchOptions}
          selectedBranches={selectedBranches}
          initialSelectedBranchOptions={initialSelectedBranchOptions}
          onBranchChange={setSelectedBranches}
          branchLoading={branchLoading}
          branchError={branchError}
          // Validation errors for the hierarchy fields
          zoneValidationError={errors.selectedZone?.message}
          regionValidationError={errors.selectedRegion?.message}
          areaValidationError={errors.selectedArea?.message}
          branchIdsError={errors.branchIds?.message}
          triggerValidation={trigger}
          // Genex user
          genexUserOptions={genexUserOptions}
          genexUsersLoading={genexUsersLoading}
          selectedGenexUser={selectedGenexUser}
          setSelectedGenexUser={setSelectedGenexUser}
        />

        <FormFooter
          buttons={[
            {
              label: isSubmittingAPI
                ? isEdit
                  ? "Saving..."
                  : "Creating..."
                : isEdit
                  ? "Update Profile"
                  : "Create Profile",
              props: {
                type: "submit",
                disabled: isSubmittingAPI || submitSuccess || !isValid,
              },
            },
          ]}
        />
      </form>
    </PortraitFormContainer>
  );
};

UserForm.displayName = "UserForm";
export default UserForm;
