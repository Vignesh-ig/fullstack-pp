import RoleBadge from "../../../components/ui/badge/RoleBadge";
import InputField from "../../../components/ui/common/InputField";
import SearchableSelectField from "../../../components/ui/common/SearchableSelectField";
import SelectField from "../../../components/ui/common/SelectField";
import SelectFieldWithCheckbox from "../../../components/ui/common/SelectFieldWithCheckbox";
import StatusToggle from "../../../components/ui/common/StatusToggle";
import { ROLES } from "../../../constants/roles";
import { REGEX } from "../../../utils/validation/regex";

/**
 * UserFormFields
 *
 * Extracted form fields for UserForm to reduce component size. Uses a fieldset as a semantic wrapper for form controls.
 *
 * @param {function} register - react-hook-form register function.
 * @param {object} errors - react-hook-form errors object.
 * @param {function} setValue - react-hook-form setValue function.
 * @param {string} roleId - Watched roleId value.
 * @param {boolean} isActive - Watched isActive value.
 * @param {boolean} rolesLoading - Loading state for roles.
 * @param {object[]} roleOptions - Formatted role options for SelectField.
 * @param {boolean} isEdit - Whether the form is in edit mode.
 * @param {boolean} zoneLoading - Loading state for zones.
 * @param {string} selectedZone - Currently selected zone ID.
 * @param {function} onZoneChange - Called when zone selection changes.
 * @param {object[]} regionOptions - Region options for SearchableSelectField with frontend search.
 * @param {boolean} regionLoading - Loading state for regions.
 * @param {string} selectedRegion - Currently selected region ID.
 * @param {function} onRegionChange - Called when region selection changes.
 * @param {object[]} areaOptions - Area options for SearchableSelectField.
 * @param {boolean} areaLoading - Loading state for areas.
 * @param {string} selectedArea - Currently selected area ID.
 * @param {function} onAreaChange - Called when area selection changes.
 * @param {object[]} branchOptions - Branch options for SelectFieldWithCheckbox.
 * @param {string[]} selectedBranches - Currently selected branch IDs.
 * @param {object[]} initialSelectedBranchOptions - Pre-built { value, label } objects for the
 * @param {function} onBranchChange - Called when branch selection changes.
 * @param {boolean} branchLoading - True while branch list is loading.
 * @param {string} branchError - Fetch error message for branches.
 * @param {any} regionValidationError - regionValidationError
 * @param {any} areaValidationError - areaValidationError
 * @param {any} branchIdsError - branchIdsError
 * @param {any} triggerValidation - triggerValidation
 * @param {boolean} genexUsersLoading - Loading state for Genex users.
 * @param {string} selectedGenexUser - Selected Genex user code.
 * @param {function} setSelectedGenexUser - Function to update selected Genex user.
 */
const UserFormFields = ({
  register,
  errors,
  setValue,
  roleId,
  isActive,
  rolesLoading,
  roleOptions,
  isEdit,
  // Zone → Region → Area → Branch hierarchy
  zoneOptions = [],
  zoneLoading = false,
  selectedZone = "",
  onZoneChange,
  regionOptions = [],
  regionLoading = false,
  selectedRegion = "",
  onRegionChange,
  areaOptions = [],
  areaLoading = false,
  selectedArea = "",
  onAreaChange,
  branchOptions = [],
  selectedBranches = [],
  initialSelectedBranchOptions = [],
  onBranchChange,
  branchLoading = false,
  branchError = null,
  // Hierarchy validation errors
  zoneValidationError,
  regionValidationError,
  areaValidationError,
  branchIdsError,
  triggerValidation,
  // Genex user
  genexUserOptions = [],
  genexUsersLoading = false,
  selectedGenexUser,
  setSelectedGenexUser,
}) => {
  // Determine whether the selected role is BRANCH_USER.
  // roleId is a UUID; we match by label since ROLES constants hold backend strings.
  const selectedRoleLabel =
    roleOptions.find((o) => o.value === roleId)?.label ?? "";
  const isBranchUser =
    selectedRoleLabel.replace(/\s+/g, "_").toUpperCase() === ROLES.BRANCH;

  return (
    <fieldset className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
      {!isEdit && (
        <SearchableSelectField
          label="Select Genex User"
          subLabel="Select the user to auto-fill the details below"
          name="genexUser"
          value={selectedGenexUser}
          onChange={(opt) => {
            setSelectedGenexUser(opt.value);
            setValue("userName", opt.data.employeeName, {
              shouldValidate: true,
            });
            setValue("userEmployeeCode", opt.data.userName, {
              shouldValidate: true,
            });
            setValue("userEmail", opt.data.emailId, { shouldValidate: true });
          }}
          options={genexUserOptions}
          placeholder={
            genexUsersLoading
              ? "Loading Genex users..."
              : "Search and select Genex user..."
          }
          className="sm:col-span-2 mb-4"
          required={true}
          disabled={genexUsersLoading}
        />
      )}

      <InputField
        label="Employee Name"
        {...register("userName")}
        placeholder="Enter employee name"
        error={errors.userName?.message}
        className="mb-4"
        required={true}
        regex={REGEX.NAME}
        disabled={true}
      />

      {/* System User Name - Which can be Employee ID / Username */}
      <InputField
        label="System User Name"
        {...register("userEmployeeCode")}
        placeholder="Enter system user name"
        error={errors.userEmployeeCode?.message}
        className="mb-4"
        required={true}
        regex={REGEX.USERNAME}
        disabled={true}
      />

      <InputField
        label="Email"
        type="email"
        {...register("userEmail")}
        placeholder="Enter email"
        error={errors.userEmail?.message}
        className="sm:col-span-2 mb-4"
        required={true}
        regex={REGEX.EMAIL}
        disabled={true}
      />

      <SelectField
        label="Role"
        name="roleId"
        value={roleId}
        onChange={(e) =>
          setValue("roleId", e.target.value, { shouldValidate: false })
        }
        onBlur={() => triggerValidation?.("roleId")}
        options={
          rolesLoading
            ? [{ value: "", label: "Loading roles..." }]
            : roleOptions
        }
        error={errors.roleId?.message}
        className="sm:col-span-2 mb-4"
        required={true}
        renderOption={(opt) =>
          opt.roleName ? (
            <RoleBadge roleName={opt.roleName} />
          ) : (
            <span className="text-sm text-text-secondary">{opt.label}</span>
          )
        }
      />

      {/* Branch hierarchy — visible only when BRANCH_USER role is selected */}
      {isBranchUser && (
        <>
          {/* Zone / Region / Area — single row, 3-column grid */}
          <div className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-x-4">
            {/* Zone — plain SelectField, no search needed (only ~4 zones) */}
            <SelectField
              label="Zone"
              name="zone"
              value={selectedZone}
              onChange={(e) => onZoneChange?.(e.target.value)}
              onBlur={() => triggerValidation?.("selectedZone")}
              options={
                zoneLoading
                  ? [{ value: "", label: "Loading zones..." }]
                  : zoneOptions
              }
              placeholder="Select zone"
              className="mb-4"
              required={true}
              disabled={zoneLoading}
              error={zoneValidationError}
            />

            {/* Region — searchable (frontend filtering) */}
            <SearchableSelectField
              label="Region"
              name="region"
              value={selectedRegion}
              onChange={(opt) => onRegionChange?.(opt.value)}
              onBlur={() => triggerValidation?.("selectedRegion")}
              options={regionOptions}
              placeholder={
                !selectedZone
                  ? "Select zone first"
                  : regionLoading
                    ? "Loading regions..."
                    : "Select region"
              }
              className="mb-4"
              required={true}
              disabled={!selectedZone || regionLoading}
              error={regionValidationError}
            />

            {/* Area — searchable (frontend filtering) */}
            <SearchableSelectField
              label="Area"
              name="area"
              value={selectedArea}
              onChange={(opt) => onAreaChange?.(opt.value)}
              onBlur={() => triggerValidation?.("selectedArea")}
              options={areaOptions}
              placeholder={
                !selectedRegion
                  ? "Select region first"
                  : areaLoading
                    ? "Loading areas..."
                    : "Select area"
              }
              className="mb-4"
              required={true}
              disabled={!selectedRegion || areaLoading}
              error={areaValidationError}
            />
          </div>

          {/* Branch multi-select */}
          <SelectFieldWithCheckbox
            label="Branches"
            name="branchIds"
            value={selectedBranches}
            onChange={(e) => onBranchChange?.(e.target.value)}
            onBlur={() => triggerValidation?.("branchIds")}
            options={branchOptions}
            selectedOptions={initialSelectedBranchOptions}
            countText="branches"
            placeholder={
              !selectedArea
                ? "Select area first"
                : branchLoading
                  ? "Loading branches..."
                  : "Select branches"
            }
            isLoadingMore={branchLoading}
            fetchError={branchError}
            searchPlaceholder="Search branches"
            className="sm:col-span-2 mb-4"
            required={true}
            disabled={!selectedArea || branchLoading}
            error={branchIdsError}
            showChips={true}
          />
        </>
      )}

      <StatusToggle
        label="Status"
        isActive={isActive}
        disabled={!isEdit}
        isEdit={isEdit}
        onChange={() =>
          isEdit && setValue("isActive", !isActive, { shouldValidate: true })
        }
        className="sm:col-span-2"
      />
    </fieldset>
  );
};

UserFormFields.displayName = "UserFormFields";
export default UserFormFields;
