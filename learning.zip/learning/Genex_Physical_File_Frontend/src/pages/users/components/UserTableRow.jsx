import { useSelector } from "react-redux";
import { ChevronRightIcon, EditIcon } from "../../../components/icons/icons";
import {
  RoleBadge,
  StatusBadge,
} from "../../../components/ui/badge/badgeIndex";
import IconButton from "../../../components/ui/common/IconButton";
import IconButtonWithHover from "../../../components/ui/common/IconButtonWithHover";
import TableRecordDeleteButton from "../../../components/ui/common/TableRecordDeleteButton";
import { canPerformOperation, ROLES } from "../../../constants/roles";
import UserExpandedRow from "./UserExpandedRow";

/**
 * UserTableRow
 *
 * Renders a single data row inside the users table. Includes an expand/collapse toggle for branch users, main metadata columns, and actions. When expanded, mounts a UserExpandedRow beneath the main row.
 *
 * @param {object} user - The full user record object from the API.
 * @param {number} index - Zero-based row index within the current page.
 * @param {number} serialNumber - The precomputed serial number to display.
 * @param {boolean} isExpanded - Whether the detail panel is currently open.
 * @param {function} onToggle - Called when the expand/collapse button is clicked.
 * @param {number} colSpan - Total column count passed to UserExpandedRow.
 * @param {boolean} isDeleting - Global deleting state.
 * @param {function} onEditClick - Called with the record object when the edit button is clicked.
 * @param {function} onDeleteClick - Called when delete action is clicked.
 */
const UserTableRow = ({
  user,
  serialNumber,
  isExpanded,
  onToggle,
  colSpan,
  isDeleting,
  onEditClick,
  onDeleteClick,
}) => {
  const { userEmployeeCode } = useSelector((state) => state.user);
  const canDelete = canPerformOperation(userEmployeeCode);
  const isBranchUser = user.roleDto?.roleName === ROLES.BRANCH;

  return (
    <>
      <tr
        className={`hover:bg-slate-200/80 transition-colors ${isExpanded ? "border-b border-border-subtle" : ""}`}
      >
        <td className="px-4 py-1 text-center align-middle whitespace-nowrap w-10">
          {isBranchUser && (
            <IconButton
              onClick={onToggle}
              className="p-1 hover:bg-slate-200 text-text-secondary shadow-none border-none bg-transparent hover:text-text-secondary focus:outline-none"
              ariaLabel={isExpanded ? "Collapse row" : "Expand row"}
              icon={
                <ChevronRightIcon
                  className={`w-4 h-4 transition-transform duration-200 ${
                    isExpanded ? "rotate-90" : ""
                  }`}
                />
              }
            />
          )}
        </td>
        <td className="table-td-middle">{serialNumber}</td>
        <td className="table-td-primary">{user.userEmployeeCode || "—"}</td>
        <td className="table-td-primary">{user.userName || "—"}</td>
        <td className="table-td-middle">{user.userEmail || "—"}</td>
        <td className="table-td-center">
          <RoleBadge roleName={user.roleDto?.roleName} />
        </td>
        <td className="table-td-center">
          <StatusBadge isActive={user.isActive} />
        </td>
        <td className="table-td-center">
          <div className="flex items-center justify-center gap-1">
            <IconButtonWithHover
              onClick={() => onEditClick(user)}
              icon={<EditIcon />}
              label="Edit User"
              colorClass="hover:text-brand-primary hover:bg-brand-primary/5"
            />
            {canDelete && (
              <TableRecordDeleteButton
                recordId={user.userId}
                onDeleteClick={onDeleteClick}
                isDeleting={isDeleting}
                label="Delete User"
              />
            )}
          </div>
        </td>
      </tr>

      {isBranchUser && (
        <UserExpandedRow
          user={user}
          colSpan={colSpan}
          isExpanded={isExpanded}
        />
      )}
    </>
  );
};

UserTableRow.displayName = "UserTableRow";
export default UserTableRow;
