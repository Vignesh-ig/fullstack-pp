import { useState } from "react";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { USER_TABLE_COLUMNS } from "../../../constants/tableHeaders";
import UserTableRow from "./UserTableRow";

/**
 * UsersTable
 *
 * Extracted table rendering logic for UsersList, including skeletons, empty states, and actual rows.
 *
 * @param {object[]} users - Array of user data objects.
 * @param {boolean} loading - Loading state for data fetching.
 * @param {string} error - Error message if fetching fails.
 * @param {string} search - Current search query (for empty state messaging).
 * @param {number} page - Current page number (for serial numbers).
 * @param {number} pageSize - Page size (for serial numbers).
 * @param {boolean} isDeleting - Global deleting state.
 * @param {function} onEditClick - Callback when edit action is clicked.
 * @param {function} onDeleteClick - Callback when delete action is clicked.
 */
const UsersTable = ({
  users,
  loading,
  error,
  search,
  page,
  pageSize,
  isDeleting,
  onEditClick,
  onDeleteClick,
}) => {
  const [expandedRows, setExpandedRows] = useState({});

  const toggleRow = (id) => {
    setExpandedRows((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const colSpan = USER_TABLE_COLUMNS.length;
  return (
    <Table headers={USER_TABLE_COLUMNS} headerColorClass="bg-table-header-bg">
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow key={i} columnsCount={USER_TABLE_COLUMNS.length} />
        ))
      ) : users.length === 0 && !error ? (
        <tr>
          <td colSpan={colSpan} className="h-full">
            <EmptyState
              title="No users found"
              description={
                search
                  ? `No results for "${search}". Try a different search.`
                  : "Get started by adding your first user."
              }
            />
          </td>
        </tr>
      ) : (
        users.map((user, index) => (
          <UserTableRow
            key={user.userId}
            user={user}
            index={index}
            serialNumber={(page - 1) * pageSize + index + 1}
            isExpanded={!!expandedRows[user.userId]}
            onToggle={() => toggleRow(user.userId)}
            colSpan={colSpan}
            isDeleting={isDeleting}
            onEditClick={onEditClick}
            onDeleteClick={onDeleteClick}
          />
        ))
      )}
    </Table>
  );
};

UsersTable.displayName = "UsersTable";
export default UsersTable;
