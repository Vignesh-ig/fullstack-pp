import { BuildingIcon } from "../../../components/icons/icons";
import DetailCard from "../../../components/ui/common/DetailCard";
import DetailField from "../../../components/ui/common/DetailField";

/**
 * UserExpandedRow
 *
 * Renders the full-width expanded detail panel for a user record.
 * Displays categorised detail cards, specifically Assigned Branches for Branch Users.
 *
 * @param {object} user - The full user record object from the API.
 * @param {number} colSpan - Number of columns the detail panel should span.
 * @param {boolean} isExpanded - Whether the row is expanded.
 */
const UserExpandedRow = ({ user, colSpan, isExpanded }) => {
  return (
    <tr
      className={`bg-slate-50/40 ${isExpanded ? "" : "border-b border-border-subtle"}`}
    >
      <td colSpan={colSpan} className="p-0 border-0">
        <div
          className={`expandable-row-wrapper ${isExpanded ? "expanded" : ""}`}
        >
          <div className="expandable-row-inner">
            <div className="px-6 py-4">
              <section className="bg-white border border-slate-500/70 rounded-xl p-2 sm:p-5 shadow-xs text-left">
                {/* Assigned Branches */}
                <DetailCard
                  title="Assigned Branches"
                  icon={BuildingIcon}
                  fullWidth
                >
                  <div className="w-full overflow-x-auto custom-scrollbar pb-2">
                    <dl className="grid grid-cols-5 gap-2 p-2">
                      {user.branchDtos && user.branchDtos.length > 0 ? (
                        user.branchDtos
                          .filter((branch) => branch != null)
                          .map((branch, index) => (
                            <DetailField
                              key={branch.branchId || index}
                              value={`${branch.branchName || ""} (${branch.city || ""})`}
                              className="capitalize"
                            />
                          ))
                      ) : (
                        <span className="text-slate-500 font-normal text-sm">
                          No branches assigned.
                        </span>
                      )}
                    </dl>
                  </div>
                </DetailCard>
              </section>
            </div>
          </div>
        </div>
      </td>
    </tr>
  );
};

UserExpandedRow.displayName = "UserExpandedRow";
export default UserExpandedRow;
