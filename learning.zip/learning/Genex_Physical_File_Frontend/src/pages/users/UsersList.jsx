import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { deleteUsersApi, getRolesApi, getUsersApi } from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import RoleBadge from "../../components/ui/badge/RoleBadge";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import Pagination from "../../components/ui/common/Pagination";
import { useApi } from "../../hooks/useApi";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import { toTitleCase } from "../../utils/utils";
import UsersTable from "./components/UsersTable";

/**
 * UsersList
 *
 * Renders the UsersList component.
 *
 */
const UsersList = () => {
  const navigate = useNavigate();

  const {
    execute: deleteUser,
    isLoading: isDeleting,
    error: deleteError,
    setError: setDeleteError,
  } = useApi(deleteUsersApi);

  const [roleFilter, setRoleFilter] = useState("");
  const [filterRoleOptions, setFilterRoleOptions] = useState([]);

  useEffect(() => {
    getRolesApi({ limit: 100 })
      .then((res) => {
        const list = res?.data?.data || res?.data || [];
        setFilterRoleOptions(
          list.map((r) => ({
            label: toTitleCase(r.roleName),
            value: r.roleName,
            roleName: r.roleName,
          })),
        );
      })
      .catch(() => {});
  }, []);

  const fetchFn = useCallback(
    async (params) => {
      const { searchByName, ...restParams } = params;
      return getUsersApi({
        ...restParams,
        ...(roleFilter ? { searchByRole: roleFilter } : {}),
        ...(searchByName ? { searchByName } : {}),
      });
    },
    [roleFilter],
  );

  const {
    data: users,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "searchByName");

  const handleDeleteOne = useCallback(
    async (userId) => {
      if (isDeleting) return;

      const { error } = await deleteUser([userId]);
      if (!error) {
        await refetch();
        if (page > 1 && users.length <= 1)
          setPage((prev) => Math.max(1, prev - 1)); // If this was the last user on a non-first page, go back
      }
    },
    [isDeleting, page, refetch, setPage, users.length, deleteUser],
  );

  return (
    <ListContainer>
      <ListHeader
        title="User Management"
        unit="users"
        count={pagination.totalItems}
        loading={loading}
        addLabel="Add New User"
        searchPlaceholder="Search employee name"
        search={search}
        setSearch={setSearch}
        refetch={() => {
          setRoleFilter("");
          refetch();
        }}
        onAddClick={() => navigate("add")}
      >
        <search className="mt-4 grid grid-cols-1 sm:flex sm:flex-row items-start sm:items-center gap-3 sm:gap-5 w-full">
          <FilterSelectField
            label="Filter by roles:"
            name="roleFilter"
            value={roleFilter}
            onChange={(e) => {
              setRoleFilter(e.target.value);
              setPage(1);
            }}
            placeholder="All Roles"
            options={filterRoleOptions}
            className="w-full sm:w-auto"
            renderOption={(opt) => <RoleBadge roleName={opt.roleName} />}
            renderSelected={(opt) => <RoleBadge roleName={opt.roleName} />}
          />
        </search>
      </ListHeader>

      {/* ── Error ── */}
      {(error || deleteError) && (
        <section className="px-6 pt-4">
          <ErrorBanner
            message={deleteError || error}
            onClose={() => {
              setError(null);
              setDeleteError(null);
            }}
          />
        </section>
      )}

      <UsersTable
        users={users}
        loading={loading}
        error={error}
        search={search}
        page={page}
        pageSize={pageSize}
        isDeleting={isDeleting}
        onEditClick={(user) =>
          navigate(`edit/${user.userId}`, { state: { user } })
        }
        onDeleteClick={handleDeleteOne}
      />

      {/* ── Pagination ── */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />
    </ListContainer>
  );
};

UsersList.displayName = "UsersList";
export default UsersList;
