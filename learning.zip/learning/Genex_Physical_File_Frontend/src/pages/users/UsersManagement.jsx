import { Route, Routes } from "react-router-dom";
import { ROUTES } from "../../router/routes";
import UserForm from "./UserForm";
import UsersList from "./UsersList";

/**
 * UsersManagement
 *
 * Renders the UsersManagement component.
 *
 */
const UsersManagement = () => {
  return (
    <Routes>
      <Route path="/" element={<UsersList />} />
      <Route
        path={ROUTES.FEATURES.MASTER.USER_MANAGEMENT.ADD}
        element={<UserForm mode="add" />}
      />
      <Route
        path={ROUTES.FEATURES.MASTER.USER_MANAGEMENT.EDIT}
        element={<UserForm mode="edit" />}
      />
    </Routes>
  );
};

UsersManagement.displayName = "UsersManagement";
export default UsersManagement;
