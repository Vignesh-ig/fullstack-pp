import { zodResolver } from "@hookform/resolvers/zod";
import { useCallback, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { createRackApi, updateRackApi } from "../../api/apiConfig";
import PortraitFormContainer from "../../components/layout/PortraitFormContainer";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FormFooter from "../../components/ui/common/FormFooter";
import FormHeader from "../../components/ui/common/FormHeader";
import SuccessBanner from "../../components/ui/common/SuccessBanner";
import { useVaultDropdown } from "../../hooks/dropdowns/useVaultDropdown";
import { useApi } from "../../hooks/useApi";
import { rackFormSchema } from "../../utils/schemas/configSchema";
import RackFormFields from "./components/RackFormFields";

/**
 * RackForm
 *
 * Full-page form for creating and editing racks. Matches the structure and logic of BranchForm.
 *
 * @param {"add" | "edit"} props.mode - Controls field visibility & submit behaviour.
 * @param {object} props.defaultValues - Pre-filled rack data.
 */
const RackForm = ({ mode = "add", defaultValues = {} }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { id } = useParams();
  const { userId: currentUserId } = useSelector((state) => state.user);

  const isEdit = mode === "edit";
  const locationRack = location.state?.rack;

  const apiFunction = useCallback(
    (payload) => (isEdit ? updateRackApi(payload) : createRackApi(payload)),
    [isEdit],
  );

  const {
    execute: submitRack,
    isLoading: isSubmittingAPI,
    error: submitError,
    setError: setSubmitError,
    isSuccess: submitSuccess,
  } = useApi(apiFunction);

  const resolvedDefaultValues = useMemo(
    () => ({
      rackId: defaultValues?.rackId ?? locationRack?.rackId ?? id,
      vaultName: defaultValues?.vaultName ?? locationRack?.vaultName ?? "V1",
      rackName: defaultValues?.rackName ?? locationRack?.rackName ?? "",
      rackPosition:
        defaultValues?.rackPosition ?? locationRack?.rackPosition ?? "",
      rackStatus: defaultValues?.rackStatus ?? locationRack?.rackStatus ?? true,
    }),
    [defaultValues, id, locationRack],
  );

  const [vaultDropdownEnabled, setVaultDropdownEnabled] = useState(isEdit);
  const { options: vaultOptions } = useVaultDropdown(vaultDropdownEnabled);

  const rackAppCount =
    locationRack?.rackAppCount ?? defaultValues?.rackAppCount;

  const {
    register,
    handleSubmit,
    setValue,
    trigger,
    watch,
    formState: { errors, isValid },
  } = useForm({
    resolver: zodResolver(rackFormSchema),
    mode: "onTouched",
    defaultValues: {
      mode,
      ...resolvedDefaultValues,
    },
  });

  const onSubmit = async (data) => {
    if (isSubmittingAPI) return;

    const payload = {
      vaultName: data.vaultName?.trim() || null,
      rackName: data.rackName?.trim() || null,
      rackPosition: data.rackPosition?.trim() || null,
      rackStatus: data.rackStatus,
    };

    if (isEdit) {
      payload.rackId = resolvedDefaultValues.rackId;
      payload.modifiedBy = currentUserId;
    } else {
      payload.createdBy = currentUserId;
    }

    const { error } = await submitRack(payload);
    if (!error) {
      setTimeout(() => navigate(".."), 1000);
    }
  };

  return (
    <PortraitFormContainer maxWidth="max-w-xl">
      <FormHeader
        title={isEdit ? "Edit Rack" : "Add New Rack"}
        onBack={() => navigate("..")}
      />

      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <input type="hidden" {...register("mode")} />
        <ErrorBanner
          message={submitError}
          onClose={() => setSubmitError(null)}
        />

        <SuccessBanner
          message={
            submitSuccess
              ? `Rack ${isEdit ? "updated" : "created"} successfully!!!`
              : null
          }
        />

        <RackFormFields
          register={register}
          errors={errors}
          watch={watch}
          setValue={setValue}
          trigger={trigger}
          isEdit={isEdit}
          rackAppCount={rackAppCount}
          vaultOptions={vaultOptions}
          vaultDropdownEnabled={vaultDropdownEnabled}
          setVaultDropdownEnabled={setVaultDropdownEnabled}
        />

        <FormFooter
          buttons={[
            {
              label: isSubmittingAPI
                ? isEdit
                  ? "Saving..."
                  : "Creating..."
                : isEdit
                  ? "Update Rack"
                  : "Create Rack",
              props: {
                type: "submit",
                disabled: isSubmittingAPI || submitSuccess || !isValid,
              },
            },
          ]}
        />
      </form>
    </PortraitFormContainer>
  );
};

RackForm.displayName = "RackForm";
export default RackForm;
