import { Route, Routes } from "react-router-dom";
import { ROUTES } from "../../router/routes";
import RackForm from "./RackForm";
import RackList from "./RackList";

/**
 * RackMaster
 *
 * Renders the RackMaster component.
 *
 */
const RackMaster = () => {
  return (
    <Routes>
      <Route path="/" element={<RackList />} />
      <Route
        path={ROUTES.FEATURES.MASTER.RACK_MASTER.ADD}
        element={<RackForm mode="add" />}
      />
      <Route
        path={ROUTES.FEATURES.MASTER.RACK_MASTER.EDIT}
        element={<RackForm mode="edit" />}
      />
    </Routes>
  );
};

RackMaster.displayName = "RackMaster";
export default RackMaster;
