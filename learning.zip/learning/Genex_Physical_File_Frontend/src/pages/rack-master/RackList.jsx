import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { deleteRacksApi, getRacksApi } from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import Pagination from "../../components/ui/common/Pagination";
import { canPerformOperation } from "../../constants/roles";
import { useRackDropdown } from "../../hooks/dropdowns/useRackDropdown";
import { useVaultDropdown } from "../../hooks/dropdowns/useVaultDropdown";
import { useApi } from "../../hooks/useApi";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import RackTable from "./components/RackTable";

/**
 * RackList
 *
 * Container component for rack data management. Handles fetching, searching, paginating, and deleting of racks.
 *
 */
const RackList = () => {
  const navigate = useNavigate();
  const { userEmployeeCode: currentUserCode } = useSelector(
    (state) => state.user,
  );

  const [vaultFilter, setVaultFilter] = useState("V1");
  const [rackFilter, setRackFilter] = useState("");
  const [rackSearchTerm, setRackSearchTerm] = useState("");
  const [vaultDropdownEnabled, setVaultDropdownEnabled] = useState(false);

  const { options: vaultOptions } = useVaultDropdown(vaultDropdownEnabled);

  const {
    options: rackOptions,
    page: rackPage,
    hasMore: rackHasMore,
    loading: rackLoading,
    fetchPage: fetchRackPage,
  } = useRackDropdown(
    !!vaultFilter,
    rackSearchTerm,
    false,
    false,
    vaultFilter,
    false,
  );

  const handleRackLoadMore = useCallback(() => {
    if (rackHasMore && !rackLoading) {
      fetchRackPage(rackPage, rackSearchTerm);
    }
  }, [rackHasMore, rackLoading, fetchRackPage, rackPage, rackSearchTerm]);

  const {
    execute: deleteRack,
    isLoading: isDeleting,
    error: deleteError,
    setError: setDeleteError,
  } = useApi(deleteRacksApi);

  const rackOptionsRef = useRef(rackOptions);
  useEffect(() => {
    rackOptionsRef.current = rackOptions;
  }, [rackOptions]);

  const uniqueRackOptions = useMemo(() => {
    const seen = new Set();
    return rackOptions.filter((opt) => {
      if (seen.has(opt.rackName)) return false;
      seen.add(opt.rackName);
      return true;
    });
  }, [rackOptions]);

  const fetchFn = useCallback(
    async (params) => {
      const { _dummySearchParam, ...restParams } = params;
      const selectedRackOpt = rackOptionsRef.current.find(
        (o) => o.value === rackFilter,
      );
      const searchRackName = selectedRackOpt ? selectedRackOpt.rackName : "";

      const finalParams = {
        ...restParams,
        ...(vaultFilter ? { searchByVaultName: vaultFilter } : {}),
        ...(searchRackName ? { searchByRackName: searchRackName } : {}),
      };
      return getRacksApi(finalParams);
    },
    [vaultFilter, rackFilter],
  );

  const {
    data: racks,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "_dummySearchParam");

  const handleDeleteOne = useCallback(
    async (rackId) => {
      if (isDeleting) return;

      const { error } = await deleteRack([rackId]);
      if (!error) {
        await refetch();
        if (page > 1 && racks.length <= 1) {
          setPage((prev) => Math.max(1, prev - 1));
        }
      }
    },
    [isDeleting, page, refetch, setPage, racks.length, deleteRack],
  );

  const handleVaultFilterChange = (e) => {
    setVaultFilter(e.target.value);
    setRackFilter("");
  };

  const handleRackFilterChange = (e) => {
    setRackFilter(e.target.value);
  };

  const handleRefresh = () => {
    if (vaultFilter === "" && rackFilter === "") {
      refetch();
    } else {
      setVaultFilter("");
      setRackFilter("");
    }
  };

  const selectedRackOpt = rackOptions.find((o) => o.value === rackFilter);
  const searchDesc = [
    vaultFilter ? `Vault: ${vaultFilter}` : "",
    selectedRackOpt ? `Rack: ${selectedRackOpt.rackName}` : "",
  ]
    .filter(Boolean)
    .join(", ");

  return (
    <ListContainer>
      <ListHeader
        title="Rack Master"
        unit="racks"
        count={pagination.totalItems}
        loading={loading}
        addLabel="Add New Rack"
        refetch={handleRefresh}
        onAddClick={() => navigate("add")}
      >
        <search className="mt-4 grid grid-cols-1 sm:flex sm:flex-row items-start sm:items-center gap-3 sm:gap-5 w-full">
          <FilterSelectField
            label="Filter by Vault:"
            name="vaultFilter"
            value={vaultFilter}
            onChange={handleVaultFilterChange}
            placeholder="All Vaults"
            options={vaultOptions}
            className="w-full sm:w-auto"
            onOpen={() => setVaultDropdownEnabled(true)}
          />
          <FilterSelectField
            label="Filter by Rack:"
            name="rackFilter"
            value={rackFilter}
            onChange={handleRackFilterChange}
            placeholder="All Racks"
            options={uniqueRackOptions}
            className="w-full sm:w-auto"
            disabled={!vaultFilter}
            showSearch={true}
            searchPlaceholder="Search by rack name"
            searchTerm={rackSearchTerm}
            onSearchChange={setRackSearchTerm}
            isLoadingMore={rackLoading}
            hasMore={rackHasMore}
            onLoadMore={handleRackLoadMore}
          />
        </search>
      </ListHeader>

      {/* ── Error ── */}
      {(error || deleteError) && (
        <section className="px-6 pt-4">
          <ErrorBanner
            message={deleteError || error}
            onClose={() => {
              setError(null);
              setDeleteError(null);
            }}
          />
        </section>
      )}

      <RackTable
        racks={racks}
        loading={loading}
        error={error}
        search={searchDesc}
        page={page}
        pageSize={pageSize}
        currentUserCode={currentUserCode}
        canDelete={canPerformOperation(currentUserCode)}
        isDeleting={isDeleting}
        onEditClick={(rack) =>
          navigate(`edit/${rack.rackId}`, { state: { rack } })
        }
        onDeleteClick={handleDeleteOne}
      />

      {/* ── Pagination ── */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />
    </ListContainer>
  );
};

RackList.displayName = "RackList";
export default RackList;
