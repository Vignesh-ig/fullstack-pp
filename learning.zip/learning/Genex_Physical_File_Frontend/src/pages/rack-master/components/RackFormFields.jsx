import InputField from "../../../components/ui/common/InputField";
import SelectField from "../../../components/ui/common/SelectField";
import StatusToggle from "../../../components/ui/common/StatusToggle";
import { REGEX } from "../../../utils/validation/regex";

/**
 * RackFormFields
 *
 * Renders the input fields for the Rack form.
 *
 * @param {function} register - react-hook-form register function.
 * @param {object} errors - react-hook-form errors object.
 * @param {function} watch - react-hook-form watch function.
 * @param {any} setValue - setValue
 * @param {any} trigger - trigger
 * @param {boolean} isEdit - Whether the form is in edit mode.
 * @param {number} rackAppCount - Current number of applications assigned to this rack.
 * @param {any} vaultOptions - vaultOptions
 * @param {any} setVaultDropdownEnabled - setVaultDropdownEnabled
 */
const RackFormFields = ({
  register,
  errors,
  watch,
  setValue,
  trigger,
  isEdit,
  rackAppCount,
  vaultOptions,
  setVaultDropdownEnabled,
}) => {
  const rackStatus = watch("rackStatus");

  return (
    <fieldset className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
      {/* Vault Name (Mandatory) */}
      <SelectField
        label="Vault Name"
        name="vaultName"
        value={watch("vaultName")}
        onChange={(e) =>
          setValue("vaultName", e.target.value, { shouldValidate: true })
        }
        onBlur={() => trigger?.("vaultName")}
        placeholder="Select vault"
        options={vaultOptions}
        error={errors.vaultName?.message}
        className="sm:col-span-2 mb-4"
        required={true}
        disabled={isEdit}
        onOpen={() => setVaultDropdownEnabled(true)}
      />

      {/* Rack Name (Mandatory) */}
      <InputField
        label="Rack Name"
        {...register("rackName")}
        error={errors.rackName?.message}
        placeholder="Enter rack name"
        required
        maxLength={30}
        className="sm:col-span-2 mb-4"
        disabled={isEdit}
        regex={REGEX.RACK_CODE}
      />

      {/* Self (Mandatory) */}
      <InputField
        label="Self"
        {...register("rackPosition")}
        error={errors.rackPosition?.message}
        placeholder="Enter self"
        required
        maxLength={50}
        className="sm:col-span-2 mb-4"
        regex={REGEX.RACK_CODE}
      />

      {/* Count (Read-only in edit mode) */}
      {isEdit && (
        <InputField
          label="Count"
          value={rackAppCount ?? "—"}
          disabled={true}
          className="sm:col-span-2 mb-4"
        />
      )}

      {/* Status Toggle (Always disabled — set at system level) */}
      <StatusToggle
        label="Status"
        isActive={rackStatus}
        disabled={true}
        isEdit={true}
        onChange={() => {}}
        className="sm:col-span-2"
      />
    </fieldset>
  );
};

RackFormFields.displayName = "RackFormFields";
export default RackFormFields;
