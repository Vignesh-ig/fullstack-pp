import { StatusBadge } from "../../../components/ui/badge/badgeIndex";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { RACK_TABLE_COLUMNS } from "../../../constants/tableHeaders";

/**
 * RackTable
 *
 * Extracted table rendering logic for RackList, including skeletons, empty states, and actual rows.
 *
 * @param {object[]} racks - Array of rack data objects.
 * @param {boolean} loading - Loading state for data fetching.
 * @param {string} error - Error message if fetching fails.
 * @param {string} search - Current search query (for empty state messaging).
 * @param {number} page - Current page number (for serial numbers).
 * @param {number} pageSize - Page size (for serial numbers).
 */
const RackTable = ({ racks = [], loading, error, search, page, pageSize }) => {
  return (
    <Table headers={RACK_TABLE_COLUMNS} headerColorClass="bg-table-header-bg">
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow key={i} columnsCount={RACK_TABLE_COLUMNS.length} />
        ))
      ) : racks.length === 0 && !error ? (
        <tr>
          <td colSpan={RACK_TABLE_COLUMNS.length} className="h-full">
            <EmptyState
              title="No racks found"
              description={
                search
                  ? `No results for "${search}". Try a different search.`
                  : "Get started by adding your first rack."
              }
            />
          </td>
        </tr>
      ) : (
        racks.map((rack, index) => (
          <tr
            key={rack.rackId}
            className="hover:bg-slate-200/80 transition-colors"
          >
            <td className="table-td">{(page - 1) * pageSize + index + 1}</td>
            <td className="table-td-primary-branch">{rack.vaultName || "—"}</td>
            <td className="table-td-primary-branch">{rack.rackName || "—"}</td>
            <td className="table-td-primary-branch">
              {rack.rackPosition || "—"}
            </td>
            <td className="table-td text-center">{rack.rackAppCount ?? "—"}</td>
            <td className="px-6 py-1 text-center">
              <StatusBadge isActive={rack.rackStatus} />
            </td>
            {/* <td className="px-6 py-1 text-center">
              <div className="flex items-center justify-center gap-1">
                <IconButtonWithHover
                  onClick={() => onEditClick(rack)}
                  icon={<EditIcon />}
                  label="Edit Rack"
                  colorClass="hover:text-brand-primary hover:bg-brand-primary/5"
                />
                {canDelete && (
                  <TableRecordDeleteButton
                    recordId={rack.rackId}
                    onDeleteClick={onDeleteClick}
                    isDeleting={isDeleting}
                    label="Delete Rack"
                  />
                )}
              </div>
            </td> */}
          </tr>
        ))
      )}
    </Table>
  );
};

RackTable.displayName = "RackTable";
export default RackTable;
