import { Route, Routes } from "react-router-dom";
import TransactionDetailsPage from "../../components/ui/transaction/TransactionDetailsPage";
import { stampingTransactionSchema } from "../../utils/schemas/configSchema";
import StampingFileDetails from "./components/StampingFileDetails";
import StampingTransactionUpdateForm from "./components/StampingTransactionUpdateForm";
import StampingList from "./StampingList";
import StampingAmountList from "./stamping-amount/StampingAmountList";
import { ROUTES } from "../../router/routes";

/**
 * Stamping
 *
 * Renders the Stamping module component.
 *
 */
const Stamping = () => {
  return (
    <Routes>
      <Route path="/" element={<StampingList />} />
      <Route
        path={ROUTES.FEATURES.TRANSACTION.STAMPING.AMOUNT}
        element={<StampingAmountList />}
      />
      <Route
        path="details/:id"
        element={
          <TransactionDetailsPage
            schema={stampingTransactionSchema}
            isHealthCheck={false}
            isStamping={true}
            title="Stamping Details"
            FileDetailsComponent={StampingFileDetails}
            UpdateFormComponent={StampingTransactionUpdateForm}
          />
        }
      />
    </Routes>
  );
};

Stamping.displayName = "Stamping";
export default Stamping;
