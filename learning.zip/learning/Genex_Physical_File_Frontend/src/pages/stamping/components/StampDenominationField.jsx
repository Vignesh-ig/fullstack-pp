import { useCallback, useEffect, useRef, useState } from "react";
import { getStampStackMasterApi } from "../../../api/apiConfig";
import SearchableSelectField from "../../../components/ui/common/SearchableSelectField";
import SelectFieldWithCheckbox from "../../../components/ui/common/SelectFieldWithCheckbox";
import { useDebounce } from "../../../hooks/useDebounce";

/**
 * StampDenominationField
 *
 * Renders a single denomination selection field for the Stamping Details form.
 * - FIXED: single-select (SearchableSelectField) that auto-selects the first result
 *   and supports server-side search by denominationSerialNo.
 * - VARIABLE: multi-select (SelectFieldWithCheckbox) with checkboxes and
 *   server-side search by denominationSerialNo.
 *
 * @param {Object} deno - Denomination object { stampDenominationNo, stampDenominationMasterId }
 * @param {boolean} isFixed - Whether the stamp type is FIXED
 * @param {string|string[]} value - Selected value(s); string for FIXED, string[] for VARIABLE
 * @param {Function} onChange - Called with (denoNo, value) when selection changes
 * @param {string} stateParam - State string for API call (uppercase, no spaces)
 * @param {Function} onOptionsLoad - Called with (denoNo, options[]) when options load or change
 * @param {boolean} disabled - Whether the field is disabled
 */
const StampDenominationField = ({
  deno,
  isFixed,
  value,
  onChange,
  stateParam,
  onOptionsLoad,
  disabled,
}) => {
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(false);

  // Stable internal refs to avoid stale closures
  const loadingRef = useRef(false);
  const optionsRef = useRef([]);
  const pageRef = useRef(1);
  const searchTermRef = useRef("");
  // Tracks whether the dropdown has been opened at least once (prevents
  // the debouncedFixedSearch effect from firing on initial mount for FIXED).
  const hasOpenedRef = useRef(false);
  const onOptionsLoadRef = useRef(onOptionsLoad);
  useEffect(() => {
    onOptionsLoadRef.current = onOptionsLoad;
  });

  // Local search term — only for FIXED (SearchableSelectField has no internal debounce).
  // SelectFieldWithCheckbox debounces at 500 ms internally.
  const [fixedSearchTerm, setFixedSearchTerm] = useState("");
  const debouncedFixedSearch = useDebounce(fixedSearchTerm, 400);

  const fetchOptions = useCallback(
    async ({ page = 1, search = "", append = false } = {}) => {
      if (loadingRef.current) return;
      loadingRef.current = true;
      setLoading(true);
      try {
        const params = {
          page,
          limit: 10,
          state: stateParam,
          denominationAmount: deno.stampDenominationNo,
          status: "IN_STOCK",
          ...(search ? { denominationSerialNo: search } : {}),
        };
        const res = await getStampStackMasterApi(params);
        if (res?.data?.data) {
          const newOpts = res.data.data.map((item) => ({
            label: item.denominationSerialNo,
            value: item.stampStackMasterId,
          }));
          const finalOpts = append
            ? [...optionsRef.current, ...newOpts]
            : newOpts;
          optionsRef.current = finalOpts;
          setOptions(finalOpts);
          onOptionsLoadRef.current?.(deno.stampDenominationNo, finalOpts);
          setHasMore(res.data.hasNextPage ?? false);
          pageRef.current = page;
          searchTermRef.current = search;
        }
      } catch (err) {
        console.error(
          `Failed to fetch deno ${deno.stampDenominationNo}:`,
          err,
        );
      } finally {
        loadingRef.current = false;
        setLoading(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [deno.stampDenominationNo, stateParam],
  );

  // Shared open handler — fires on EVERY click of the dropdown trigger for both types.
  // Resets the FIXED search box and always fetches a fresh page 1 from the server.
  const handleOpen = useCallback(() => {
    hasOpenedRef.current = true;
    setFixedSearchTerm("");
    fetchOptions({ page: 1, search: "" });
  }, [fetchOptions]);

  // FIXED: initial fetch on mount so the 0th serial is pre-selected before user interaction.
  useEffect(() => {
    if (!isFixed) return;
    hasOpenedRef.current = true; // allow the search effect to work post-mount
    fetchOptions({ page: 1, search: "" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // FIXED: re-fetch when the user types in the search box (debounced).
  // Gated by hasOpenedRef so it never fires on mount before any interaction.
  useEffect(() => {
    if (!isFixed || !hasOpenedRef.current) return;
    fetchOptions({ page: 1, search: debouncedFixedSearch });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedFixedSearch]);

  // FIXED: auto-select index 0 whenever fresh options arrive.
  // No !value guard — every open fetches fresh data and re-selects 0th.
  useEffect(() => {
    if (isFixed && options.length > 0) {
      onChange(deno.stampDenominationNo, options[0].value);
    }
  }, [isFixed, options, onChange, deno.stampDenominationNo]);

  // VARIABLE: server-side search — debounced internally by SelectFieldWithCheckbox at 500 ms
  const handleVariableSearchChange = useCallback(
    (term) => {
      fetchOptions({ page: 1, search: term });
    },
    [fetchOptions],
  );

  // Both: load more pages when user scrolls to bottom
  const handleLoadMore = useCallback(() => {
    if (hasMore && !loadingRef.current) {
      fetchOptions({
        page: pageRef.current + 1,
        search: searchTermRef.current,
        append: true,
      });
    }
  }, [hasMore, fetchOptions]);

  if (isFixed) {
    return (
      <SearchableSelectField
        label={`Deno ${deno.stampDenominationNo}`}
        value={value || ""}
        onChange={(opt) =>
          onChange(
            deno.stampDenominationNo,
            typeof opt === "object" && opt !== null ? opt.value : opt,
          )
        }
        options={options}
        searchTerm={fixedSearchTerm}
        onSearchChange={setFixedSearchTerm}
        onOpen={handleOpen}
        hasMore={hasMore}
        isLoadingMore={loading}
        onLoadMore={handleLoadMore}
        placeholder={loading ? "Loading..." : "Select serial"}
        disabled={disabled}
        triggerClassName={
          value
            ? "py-3.5 !bg-white !border-brand-accent !ring-1 !ring-brand-accent/20"
            : "py-3.5"
        }
      />
    );
  }

  // VARIABLE — multi-select with checkboxes
  return (
    <SelectFieldWithCheckbox
      label={`Deno ${deno.stampDenominationNo}`}
      name={`deno_${deno.stampDenominationNo}`}
      value={Array.isArray(value) ? value : []}
      onChange={({ target: { value: vals } }) =>
        onChange(deno.stampDenominationNo, vals)
      }
      options={options}
      countText="selected"
      placeholder={loading ? "Loading..." : "Select serials"}
      onSearchChange={handleVariableSearchChange}
      searchPlaceholder="Search serial number"
      onOpen={handleOpen}
      hasMore={hasMore}
      isLoadingMore={loading}
      onLoadMore={handleLoadMore}
      disabled={disabled}
      showSearch
    />
  );
};

StampDenominationField.displayName = "StampDenominationField";
export default StampDenominationField;
