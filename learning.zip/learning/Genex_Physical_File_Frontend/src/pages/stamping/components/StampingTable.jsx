import { useNavigate } from "react-router-dom";
import { updateTransactionLockApi } from "../../../api/apiConfig";
import { StampTypeBadge } from "../../../components/ui/badge/badgeIndex";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { STAMP_TYPE } from "../../../constants/stampingConstants";
import { STAMPING_TABLE_COLUMNS } from "../../../constants/tableHeaders";
import { ROUTES } from "../../../router/routes";
import { toTitleCase } from "../../../utils/utils";

/**
 * StampingTable
 *
 * Renders the tabular list of Stamping transactions.
 *
 * @param {Array} records - The array of stamping records.
 * @param {boolean} loading - Indicates if the data is currently loading.
 * @param {string} error - Any error message from fetching data.
 * @param {string} search - The search term to display in the empty state.
 * @param {number} page - The current page number for index calculation.
 * @param {number} pageSize - The current page size for index calculation.
 * @param {Set} selectedIds - The set of currently selected transaction IDs.
 * @param {Function} onSelectionChange - Callback fired when the selection changes.
 */
const StampingTable = ({
  records,
  loading,
  error,
  search,
  page,
  pageSize,
  selectedIds,
  onSelectionChange,
}) => {
  const navigate = useNavigate();

  const handleRowClick = async (record) => {
    const id = record.appNo || record.barcode;
    if (id) {
      try {
        await updateTransactionLockApi({
          appNos: record.appNo,
          isLocked: true,
        });
        navigate(
          ROUTES.FEATURES.TRANSACTION.STAMPING.DETAILS.replace(
            ":id",
            encodeURIComponent(id),
          ),
          { state: { record } },
        );
      } catch (err) {
        console.error("Failed to lock transaction:", err);
        alert(
          err?.response?.data?.message ||
            "This record is already locked by another user or cannot be accessed right now.",
        );
      }
    }
  };

  const allPageIds = records?.map((r) => r.transactionId) || [];
  const isAllSelected =
    allPageIds.length > 0 && allPageIds.every((id) => selectedIds?.has(id));
  const isIndeterminate =
    !isAllSelected && allPageIds.some((id) => selectedIds?.has(id));

  const handleSelectAll = () => {
    if (!onSelectionChange) return;
    const next = new Set(selectedIds);
    if (isAllSelected) {
      allPageIds.forEach((id) => next.delete(id));
    } else {
      allPageIds.forEach((id) => next.add(id));
    }
    onSelectionChange(next);
  };

  const handleSelectOne = (id, e) => {
    e.stopPropagation();
    if (!onSelectionChange) return;
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    onSelectionChange(next);
  };

  const colSpan = STAMPING_TABLE_COLUMNS.length;

  const tableHeaders = [
    {
      id: "selectAll",
      align: "center",
      paddingClass: "px-4 py-4",
      widthClass: "w-12",
      label: (
        <input
          type="checkbox"
          className="w-4 h-4 cursor-pointer accent-brand-primary"
          checked={isAllSelected}
          ref={(el) => {
            if (el) el.indeterminate = isIndeterminate;
          }}
          onChange={handleSelectAll}
          aria-label="Select all records"
        />
      ),
    },
    ...STAMPING_TABLE_COLUMNS.slice(1).map((h) => ({
      ...h,
      id: h.label,
    })),
  ];

  return (
    <Table headers={tableHeaders} headerColorClass="bg-table-header-bg">
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow key={i} columnsCount={colSpan} />
        ))
      ) : records?.length === 0 && !error ? (
        <tr>
          <td colSpan={colSpan} className="h-full">
            <EmptyState
              title="No stamping records found"
              description={
                search
                  ? `No results for "${search}". Try a different search.`
                  : "No stamping records available."
              }
            />
          </td>
        </tr>
      ) : (
        records?.map((rec, index) => {
          const serialNumber = (page - 1) * pageSize + index + 1;
          return (
            <tr
              key={rec.transactionId || index}
              onClick={() => handleRowClick(rec)}
              className="hover:bg-brand-primary/5 transition-colors cursor-pointer"
            >
              <td
                className="table-td-center"
                onClick={(e) => handleSelectOne(rec.transactionId, e)}
              >
                <input
                  type="checkbox"
                  className="w-4 h-4 cursor-pointer accent-brand-primary"
                  checked={selectedIds?.has(rec.transactionId)}
                  onChange={(e) => handleSelectOne(rec.transactionId, e)}
                  aria-label={`Select record ${rec.appNo}`}
                />
              </td>
              <td className="table-td">{serialNumber}</td>
              <td className="table-td">{rec.appNo || "—"}</td>
              <td className="table-td">{rec.aggNo || "—"}</td>
              <td className="table-td">{rec.barcode || "—"}</td>
              <td className="table-td">{rec.customerName || "—"}</td>
              <td className="table-td">
                {rec.stateDesc ? toTitleCase(rec.stateDesc) : "—"}
              </td>
              <td className="table-td-center">
                <StampTypeBadge
                  stampType={
                    rec.stampType
                      ? rec.stampType.toUpperCase()
                      : STAMP_TYPE.NO_STAMPING
                  }
                />
              </td>
            </tr>
          );
        })
      )}
    </Table>
  );
};

StampingTable.displayName = "StampingTable";
export default StampingTable;
