import { useRef, useState } from "react";
import { FileIcon } from "../../../components/icons/icons";
import {
  StampTypeBadge,
  StatusBadge,
} from "../../../components/ui/badge/badgeIndex";
import DetailCard from "../../../components/ui/common/DetailCard";
import DetailField from "../../../components/ui/common/DetailField";
import DocumentButton from "../../../components/ui/common/DocumentButton";
import { STAMP_TYPE } from "../../../constants/stampingConstants";
import { formatDateOnlyToIST, toTitleCase } from "../../../utils/utils";

/**
 * StampingFileDetails
 *
 * Renders the read-only file details cards showing the current record's information.
 *
 * @param {Object} currentRecord - The current record object to display.
 */
const StampingFileDetails = ({ currentRecord: rec }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const expandRef = useRef(null);
  const containerRef = useRef(null);

  const toggleExpand = () => {
    setIsExpanded((prev) => {
      const next = !prev;

      if (next) {
        setTimeout(() => {
          expandRef.current?.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
        }, 450);
      } else {
        containerRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }

      return next;
    });
  };
  if (!rec) return null;

  return (
    <DetailCard title="File Details" icon={FileIcon}>
      <dl className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-6 pt-2">
        <DetailField
          label="Assigned To"
          value={
            rec.assignedUser?.userName
              ? `${rec.assignedUser.userName}${rec.assignedUser.userEmployeeCode ? ` (${rec.assignedUser.userEmployeeCode})` : ""}`
              : "Unassigned"
          }
        />
        <DetailField
          label="Assigned To Email"
          value={rec.assignedUser?.userEmail || "N/A"}
        />
        <DetailField label="Application No" value={rec.appNo || "N/A"} />
        <DetailField label="Agreement No" value={rec.aggNo || "N/A"} />
        <DetailField label="Barcode" value={rec.barcode || "N/A"} />
        <DetailField label="Ageing" value={rec.ageingNo || "N/A"} />
        <DetailField label="Customer Name" value={rec.customerName || "N/A"} />
        <DetailField label="File Type" value={rec.fileType || "N/A"} />

        {isExpanded && (
          <div ref={expandRef} className="contents">
            <DetailField
              label="Vault Name"
              value={rec.rack?.vaultName || "N/A"}
            />
            <DetailField
              label="Rack Name"
              value={rec.rack?.rackName || "N/A"}
            />
            <DetailField label="Self" value={rec.rack?.rackPosition || "N/A"} />
            <DetailField
              label="Rack Status"
              value={
                typeof rec.rack?.rackStatus === "boolean" ? (
                  <StatusBadge isActive={rec.rack?.rackStatus} />
                ) : (
                  "N/A"
                )
              }
            />
            <DetailField label="Scheme" value={rec.schemaProduct || "N/A"} />
            <DetailField
              label="eSign Status"
              value={
                typeof rec.isESign === "boolean" ? (
                  <StatusBadge isActive={rec.isESign} />
                ) : (
                  "N/A"
                )
              }
            />
            <DetailField
              label="State"
              value={
                rec.stateDesc ? toTitleCase(rec.stateDesc) : rec.state || "N/A"
              }
            />
            <DetailField label="Branch Name" value={rec.branchDesc || "N/A"} />
            <DetailField
              label="Branch Code"
              value={rec.genexFromBranch || "N/A"}
            />
            <DetailField
              label="Stamp Type"
              value={
                <StampTypeBadge
                  stampType={
                    rec.stampType
                      ? rec.stampType.toUpperCase()
                      : STAMP_TYPE.NO_STAMPING
                  }
                />
              }
            />
            <DetailField
              label="Stamp Amount"
              value={rec.leapStampAmount || "N/A"}
            />
            <DetailField label="Lead ID" value={rec.leadId || "N/A"} />
            <DetailField
              label="Amount Finance"
              value={rec.amountFinance ? <b>{rec.amountFinance}</b> : "N/A"}
            />
            <DetailField label="Model No" value={rec.modelNo || "N/A"} />
            <DetailField label="Make" value={rec.make || "N/A"} />
            <DetailField
              label="Disbursement Date"
              value={formatDateOnlyToIST(rec.handOffDate, "N/A")}
            />
            <DetailField
              label="EMI End Date"
              value={formatDateOnlyToIST(rec.emiEndDate, "N/A")}
            />
            <DetailField label="POD No" value={rec.podNo || "N/A"} />
            <DetailField label="Query POD No" value={rec.missingPodNo || "N/A"} />
            <DetailField label="VBarcode" value={rec.vbarCode || "N/A"} />
            <DetailField
              label="Current Stage"
              value={rec.stage?.stageName || "N/A"}
            />
            <DetailField
              label="Query Status"
              value={rec.query?.queryName?.replace(/_/g, " ") || "N/A"}
            />
            <DetailField label="Loan ID" value={rec.loanId || "N/A"} />
            <DetailField
              label="Business Date"
              value={formatDateOnlyToIST(rec.businessDate, "N/A")}
            />
            <DetailField
              label="Sourcing Date"
              value={formatDateOnlyToIST(rec.sourcingDate, "N/A")}
            />
            <DetailField label="Tenure" value={rec.tenure || "N/A"} />
            <DetailField label="BIRR" value={rec.birr || "N/A"} />
            <DetailField
              label="Registrable Status"
              value={rec.registrableStatus || "N/A"}
            />
            <DetailField
              label="Udyam Number Status"
              value={rec.udhayamNumberStatus || "N/A"}
            />
            <DetailField label="PAC Amount" value={rec.pacAmount || "N/A"} />
            <DetailField
              label="Carton Barcode"
              value={rec.queryCartonBarcode || "N/A"}
            />
            <div className="sm:col-span-2 md:col-span-2">
              <DetailField
                label="Query Code"
                value={rec.queryCategory?.queryCategoryName || "N/A"}
              />
            </div>
          </div>
        )}
      </dl>

      <div className="flex justify-end items-center gap-4 mt-4 pt-3 border-t border-slate-200">
        <DocumentButton
          id="stamping-view-document-btn"
          appNo={rec.appNo}
          customerName={rec.customerName}
        />

        <button
          type="button"
          onClick={toggleExpand}
          className="text-sm font-semibold text-brand-primary underline underline-offset-2 hover:opacity-75 transition-opacity"
        >
          {isExpanded ? "Minimize" : "Expand"}
        </button>
      </div>
    </DetailCard>
  );
};

StampingFileDetails.displayName = "StampingFileDetails";
export default StampingFileDetails;
