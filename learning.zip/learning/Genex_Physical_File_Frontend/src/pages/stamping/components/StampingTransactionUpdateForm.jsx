import { zodResolver } from "@hookform/resolvers/zod";
import { useCallback, useEffect, useState } from "react";
import { Controller, useForm, useWatch } from "react-hook-form";
import { getStampDenominationsApi } from "../../../api/apiConfig";
import Button from "../../../components/ui/common/Button";
import DenominationsTable from "../../../components/ui/common/DenominationsTable";
import ErrorBanner from "../../../components/ui/common/ErrorBanner";
import InputField from "../../../components/ui/common/InputField";
import { STAMP_TYPE } from "../../../constants/stampingConstants";
import { useStampDenominationLogic } from "../hooks/useStampDenominationLogic";
import StampDenominationField from "./StampDenominationField";

/**
 * StampingTransactionUpdateForm
 *
 * Custom update form for the Stamping Details page.
 * Handles FIXED and VARIABLE stamp type logic:
 * - FIXED: only the matching denomination is shown, auto-selected, Stamp Amount hidden.
 * - VARIABLE: all denominations <= stampAmount shown as multi-select, with total tracking.
 * Both modes support server-side search by denominationSerialNo.
 * Displays a summary table and status message once denominations are selected.
 *
 * @param {Function} onSubmit         - Submission handler for the form.
 * @param {boolean}  isSaving         - Whether the form is currently submitting.
 * @param {any}      schema           - Zod schema for useForm validation.
 * @param {Object}   currentRecord    - The full record object from the API.
 * @param {string}   formId           - HTML form id attribute.
 * @param {string}   globalError      - Global error message from submission.
 */
const StampingTransactionUpdateForm = ({
  onSubmit,
  isSaving,
  schema,
  currentRecord,
  formId = "stampingTransactionForm",
  globalError,
}) => {
  const isFixedType =
    currentRecord?.stampType?.toUpperCase() === STAMP_TYPE.FIXED;

  const insertionAmount = currentRecord?.leapStampAmount
    ? Number(currentRecord.leapStampAmount)
    : 0;

  const {
    control,
    handleSubmit,
    setValue,
    register,
    formState: { errors },
  } = useForm({
    mode: "onBlur",
    resolver: zodResolver(schema),
    defaultValues: {
      stampAmount: isFixedType ? null : "",
      insertionAmount: currentRecord?.leapStampAmount
        ? Number(currentRecord.leapStampAmount)
        : null,
    },
  });

  const watchStampAmount = useWatch({ control, name: "stampAmount" });

  // FIXED: final amount = insertion amount (no deduction needed)
  // VARIABLE: final amount = insertion amount - user-entered stamp amount
  let finalAmount = null;
  if (isFixedType) {
    finalAmount = insertionAmount;
  } else if (watchStampAmount && String(watchStampAmount).trim() !== "") {
    const parsed = Number(watchStampAmount);
    if (!isNaN(parsed)) {
      finalAmount = insertionAmount - parsed;
    }
  }

  // Ensure computed amounts are registered and updated in the form state for schema validation
  useEffect(() => {
    register("insertionAmount");
    register("finalAmount");
  }, [register]);

  useEffect(() => {
    setValue("finalAmount", finalAmount, { shouldValidate: true });
  }, [finalAmount, setValue]);

  // ── Denomination state ──────────────────────────────────────────────────────

  const [denominations, setDenominations] = useState([]);

  // { [denoNo]: string (FIXED) | string[] (VARIABLE) }
  const [selectedSerials, setSelectedSerials] = useState({});

  // { [denoNo]: { [stampStackMasterId]: denominationSerialNo } }
  const [knownLabels, setKnownLabels] = useState({});

  const stateParam = currentRecord?.stateDesc
    ? currentRecord.stateDesc.replace(/\s+/g, "").toUpperCase()
    : "";

  useEffect(() => {
    getStampDenominationsApi()
      .then((res) => {
        if (res?.data?.data) {
          setDenominations(res.data.data);
        }
      })
      .catch((err) => console.error("Failed to fetch denominations:", err));
  }, []);

  const handleSerialChange = useCallback((denoNo, value) => {
    setSelectedSerials((prev) => ({ ...prev, [denoNo]: value }));
  }, []);

  const handleRemoveSerial = useCallback((denoNo, idToRemove) => {
    setSelectedSerials((prev) => {
      const current = prev[denoNo];
      if (Array.isArray(current)) {
        return {
          ...prev,
          [denoNo]: current.filter((id) => id !== idToRemove),
        };
      }
      return {
        ...prev,
        [denoNo]: "",
      };
    });
  }, []);

  const handleOptionsLoad = useCallback((denoNo, opts) => {
    setKnownLabels((prev) => {
      const denoLabels = { ...(prev[denoNo] || {}) };
      opts.forEach((o) => {
        denoLabels[o.value] = o.label;
      });
      return { ...prev, [denoNo]: denoLabels };
    });
  }, []);

  // ── Denomination logic hook ─────────────────────────────────────────────────

  const {
    isFixed,
    filteredDenominations,
    denoStatusMessage,
    denoSelectionSummary,
    hasAnySelection,
    totalSelectedAmount,
  } = useStampDenominationLogic({
    denominations,
    stampType: currentRecord?.stampType,
    stampAmount: finalAmount, // Compare denominations against finalAmount
    selectedSerials,
    knownLabels,
  });

  // If VARIABLE, disable all denomination dropdowns once the final amount is reached (or exceeded)
  const shouldDisableDenoFields =
    !isFixed &&
    (denoStatusMessage === "matches" || denoStatusMessage === "exceeds");

  const handleFormSubmit = (data) => {
    if (denoStatusMessage === "exceeds") {
      // Prevent submission if denomination selection exceeds final amount
      return;
    }

    const stampStackMasterList = [];
    Object.values(selectedSerials).forEach((val) => {
      if (Array.isArray(val)) {
        stampStackMasterList.push(...val);
      } else if (val) {
        stampStackMasterList.push(val);
      }
    });

    onSubmit({ ...data, stampStackMasterList, finalAmount });
  };

  const handleFormError = (errs) => {
    console.error("Form validation failed:", errs);
  };

  return (
    <form
      id={formId}
      onSubmit={handleSubmit(handleFormSubmit, handleFormError)}
      className="bg-white p-6 rounded-xl border border-border-main flex flex-col gap-5 shadow-sm"
    >
      <legend className="text-sm font-bold text-text-secondary uppercase tracking-wider mb-2">
        Stamp Validation
      </legend>
      {globalError && <ErrorBanner message={globalError} />}
      {/* ── Main read-only + controlled fields ── */}
      <fieldset className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <InputField
          label="Insertion Amount"
          name="insertionAmount"
          value={currentRecord?.leapStampAmount || ""}
          disabled
        />

        {/* Stamp Amount — hidden for FIXED (denomination covers it) */}
        {!isFixed && (
          <Controller
            name="stampAmount"
            control={control}
            render={({ field }) => (
              <InputField
                {...field}
                label="Stamp Amount"
                type="number"
                error={
                  errors.stampAmount?.message ||
                  (errors.finalAmount ? true : undefined)
                }
              />
            )}
          />
        )}

        <InputField
          label="Final Amount"
          name="finalAmount"
          value={
            finalAmount !== null ? finalAmount : currentRecord?.leapStampAmount
          }
          disabled
          required
          error={errors.finalAmount?.message}
        />
      </fieldset>
      {/* ── Denomination Dropdowns ── */}
      {filteredDenominations.length > 0 && (
        <>
          <h4 className="text-sm font-bold text-text-secondary uppercase tracking-wider">Denominations</h4>
          <fieldset className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDenominations.map((deno) => (
              <StampDenominationField
                key={deno.stampDenominationMasterId}
                deno={deno}
                isFixed={isFixed}
                value={selectedSerials[deno.stampDenominationNo]}
                onChange={handleSerialChange}
                stateParam={stateParam}
                onOptionsLoad={handleOptionsLoad}
                disabled={shouldDisableDenoFields}
              />
            ))}
          </fieldset>
        </>
      )}
      {/* ── Status Message ── */}
      {denoStatusMessage !== "matches" &&
        denoStatusMessage !== "exceeds" &&
        totalSelectedAmount > 0 &&
        finalAmount > 0 && (
          <p className="text-sm font-medium text-text-primary animate-in fade-in duration-300">
            Pending Amount:{" "}
            <span className="text-brand-primary">
              ₹ {finalAmount - totalSelectedAmount}
            </span>
          </p>
        )}
      {denoStatusMessage === "matches" && (
        <p className="text-sm font-medium text-status-success animate-in fade-in duration-300">
          ✓ Deno selection matches with the final amount
        </p>
      )}
      {denoStatusMessage === "exceeds" && (
        <p className="text-sm font-medium text-status-error animate-in fade-in duration-300">
          ⚠ Deno selection exceeds with the final amount
        </p>
      )}
      {/* ── Denomination Selection Summary Table ── */}
      {hasAnySelection && (
        <section className="animate-in fade-in slide-in-from-bottom-2 duration-300 mt-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-text-secondary mb-1">
            Denomination Selection Summary
          </h3>
          <DenominationsTable
            data={denoSelectionSummary}
            onRemoveSerial={handleRemoveSerial}
          />
        </section>
      )}
      <footer className="mt-2 flex items-center justify-end">
        <Button
          type="submit"
          disabled={isSaving || denoStatusMessage !== "matches"}
          className="w-36"
        >
          {isSaving ? "Saving..." : "Save"}
        </Button>
      </footer>
    </form>
  );
};

StampingTransactionUpdateForm.displayName = "StampingTransactionUpdateForm";
export default StampingTransactionUpdateForm;
