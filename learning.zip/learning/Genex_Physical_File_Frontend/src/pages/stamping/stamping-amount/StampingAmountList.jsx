import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import LandscapeFormContainer from "../../../components/layout/LandscapeFormContainer";
import FormHeader from "../../../components/ui/common/FormHeader";
import Pagination from "../../../components/ui/common/Pagination";
import { formatCurrency } from "../../../utils/utils";
import StampingAmountTable from "./components/StampingAmountTable";

/**
 * StampingAmountList
 *
 * Calculates and displays the total leapStampAmount grouped by State
 * for the selected records passed via routing state.
 */
const StampingAmountList = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const selectedRecords = location.state?.selectedRecords;

  useEffect(() => {
    if (!selectedRecords || selectedRecords.length === 0) {
      navigate("..", { replace: true });
    }
  }, [selectedRecords, navigate]);

  const safeSelectedRecords = selectedRecords || [];

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const groupedData = useMemo(() => {
    const groups = {};

    safeSelectedRecords.forEach((rec) => {
      const stateDesc = rec.stateDesc || "Unknown";
      if (!groups[stateDesc]) {
        groups[stateDesc] = {
          stateDesc,
          totalAmount: 0,
          count: 0,
          appNos: [],
        };
      }
      groups[stateDesc].count += 1;
      // Depending on the API, leapStampAmount could be a string or a number
      const amount = parseFloat(rec.leapStampAmount) || 0;
      groups[stateDesc].totalAmount += amount;
      if (rec.appNo) {
        groups[stateDesc].appNos.push(rec.appNo);
      }
    });

    return Object.values(groups);
  }, [safeSelectedRecords]);

  const totalPages = Math.ceil(groupedData.length / pageSize);

  const paginatedData = useMemo(() => {
    const startIndex = (page - 1) * pageSize;
    return groupedData.slice(startIndex, startIndex + pageSize);
  }, [groupedData, page, pageSize]);

  const currentPageTotalAmount = useMemo(() => {
    return paginatedData.reduce((acc, rec) => acc + (rec.totalAmount || 0), 0);
  }, [paginatedData]);

  return (
    <LandscapeFormContainer className="mb-4 flex flex-col h-full">
      <FormHeader
        title="Stamp Amount Calculation"
        onBack={() => navigate("..")}
      />

      <div className="flex-1 overflow-auto">
        <StampingAmountTable
          records={paginatedData}
          page={page}
          pageSize={pageSize}
        />
      </div>

      <Pagination
        currentPage={page}
        totalPages={totalPages}
        onPageChange={setPage}
        totalItems={groupedData.length}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
        actions={
          <div className="flex items-center gap-1.5 whitespace-nowrap">
            <span className="text-md font-medium text-text-primary">
              Total Stamp Amount:
            </span>
            <span className="text-xl font-bold text-brand-primary leading-none">
              {formatCurrency(currentPageTotalAmount)}
            </span>
          </div>
        }
      />
    </LandscapeFormContainer>
  );
};

StampingAmountList.displayName = "StampingAmountList";
export default StampingAmountList;
