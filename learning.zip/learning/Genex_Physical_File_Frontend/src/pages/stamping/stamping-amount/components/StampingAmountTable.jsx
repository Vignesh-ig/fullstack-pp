import React, { useState } from "react";
import { ChevronRightIcon } from "../../../../components/icons/icons";
import EmptyState from "../../../../components/ui/common/EmptyState";
import IconButton from "../../../../components/ui/common/IconButton";
import Table from "../../../../components/ui/common/Table";
import { STAMPING_AMOUNT_TABLE_COLUMNS } from "../../../../constants/tableHeaders";
import { formatCurrency, toTitleCase } from "../../../../utils/utils";

/**
 * StampingAmountTable
 *
 * Renders the tabular list of Stamping Amounts grouped by State.
 *
 * @param {Array} records - The array of grouped stamping amount records.
 * @param {number} page - The current page number for index calculation.
 * @param {number} pageSize - The current page size for index calculation.
 */
const StampingAmountTable = ({ records, page = 1, pageSize = 10 }) => {
  const [expandedRows, setExpandedRows] = useState({});

  const toggleRow = (stateDesc) => {
    setExpandedRows((prev) => ({
      ...prev,
      [stateDesc]: !prev[stateDesc],
    }));
  };

  const colSpan = STAMPING_AMOUNT_TABLE_COLUMNS.length;

  return (
    <Table
      headers={STAMPING_AMOUNT_TABLE_COLUMNS}
      headerColorClass="bg-table-header-bg"
    >
      {records?.length === 0 ? (
        <tr>
          <td colSpan={colSpan} className="h-full">
            <EmptyState
              title="No data found"
              description="No selected stamping records available."
            />
          </td>
        </tr>
      ) : (
        records?.map((rec, index) => {
          const isExpanded = !!expandedRows[rec.stateDesc];
          const serialNumber = (page - 1) * pageSize + index + 1;
          return (
            <React.Fragment key={rec.stateDesc}>
              <tr
                className="hover:bg-slate-200/80 transition-colors cursor-pointer border-b border-border-subtle"
                onClick={() => toggleRow(rec.stateDesc)}
              >
                <td
                  className="table-td-center"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleRow(rec.stateDesc);
                  }}
                >
                  <IconButton
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleRow(rec.stateDesc);
                    }}
                    className="p-1 hover:bg-slate-200 text-text-secondary shadow-none border-none bg-transparent hover:text-text-secondary focus:outline-none"
                    ariaLabel={isExpanded ? "Collapse row" : "Expand row"}
                    icon={
                      <ChevronRightIcon
                        className={`w-4 h-4 transition-transform duration-200 ${
                          isExpanded ? "rotate-90" : ""
                        }`}
                      />
                    }
                  />
                </td>
                <td className="table-td-middle-cpu">{serialNumber}</td>
                <td className="table-td-middle">
                  {rec.stateDesc ? toTitleCase(rec.stateDesc) : "—"}
                </td>
                <td className="table-td-middle font-medium text-text-primary">
                  {rec.totalAmount !== null && rec.totalAmount !== undefined
                    ? formatCurrency(rec.totalAmount)
                    : "—"}
                </td>
                <td className="table-td-center font-semibold text-brand-primary">
                  {rec.count}
                </td>
              </tr>
              <tr className="bg-slate-50/40">
                <td colSpan={colSpan} className="p-0 border-0">
                  <div
                    className={`expandable-row-wrapper ${
                      isExpanded ? "expanded" : ""
                    }`}
                  >
                    <div className="expandable-row-inner w-full">
                      <div className="px-6 py-4 border-b border-border-subtle">
                        <section className="bg-white border border-slate-500/70 rounded-xl p-2 sm:p-5 shadow-xs text-left w-full">
                          <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-3">
                            Applications Selected:{" "}
                          </h4>
                          <div className="flex flex-wrap gap-2">
                            {rec.appNos.map((appNo) => (
                              <span
                                key={appNo}
                                className="px-2.5 py-1 bg-slate-50 border border-border-main rounded-md text-xs font-semibold text-text-secondary tracking-wide shadow-sm"
                              >
                                {appNo}
                              </span>
                            ))}
                          </div>
                        </section>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
            </React.Fragment>
          );
        })
      )}
    </Table>
  );
};

StampingAmountTable.displayName = "StampingAmountTable";
export default StampingAmountTable;
