import { useMemo } from "react";
import { STAMP_TYPE } from "../../../constants/stampingConstants";

/**
 * useStampDenominationLogic
 *
 * Encapsulates denomination filtering, total amount calculation, status messages,
 * and selection summary data for the Stamping Details form.
 *
 * @param {Array} params.denominations - Full denomination list from getStampDenominationsApi
 * @param {string} params.stampType - "FIXED" | "VARIABLE" from currentRecord
 * @param {number|string} params.stampAmount - Target stamp amount from currentRecord
 * @param {Object} params.selectedSerials - { [denoNo]: string (FIXED) | string[] (VARIABLE) }
 * @param {Object} params.knownLabels - { [denoNo]: { [stampStackMasterId]: serialLabel } }
 * @returns {Object} Derived denomination state
 */
export const useStampDenominationLogic = ({
  denominations = [],
  stampType,
  stampAmount,
  selectedSerials = {},
  knownLabels = {},
}) => {
  const isFixed = stampType?.toUpperCase() === STAMP_TYPE.FIXED;
  const isVariable = stampType?.toUpperCase() === STAMP_TYPE.VARIABLE;
  const amount = Number(stampAmount) || 0;

  /**
   * Filter denominations from the API response based on stampType and stampAmount.
   * FIXED: only the denomination whose value exactly matches stampAmount.
   * VARIABLE: all denominations with stampDenominationNo less than or equal to stampAmount.
   */
  const filteredDenominations = useMemo(() => {
    if (!denominations.length || !amount) return [];
    if (isFixed) {
      return denominations.filter((d) => d.stampDenominationNo === amount);
    }
    if (isVariable) {
      return denominations.filter((d) => d.stampDenominationNo <= amount);
    }
    return [];
  }, [denominations, isFixed, isVariable, amount]);

  /** Sum of (selectionCount x denominationValue) across all filtered denominations. */
  const totalSelectedAmount = useMemo(() => {
    return filteredDenominations.reduce((total, deno) => {
      const sel = selectedSerials[deno.stampDenominationNo];
      if (!sel) return total;
      if (isFixed) {
        return total + deno.stampDenominationNo;
      }
      const count = Array.isArray(sel) ? sel.length : 0;
      return total + count * deno.stampDenominationNo;
    }, 0);
  }, [filteredDenominations, selectedSerials, isFixed]);

  /** "matches" | "exceeds" | "partial" | null */
  const denoStatusMessage = useMemo(() => {
    if (totalSelectedAmount === 0) return null;
    if (totalSelectedAmount === amount) return "matches";
    if (totalSelectedAmount > amount) return "exceeds";
    return "partial";
  }, [totalSelectedAmount, amount]);

  /** Rows for the summary table — only denominations with at least one selection. */
  const denoSelectionSummary = useMemo(() => {
    return filteredDenominations
      .map((deno) => {
        const sel = selectedSerials[deno.stampDenominationNo];
        const labelsForDeno = knownLabels[deno.stampDenominationNo] || {};

        if (isFixed) {
          if (!sel) return null;
          return {
            denoNo: deno.stampDenominationNo,
            count: 1,
            serials: [{ id: sel, label: labelsForDeno[sel] || sel }],
          };
        }

        if (!sel || !Array.isArray(sel) || sel.length === 0) return null;
        return {
          denoNo: deno.stampDenominationNo,
          count: sel.length,
          serials: sel.map((v) => ({ id: v, label: labelsForDeno[v] || v })),
        };
      })
      .filter(Boolean);
  }, [filteredDenominations, selectedSerials, knownLabels, isFixed]);

  const hasAnySelection = denoSelectionSummary.length > 0;

  return {
    isFixed,
    isVariable,
    filteredDenominations,
    totalSelectedAmount,
    denoStatusMessage,
    denoSelectionSummary,
    hasAnySelection,
  };
};
