import { useState } from "react";
import { useNavigate } from "react-router-dom";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import NavigationBanners from "../../components/ui/common/NavigationBanners";
import Pagination from "../../components/ui/common/Pagination";
import { APP_STAGES } from "../../constants/stages";
import useNavigationBanners from "../../hooks/useNavigationBanners";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import useTransactionFetch from "../../hooks/useTransactionFetch";
import { ROUTES } from "../../router/routes";
import StampingTable from "./components/StampingTable";

/**
 * StampingList
 *
 * Fetches and displays transactions currently in the STAMPING stage.
 */
const StampingList = () => {
  const { fetchFn } = useTransactionFetch({ stage: APP_STAGES.STAMPING });

  const {
    data: records,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "likeAppNoOrBarcode");

  const navigate = useNavigate();
  const [selectedIds, setSelectedIds] = useState(new Set());
  const {
    successMessage,
    setSuccessMessage,
    warningMessage,
    setWarningMessage,
  } = useNavigationBanners();

  const hasSelection = selectedIds.size > 0;

  const handleCalculateAmount = () => {
    if (!hasSelection) return;

    // Get full objects of selected records
    const selectedRecords = records.filter((r) =>
      selectedIds.has(r.transactionId),
    );

    navigate(ROUTES.FEATURES.TRANSACTION.STAMPING.AMOUNT, {
      state: { selectedRecords },
    });
  };

  return (
    <ListContainer>
      <ListHeader
        title="Stamping Health Check"
        unit="records"
        count={pagination.totalItems}
        loading={loading}
        search={search}
        setSearch={setSearch}
        refetch={refetch}
      />

      <NavigationBanners
        successMessage={successMessage}
        setSuccessMessage={setSuccessMessage}
        warningMessage={warningMessage}
        setWarningMessage={setWarningMessage}
        error={error}
        setError={setError}
      />

      <StampingTable
        records={records}
        loading={loading}
        error={error}
        search={search}
        page={page}
        pageSize={pageSize}
        selectedIds={selectedIds}
        onSelectionChange={setSelectedIds}
      />

      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
        showAction={true}
        actionLabel="Calculate Total Stamp Amount"
        actionId="stamping-calc-amount"
        onActionClick={handleCalculateAmount}
        actionDisabled={!hasSelection}
      />
    </ListContainer>
  );
};

StampingList.displayName = "StampingList";
export default StampingList;
