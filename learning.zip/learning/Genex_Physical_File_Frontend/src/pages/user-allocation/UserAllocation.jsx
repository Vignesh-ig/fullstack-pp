import { useSelector } from "react-redux";
import { Navigate, Route, Routes } from "react-router-dom";
import { ADMIN_ROLES } from "../../constants/roles";
import { ROUTES } from "../../router/routes";
import UserAllocationEditForm from "./UserAllocationEditForm";
import UserAllocationForm from "./UserAllocationForm";
import UserAllocationList from "./UserAllocationList";

/**
 * UserAllocation
 *
 * Renders the UserAllocation component.
 *
 */
const UserAllocation = () => {
  const { roleName } = useSelector((state) => state.user);
  const isAdmin = ADMIN_ROLES.includes(roleName);

  return (
    <Routes>
      <Route path="/" element={<UserAllocationList />} />
      <Route
        path={ROUTES.FEATURES.TRANSACTION.USER_ALLOCATION.ADD}
        element={isAdmin ? <UserAllocationForm /> : <Navigate to="." replace />}
      />
      <Route
        path={ROUTES.FEATURES.TRANSACTION.USER_ALLOCATION.EDIT}
        element={
          isAdmin ? <UserAllocationEditForm /> : <Navigate to="." replace />
        }
      />
    </Routes>
  );
};

UserAllocation.displayName = "UserAllocation";
export default UserAllocation;
