import { createContext } from "react";

export const UserAllocationFormContext = createContext(null);
