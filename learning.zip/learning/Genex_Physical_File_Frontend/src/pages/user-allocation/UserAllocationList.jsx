import { useCallback, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { deleteRackAssignedApi, getRackAssignedApi } from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import NavigationBanners from "../../components/ui/common/NavigationBanners";
import Pagination from "../../components/ui/common/Pagination";
import { ADMIN_ROLES } from "../../constants/roles";
import { useRackDropdown } from "../../hooks/dropdowns/useRackDropdown";
import { useUsersDropdown } from "../../hooks/dropdowns/useUsersDropdown";
import { useVaultDropdown } from "../../hooks/dropdowns/useVaultDropdown";
import { useApi } from "../../hooks/useApi";
import useNavigationBanners from "../../hooks/useNavigationBanners";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import { ROUTES } from "../../router/routes";
import UserAllocationTable from "./components/UserAllocationTable";

/**
 * UserAllocationList
 *
 * Fetches and displays rack-assigned records for the currently logged-in user. Supports pagination, status filtering, and refresh.
 *
 */
const UserAllocationList = () => {
  const { userId: currentUserId, roleName } = useSelector(
    (state) => state.user,
  );
  const isAdmin = ADMIN_ROLES.includes(roleName);
  const navigate = useNavigate();

  const {
    successMessage,
    setSuccessMessage,
    warningMessage,
    setWarningMessage,
  } = useNavigationBanners();

  const [assignedUserFilter, setAssignedUserFilter] = useState("");
  const [userSearchTerm, setUserSearchTerm] = useState("");
  const [vaultFilter, setVaultFilter] = useState("V1");
  const [rackFilter, setRackFilter] = useState("");
  const [vaultDropdownEnabled, setVaultDropdownEnabled] = useState(false);
  const [rackSearchTerm, setRackSearchTerm] = useState("");

  const { options: vaultOptions } = useVaultDropdown(vaultDropdownEnabled);

  const {
    options: rackOptions,
    page: rackPage,
    hasMore: rackHasMore,
    loading: rackLoading,
    fetchPage: fetchRackPage,
  } = useRackDropdown(!!vaultFilter, rackSearchTerm, true, false, vaultFilter);

  const handleRackLoadMore = useCallback(() => {
    if (rackHasMore && !rackLoading) {
      fetchRackPage(rackPage, rackSearchTerm);
    }
  }, [rackHasMore, rackLoading, fetchRackPage, rackPage, rackSearchTerm]);

  const {
    execute: deleteRackAssigned,
    isLoading: isDeleting,
    error: deleteError,
    setError: setDeleteError,
  } = useApi(deleteRackAssignedApi);

  const {
    options: userOptions,
    page: usersPage,
    hasMore: usersHasMore,
    loading: usersLoading,
    fetchPage: fetchUsersPage,
  } = useUsersDropdown(isAdmin, userSearchTerm);

  const handleUserLoadMore = useCallback(() => {
    if (usersHasMore && !usersLoading) {
      fetchUsersPage(usersPage, userSearchTerm);
    }
  }, [usersHasMore, usersLoading, fetchUsersPage, usersPage, userSearchTerm]);

  const fetchFn = useCallback(
    async (params) => {
      if (!currentUserId)
        return { data: [], totalPages: 1, currentPage: 1, totalItems: 0 };

      const { _dummySearchParam, ...restParams } = params; // NOSONAR

      const finalParams = {
        ...restParams,
        userAssigned: true,
        assignedStatus: "PENDING",
        ...(vaultFilter ? { vaultName: vaultFilter } : {}),
        ...(rackFilter ? { assignedRack: rackFilter } : {}),
        ...(isAdmin
          ? assignedUserFilter
            ? { assignedUser: assignedUserFilter }
            : {}
          : { assignedUser: currentUserId }),
      };

      return getRackAssignedApi(finalParams);
    },
    [isAdmin, currentUserId, assignedUserFilter, vaultFilter, rackFilter],
  );

  const {
    data: records,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize: handlePageSizeChange,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "likeAppNoOrBarcode");

  const handleRefresh = () => {
    if (assignedUserFilter === "" && vaultFilter === "" && rackFilter === "") {
      refetch();
    } else {
      setAssignedUserFilter("");
      setVaultFilter("");
      setRackFilter("");
    }
  };

  const handleDeleteOne = useCallback(
    async (id) => {
      if (isDeleting) return;
      try {
        await deleteRackAssigned([id]);
        if (records.length === 1 && page > 1) {
          setPage(page - 1);
        } else {
          refetch();
        }
      } catch (err) {
        console.error("Failed to delete record:", err);
      }
    },
    [isDeleting, deleteRackAssigned, records.length, page, setPage, refetch],
  );

  const handleUserFilterChange = (e) => {
    setAssignedUserFilter(e.target.value);
  };

  const handleVaultFilterChange = (e) => {
    setVaultFilter(e.target.value);
    setRackFilter("");
  };

  const handleRackFilterChange = (e) => {
    setRackFilter(e.target.value);
  };

  const handleAllocateClick = () => {
    navigate(ROUTES.FEATURES.TRANSACTION.USER_ALLOCATION.ADD);
  };

  return (
    <ListContainer>
      {/* Header */}
      <ListHeader
        title="User Allocation"
        unit="records"
        count={pagination.totalItems}
        loading={loading}
        search={search}
        setSearch={setSearch}
        refetch={handleRefresh}
        onAddClick={isAdmin ? handleAllocateClick : undefined}
        addLabel="Allocate to User"
      >
        <search className="mt-4 grid grid-cols-1 sm:flex sm:flex-row items-start sm:items-center gap-3 sm:gap-5 w-full">
          <FilterSelectField
            label="Filter by Vault:"
            name="vaultFilter"
            value={vaultFilter}
            onChange={handleVaultFilterChange}
            placeholder="All Vaults"
            options={vaultOptions}
            className="w-full sm:w-auto"
            onOpen={() => setVaultDropdownEnabled(true)}
          />
          <FilterSelectField
            label="Filter by Rack:"
            name="rackFilter"
            value={rackFilter}
            onChange={handleRackFilterChange}
            placeholder="All Racks"
            options={rackOptions}
            className="w-full sm:w-auto"
            disabled={!vaultFilter}
            showSearch={true}
            searchPlaceholder="Search by rack name"
            searchTerm={rackSearchTerm}
            onSearchChange={setRackSearchTerm}
            isLoadingMore={rackLoading}
            hasMore={rackHasMore}
            onLoadMore={handleRackLoadMore}
          />
          {isAdmin && (
            <FilterSelectField
              label="Filter by User:"
              name="assignedUserFilter"
              value={assignedUserFilter}
              onChange={handleUserFilterChange}
              placeholder="All Users"
              options={userOptions}
              className="w-full sm:w-auto"
              showSearch={true}
              searchPlaceholder="Search by user name"
              searchTerm={userSearchTerm}
              onSearchChange={setUserSearchTerm}
              isLoadingMore={usersLoading}
              hasMore={usersHasMore}
              onLoadMore={handleUserLoadMore}
            />
          )}
        </search>
      </ListHeader>

      <NavigationBanners
        successMessage={successMessage}
        setSuccessMessage={setSuccessMessage}
        warningMessage={warningMessage}
        setWarningMessage={setWarningMessage}
        error={error || deleteError}
        setError={(err) => {
          setError(err);
          setDeleteError(err);
        }}
      />

      {/* Table */}
      <UserAllocationTable
        records={records}
        loading={loading}
        error={error}
        page={page}
        pageSize={pageSize}
        onEditClick={
          isAdmin
            ? (rec) =>
                navigate(`edit/${rec.rackAssignedId}`, {
                  state: { record: rec },
                })
            : undefined
        }
        onDeleteClick={handleDeleteOne}
        isDeleting={isDeleting}
      />

      {/* Pagination */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={handlePageSizeChange}
      />
    </ListContainer>
  );
};

UserAllocationList.displayName = "UserAllocationList";
export default UserAllocationList;
