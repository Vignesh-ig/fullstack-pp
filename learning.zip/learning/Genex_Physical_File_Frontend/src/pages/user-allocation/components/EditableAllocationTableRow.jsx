import React from "react";
import RecordCard from "../../../components/ui/common/RecordCard";

/**
 * EditableAllocationTableRow
 *
 * Renders a single optimized row for the EditableAllocationTable.
 * Memoized to prevent re-rendering when other rows change.
 */
const EditableAllocationTableRow = React.memo(
  ({ index, row, isChecked, onCheck, isHighlighted }) => {
    const isAssigned = Boolean(row.assignedUserName);

    return (
      <div className="flex items-center gap-3 w-full transition-all duration-300 ease-out transform-gpu hover:transform-[perspective(400px)_rotateX(1.5deg)_scale(1)] hover:shadow-2xl rounded-xl">
        <div className="shrink-0 flex items-center justify-center pl-3">
          <input
            type="checkbox"
            className="w-5 h-5 text-brand-primary border-slate-300 rounded focus:ring-brand-primary cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            checked={isChecked}
            onChange={(e) => onCheck(index, e.target.checked)}
          />
        </div>
        <div className="flex-1 min-w-0 pr-1 py-1">
          <RecordCard
            className={
              isHighlighted
                ? isAssigned
                  ? "record-card-assigned ring-1 ring-emerald-300"
                  : "bg-brand-accent/1 border-brand-primary shadow-md"
                : isAssigned
                  ? "record-card-assigned"
                  : "bg-white border-brand-accent/40 hover:border-brand-accent"
            }
            index={index}
            title={`Application No: ${row.appNo || "N/A"}`}
            details={[
              {
                label: "Assigned To",
                value: row.assignedUserName || "Not Assigned",
              },
              { label: "Barcode", value: row.barcode },
              { label: "File Type", value: row.fileType || "N/A" },
              { label: "Rack Name", value: row.rackName },
              { label: "Self", value: row.position },
              { label: "Ageing", value: row.ageingNo ?? "N/A" },
            ]}
          />
        </div>
      </div>
    );
  },
  (prev, next) => {
    if (prev.index !== next.index) return false;
    if (prev.row !== next.row) return false;
    if (prev.isChecked !== next.isChecked) return false;
    if (prev.isHighlighted !== next.isHighlighted) return false;
    return true;
  },
);

EditableAllocationTableRow.displayName = "EditableAllocationTableRow";
export default EditableAllocationTableRow;
