import InputField from "../../../components/ui/common/InputField";
import SearchableSelectField from "../../../components/ui/common/SearchableSelectField";
import SelectField from "../../../components/ui/common/SelectField";

/**
 * UserAllocationEditFormFields
 *
 * Renders the input fields for the rack allocation edit form.
 *
 * @param {Function} register - React Hook Form register function
 * @param {Function} setValue - React Hook Form setValue function
 * @param {Function} watch - React Hook Form watch function
 * @param {Function} trigger - React Hook Form trigger function
 * @param {Object} errors - React Hook Form errors object
 * @param {Array} mergedUsersOptions - Options for user select fields
 * @param {Array} fileTypeOptions - Options for file type select field
 * @param {any} vaultOptions - vaultOptions
 * @param {Array} mergedRackOptions - Options for rack select field
 * @param {boolean} usersLoading - Loading state for users
 * @param {any} usersHasMore - usersHasMore
 * @param {any} handleUserLoadMore - handleUserLoadMore
 * @param {any} userSearchTerm - userSearchTerm
 * @param {any} setUserSearchTerm - setUserSearchTerm
 * @param {boolean} rackLoading - Loading state for racks
 * @param {any} rackHasMore - rackHasMore
 * @param {any} handleRackLoadMore - handleRackLoadMore
 * @param {any} rackSearchTerm - rackSearchTerm
 * @param {any} setRackSearchTerm - setRackSearchTerm
 * @param {string} assignedStatus - The current status of the assignment
 */
const UserAllocationEditFormFields = ({
  setValue,
  watch,
  trigger,
  errors,
  mergedUsersOptions,
  vaultOptions,
  mergedRackOptions,
  usersLoading,
  usersHasMore,
  handleUserLoadMore,
  userSearchTerm,
  setUserSearchTerm,
  rackLoading,
  rackHasMore,
  handleRackLoadMore,
  rackSearchTerm,
  setRackSearchTerm,
  assignedStatus,
}) => {
  const assignedUser = watch("assignedUser");
  const vaultName = watch("vaultName");
  const rackId = watch("rackId");

  return (
    <fieldset className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
      {/* Application Number (Disabled) */}
      <InputField
        label="Application Number"
        value={watch("appNo")}
        disabled={true}
        placeholder="Application Number"
        className="mb-4"
      />

      {/* Agreement Number (Disabled) */}
      <InputField
        label="Agreement Number"
        value={watch("aggNo")}
        disabled={true}
        placeholder="Agreement Number"
        className="mb-4"
      />

      {/* Barcode (Disabled) */}
      <InputField
        label="Barcode"
        value={watch("barcode")}
        disabled={true}
        placeholder="Barcode"
        className="mb-4"
      />

      {/* Assigned Status (Disabled) */}
      <InputField
        label="Assigned Status"
        value={assignedStatus ?? "—"}
        disabled={true}
        className="mb-4"
      />

      <SelectField
        label="Vault Name"
        name="vaultName"
        value={vaultName}
        onChange={(e) => {
          setValue("vaultName", e.target.value, { shouldValidate: true });
          setValue("rackId", "", { shouldValidate: true });
        }}
        onBlur={() => trigger("vaultName")}
        placeholder="Select vault"
        options={vaultOptions}
        error={errors.vaultName?.message}
        className="mb-4"
        required={false}
        disabled={true}
      />

      {/* Rack Name */}
      <SearchableSelectField
        label="Rack Name"
        name="rackId"
        value={rackId}
        onChange={(opt) =>
          setValue("rackId", opt.value, { shouldValidate: true })
        }
        onBlur={() => trigger("rackId")}
        options={mergedRackOptions}
        placeholder="Select rack"
        searchTerm={rackSearchTerm}
        onSearchChange={setRackSearchTerm}
        isLoadingMore={rackLoading}
        hasMore={rackHasMore}
        onLoadMore={handleRackLoadMore}
        error={errors.rackId?.message}
        className="mb-4"
        required={false}
        disabled={true}
      />

      {/* Ageing */}
      <InputField
        label="Ageing"
        value={watch("ageingNo") || "N/A"}
        disabled={true}
        className="mb-4"
        inputClassName={
          Number(watch("ageingNo")) > 15 ? "!text-red-600 !font-bold" : ""
        }
      />

      {/* Assigned To */}
      <SearchableSelectField
        label="Assigned To"
        name="assignedUser"
        value={assignedUser}
        onChange={(opt) =>
          setValue("assignedUser", opt.value, { shouldValidate: true })
        }
        onBlur={() => trigger("assignedUser")}
        options={mergedUsersOptions}
        placeholder="Select assigned user"
        searchTerm={userSearchTerm}
        onSearchChange={setUserSearchTerm}
        isLoadingMore={usersLoading}
        hasMore={usersHasMore}
        onLoadMore={handleUserLoadMore}
        error={errors.assignedUser?.message}
        className="mb-4"
        required={true}
      />
    </fieldset>
  );
};

UserAllocationEditFormFields.displayName = "UserAllocationEditFormFields";
export default UserAllocationEditFormFields;
