import { useCallback, useRef, useState } from "react";
import { Virtuoso } from "react-virtuoso";
import DashedEmptyState from "../../../components/ui/common/DashedEmptyState";
import SearchInput from "../../../components/ui/common/SearchInput";
import EditableAllocationTableRow from "./EditableAllocationTableRow";

/**
 * EditableAllocationTable
 *
 * Renders an editable table of rack allocation entries inside the creation form.
 * Uses client-side filtering for user dropdowns with a single fetched user list.
 *
 * @param {Object[]} props.rows - Array of row objects to render.
 * @param {Object[]} [props.errors=[]] - Array of error objects corresponding to rows.
 * @param {Object} [props.touchedFields={}] - Map of fields that have been focused/blurred.
 * @param {function} props.onBlur - Blur event handler.
 * @param {function} props.onChange - Change event handler (index, field, value).
 * @param {function} props.onRemove - Function to remove a row.
 */
const EditableAllocationTable = ({
  rows,
  errors = [],
  touchedFields = {},
  onBlur,
  onChange,
  onRemove,
  selectedRows,
  onToggleRow,
  onToggleAll,
}) => {
  const isAllSelected = rows.length > 0 && selectedRows.size === rows.length;
  const [searchText, setSearchText] = useState("");
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const virtuosoRef = useRef(null);

  const handleSearch = (e, explicitSearchValue = null) => {
    if (e) e.preventDefault();
    const query =
      explicitSearchValue !== null ? explicitSearchValue : searchText;

    if (!query.trim()) {
      setHighlightedIndex(-1);
      return;
    }

    const lowerSearch = query.toLowerCase();
    const index = rows.findIndex(
      (r) =>
        r.appNo?.toLowerCase().includes(lowerSearch) ||
        r.barcode?.toLowerCase().includes(lowerSearch),
    );

    if (index !== -1) {
      setHighlightedIndex(index);
      virtuosoRef.current?.scrollToIndex({
        index,
        align: "center",
        behavior: "smooth",
      });
    } else {
      setHighlightedIndex(-1);
    }
  };

  const rowContent = useCallback(
    (index, row) => (
      <EditableAllocationTableRow
        index={index}
        row={row}
        onChange={onChange}
        onBlur={onBlur}
        onRemove={onRemove}
        errors={errors}
        touchedFields={touchedFields}
        isChecked={selectedRows.has(index)}
        onCheck={onToggleRow}
        isHighlighted={index === highlightedIndex}
      />
    ),
    [
      onChange,
      onBlur,
      onRemove,
      errors,
      touchedFields,
      selectedRows,
      onToggleRow,
      highlightedIndex,
    ],
  );

  if (rows.length === 0) {
    return (
      <DashedEmptyState
        title="No records added yet."
        description="Select dispatch records above to add them here."
      />
    );
  }

  const totalRecords = rows.length;
  const assignedRecords = rows.filter((r) => r.assignedUserName).length;
  const pendingRecords = totalRecords - assignedRecords;

  return (
    <div
      className="bg-white rounded-xl p-2 border border-slate-300 flex flex-col"
      style={{
        height: "clamp(400px, calc(100vh - 350px), 800px)",
      }}
    >
      <div className="flex flex-wrap justify-between items-center p-2 border-b border-slate-100 mb-2 shrink-0 gap-y-3 gap-x-2">
        <label className="ml-1 flex items-center gap-2 cursor-pointer text-sm font-medium text-slate-700 hover:text-brand-primary transition-colors shrink-0 order-1">
          <input
            type="checkbox"
            className="w-5 h-5 text-brand-primary border-slate-300 rounded focus:ring-brand-primary cursor-pointer"
            checked={isAllSelected}
            onChange={(e) => onToggleAll(e.target.checked)}
          />
          Select All
        </label>

        <div className="sm:flex-1 flex justify-center order-3 sm:order-2 sm:w-auto sm:max-w-52">
          <SearchInput
            className="w-full"
            value={searchText}
            onChange={(val) => setSearchText(val)}
            placeholder="Search"
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                const currentValue = e.target.value;
                setSearchText(currentValue);
                handleSearch(e, currentValue);
              }
            }}
          />
        </div>

        <div className="flex items-center gap-3 sm:gap-4 text-sm shrink-0 order-2 sm:order-3">
          <span className="font-medium text-slate-600">
            Assigned:{" "}
            <span className="font-bold text-emerald-700">
              {assignedRecords}
            </span>
          </span>
          <span className="font-medium text-slate-600">
            Pending:{" "}
            <span className="font-bold text-brand-primary">
              {pendingRecords}
            </span>
          </span>
        </div>
      </div>
      <div className="flex-1 min-h-0">
        <Virtuoso
          ref={virtuosoRef}
          className="custom-scrollbar"
          style={{ height: "100%", width: "100%" }}
          data={rows}
          itemContent={rowContent}
        />
      </div>
    </div>
  );
};

EditableAllocationTable.displayName = "EditableAllocationTable";
export default EditableAllocationTable;
