import { useSelector } from "react-redux";
import { ChevronRightIcon, EditIcon } from "../../../components/icons/icons";
import IconButton from "../../../components/ui/common/IconButton";
import IconButtonWithHover from "../../../components/ui/common/IconButtonWithHover";
import TableRecordDeleteButton from "../../../components/ui/common/TableRecordDeleteButton";
import { canPerformOperation, ROLES } from "../../../constants/roles";
import UserAllocationExpandedRow from "./UserAllocationExpandedRow";

/**
 * UserAllocationTableRow
 *
 * Renders a single data row inside the rack allocation table. Includes an expand/collapse toggle, main metadata columns, and an edit action. When expanded, mounts a UserAllocationExpandedRow beneath the main row.
 *
 * @param {object} rec - The full rack allocation record object from the API.
 * @param {number} index - Zero-based row index within the current page.
 * @param {number} serialNumber - The precomputed serial number to display.
 * @param {boolean} isExpanded - Whether the detail panel is currently open.
 * @param {function} onToggle - Called when the expand/collapse button is clicked.
 * @param {number} colSpan - Total column count passed to UserAllocationExpandedRow.
 * @param {function} onEditClick - Called with the record object when the edit button is clicked.
 * @param {function} onDeleteClick - Callback when delete action is clicked.
 * @param {boolean} isDeleting - Global deleting state.
 */
const UserAllocationTableRow = ({
  rec,
  serialNumber,
  isExpanded,
  onToggle,
  colSpan,
  onEditClick,
  onDeleteClick,
  isDeleting,
}) => {
  const { roleName, userEmployeeCode } = useSelector((state) => state.user);
  const canDelete = canPerformOperation(userEmployeeCode);
  const isCpu = roleName === ROLES.CPU;
  const { assignedStatus } = rec; // NOSONAR
  const isPending = assignedStatus?.toLowerCase() === "pending";
  return (
    <>
      <tr
        onClick={onToggle}
        className="hover:bg-slate-200/80 transition-colors cursor-pointer border-b border-border-subtle"
      >
        <td
          className="table-td-center"
          onClick={(e) => {
            e.stopPropagation();
            onToggle();
          }}
        >
          <IconButton
            onClick={(e) => {
              e.stopPropagation();
              onToggle();
            }}
            className="p-1 hover:bg-slate-200 text-text-secondary shadow-none border-none bg-transparent hover:text-text-secondary focus:outline-none"
            ariaLabel={isExpanded ? "Collapse row" : "Expand row"}
            icon={
              <ChevronRightIcon
                className={`w-4 h-4 transition-transform duration-200 ${
                  isExpanded ? "rotate-90" : ""
                }`}
              />
            }
          />
        </td>
        <td className={isCpu ? "table-td-middle-cpu" : "table-td-middle"}>
          {serialNumber}
        </td>
        <td className={isCpu ? "table-td-middle-cpu" : "table-td-middle"}>
          {rec.appNo || "—"}
        </td>
        <td className="px-6 py-1 text-sm font-medium text-text-primary whitespace-nowrap align-middle">
          {rec.assignedUser?.userName
            ? `${rec.assignedUser.userName}${rec.assignedUser.userEmployeeCode ? ` (${rec.assignedUser.userEmployeeCode})` : ""}`
            : "—"}
        </td>
        <td className={isCpu ? "table-td-middle-cpu" : "table-td-middle"}>
          {rec.fileType || "—"}
        </td>
        <td
          className={`${isCpu ? "table-td-middle-cpu" : "table-td-middle"} ${
            rec.ageingNo !== "" &&
            rec.ageingNo != null &&
            Number(rec.ageingNo) > 15
              ? "text-red-600 font-bold"
              : ""
          }`}
        >
          {rec.ageingNo !== "" && rec.ageingNo != null ? rec.ageingNo : "—"}
        </td>
        <td className={isCpu ? "table-td-middle-cpu" : "table-td-middle"}>
          {rec.customerName || "—"}
        </td>
        <td className={isCpu ? "table-td-middle-cpu" : "table-td-middle"}>
          {rec.rackName || "—"}
        </td>
        <td className={isCpu ? "table-td-middle-cpu" : "table-td-middle"}>
          {rec.rackPosition || "—"}
        </td>
        {(typeof onEditClick === "function" || canDelete) && (
          <td className="table-td-center">
            <div className="flex items-center justify-center gap-1">
              {typeof onEditClick === "function" && (
                <IconButtonWithHover
                  onClick={(e) => {
                    e.stopPropagation();
                    onEditClick(rec);
                  }}
                  icon={<EditIcon />}
                  label="Edit Record"
                  colorClass="hover:text-brand-primary hover:bg-brand-primary/5"
                />
              )}
              {canDelete && typeof onDeleteClick === "function" && (
                <TableRecordDeleteButton
                  recordId={rec.rackAssignedId}
                  onDeleteClick={onDeleteClick}
                  isDeleting={isDeleting}
                  label="Delete Record"
                />
              )}
            </div>
          </td>
        )}
      </tr>

      <UserAllocationExpandedRow
        rec={rec}
        colSpan={colSpan}
        isExpanded={isExpanded}
      />
    </>
  );
};

UserAllocationTableRow.displayName = "UserAllocationTableRow";

export default UserAllocationTableRow;
