import { useState } from "react";
import { useSelector } from "react-redux";
import { canPerformOperation } from "../../../constants/roles";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { USER_ALLOCATION_TABLE_COLUMNS } from "../../../constants/tableHeaders";
import UserAllocationTableRow from "./UserAllocationTableRow";

/**
 * UserAllocationTable
 *
 * Renders the paginated list of rack-assigned records inside a scrollable Table. Supports row-level expand/collapse via UserAllocationExpandedRow. Shows a skeleton loader while fetching and an EmptyState when no records exist.
 *
 * @param {object[]} records - Array of rack allocation record objects from the API.
 * @param {boolean} loading - True while records are being fetched.
 * @param {string} error - Error message if the fetch failed; suppresses EmptyState.
 * @param {number} page - Current page number (1-based) used to compute S.No.
 * @param {number} pageSize - Number of records per page used to compute S.No.
 * @param {function} onEditClick - Called with the record object when the edit button is clicked.
 * @param {function} onDeleteClick - Callback when delete action is clicked.
 * @param {boolean} isDeleting - Global deleting state.
 */
const UserAllocationTable = ({
  records,
  loading,
  error,
  page,
  pageSize,
  onEditClick,
  onDeleteClick,
  isDeleting,
}) => {
  const { userEmployeeCode } = useSelector((state) => state.user);
  const canDelete = canPerformOperation(userEmployeeCode);
  const [expandedRows, setExpandedRows] = useState({});

  const toggleRow = (id) => {
    setExpandedRows((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const hasEdit = typeof onEditClick === "function" || canDelete;
  const displayedHeaders = hasEdit
    ? USER_ALLOCATION_TABLE_COLUMNS
    : USER_ALLOCATION_TABLE_COLUMNS.filter((col) => col.label !== "Actions");
  const colSpan = displayedHeaders.length;

  return (
    <Table headers={displayedHeaders} headerColorClass="bg-table-header-bg">
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow key={i} columnsCount={colSpan} />
        ))
      ) : records.length === 0 && !error ? (
        <tr>
          <td colSpan={colSpan} className="h-full">
            <EmptyState
              title="No allocations found"
              description={
                hasEdit
                  ? "No rack assignments found for your account. Click 'Allocate to User' to create one."
                  : "No rack assignments found for your account."
              }
            />
          </td>
        </tr>
      ) : (
        records.map((rec, index) => (
          <UserAllocationTableRow
            key={rec.rackAssignedId}
            rec={rec}
            index={index}
            serialNumber={(page - 1) * pageSize + index + 1}
            isExpanded={!!expandedRows[rec.rackAssignedId]}
            onToggle={() => toggleRow(rec.rackAssignedId)}
            colSpan={colSpan}
            onEditClick={onEditClick}
            onDeleteClick={onDeleteClick}
            isDeleting={isDeleting}
          />
        ))
      )}
    </Table>
  );
};

UserAllocationTable.displayName = "UserAllocationTable";
export default UserAllocationTable;
