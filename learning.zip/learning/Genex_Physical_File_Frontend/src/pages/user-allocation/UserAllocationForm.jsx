import { useCallback, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getRackAssignedApi, updateRackAssignedApi } from "../../api/apiConfig";
import LandscapeFormContainer from "../../components/layout/LandscapeFormContainer";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FormFooter from "../../components/ui/common/FormFooter";
import FormHeader from "../../components/ui/common/FormHeader";
import SearchableSelectField from "../../components/ui/common/SearchableSelectField";
import SelectField from "../../components/ui/common/SelectField";
import { ALLOCATION_ENUMS } from "../../constants/stages";
// import { useFileTypes } from "../../hooks/dropdowns/useFileTypes";
import { useRackDropdown } from "../../hooks/dropdowns/useRackDropdown";
import { useUsersDropdown } from "../../hooks/dropdowns/useUsersDropdown";
import { useVaultDropdown } from "../../hooks/dropdowns/useVaultDropdown";
import { useApi } from "../../hooks/useApi";
import {
  userAllocationFormSchema,
  userAllocationRowSchema,
} from "../../utils/schemas/configSchema";
import EditableAllocationTable from "./components/EditableAllocationTable";
import { UserAllocationFormContext } from "./contexts/UserAllocationFormContext";

/**
 * Empty row factory — defines the shape of each allocation entry.
 */
const createEmptyRow = () => ({
  assignedUser: "",
  rackId: "",
  rackName: "",
  self: "",
  rackAppCount: "",
  assignedStatus: null,
});

/**
 * UserAllocationForm
 *
 * Full-width landscape form that collects one or more user allocation entries
 * and submits them as an array to PUT /rackAssigned.
 * Displays a Rack multi-select dropdown and an inline editable table.
 *
 * Fetches the unassigned dispatch records for the selected rack, and populates
 * them into the table for individual user assignment.
 */
const UserAllocationForm = () => {
  const { userId: currentUserId } = useSelector((state) => state.user);
  const [userSearchTerm, setUserSearchTerm] = useState("");
  const {
    options: usersOptions,
    loading: usersLoading,
    hasMore: usersHasMore,
    fetchPage: fetchUsersPage,
    page: usersPage,
  } = useUsersDropdown(true, userSearchTerm);

  const handleUserLoadMore = useCallback(() => {
    if (usersHasMore && !usersLoading) {
      fetchUsersPage(usersPage, userSearchTerm);
    }
  }, [usersHasMore, usersLoading, fetchUsersPage, usersPage, userSearchTerm]);

  // const { options: fileTypeOptions } = useFileTypes();
  const fileTypeOptions = []; // Fallback empty array

  const navigate = useNavigate();

  const [rows, setRows] = useState([]);
  const [validationErrors, setValidationErrors] = useState([]);
  const [touchedFields, setTouchedFields] = useState({});
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [submitWarning, setSubmitWarning] = useState(null);

  const {
    execute: updateRackAssigned,
    isLoading: isSubmittingAPI,
    error: submitError,
    setError: setSubmitError,
  } = useApi(updateRackAssignedApi);

  const handleClose = () => {
    navigate("..");
  };

  const [selectedVault, setSelectedVault] = useState("V1");
  const [vaultDropdownEnabled, setVaultDropdownEnabled] = useState(false);
  const { options: vaultOptions } = useVaultDropdown(vaultDropdownEnabled);

  const [selectedRackOpt, setSelectedRackOpt] = useState(null);

  const [rackSearchTerm, setRackSearchTerm] = useState("");
  const {
    options: rackOptions,
    loading: rackLoading,
    hasMore: rackHasMore,
    fetchPage: fetchRackPage,
    page: rackPage,
  } = useRackDropdown(
    !!selectedVault,
    rackSearchTerm,
    false,
    true,
    selectedVault,
  );

  const handleRackLoadMore = useCallback(() => {
    if (rackHasMore && !rackLoading) {
      fetchRackPage(rackPage, rackSearchTerm);
    }
  }, [rackHasMore, rackLoading, fetchRackPage, rackPage, rackSearchTerm]);

  const contextValue = {
    usersOptions,
    usersLoading,
    usersHasMore,
    handleUserLoadMore,
    userSearchTerm,
    setUserSearchTerm,
    fileTypeOptions,
    rackOptions,
    rackLoading,
    rackHasMore,
    handleRackLoadMore,
    rackSearchTerm,
    setRackSearchTerm,
  };

  // ── Row management ────────────────────────────────────────────────────────
  const handleRowChange = (index, field, value) => {
    setRows((prev) => {
      const updatedRows = [...prev];
      updatedRows[index] = { ...updatedRows[index], [field]: value };
      if (field === "rackId") {
        updatedRows[index].rackSelectedAt = value ? Date.now() : undefined;
      }

      // Live validate the single row
      const rowResult = userAllocationRowSchema.safeParse(updatedRows[index]);
      setValidationErrors((prevErrors) => {
        const nextErrors = [...prevErrors];
        const rowErrors = {};

        if (!rowResult.success) {
          const issues = rowResult.error.issues || rowResult.error.errors || [];
          issues.forEach((issue) => {
            const issueField = issue.path[0];
            if (typeof issueField === "string") {
              rowErrors[issueField] = issue.message;
            }
          });
        }
        nextErrors[index] = rowErrors;
        return nextErrors;
      });

      return updatedRows;
    });
  };

  const handleBulkAssignedUserChange = (opt) => {
    const selectedUserId = opt?.value || "";
    const selectedUserName = opt?.label || "";
    if (!selectedUserId) return;

    if (selectedRows.size === 0) {
      setSubmitWarning(
        "Please select the pending records to assign it to user.",
      );
      return;
    }

    setSubmitWarning(null);

    setRows((prevRows) => {
      const updatedRows = prevRows.map((row, index) => {
        if (!selectedRows.has(index)) return row;
        return {
          ...row,
          assignedUser: selectedUserId,
          assignedUserName: selectedUserName,
        };
      });

      // Live validate all updated rows
      setValidationErrors((prevErrors) => {
        const nextErrors = [...prevErrors];
        updatedRows.forEach((row, index) => {
          if (!selectedRows.has(index)) return;
          const rowResult = userAllocationRowSchema.safeParse(row);
          const rowErrors = {};

          if (!rowResult.success) {
            const issues =
              rowResult.error.issues || rowResult.error.errors || [];
            issues.forEach((issue) => {
              const issueField = issue.path[0];
              if (typeof issueField === "string") {
                rowErrors[issueField] = issue.message;
              }
            });
          }
          nextErrors[index] = rowErrors;
        });
        return nextErrors;
      });

      return updatedRows;
    });

    // Uncheck rows after assignment
    setSelectedRows(new Set());
  };

  const handleToggleRow = useCallback((index, checked) => {
    setSelectedRows((prev) => {
      const next = new Set(prev);
      if (checked) next.add(index);
      else next.delete(index);
      return next;
    });
  }, []);

  const handleToggleAll = useCallback(
    (checked) => {
      if (checked) {
        setSelectedRows(new Set(rows.map((_, i) => i)));
      } else {
        setSelectedRows(new Set());
      }
    },
    [rows],
  );

  const handleBlur = (index, field) => {
    const key = `${index}_${field}`;
    setTouchedFields((prev) => {
      if (prev[key]) return prev;
      return { ...prev, [key]: true };
    });

    // Validate the row immediately on focus out to ensure errors are updated
    setRows((prevRows) => {
      const row = prevRows[index];
      if (row) {
        const rowResult = userAllocationRowSchema.safeParse(row);
        setValidationErrors((prevErrors) => {
          const nextErrors = [...prevErrors];
          const rowErrors = {};
          if (!rowResult.success) {
            const issues =
              rowResult.error.issues || rowResult.error.errors || [];
            issues.forEach((issue) => {
              const issueField = issue.path[0];
              if (typeof issueField === "string") {
                rowErrors[issueField] = issue.message;
              }
            });
          }
          nextErrors[index] = rowErrors;
          return nextErrors;
        });
      }
      return prevRows;
    });
  };

  const removeRow = (index) => {
    setRows((prev) => prev.filter((_, i) => i !== index));
    setValidationErrors((prev) => prev.filter((_, i) => i !== index));
    setTouchedFields((prev) => {
      const next = {};
      Object.keys(prev).forEach((key) => {
        const parts = key.split("_");
        const rIndex = parseInt(parts[0], 10);
        const fieldName = parts.slice(1).join("_");
        if (rIndex < index) {
          next[key] = prev[key];
        } else if (rIndex > index) {
          next[`${rIndex - 1}_${fieldName}`] = prev[key];
        }
      });
      return next;
    });
  };

  const handleRackSelect = async (opt) => {
    setSelectedRackOpt(opt || null);
    if (!opt || !opt.value) {
      setRows([]);
      setValidationErrors([]);
      setTouchedFields({});
      setSelectedRows(new Set());
      return;
    }

    try {
      const response = await getRackAssignedApi({
        assignedRack: opt.value,
        userAssigned: false,
        limit: 45,
      });
      const records = response?.data?.data || [];

      if (records.length === 0) {
        setRows([]);
        setValidationErrors([]);
        setTouchedFields({});
        setSelectedRows(new Set());
        return; // No unassigned records found
      }

      const newRows = records.map((rec) => ({
        ...createEmptyRow(),
        rackAssignedId: rec.rackAssignedId,
        ageingNo: rec.ageingNo ?? "",
        appNo: rec.appNo || "",
        barcode: rec.barcode || "",
        customerName: rec.customerName || "",
        fileTypeId: rec.fileTypeId || "",
        fileType: rec.fileType || "",
        rackId: rec.rackId || opt.value,
        rackName: rec.rackName || opt.label,
        position: rec.rackPosition || "N/A",
        assignedStatus: rec.assignedStatus || null,
        genexFromBranch: rec.genexFromBranch || null,
      }));

      setRows(newRows);
      setTouchedFields({});
      setValidationErrors(records.map(() => ({})));
    } catch (error) {
      console.error("Failed to fetch rack assigned records", error);
    }
  };

  // ── Validation ────────────────────────────────────────────────────────────
  const validate = () => {
    const result = userAllocationFormSchema.safeParse(rows);
    if (!result.success) {
      const issues = result.error.issues || result.error.errors || [];

      // Set all validation errors in the state array
      const errorsArray = Array.from({ length: rows.length }).map(() => ({}));
      issues.forEach((issue) => {
        const rowIndex = issue.path[0];
        const fieldName = issue.path[1];
        if (typeof rowIndex === "number" && typeof fieldName === "string") {
          errorsArray[rowIndex][fieldName] = issue.message;
        }
      });
      setValidationErrors(errorsArray);

      const firstError = issues[0];
      if (firstError) {
        const pathIndex = firstError.path[0];
        const message = firstError.message;

        if (typeof pathIndex === "number") {
          return `Entry #${pathIndex + 1}: ${message}`;
        }
        return message;
      }
      return "Please fix all validation errors in the table.";
    }
    setValidationErrors([]);
    return null;
  };

  // ── Submission ────────────────────────────────────────────────────────────
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSubmittingAPI) return;

    setSubmitError(null);
    const rowsToSubmit = rows.filter((row) => row.assignedUser);

    if (rowsToSubmit.length === 0) {
      setSubmitError("No records have been assigned to a user yet.");
      return;
    }

    const validationError = validate();
    if (validationError) {
      // Only error if the invalid row is one we are trying to submit
      const hasErrorsInSubmittingRows = rows.some(
        (row, i) =>
          row.assignedUser && Object.keys(validationErrors[i] || {}).length > 0,
      );
      if (hasErrorsInSubmittingRows) {
        setSubmitError(validationError);
        setTouchedFields(() => {
          const allTouched = {};
          rows.forEach((row, rowIndex) => {
            if (row.assignedUser) {
              const fields = ["assignedUser", "rackId"];
              fields.forEach((fieldName) => {
                allTouched[`${rowIndex}_${fieldName}`] = true;
              });
            }
          });
          return allTouched;
        });
        return;
      }
    }

    const payload = rowsToSubmit.map((row) => ({
      rackAssignedId: row.rackAssignedId,
      ageingNo: row.ageingNo || "",
      healthcheckUser: row.assignedUser || null,
      appNo: row.appNo || null,
      aggNo: row.aggNo || null,
      barcode: row.barcode || null,
      assignedUser: row.assignedUser || null,
      fileTypeId: row.fileTypeId || null,
      rackId: row.rackId,
      podNo: row.podNo || null,
      customerName: row.customerName || null,
      schemaProduct: row.schemaProduct || null,
      scheme: row.scheme || null,
      isESign: row.isESign || null,
      amountFinance: row.amountFinance || null,
      createdBy: currentUserId,
      userAssigned: true,
      modifiedBy: currentUserId,
      assignedStatus: row.assignedStatus || null,
      genexFromBranch: row.genexFromBranch || null,
    }));

    const { error } = await updateRackAssigned(payload, {
      rackAllocationAction: ALLOCATION_ENUMS.ASSIGN_USER,
    });

    if (!error) {
      navigate("..", {
        state: {
          savedSuccess: true,
          successMessage:
            "User Allocations updated successfully and moved to Health Check",
        },
      });
    }
  };

  // ── Render ────────────────────────────────────────────────────────────────
  const assignedCount = rows.filter((r) => r.assignedUserName).length;

  return (
    <LandscapeFormContainer className="mb-4">
      <FormHeader
        title="Allocate to User"
        onBack={handleClose}
        rightContent={
          <div className="flex items-center gap-1.5 whitespace-nowrap">
            <span className="text-sm font-medium text-text-primary">
              Added records:
            </span>
            <span className="text-xl font-bold text-brand-primary leading-none">
              {rows.length}
            </span>
          </div>
        }
      />

      <form onSubmit={handleSubmit} noValidate>
        {/* Banners */}
        <ErrorBanner
          type="warning"
          message={submitWarning}
          onClose={() => setSubmitWarning(null)}
        />
        <ErrorBanner
          message={submitError}
          onClose={() => setSubmitError(null)}
        />

        <div className="flex flex-col lg:flex-row gap-6 items-start">
          {/* Selectors vertical container (left) */}
          <fieldset className="flex flex-col gap-4 w-full lg:w-1/3 xl:w-1/4">
            {/* 1. Vault Selection */}
            <div>
              <SelectField
                label="1. Select Vault"
                name="top_assigned_vault"
                value={selectedVault}
                onChange={(e) => {
                  setSelectedVault(e.target.value);
                  setRackSearchTerm("");
                  setSelectedRackOpt(null);
                  setRows([]);
                  setValidationErrors([]);
                  setTouchedFields({});
                }}
                options={vaultOptions}
                placeholder="Select vault"
                className="mb-0 w-full"
                onOpen={() => setVaultDropdownEnabled(true)}
              />
            </div>

            {/* Rack selection dropdown */}
            <div>
              <SearchableSelectField
                label="2. Select Rack Records to Allocate"
                name="rack_top"
                value={selectedRackOpt?.value || ""}
                onChange={handleRackSelect}
                options={rackOptions}
                searchTerm={rackSearchTerm}
                onSearchChange={setRackSearchTerm}
                isLoadingMore={rackLoading}
                hasMore={rackHasMore}
                onLoadMore={handleRackLoadMore}
                className="mb-0 w-full"
                disabled={!selectedVault}
                placeholder={
                  !selectedVault ? "Select vault first" : "Select rack..."
                }
              />
            </div>

            {/* Bulk User assignment - rendered conditionally when rows exist */}
            {rows.length > 0 && (
              <>
                <div>
                  <SearchableSelectField
                    label="3. Bulk Assign User"
                    name="bulk_assigned_user"
                    value=""
                    onChange={handleBulkAssignedUserChange}
                    options={usersOptions}
                    placeholder="Select user to apply to all rows"
                    searchTerm={userSearchTerm}
                    onSearchChange={setUserSearchTerm}
                    isLoadingMore={usersLoading}
                    hasMore={usersHasMore}
                    onLoadMore={handleUserLoadMore}
                    className="mb-0 w-full"
                  />
                </div>

                <p className="text-xs text-text-secondary mt-1">
                  Select at least one record to enable actions.
                </p>
              </>
            )}
          </fieldset>

          {/* Table View (right) */}
          <section className="w-full lg:w-2/3 xl:w-3/4 lg:mb-4">
            <UserAllocationFormContext.Provider value={contextValue}>
              <EditableAllocationTable
                rows={rows}
                errors={validationErrors}
                touchedFields={touchedFields}
                onBlur={handleBlur}
                onChange={handleRowChange}
                onRemove={removeRow}
                selectedRows={selectedRows}
                onToggleRow={handleToggleRow}
                onToggleAll={handleToggleAll}
              />
            </UserAllocationFormContext.Provider>
          </section>
        </div>

        <FormFooter
          buttons={[
            {
              label: isSubmittingAPI
                ? "Saving..."
                : `Submit ${assignedCount > 0 ? `(${assignedCount} entries)` : ""}`,
              props: {
                type: "submit",
                disabled: isSubmittingAPI || assignedCount === 0,
              },
            },
          ]}
        />
      </form>
    </LandscapeFormContainer>
  );
};

UserAllocationForm.displayName = "UserAllocationForm";
export default UserAllocationForm;
