import { useState } from "react";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import NavigationBanners from "../../components/ui/common/NavigationBanners";
import Pagination from "../../components/ui/common/Pagination";
import { APP_STAGES } from "../../constants/stages";
import useNavigationBanners from "../../hooks/useNavigationBanners";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import useTransactionFetch from "../../hooks/useTransactionFetch";
import HealthCheckTable from "./components/HealthCheckTable";

/** Options for the "Filter by Stage" dropdown */
const STAGE_FILTER_OPTIONS = [
  { value: APP_STAGES.HEALTH_CHECK, label: "Health Check" },
  { value: APP_STAGES.QUERY_RESOLVED, label: "Query Case - Health Check" },
];

/**
 * HealthCheckList
 *
 * Container component for Health Check data management. Handles fetching,
 * searching, paginating, and filtering by stage (Health Check / Query Resolved).
 */

const HealthCheckList = () => {
  const {
    successMessage,
    setSuccessMessage,
    warningMessage,
    setWarningMessage,
  } = useNavigationBanners();

  // "" means "All" → both stages; otherwise a single stage value is passed.
  const [stageFilter, setStageFilter] = useState("");

  const activeStage = stageFilter
    ? stageFilter
    : `${APP_STAGES.HEALTH_CHECK},${APP_STAGES.QUERY_RESOLVED}`;

  const { fetchFn } = useTransactionFetch({ stage: activeStage });

  const {
    data: records,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "likeAppNoOrBarcode");

  const handleRefresh = async () => {
    await refetch();
  };

  return (
    <ListContainer>
      <ListHeader
        title="Health Check"
        unit="records"
        count={pagination.totalItems}
        loading={loading}
        search={search}
        setSearch={setSearch}
        refetch={handleRefresh}
      >
        {/* ── Stage Filter ── */}
        <section className="mt-3 flex flex-wrap items-center gap-3">
          <FilterSelectField
            label="Filter by Stage:"
            name="stageFilter"
            value={stageFilter}
            onChange={(e) => {
              setStageFilter(e.target.value);
              setPage(1);
            }}
            options={STAGE_FILTER_OPTIONS}
            placeholder="All"
            buttonClass="min-w-40"
          />
        </section>
      </ListHeader>

      <NavigationBanners
        successMessage={successMessage}
        setSuccessMessage={setSuccessMessage}
        warningMessage={warningMessage}
        setWarningMessage={setWarningMessage}
        error={error}
        setError={setError}
      />

      <HealthCheckTable
        records={records}
        loading={loading}
        error={error}
        search={search}
        page={page}
        pageSize={pageSize}
      />

      {/* ── Pagination ── */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />
    </ListContainer>
  );
};

HealthCheckList.displayName = "HealthCheckList";
export default HealthCheckList;
