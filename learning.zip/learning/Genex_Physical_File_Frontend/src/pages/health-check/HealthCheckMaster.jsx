import { Route, Routes } from "react-router-dom";
import TransactionDetailsPage from "../../components/ui/transaction/TransactionDetailsPage";
import { ROUTES } from "../../router/routes";
import { healthCheckTransactionSchema } from "../../utils/schemas/configSchema";
import HealthCheckFileDetails from "./components/HealthCheckFileDetails";
import HealthCheckList from "./HealthCheckList";

/**
 * HealthCheckMaster
 *
 * Renders the HealthCheck routing component.
 */
const HealthCheckMaster = () => {
  return (
    <Routes>
      <Route path="/" element={<HealthCheckList />} />
      <Route
        path={ROUTES.FEATURES.TRANSACTION.HEALTH_CHECK.DETAILS}
        element={
          <TransactionDetailsPage
            schema={healthCheckTransactionSchema}
            isHealthCheck={true}
            title="Health Check Details"
            FileDetailsComponent={HealthCheckFileDetails}
          />
        }
      />
    </Routes>
  );
};

HealthCheckMaster.displayName = "HealthCheckMaster";
export default HealthCheckMaster;
