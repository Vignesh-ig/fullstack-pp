import { useNavigate } from "react-router-dom";
import { updateTransactionLockApi } from "../../../api/apiConfig";
import TaskStatusBadge from "../../../components/ui/badge/TaskStatusBadge";
import { StampTypeBadge } from "../../../components/ui/badge/badgeIndex";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { APP_STAGES, STAGE_NAMES } from "../../../constants/stages";
import { STAMP_TYPE } from "../../../constants/stampingConstants";
import { TASK_STATUS } from "../../../constants/status";
import { HEALTH_CHECK_TABLE_COLUMNS } from "../../../constants/tableHeaders";
import { ROUTES } from "../../../router/routes";
import { toTitleCase } from "../../../utils/utils";

/**
 * Maps a health-check stage name to the corresponding TaskStatusBadge status.
 * HEALTH_CHECK  → PENDING  (badge-status-pending)
 * QUERY_RESOLVED → IN_PROCESS (badge-status-in-process)
 */
const STAGE_TO_TASK_STATUS = {
  [APP_STAGES.HEALTH_CHECK]: TASK_STATUS.PENDING,
  [APP_STAGES.QUERY_RESOLVED]: TASK_STATUS.IN_PROCESS,
};

/**
 * HealthCheckTable
 *
 * @param {object[]} records - Array of health check data objects.
 * @param {boolean} loading - Loading state for data fetching.
 * @param {string} error - Error message if fetching fails.
 * @param {string} search - Current search query (for empty state messaging).
 * @param {number} page - Current page number (for serial numbers).
 * @param {number} pageSize - Page size (for serial numbers).
 */
const HealthCheckTable = ({
  records = [],
  loading,
  error,
  search,
  page,
  pageSize,
}) => {
  const navigate = useNavigate();

  const handleRowClick = async (record) => {
    // Navigate using appNo or barcode as requested by the user
    const id = record.appNo || record.barcode;
    if (id) {
      try {
        await updateTransactionLockApi({
          appNos: record.appNo,
          isLocked: true,
        });
        navigate(
          ROUTES.FEATURES.TRANSACTION.HEALTH_CHECK.DETAILS.replace(
            ":id",
            encodeURIComponent(id),
          ),
          { state: { record } },
        );
      } catch (err) {
        console.error("Failed to lock transaction:", err);
        alert(
          err?.response?.data?.message ||
            "This record is already locked by another user or cannot be accessed right now.",
        );
      }
    }
  };

  return (
    <Table
      headers={HEALTH_CHECK_TABLE_COLUMNS}
      headerColorClass="bg-table-header-bg"
    >
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow
            key={i}
            columnsCount={HEALTH_CHECK_TABLE_COLUMNS.length}
          />
        ))
      ) : records.length === 0 && !error ? (
        <tr>
          <td colSpan={HEALTH_CHECK_TABLE_COLUMNS.length} className="h-full">
            <EmptyState
              title="No records found"
              description={
                search
                  ? `No results for "${search}". Try a different search.`
                  : "No health check records available."
              }
              
            />
          </td>
        </tr>
      ) : (
        records.map((record, index) => (
          <tr
            key={record.transactionId || index}
            onClick={() => handleRowClick(record)}
            className="hover:bg-brand-primary/5 transition-colors cursor-pointer"
          >
            <td className="table-td">{(page - 1) * pageSize + index + 1}</td>
            <td className="table-td">{record.appNo || "—"}</td>
            <td className="table-td">{record.aggNo || "—"}</td>
            <td className="table-td">{record.barcode || "—"}</td>
            <td className="table-td">
              {record.branchDesc ? toTitleCase(record.branchDesc) : "—"}
            </td>
            <td className="table-td">{record.customerName || "—"}</td>
             {/* <td className="table-td-center">{"—"}</td> */}
            <td className="table-td-center">
              <StampTypeBadge
                stampType={
                  record.stampType
                    ? record.stampType.toUpperCase()
                    : STAMP_TYPE.NO_STAMPING
                }
              />
            </td>
            <td className="table-td-primary-rack-allocation-completed py-2.5">
              {record.stage?.stageName ? (
                <TaskStatusBadge
                  status={
                    STAGE_TO_TASK_STATUS[record.stage.stageName] ??
                    record.stage.stageName
                  }
                  label={
                    STAGE_NAMES[record.stage.stageName] ??
                    record.stage.stageName
                  }
                />
              ) : (
                "—"
              )}
            </td>
          </tr>
        ))
      )}
    </Table>
  );
};

HealthCheckTable.displayName = "HealthCheckTable";
export default HealthCheckTable;
