import { useRef, useState } from "react";
import { FileIcon } from "../../../components/icons/icons";
import { StampTypeBadge } from "../../../components/ui/badge/badgeIndex";
import StatusBadge from "../../../components/ui/badge/StatusBadge";
import DetailCard from "../../../components/ui/common/DetailCard";
import DetailField from "../../../components/ui/common/DetailField";
import DocumentButton from "../../../components/ui/common/DocumentButton";
import { APP_STAGES } from "../../../constants/stages";
import { STAMP_TYPE } from "../../../constants/stampingConstants";
import { formatDateOnlyToIST, toTitleCase } from "../../../utils/utils";

/**
 * HealthCheckFileDetails
 *
 * Renders the read-only file details card showing the current record's information.
 *
 * @param {Object} currentRecord - The current record object to display.
 */
const HealthCheckFileDetails = ({ currentRecord }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const expandRef = useRef(null);
  const containerRef = useRef(null);

  const toggleExpand = () => {
    setIsExpanded((prev) => {
      const next = !prev;

      if (next) {
        setTimeout(() => {
          expandRef.current?.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
        }, 450);
      } else {
        containerRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }

      return next;
    });
  };

  if (!currentRecord) return null;

  const assignedUser = currentRecord.assignedUser;

  return (
    <div ref={containerRef}>
      <DetailCard title="File Details" icon={FileIcon}>
        <dl className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-6 pt-2">
          {/* Always visible fields */}
          {/* <DetailField
            label="Assigned To"
            value={
              assignedUser
                ? `${assignedUser.userName} (${
                    assignedUser.userEmployeeCode ?? "N/A"
                  })`
                : "Unassigned"
            }
          />
          <DetailField
            label="Assigned To Email"
            value={assignedUser?.userEmail || "N/A"}
          /> */}
          <DetailField
            label="Application No"
            value={currentRecord.appNo || "N/A"}
          />
          <DetailField
            label="Agreement No"
            value={currentRecord.aggNo || "N/A"}
          />
          <DetailField label="Barcode" value={currentRecord.barcode || "N/A"} />
          {/* <DetailField label="Ageing" value={currentRecord.ageingNo || "N/A"} /> */}
          <DetailField
            label="Customer Name"
            value={currentRecord.customerName || "N/A"}
          />

          {/* Expanded fields */}
          {isExpanded && (
            <div ref={expandRef} className="contents">
              <DetailField
                label="File Type"
                value={currentRecord.fileType || "N/A"}
              />
              {/* <DetailField
                label="Vault Name"
                value={currentRecord.rack?.vaultName || "N/A"}
              />
              <DetailField
                label="Rack Name"
                value={currentRecord.rack?.rackName || "N/A"}
              />
              <DetailField
                label="Self"
                value={currentRecord.rack?.rackPosition || "N/A"}
              />
              <DetailField
                label="Rack Status"
                value={
                  typeof currentRecord.rack?.rackStatus === "boolean" ? (
                    <StatusBadge isActive={currentRecord.rack?.rackStatus} />
                  ) : (
                    "N/A"
                  )
                }
              /> */}
              <DetailField
                label="Scheme"
                value={currentRecord.schemaProduct || "N/A"}
              />
              <DetailField
                label="eSign Status"
                value={
                  typeof currentRecord.isESign === "boolean" ? (
                    <StatusBadge isActive={currentRecord.isESign} />
                  ) : (
                    "N/A"
                  )
                }
              />
              <DetailField
                label="State"
                value={
                  currentRecord.stateDesc
                    ? toTitleCase(currentRecord.stateDesc)
                    : currentRecord.state || "N/A"
                }
              />
              <DetailField
                label="Branch Name"
                value={currentRecord.branchDesc || "N/A"}
              />
              <DetailField
                label="Branch Code"
                value={currentRecord.genexFromBranch || "N/A"}
              />
              <DetailField
                label="Stamp Type"
                value={
                  <StampTypeBadge
                    stampType={
                      currentRecord.stampType
                        ? currentRecord.stampType.toUpperCase()
                        : STAMP_TYPE.NO_STAMPING
                    }
                  />
                }
              />
              <DetailField
                label="Stamp Amount"
                value={currentRecord.leapStampAmount || "N/A"}
              />
              <DetailField
                label="Lead ID"
                value={currentRecord.leadId || "N/A"}
              />
              <DetailField
                label="Amount Finance"
                value={currentRecord.amountFinance || "N/A"}
              />
              <DetailField
                label="Model No"
                value={currentRecord.modelNo || "N/A"}
              />
              <DetailField label="Make" value={currentRecord.make || "N/A"} />
              <DetailField
                label="Disbursement Date"
                value={formatDateOnlyToIST(currentRecord.handOffDate, "N/A")}
              />
              <DetailField
                label="EMI End Date"
                value={formatDateOnlyToIST(currentRecord.emiEndDate, "N/A")}
              />
              <DetailField
                label="POD No"
                value={currentRecord.podNo || "N/A"}
              />
              <DetailField
                label="Query POD No"
                value={currentRecord.missingPodNo || "N/A"}
              />
              <DetailField
                label="VBarcode"
                value={currentRecord.vbarCode || "N/A"}
              />
              <DetailField
                label="Current Stage"
                value={currentRecord.stage?.stageName || "N/A"}
              />
              <DetailField
                label="Query Status"
                value={
                  currentRecord.query?.queryName?.replace(/_/g, " ") || "N/A"
                }
              />
              <DetailField
                label="Loan ID"
                value={currentRecord.loanId || "N/A"}
              />
              <DetailField
                label="Business Date"
                value={formatDateOnlyToIST(currentRecord.businessDate, "N/A")}
              />
              <DetailField
                label="Sourcing Date"
                value={formatDateOnlyToIST(currentRecord.sourcingDate, "N/A")}
              />
              <DetailField
                label="Tenure"
                value={currentRecord.tenure || "N/A"}
              />
              <DetailField label="BIRR" value={currentRecord.birr || "N/A"} />
              <DetailField
                label="Registrable Status"
                value={currentRecord.registrableStatus || "N/A"}
              />
              <DetailField
                label="Udyam Number Status"
                value={currentRecord.udhayamNumberStatus || "N/A"}
              />
              <DetailField
                label="PAC Amount"
                value={currentRecord.pacAmount || "N/A"}
              />
              {currentRecord.stage?.stageName === APP_STAGES.QUERY_RESOLVED && (
                <>
                  <DetailField
                    label="Carton Barcode"
                    value={currentRecord.queryCartonBarcode || "N/A"}
                  />
                  <div className="sm:col-span-2 md:col-span-2">
                    <DetailField
                      label="Query Code"
                      value={
                        currentRecord.queryCategory?.queryCategoryName || "N/A"
                      }
                    />
                  </div>
                </>
              )}
            </div>
          )}
        </dl>

        {/* Actions */}
        <div className="flex justify-end items-center gap-4 mt-4 pt-3 border-t border-slate-200">
          <DocumentButton
            id="health-check-view-document-btn"
            appNo={currentRecord.appNo}
            customerName={currentRecord.customerName}
          />

          <button
            type="button"
            onClick={toggleExpand}
            className="text-sm font-semibold text-brand-primary underline underline-offset-2 hover:opacity-75 transition-opacity"
          >
            {isExpanded ? "Minimize" : "Expand"}
          </button>
        </div>
      </DetailCard>
    </div>
  );
};

HealthCheckFileDetails.displayName = "HealthCheckFileDetails";

export default HealthCheckFileDetails;
