import { useCallback, useEffect, useRef } from "react";
import { Virtuoso } from "react-virtuoso";
import DashedEmptyState from "../../../components/ui/common/DashedEmptyState";
import OutwardScannedCard from "./OutwardScannedCard";

/**
 * OutwardScannedTable
 *
 * Renders a virtualized list of scanned barcode record cards.
 * Mirrors EditableAllocationTable but without context dependencies or edit capabilities.
 *
 * The outer container always maintains a fixed clamp height so the left panel
 * (stretched via items-stretch) stays consistent — the submit button never moves.
 *
 * @param {Object[]} props.rows - Array of scanned transaction record objects.
 * @param {function} props.onRemove - Called with the row index to remove a record.
 */
const OutwardScannedTable = ({ rows, onRemove }) => {
  const virtuosoRef = useRef(null);
  const prevRowsLength = useRef(rows.length);

  // Auto-scroll to newest card on add
  useEffect(() => {
    if (rows.length > prevRowsLength.current) {
      setTimeout(() => {
        virtuosoRef.current?.scrollToIndex({
          index: rows.length - 1,
          align: "start",
          behavior: "smooth",
        });
      }, 50);
    }
    prevRowsLength.current = rows.length;
  }, [rows.length]);

  const rowContent = useCallback(
    (index, row) => (
      <div className="px-1 pt-1">
        <OutwardScannedCard index={index} row={row} onRemove={onRemove} />
      </div>
    ),
    [onRemove],
  );

  return (
    <div
      className="bg-white rounded-xl p-2 border border-slate-200"
      style={{ height: "clamp(400px, calc(100vh - 200px), 800px)" }}
    >
      {rows.length === 0 ? (
        <DashedEmptyState
          title="No records added yet."
          description="Scan a barcode to add records here."
        />
      ) : (
        <Virtuoso
          ref={virtuosoRef}
          className="custom-scrollbar"
          style={{ height: "100%", width: "100%" }}
          data={rows}
          itemContent={rowContent}
        />
      )}
    </div>
  );
};

OutwardScannedTable.displayName = "OutwardScannedTable";
export default OutwardScannedTable;
