/* eslint-disable react/prop-types */
import React from "react";
import StampTypeBadge from "../../../components/ui/badge/StampTypeBadge";
import StatusBadge from "../../../components/ui/badge/StatusBadge";
import RecordCard from "../../../components/ui/common/RecordCard";
import TableRecordDeleteButton from "../../../components/ui/common/TableRecordDeleteButton";
import { STAMP_TYPE } from "../../../constants/stampingConstants";
import { formatDateOnlyToIST } from "../../../utils/utils";

/**
 * OutwardScannedCard
 *
 * Renders a single scanned barcode record card inside the OutwardScannedTable.
 * Memoized to prevent re-rendering when sibling cards change.
 *
 * @param {number} props.index - Card index (0-based).
 * @param {Object} props.row - Transaction record object fetched from the API.
 * @param {string} props.row.appNo - Application number.
 * @param {string} props.row.aggNo - Agreement number.
 * @param {string} props.row.barcode - Barcode value.
 * @param {string} props.row.fileType - File type string.
 * @param {string} [props.row.stampType] - Stamp type of the record.
 * @param {function} props.onRemove - Handler called with the card index when Remove is clicked.
 */
const OutwardScannedCard = React.memo(
  ({ index, row, onRemove }) => {
    const { stampType } = row;
    return (
      <div className="transition-all duration-300 ease-out transform-gpu hover:transform-[perspective(400px)_rotateX(1.5deg)_scale(1)] hover:shadow-2xl rounded-xl">
        <RecordCard
          index={index}
          title={`Application No: ${row.appNo}`}
          details={[
            { label: "Agreement No", value: row.aggNo },
            { label: "Barcode", value: row.barcode },
            { label: "Customer Name", value: row.customerName || "N/A" },
            { label: "File Type", value: row.fileType || "N/A" },
            { label: "Scheme", value: row.schemaProduct || "N/A" },
            { label: "State", value: row.stateDesc || "N/A" },
            { label: "Branch", value: row.branchDesc || "N/A" },
            {
              label: "Agreement Generated Date",
              value: formatDateOnlyToIST(row.businessDate, "N/A"),
            },
            {
              label: "EMI End Date",
              value: formatDateOnlyToIST(row.emiEndDate, "N/A"),
            },
            {
              label: "Stamp Type",
              value: (
                <StampTypeBadge
                  stampType={
                    stampType ? stampType.toUpperCase() : STAMP_TYPE.NO_STAMPING
                  }
                />
              ),
            },
            { label: "Vault Name", value: row.rack?.vaultName || "N/A" },
            { label: "Rack Name", value: row.rack?.rackName || "N/A" },
            { label: "Self", value: row.rack?.rackPosition || "N/A" },
            { label: "Ageing", value: row.ageingNo ?? "N/A" },
            {
              label: "Esign",
              value:
                typeof row.isESign === "boolean" ? (
                  <StatusBadge isActive={row.isESign} />
                ) : (
                  "N/A"
                ),
            },
          ]}
          action={
            <TableRecordDeleteButton
              recordId={index}
              onDeleteClick={onRemove}
              label="Remove"
              bypassPermissionCheck={true}
            />
          }
        />
      </div>
    );
  },
  (prev, next) => {
    if (prev.index !== next.index) return false;
    if (prev.row !== next.row) return false;
    if (prev.onRemove !== next.onRemove) return false;
    return true;
  },
);

OutwardScannedCard.displayName = "OutwardScannedCard";
export default OutwardScannedCard;
