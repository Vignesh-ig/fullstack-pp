import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { getTransactionApi } from "../../api/apiConfig";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import InputField from "../../components/ui/common/InputField";
import SelectField from "../../components/ui/common/SelectField";
import SuccessBanner from "../../components/ui/common/SuccessBanner";
import { APP_STAGES } from "../../constants/stages";
import { useRackDropdown } from "../../hooks/dropdowns/useRackDropdown";
import { useVaultDropdown } from "../../hooks/dropdowns/useVaultDropdown";
import { useStages } from "../../hooks/useStages";
import { useTransactionSubmit } from "../../hooks/useTransactionSubmit";
import OutwardScannedTable from "./components/OutwardScannedTable";

/**
 * Outward
 *
 * Landscape two-panel form for the Outward stage.
 *
 * Left panel  (1/5) — styled exactly like Return to Rack:
 *   1. Select Vault
 *   2. Select Rack
 *   3. Scan Barcode — auto-focuses when rack is selected; on Enter triggers
 *      GET /transaction with likeAppNoOrBarcode + stages=OUTWARD.
 *   4. Select Stage — enabled only after at least one record is scanned.
 *   Submit button — pinned to bottom via mt-auto (like Return to Rack).
 *
 * Right panel (4/5) — styled like Rack Allocation:
 *   • OutwardScannedTable renders scanned records as RecordCards (Virtuoso).
 *   • DashedEmptyState shown inside a fixed-height container when no records.
 */
const Outward = () => {
  const { stageOptions } = useStages();

  // ── Vault & Rack dropdowns ─────────────────────────────────────────────────
  const [selectedVault, setSelectedVault] = useState("V1");
  const [vaultDropdownEnabled, setVaultDropdownEnabled] = useState(false);
  const { options: vaultOptions } = useVaultDropdown(vaultDropdownEnabled);

  const [selectedRackOpt, setSelectedRackOpt] = useState(null);
  const [rackSearchTerm, setRackSearchTerm] = useState("");
  const {
    options: rackOptions,
    loading: rackLoading,
    hasMore: rackHasMore,
    fetchPage: fetchRackPage,
    page: rackPage,
  } = useRackDropdown(
    !!selectedVault,
    rackSearchTerm,
    true, // showPositionInLabel
    false, // disableIfFull — outward doesn't need capacity check
    selectedVault,
  );

  const handleRackLoadMore = useCallback(() => {
    if (rackHasMore && !rackLoading) {
      fetchRackPage(rackPage, rackSearchTerm);
    }
  }, [rackHasMore, rackLoading, fetchRackPage, rackPage, rackSearchTerm]);

  // ── Scanned records state ─────────────────────────────────────────────────
  const [rows, setRows] = useState([]);
  const [barcodeInput, setBarcodeInput] = useState("");
  const [isFetchingBarcode, setIsFetchingBarcode] = useState(false);
  const [selectedStageId, setSelectedStageId] = useState("");

  // ── Banner state ──────────────────────────────────────────────────────────
  const [error, setError] = useState(null);
  const [successMsg, setSuccessMsg] = useState(null);

  const barcodeFocusRef = useRef(null);

  // Auto-focus barcode input when rack is selected (mirrors RackAllocationForm)
  useEffect(() => {
    if (selectedRackOpt && !isFetchingBarcode) {
      setTimeout(() => {
        if (barcodeFocusRef.current) {
          barcodeFocusRef.current.focus();
        }
      }, 0);
    }
  }, [selectedRackOpt, isFetchingBarcode]);

  // Auto-focus barcode input on initial page load
  useEffect(() => {
    if (barcodeFocusRef.current) {
      barcodeFocusRef.current.focus();
    }
  }, []);

  // ── Duplicate guard ───────────────────────────────────────────────────────
  const existingTransactionIds = useMemo(
    () => new Set(rows.map((r) => r.transactionId)),
    [rows],
  );

  // ── Row management ────────────────────────────────────────────────────────
  const removeRow = useCallback((index) => {
    setRows((prev) => prev.filter((_, i) => i !== index));
  }, []);

  // ── Submission ────────────────────────────────────────────────────────────
  const { onSubmit, isSaving: isSubmitting } = useTransactionSubmit(
    rows,
    [],
    stageOptions,
    setError,
    (successMessage) => {
      setRows([]);

      setSelectedStageId("");
      setSuccessMsg(successMessage);

      setTimeout(() => setSuccessMsg(null), 3000);
    },
    false,
    false,
    true,
  );

  const handleSubmit = async () => {
    if (rows.length === 0 || !selectedStageId || isSubmitting) return;
    await onSubmit({ stageId: selectedStageId });
  };

  const isSubmitDisabled =
    rows.length === 0 || !selectedStageId || isSubmitting || isFetchingBarcode;

  // ── Barcode scanning ──────────────────────────────────────────────────────
  const handleBarcodeKeyDown = async (e) => {
    if (e.key !== "Enter") return;
    e.preventDefault();

    const val = barcodeInput.trim();
    if (!val) return;

    setIsFetchingBarcode(true);
    setError(null);

    try {
      const res = await getTransactionApi({
        page: 1,
        limit: 10,
        likeAppNoOrBarcode: val,
        stages: APP_STAGES.OUTWARD,
      });

      const items = res?.data?.data || [];

      if (items.length === 0) {
        setError(`This record is not in outward queue: ${val}`);
        return;
      }

      const record = items[0];

      if (existingTransactionIds.has(record.transactionId)) {
        setError(
          `Record with Application No: ${record.appNo} is already added.`,
        );
        setBarcodeInput("");
        return;
      }

      setRows((prev) => [...prev, record]);
      setBarcodeInput("");
    } catch (err) {
      setError(
        err?.response?.data?.message ||
          err?.message ||
          "Failed to fetch barcode details",
      );
    } finally {
      setIsFetchingBarcode(false);
    }
  };

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <main className="h-fit">
      {/* Page header */}
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-3">
        <h2 className="text-lg sm:text-xl font-bold text-text-primary">
          Outward
        </h2>
        <div className="flex items-center justify-end gap-4">
          <div className="flex items-center gap-1.5 whitespace-nowrap border-l border-border-main pl-4 sm:pl-6">
            <span className="text-sm font-medium text-text-primary">
              Added records:
            </span>
            <span className="text-xl font-bold text-brand-primary leading-none">
              {rows.length}
            </span>
          </div>
        </div>
      </header>
      <div className="h-px w-full bg-border-main mb-4" />

      {/* Banners */}
      <ErrorBanner message={error} onClose={() => setError(null)} />
      <SuccessBanner message={successMsg} />

      {/* Two-panel layout — items-stretch ensures left panel fills right panel height */}
      <div className="flex flex-col lg:flex-row gap-4 lg:gap-6 items-stretch">
        {/* ── Left panel — exactly like Return to Rack ── */}
        <fieldset className="bg-white rounded-xl shadow-sm border border-border-subtle p-4 sm:p-5 flex flex-col gap-4 w-full lg:w-1/4 shrink-0 lg:mb-5">
          <div className="flex flex-col gap-4">
            {/* 1. Scan Barcode — auto-focuses when rack selected */}
            <InputField
              label="1. Scan Barcode / Enter App No"
              name="outward_barcode_scan"
              value={barcodeInput}
              ref={barcodeFocusRef}
              onChange={(e) => setBarcodeInput(e.target.value)}
              onKeyDown={handleBarcodeKeyDown}
              placeholder="Scan barcode / Enter App No"
              className="mb-0 w-full"
              onClear={() => {
                setBarcodeInput("");
                if (barcodeFocusRef.current) {
                  barcodeFocusRef.current.focus();
                }
              }}
            />

            {/* 2. Select Stage — enabled only when at least 1 record is scanned */}
            <SelectField
              label="2. Select Stage"
              name="outward_stage"
              options={stageOptions}
              value={selectedStageId}
              onChange={(e) => setSelectedStageId(e.target.value)}
              placeholder="Select Stage"
              disabled={rows.length === 0 || isSubmitting}
              className="mb-0 w-full"
            />
          </div>

          {/* Helper text — same position as Return to Rack */}
          <p className="text-xs text-text-secondary mt-1">
            Scan barcodes / Enter Application Number to add records.
          </p>

          {/* Submit button — mt-auto pins it to the bottom like Return to Rack */}
          <button
            id="outward-submit"
            type="button"
            onClick={handleSubmit}
            disabled={isSubmitDisabled}
            className={`w-full bg-brand-primary text-white font-bold py-2.5 px-4 rounded-xl shadow-lg transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-brand-accent focus:ring-offset-2 mt-auto ${
              isSubmitDisabled
                ? "opacity-30 cursor-not-allowed"
                : "cursor-pointer hover:bg-brand-hover shadow-brand-primary/20 hover:shadow-xl hover:shadow-brand-hover/40 transform hover:-translate-y-0.5"
            }`}
          >
            {isSubmitting
              ? "Saving..."
              : `Submit${rows.length > 0 ? ` (${rows.length} entries)` : ""}`}
          </button>
        </fieldset>

        {/* ── Right panel — exactly like Rack Allocation cards ── */}
        <section className="w-full lg:w-4/5 lg:mb-4">
          <OutwardScannedTable rows={rows} onRemove={removeRow} />
        </section>
      </div>
    </main>
  );
};

Outward.displayName = "Outward";
export default Outward;
