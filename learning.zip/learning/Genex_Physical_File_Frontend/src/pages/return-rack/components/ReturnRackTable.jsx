import { useState } from "react";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { RETURN_RACK_TABLE_COLUMNS } from "../../../constants/tableHeaders";
import ReturnRackTableRow from "./ReturnRackTableRow";

/**
 * ReturnRackTable
 *
 * Renders the Return Rack records table with per-row checkboxes, an expand/collapse toggle, and a select-all checkbox in the header.
 * Uses the same columns as Outward.
 *
 * @param {object[]} records - Array of rack assigned records.
 * @param {boolean} loading - Whether data is being fetched.
 * @param {string} error - Error message if fetch failed.
 * @param {string} search - Active search query.
 * @param {number} page - Current page number.
 * @param {number} pageSize - Current page size.
 * @param {Set<string>} selectedIds - Set of selected rackAssignedIds.
 * @param {function} onSelectionChange - Called with the updated Set when selection changes.
 */
const ReturnRackTable = ({
  records = [],
  loading,
  error,
  search,
  page,
  pageSize,
  selectedIds,
  onSelectionChange,
}) => {
  const [expandedRows, setExpandedRows] = useState({});

  const allPageIds = records.map((r) => r.rackAssignedId);
  const isAllSelected =
    allPageIds.length > 0 && allPageIds.every((id) => selectedIds.has(id));
  const isIndeterminate =
    !isAllSelected && allPageIds.some((id) => selectedIds.has(id));

  const handleSelectAll = () => {
    const next = new Set(selectedIds);
    if (isAllSelected) {
      allPageIds.forEach((id) => next.delete(id));
    } else {
      allPageIds.forEach((id) => next.add(id));
    }
    onSelectionChange(next);
  };

  const handleSelectOne = (id) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    onSelectionChange(next);
  };

  const toggleRow = (id) => {
    setExpandedRows((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const colSpan = RETURN_RACK_TABLE_COLUMNS.length + 1;

  const tableHeaders = [
    {
      id: "toggle",
      label: "",
      paddingClass: "px-4 py-4",
      widthClass: "w-12",
    },
    {
      id: "selectAll",
      align: "center",
      paddingClass: "px-4 py-4",
      widthClass: "w-12",
      label: (
        <input
          type="checkbox"
          className="w-4 h-4 cursor-pointer accent-brand-primary"
          checked={isAllSelected}
          ref={(el) => {
            if (el) el.indeterminate = isIndeterminate;
          }}
          onChange={handleSelectAll}
          aria-label="Select all records"
        />
      ),
    },
    ...RETURN_RACK_TABLE_COLUMNS.slice(1).map((h) => ({
      ...h,
      id: h.label,
    })),
  ];

  return (
    <Table headers={tableHeaders}>
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow key={i} columnsCount={colSpan} />
        ))
      ) : records.length === 0 && !error ? (
        <tr>
          <td colSpan={colSpan} className="h-full">
            <EmptyState
              title="No records found"
              description={
                search
                  ? `No results for "${search}". Try a different search.`
                  : "No rack assignments found."
              }
            />
          </td>
        </tr>
      ) : (
        records.map((record, index) => {
          const isChecked = selectedIds.has(record.rackAssignedId);
          return (
            <ReturnRackTableRow
              key={record.rackAssignedId || index}
              rec={record}
              serialNumber={(page - 1) * pageSize + index + 1}
              isExpanded={!!expandedRows[record.rackAssignedId]}
              onToggle={() => toggleRow(record.rackAssignedId)}
              colSpan={colSpan}
              isChecked={isChecked}
              onSelect={() => handleSelectOne(record.rackAssignedId)}
            />
          );
        })
      )}
    </Table>
  );
};

ReturnRackTable.displayName = "ReturnRackTable";
export default ReturnRackTable;
