import { ChevronRightIcon } from "../../../components/icons/icons";
import IconButton from "../../../components/ui/common/IconButton";
import ReturnRackExpandedRow from "./ReturnRackExpandedRow";

/**
 * ReturnRackTableRow
 *
 * Renders a single data row inside the return rack table.
 * Includes an expand/collapse toggle, selection checkbox, and main metadata columns.
 *
 * @param {object} rec - The record object from the API.
 * @param {number} serialNumber - The precomputed serial number to display.
 * @param {boolean} isExpanded - Whether the detail panel is currently open.
 * @param {function} onToggle - Called when the expand/collapse button is clicked.
 * @param {number} colSpan - Total column count passed to ReturnRackExpandedRow.
 * @param {boolean} isChecked - Whether the row is currently selected for bulk actions.
 * @param {function} onSelect - Called to toggle the selection of this row.
 */
const ReturnRackTableRow = ({
  rec,
  serialNumber,
  isExpanded,
  onToggle,
  colSpan,
  isChecked,
  onSelect,
}) => {
  return (
    <>
      <tr
        onClick={onToggle}
        className={`hover:bg-brand-primary/5 transition-colors cursor-pointer border-b border-border-subtle ${
          isChecked ? "bg-brand-primary/5" : ""
        }`}
      >
        <td
          className="table-td-center w-12"
          onClick={(e) => {
            e.stopPropagation();
            onToggle();
          }}
        >
          <IconButton
            onClick={(e) => {
              e.stopPropagation();
              onToggle();
            }}
            className="p-1 hover:bg-slate-200 text-text-secondary shadow-none border-none bg-transparent hover:text-text-secondary focus:outline-none"
            ariaLabel={isExpanded ? "Collapse row" : "Expand row"}
            icon={
              <ChevronRightIcon
                className={`w-4 h-4 transition-transform duration-200 ${
                  isExpanded ? "rotate-90" : ""
                }`}
              />
            }
          />
        </td>

        {/* Checkbox cell */}
        <td
          className="table-td w-12"
          onClick={(e) => {
            e.stopPropagation();
            onSelect();
          }}
        >
          <input
            type="checkbox"
            className="w-4 h-4 cursor-pointer accent-brand-primary"
            checked={isChecked}
            onChange={() => {}}
            aria-label={`Select record ${rec.appNo || rec.rackAssignedId}`}
          />
        </td>

        <td className="table-td-middle">{serialNumber}</td>
        <td className="table-td-middle">{rec.appNo || "—"}</td>
        <td className="table-td-middle">{rec.barcode || "—"}</td>
        <td className="table-td-middle">
          {rec.assignedUser?.userName
            ? `${rec.assignedUser.userName}${rec.assignedUser.userEmployeeCode ? ` (${rec.assignedUser.userEmployeeCode})` : ""}`
            : "—"}
        </td>
        <td className="table-td-middle">{rec.vaultName || "—"}</td>
        <td className="table-td-middle">{rec.rackName || "—"}</td>
      </tr>

      <ReturnRackExpandedRow
        rec={rec}
        colSpan={colSpan}
        isExpanded={isExpanded}
      />
    </>
  );
};

ReturnRackTableRow.displayName = "ReturnRackTableRow";
export default ReturnRackTableRow;
