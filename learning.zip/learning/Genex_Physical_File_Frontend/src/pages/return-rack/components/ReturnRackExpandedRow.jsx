import {
  FileIcon,
  ServerIcon,
  UserIcon,
} from "../../../components/icons/icons";
import { StatusBadge } from "../../../components/ui/badge/badgeIndex";
import DetailCard from "../../../components/ui/common/DetailCard";
import DetailField from "../../../components/ui/common/DetailField";

/**
 * ReturnRackExpandedRow
 *
 * Renders the full-width expanded detail panel for a return rack record.
 *
 * @param {object} rec - The record object from the API.
 * @param {number} colSpan - Number of columns the detail panel should span.
 * @param {boolean} isExpanded - Whether the row is expanded.
 */
const ReturnRackExpandedRow = ({ rec, colSpan, isExpanded }) => {
  return (
    <tr className="bg-slate-50/40">
      <td colSpan={colSpan} className="p-0 border-0">
        <div
          className={`expandable-row-wrapper ${isExpanded ? "expanded" : ""}`}
        >
          <div className="expandable-row-inner">
            <div className="px-6 py-4 border-b border-border-subtle">
              <section className="bg-white border border-slate-500/70 rounded-xl p-2 sm:p-5 shadow-xs grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 text-left">
                {/* Section 1: Assigned User Details */}
                <DetailCard title="Assigned User Details" icon={UserIcon}>
                  <dl className="grid min-h-24 grid-rows-[auto_1fr_auto] gap-2">
                    <DetailField
                      label="Email"
                      value={rec.assignedUser?.userEmail}
                    />
                  </dl>
                </DetailCard>

                {/* Section 2: Despatch Details */}
                <DetailCard title="Despatch Details" icon={FileIcon}>
                  <dl className="grid grid-cols-2 gap-4">
                    <DetailField label="Agreement Number" value={rec.aggNo} />
                    <DetailField
                      label="Customer Name"
                      value={rec.customerName}
                    />
                    <DetailField label="Ageing" value={rec.ageingNo} />
                    <div>
                      <dt className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                        eSign Status
                      </dt>
                      <dd className="mt-1">
                        {typeof rec.isESign === "boolean" ? (
                          <StatusBadge isActive={rec.isESign} />
                        ) : (
                          "—"
                        )}
                      </dd>
                    </div>
                  </dl>
                </DetailCard>

                {/* Section 3: Rack Details */}
                <DetailCard title="Rack Details" icon={ServerIcon}>
                  <dl className="grid grid-cols-2 gap-4">
                    <DetailField label="Self" value={rec.rackPosition} />
                    <DetailField
                      label="Count"
                      value={rec.rackAppCount ?? "—"}
                    />
                    <div>
                      <dt className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                        Rack Status
                      </dt>
                      <dd className="mt-1">
                        {typeof rec.rackStatus === "boolean" ? (
                          <StatusBadge isActive={rec.rackStatus} />
                        ) : (
                          "—"
                        )}
                      </dd>
                    </div>
                  </dl>
                </DetailCard>
              </section>
            </div>
          </div>
        </div>
      </td>
    </tr>
  );
};

ReturnRackExpandedRow.displayName = "ReturnRackExpandedRow";
export default ReturnRackExpandedRow;
