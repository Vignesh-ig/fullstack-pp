import { useCallback, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { getRackAssignedApi, updateRackAssignedApi } from "../../api/apiConfig";
import ConfirmationDialog from "../../components/ui/common/ConfirmationDialog";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import Pagination from "../../components/ui/common/Pagination";
import RefreshButton from "../../components/ui/common/RefreshButton";
import SearchableSelectField from "../../components/ui/common/SearchableSelectField";
import SearchInput from "../../components/ui/common/SearchInput";
import SelectField from "../../components/ui/common/SelectField";
import { ALLOCATION_ENUMS } from "../../constants/stages";
import { TASK_STATUS } from "../../constants/status";
import { useRackDropdown } from "../../hooks/dropdowns/useRackDropdown";
import { useUsersDropdown } from "../../hooks/dropdowns/useUsersDropdown";
import { useVaultDropdown } from "../../hooks/dropdowns/useVaultDropdown";
import { useApi } from "../../hooks/useApi";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import ReturnRackTable from "./components/ReturnRackTable";

/**
 * ReturnRack
 *
 * Landscape 20/80 layout page for returning rack-assigned files back to a rack.
 *
 * Left panel (20%): Action controls — "Select where" dropdown, and conditionally
 *   vault + rack dropdowns when "Move to another rack" is selected.
 *
 * Right panel (80%): Filters at the top (vault, rack, user), paginated
 *   ReturnRackTable with per-row selection, and Pagination (navigation only).
 *
 * Behaviour:
 * - Interacting with the "Select where" dropdown without a record selected shows
 *   a warning: "Select the record to proceed".
 * - Vault + Rack dropdowns appear only when moveOption === "another", matching
 *   the RackAllocationForm pattern exactly.
 * - "Return to rack" submit button is in the FormFooter.
 */
const MOVE_OPTIONS = [
  { value: "same", label: "Same rack" },
  { value: "another", label: "Another rack" },
];

const ReturnRack = () => {
  const { userId: currentUserId } = useSelector((state) => state.user);

  // ── Filter dropdowns (right panel header) ──────────────────────────────────
  const [vaultFilter, setVaultFilter] = useState("V1");
  const [rackFilter, setRackFilter] = useState("");
  const [rackSearchTerm, setRackSearchTerm] = useState("");
  const [assignedUserFilter, setAssignedUserFilter] = useState("");
  const [userSearchTerm, setUserSearchTerm] = useState("");

  const { options: vaultOptions } = useVaultDropdown(true);

  const {
    options: rackOptions,
    loading: rackLoading,
    hasMore: rackHasMore,
    fetchPage: fetchRackPage,
    page: rackPage,
  } = useRackDropdown(
    !!vaultFilter,
    rackSearchTerm,
    true,
    false,
    vaultFilter,
    true,
    true,
  );

  const handleRackLoadMore = useCallback(() => {
    if (rackHasMore && !rackLoading) {
      fetchRackPage(rackPage, rackSearchTerm);
    }
  }, [rackHasMore, rackLoading, fetchRackPage, rackPage, rackSearchTerm]);

  const {
    options: userOptions,
    page: usersPage,
    hasMore: usersHasMore,
    loading: usersLoading,
    fetchPage: fetchUsersPage,
  } = useUsersDropdown(true, userSearchTerm);

  const handleUserLoadMore = useCallback(() => {
    if (usersHasMore && !usersLoading) {
      fetchUsersPage(usersPage, userSearchTerm);
    }
  }, [usersHasMore, usersLoading, fetchUsersPage, usersPage, userSearchTerm]);

  // ── Paginated table data ───────────────────────────────────────────────────
  const fetchFn = useCallback(
    async (params) => {
      const { _dummySearchParam, ...restParams } = params; // NOSONAR
      const finalParams = {
        ...restParams,
        assignedStatus: TASK_STATUS.PENDING,
        userAssigned: true,
        ...(vaultFilter ? { vaultName: vaultFilter } : {}),
        ...(rackFilter ? { assignedRack: rackFilter } : {}),
        ...(assignedUserFilter ? { assignedUser: assignedUserFilter } : {}),
      };
      return getRackAssignedApi(finalParams);
    },
    [vaultFilter, rackFilter, assignedUserFilter],
  );

  const {
    data: records,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "likeAppNoOrBarcode");

  // ── Action controls state (left panel) ────────────────────────────────────
  const [moveOption, setMoveOption] = useState("same");
  const [actionVault, setActionVault] = useState("V1");
  const [actionRackSearchTerm, setActionRackSearchTerm] = useState("");
  const [actionRackOpt, setActionRackOpt] = useState(null);

  // ── Warning / submit state ────────────────────────────────────────────────
  const [actionWarning, setActionWarning] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // ── Row selection ──────────────────────────────────────────────────────────
  const [selectedIds, setSelectedIds] = useState(new Set());
  const hasSelection = selectedIds.size > 0;

  /**
   * Wraps setSelectedIds — resets action controls to defaults when the
   * last selected record is unchecked (selection becomes empty).
   */
  const handleSelectionChange = (nextIds) => {
    setSelectedIds(nextIds);
    if (nextIds.size === 0) {
      setMoveOption("same");
      setActionRackOpt(null);
      setActionRackSearchTerm("");
      setActionWarning(null);
    }
  };

  useEffect(() => {
    setSelectedIds(new Set());
    setMoveOption("same");
    setActionRackOpt(null);
    setActionRackSearchTerm("");
    setActionWarning(null);
  }, [vaultFilter, rackFilter, assignedUserFilter, search]);

  const {
    execute: updateRackAssigned,
    isLoading: isSubmitting,
    error: submitError,
    setError: setSubmitError,
  } = useApi(updateRackAssignedApi);

  const {
    options: actionRackOptions,
    loading: actionRackLoading,
    hasMore: actionRackHasMore,
    fetchPage: fetchActionRackPage,
    page: actionRackPage,
  } = useRackDropdown(
    !!actionVault && moveOption === "another",
    actionRackSearchTerm,
    true,
    true,
    actionVault,
    true,
    true,
  );

  const handleActionRackLoadMore = useCallback(() => {
    if (actionRackHasMore && !actionRackLoading) {
      fetchActionRackPage(actionRackPage, actionRackSearchTerm);
    }
  }, [
    actionRackHasMore,
    actionRackLoading,
    fetchActionRackPage,
    actionRackPage,
    actionRackSearchTerm,
  ]);

  // ── Handlers ───────────────────────────────────────────────────────────────

  /**
   * Guard: show warning if no record is selected when user touches the
   * "Select where" dropdown.
   */
  const handleMoveOptionChange = (e) => {
    if (!hasSelection) {
      setActionWarning("Select the record to proceed");
      return;
    }
    setActionWarning(null);
    setMoveOption(e.target.value);
    if (e.target.value === "same") {
      setActionRackOpt(null);
      setActionRackSearchTerm("");
    }
  };

  const handleSubmit = async () => {
    if (!hasSelection) return;

    if (error) setError(null);
    setSubmitError(null);

    const selectedRecords = records.filter((r) =>
      selectedIds.has(r.rackAssignedId),
    );

    const payload = selectedRecords.map((currentRecord) => ({
      rackAssignedId: currentRecord.rackAssignedId,
      ageingNo: currentRecord.ageingNo || "",
      healthcheckUser: null,
      appNo: currentRecord.appNo || null,
      aggNo: currentRecord.aggNo || null,
      barcode: currentRecord.barcode || null,
      assignedUser: null,
      returnAssignedUser: null,
      fileTypeId: currentRecord.fileTypeId || null,
      rackId:
        moveOption === "another" && actionRackOpt
          ? actionRackOpt.value
          : currentRecord.rackId || null,
      podNo: currentRecord.podNo || null,
      customerName: currentRecord.customerName || null,
      schemaProduct: currentRecord.schemaProduct || null,
      scheme: currentRecord.scheme || null,
      isESign: currentRecord.isESign ?? null,
      amountFinance: currentRecord.amountFinance || null,
      createdBy: currentRecord.createdBy?.userId || currentUserId,
      userAssigned: false,
      modifiedBy: currentUserId,
      assignedStatus: TASK_STATUS.PENDING,
      genexFromBranch: currentRecord.genexFromBranch || null,
    }));

    const { error: apiError } = await updateRackAssigned(payload, {
      rackAllocationAction: ALLOCATION_ENUMS.RETURN_TO_RACK,
    });

    if (!apiError) {
      setSelectedIds(new Set());
      setMoveOption("same");
      setActionRackOpt(null);
      setActionRackSearchTerm("");
      setActionWarning(null);
      setIsDialogOpen(false);
      refetch();
    }
  };

  const handleRefresh = () => {
    if (!assignedUserFilter && !rackFilter && !search) {
      refetch();
    } else {
      setAssignedUserFilter("");
      setRackFilter("");
      setVaultFilter("V1");
      setRackSearchTerm("");
      setUserSearchTerm("");
      setSearch("");
    }
  };

  // ── Submit button disabled state ───────────────────────────────────────────
  const isSubmitDisabled =
    !hasSelection ||
    isSubmitting ||
    (moveOption === "another" && !actionRackOpt?.value);

  return (
    <main className="h-fit">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-3">
        <h2 className="text-lg sm:text-xl font-bold text-text-primary">
          Return To Rack
        </h2>
        <div className="flex items-center justify-end gap-4">
          <RefreshButton onRefresh={handleRefresh} size="md" />
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder={"Search by App No or Barcode"}
            expandable
          />
          <div className="flex items-center gap-1.5 whitespace-nowrap border-l border-border-main pl-4 sm:pl-6">
            <span className="text-sm font-medium text-text-primary">
              Total records:
            </span>
            <span className="text-xl font-bold text-brand-primary leading-none">
              {pagination.totalItems}
            </span>
          </div>
          <div className="flex items-center gap-1.5 whitespace-nowrap border-l border-border-main pl-4 sm:pl-6">
            <span className="text-sm font-medium text-text-primary">
              Selected records:
            </span>
            <span className="text-xl font-bold text-brand-primary leading-none">
              {selectedIds.size}
            </span>
          </div>
        </div>
      </header>
      <div className="h-px w-full bg-border-main mb-4" />

      {/* Banners */}
      <ErrorBanner
        type="warning"
        message={actionWarning}
        onClose={() => setActionWarning(null)}
      />
      <ErrorBanner
        message={error || submitError}
        onClose={() => {
          if (error) setError(null);
          if (submitError) setSubmitError(null);
        }}
      />

      <div className="flex flex-col lg:flex-row gap-4 lg:gap-6 items-stretch">
        <fieldset className="bg-white rounded-xl shadow-sm border border-border-subtle p-4 sm:p-5 flex flex-col gap-4 w-full lg:w-1/5 shrink-0 lg:mb-5">
          <div className="flex flex-col gap-4">
            <SelectField
              label="1. Move to"
              name="moveOption"
              options={MOVE_OPTIONS}
              value={moveOption}
              onChange={handleMoveOptionChange}
              placeholder="Select Option"
              disabled={isSubmitting}
              className="mb-0 w-full"
            />

            {moveOption === "another" && (
              <>
                <SelectField
                  label="2. Select Vault"
                  name="actionVault"
                  value={actionVault}
                  onChange={(e) => {
                    setActionVault(e.target.value);
                    setActionRackOpt(null);
                    setActionRackSearchTerm("");
                  }}
                  options={vaultOptions}
                  placeholder="Select Vault"
                  className="mb-0 w-full"
                  disabled={!hasSelection || isSubmitting}
                />

                <SearchableSelectField
                  label="3. Select Rack"
                  name="actionRack"
                  value={actionRackOpt?.value || ""}
                  onChange={(opt) => setActionRackOpt(opt)}
                  options={actionRackOptions}
                  placeholder={
                    !actionVault ? "Select vault first" : "Select rack"
                  }
                  searchTerm={actionRackSearchTerm}
                  onSearchChange={setActionRackSearchTerm}
                  isLoadingMore={actionRackLoading}
                  hasMore={actionRackHasMore}
                  onLoadMore={handleActionRackLoadMore}
                  className="mb-0 w-full"
                  disabled={!actionVault || !hasSelection || isSubmitting}
                />
              </>
            )}
          </div>

          {/* Helper text */}
          <p className="text-xs text-text-secondary mt-1">
            Select at least one record to enable actions.
          </p>

          {/* Bottom (button sticks to bottom) */}
          <button
            id="return-rack-submit"
            type="button"
            onClick={() => setIsDialogOpen(true)}
            disabled={isSubmitDisabled}
            className={`w-full bg-brand-primary text-white font-bold py-2.5 px-4 rounded-xl shadow-lg transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-brand-accent focus:ring-offset-2 mt-auto ${
              isSubmitDisabled
                ? "opacity-30 cursor-not-allowed"
                : "cursor-pointer hover:bg-brand-hover shadow-brand-primary/20 hover:shadow-xl hover:shadow-brand-hover/40 transform hover:-translate-y-0.5"
            }`}
          >
            {isSubmitting
              ? "Saving..."
              : `Return to rack${
                  selectedIds.size > 0 ? ` (${selectedIds.size})` : ""
                }`}
          </button>
        </fieldset>

        <section className="w-full lg:w-4/5 lg:mb-4 flex flex-col gap-0 rounded-xl border border-table-header-bg overflow-hidden">
          <header className="px-4 py-2 sm:px-6 sm:py-3 border-b border-border-subtle bg-white">
            <div className="flex flex-row flex-wrap items-center gap-x-4 gap-y-3 w-full">
              <FilterSelectField
                label="Filter by Vault:"
                name="vaultFilter"
                value={vaultFilter}
                onChange={(e) => {
                  setVaultFilter(e.target.value);
                  setRackFilter("");
                  setRackSearchTerm("");
                }}
                placeholder="All Vaults"
                options={vaultOptions}
                buttonClass="md:min-w-20"
              />
              <FilterSelectField
                label="Filter by rack name:"
                name="rackFilter"
                value={rackFilter}
                onChange={(e) => setRackFilter(e.target.value)}
                placeholder="All Racks"
                options={rackOptions}
                showSearch={true}
                searchPlaceholder="Search by rack name"
                searchTerm={rackSearchTerm}
                onSearchChange={setRackSearchTerm}
                isLoadingMore={rackLoading}
                hasMore={rackHasMore}
                onLoadMore={handleRackLoadMore}
                disabled={!vaultFilter}
                buttonClass="md:min-w-50"
              />
              <FilterSelectField
                label="Filter by User:"
                name="assignedUserFilter"
                value={assignedUserFilter}
                onChange={(e) => setAssignedUserFilter(e.target.value)}
                placeholder="All Users"
                options={userOptions}
                showSearch={true}
                searchPlaceholder="Search by user name"
                searchTerm={userSearchTerm}
                onSearchChange={setUserSearchTerm}
                isLoadingMore={usersLoading}
                hasMore={usersHasMore}
                onLoadMore={handleUserLoadMore}
              />
            </div>
          </header>

          <ReturnRackTable
            records={records}
            loading={loading}
            error={error}
            search={search}
            page={page}
            pageSize={pageSize}
            selectedIds={selectedIds}
            onSelectionChange={handleSelectionChange}
          />

          <Pagination
            currentPage={pagination.currentPage}
            totalPages={pagination.totalPages}
            onPageChange={setPage}
            totalItems={pagination.totalItems}
            pageSize={pageSize}
            onPageSizeChange={setPageSize}
            paginationDivClass="bg-white border-t border-table-header-bg"
          />
        </section>
      </div>

      <ConfirmationDialog
        isOpen={isDialogOpen}
        content={
          <>
            <span>
              Are you sure that you're moving the selected application into{" "}
            </span>
            <span className="text-brand-primary">
              "{moveOption === "same" ? "Same Rack" : "Another Rack"}"
            </span>
            <span>?</span>
          </>
        }
        onConfirm={handleSubmit}
        onCancel={() => setIsDialogOpen(false)}
        isSubmitting={isSubmitting}
      />
    </main>
  );
};

ReturnRack.displayName = "ReturnRack";
export default ReturnRack;
