import { Route, Routes } from "react-router-dom";
import TransactionDetailsPage from "../../components/ui/transaction/TransactionDetailsPage";
import { ROUTES } from "../../router/routes";
import { nonCriticalQueryTransactionSchema } from "../../utils/schemas/configSchema";
import NonCriticalQueryFileDetails from "./components/NonCriticalQueryFileDetails";
import NonCriticalQueryList from "./NonCriticalQueryList";

/**
 * NonCriticalQueryMaster
 *
 * Renders the Non Critical Query routing component.
 */
const NonCriticalQueryMaster = () => {
  return (
    <Routes>
      <Route path="/" element={<NonCriticalQueryList />} />
      <Route
        path={ROUTES.FEATURES.TRANSACTION.NON_CRITICAL_QUERY.DETAILS}
        element={
          <TransactionDetailsPage
            schema={nonCriticalQueryTransactionSchema}
            isHealthCheck={false}
            isNonCriticalQuery={true}
            title="Non Critical Query Details"
            FileDetailsComponent={NonCriticalQueryFileDetails}
          />
        }
      />
    </Routes>
  );
};

NonCriticalQueryMaster.displayName = "NonCriticalQueryMaster";
export default NonCriticalQueryMaster;
