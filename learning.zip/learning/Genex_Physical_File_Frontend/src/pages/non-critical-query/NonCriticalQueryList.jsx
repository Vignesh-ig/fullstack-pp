import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import NavigationBanners from "../../components/ui/common/NavigationBanners";
import Pagination from "../../components/ui/common/Pagination";
import { DECISION_UPDATE_STAGES } from "../../constants/stages";
import useNavigationBanners from "../../hooks/useNavigationBanners";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import useTransactionFetch from "../../hooks/useTransactionFetch";
import NonCriticalQueryTable from "./components/NonCriticalQueryTable";

/**
 * NonCriticalQueryList
 *
 * Container component for Non Critical Query data management.
 * Handles fetching, searching, paginating, and refreshing transaction records.
 */
const NonCriticalQueryList = () => {
  const {
    successMessage,
    setSuccessMessage,
    warningMessage,
    setWarningMessage,
  } = useNavigationBanners();

  const { fetchFn } = useTransactionFetch({
    extraParams: {
      queryState: DECISION_UPDATE_STAGES.NON_CRITICAL_QUERY,
    },
  });

  const {
    data: records,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "likeAppNoOrBarcode");

  const handleRefresh = async () => {
    await refetch();
  };

  return (
    <ListContainer>
      <ListHeader
        title="Non Critical Query"
        unit="records"
        count={pagination.totalItems}
        loading={loading}
        search={search}
        setSearch={setSearch}
        refetch={handleRefresh}
      />

      <NavigationBanners
        successMessage={successMessage}
        setSuccessMessage={setSuccessMessage}
        warningMessage={warningMessage}
        setWarningMessage={setWarningMessage}
        error={error}
        setError={setError}
      />

      <NonCriticalQueryTable
        records={records}
        loading={loading}
        error={error}
        search={search}
        page={page}
        pageSize={pageSize}
      />

      {/* ── Pagination ── */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />
    </ListContainer>
  );
};

NonCriticalQueryList.displayName = "NonCriticalQueryList";
export default NonCriticalQueryList;
