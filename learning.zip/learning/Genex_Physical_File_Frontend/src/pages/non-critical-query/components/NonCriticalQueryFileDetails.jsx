import { useRef, useState } from "react";
import { useSelector } from "react-redux";
import {
  getPFDetailsApi,
  postPFDmsApi,
  uploadPFDmsDocumentApi,
} from "../../../api/apiConfig";
import { FileIcon } from "../../../components/icons/icons";
import { StampTypeBadge } from "../../../components/ui/badge/badgeIndex";
import StatusBadge from "../../../components/ui/badge/StatusBadge";
import DetailCard from "../../../components/ui/common/DetailCard";
import DetailField from "../../../components/ui/common/DetailField";
import DocumentButton from "../../../components/ui/common/DocumentButton";
import { STAMP_TYPE } from "../../../constants/stampingConstants";
import {
  formatDateOnlyToIST,
  getTodayDmsFormatted,
  sha1FromFile,
  toTitleCase,
} from "../../../utils/utils";

/**
 * NonCriticalQueryFileDetails
 *
 * Renders the read-only file details card showing the current record's information.
 *
 * @param {Object} props
 * @param {Object} props.currentRecord
 */
const NonCriticalQueryFileDetails = ({ currentRecord }) => {
  const { userEmployeeCode, userName } = useSelector((state) => state.user);
  const [uploadedCount, setUploadedCount] = useState(0);
  const [isExpanded, setIsExpanded] = useState(false);

  const expandRef = useRef(null);
  const containerRef = useRef(null);

  const toggleExpand = () => {
    setIsExpanded((prev) => {
      const next = !prev;

      if (next) {
        setTimeout(() => {
          expandRef.current?.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
        }, 450);
      } else {
        containerRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }

      return next;
    });
  };

  if (!currentRecord) return null;

  const assignedUser = currentRecord.assignedUser;
  const rack = currentRecord.rack;

  /**
   * Builds the DMS metadata payload and uploads the file.
   * Called by DocumentUploadModal with the validated File object.
   *
   * @param {File} file - The validated file selected by the user.
   * @returns {Promise<void>}
   */
  const handleDmsUpload = async (file) => {
    const checkSum = await sha1FromFile(file);
    const fileNameWithExt = file.name;
    const fileNameNoExt = fileNameWithExt.replace(/\.[^.]+$/, "");
    const format =
      file.type === "application/pdf" ? "pdf" : file.type.split("/")[1];
    const today = getTodayDmsFormatted();

    const metadata = {
      imageId: `${currentRecord.appNo}-${today}`,
      uniqueId: currentRecord.appNo,
      sourceSys: "GENEX",
      branchCode: "1",
      branch: "CHENNAI_VF",
      vertical: "VF",
      module: "Physical_File",
      stage: "1",
      imageCategory: "Genex_Physical_File",
      imageSubCategory: "PF",
      status: "1",
      fileName: fileNameWithExt,
      imageSrc: "GENEX_Physical_File",
      imageSrcId: "1",
      format,
      user: userEmployeeCode || "1",
      size: String(file.size),
      page: "10",
      createdBy: userEmployeeCode || "1",
      createdDate: today,
      checkSum,
      keyId: ["Agno"],
      keyValue: [fileNameNoExt],
    };

    const dmsId = await uploadPFDmsDocumentApi(metadata, file);

    // Fetch PF details to get the lead_id / workflow_no
    const pfDetailsRes = await getPFDetailsApi(currentRecord.appNo);

    const postPayload = {
      lead_id: pfDetailsRes?.result?.[0]?.workflow_no || "",
      dms: dmsId,
      createdBy: userEmployeeCode || "1",
      userName: userName || "User",
      document_name: fileNameWithExt,
    };
    await postPFDmsApi(postPayload);

    setUploadedCount((prev) => prev + 1);

    return dmsId;
  };

  return (
    <div ref={containerRef}>
      <DetailCard title="File Details" icon={FileIcon}>
        <dl className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-6 pt-2">
          {/* Always Visible Fields */}
          <DetailField
            label="Assigned User"
            value={
              assignedUser
                ? `${assignedUser.userName} (${
                    assignedUser.userEmployeeCode ?? "N/A"
                  })`
                : "Unassigned"
            }
          />
          <DetailField
            label="Assigned User Email"
            value={assignedUser?.userEmail || "N/A"}
          />
          <DetailField
            label="Application No"
            value={currentRecord.appNo || "N/A"}
          />
          <DetailField
            label="Agreement No"
            value={currentRecord.aggNo || "N/A"}
          />
          <DetailField label="Barcode" value={currentRecord.barcode || "N/A"} />
          <DetailField label="Ageing" value={currentRecord.ageingNo || "N/A"} />
          <DetailField
            label="Customer Name"
            value={currentRecord.customerName || "N/A"}
          />
          <DetailField
            label="File Type"
            value={currentRecord.fileType || "N/A"}
          />

          {/* Expanded Fields */}

          {isExpanded && (
            <div ref={expandRef} className="contents">
              <DetailField
                label="Vault Name"
                value={rack?.vaultName || "N/A"}
              />
              <DetailField label="Rack Name" value={rack?.rackName || "N/A"} />
              <DetailField label="Self" value={rack?.rackPosition || "N/A"} />
              <DetailField
                label="Rack Status"
                value={
                  typeof rack?.rackStatus === "boolean" ? (
                    <StatusBadge isActive={rack.rackStatus} />
                  ) : (
                    "N/A"
                  )
                }
              />
              <DetailField
                label="Scheme"
                value={currentRecord.schemaProduct || "N/A"}
              />
              <DetailField
                label="eSign Status"
                value={
                  typeof currentRecord.isESign === "boolean" ? (
                    <StatusBadge isActive={currentRecord.isESign} />
                  ) : (
                    "N/A"
                  )
                }
              />
              <DetailField
                label="State"
                value={
                  currentRecord.stateDesc
                    ? toTitleCase(currentRecord.stateDesc)
                    : currentRecord.state || "N/A"
                }
              />
              <DetailField
                label="Branch Name"
                value={currentRecord.branchDesc || "N/A"}
              />
              <DetailField
                label="Branch Code"
                value={currentRecord.genexFromBranch || "N/A"}
              />
              <DetailField
                label="Stamp Type"
                value={
                  <StampTypeBadge
                    stampType={
                      currentRecord.stampType
                        ? currentRecord.stampType.toUpperCase()
                        : STAMP_TYPE.NO_STAMPING
                    }
                  />
                }
              />
              <DetailField
                label="Stamp Amount"
                value={currentRecord.leapStampAmount || "N/A"}
              />
              <DetailField
                label="Lead ID"
                value={currentRecord.leadId || "N/A"}
              />
              <DetailField
                label="Amount Finance"
                value={currentRecord.amountFinance || "N/A"}
              />
              <DetailField
                label="Model No"
                value={currentRecord.modelNo || "N/A"}
              />
              <DetailField label="Make" value={currentRecord.make || "N/A"} />
              <DetailField
                label="Disbursement Date"
                value={formatDateOnlyToIST(currentRecord.handOffDate, "N/A")}
              />
              <DetailField
                label="EMI End Date"
                value={formatDateOnlyToIST(currentRecord.emiEndDate, "N/A")}
              />
              <DetailField
                label="POD No"
                value={currentRecord.podNo || "N/A"}
              />
              <DetailField
                label="Query POD No"
                value={currentRecord.missingPodNo || "N/A"}
              />
              <DetailField
                label="VBarcode"
                value={currentRecord.vbarCode || "N/A"}
              />
              <DetailField
                label="Current Stage"
                value={currentRecord.stage?.stageName || "N/A"}
              />
              <DetailField
                label="Query Status"
                value={
                  currentRecord.query?.queryName?.replace(/_/g, " ") || "N/A"
                }
              />
              <DetailField
                label="Loan ID"
                value={currentRecord.loanId || "N/A"}
              />
              <DetailField
                label="Business Date"
                value={formatDateOnlyToIST(currentRecord.businessDate, "N/A")}
              />
              <DetailField
                label="Sourcing Date"
                value={formatDateOnlyToIST(currentRecord.sourcingDate, "N/A")}
              />
              <DetailField
                label="Tenure"
                value={currentRecord.tenure || "N/A"}
              />
              <DetailField label="BIRR" value={currentRecord.birr || "N/A"} />
              <DetailField
                label="Registrable Status"
                value={currentRecord.registrableStatus || "N/A"}
              />
              <DetailField
                label="Udyam Number Status"
                value={currentRecord.udhayamNumberStatus || "N/A"}
              />
              <DetailField
                label="PAC Amount"
                value={currentRecord.pacAmount || "N/A"}
              />
              <DetailField
                label="Carton Barcode"
                value={currentRecord.queryCartonBarcode || "N/A"}
              />

              <div className="sm:col-span-2 md:col-span-2">
                <DetailField
                  label="Query Code"
                  value={
                    currentRecord.queryCategory?.queryCategoryName || "N/A"
                  }
                />
              </div>
            </div>
          )}
        </dl>

        {/* Bottom Buttons */}

        <div className="flex justify-between items-center gap-4 mt-4 pt-3 border-t border-slate-200">
          <span className="text-sm font-semibold text-brand-primary">
            No of documents currently uploaded: {uploadedCount}
          </span>
          <div className="flex items-center gap-4">
            <DocumentButton
              id="non-critical-query-view-document-btn"
              appNo={currentRecord.appNo}
              customerName={currentRecord.customerName}
              showUpload={true}
              onUpload={handleDmsUpload}
            />

            <button
              type="button"
              onClick={toggleExpand}
              className="text-sm font-semibold text-brand-primary underline underline-offset-2 hover:opacity-75 transition-opacity"
            >
              {isExpanded ? "Minimize" : "Expand"}
            </button>
          </div>
        </div>
      </DetailCard>
    </div>
  );
};

NonCriticalQueryFileDetails.displayName = "NonCriticalQueryFileDetails";

export default NonCriticalQueryFileDetails;
