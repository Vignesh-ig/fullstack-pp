import { zodResolver } from "@hookform/resolvers/zod";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { getRackAssignedApi, updateRackAssignedApi } from "../../api/apiConfig";
import PortraitFormContainer from "../../components/layout/PortraitFormContainer";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FormFooter from "../../components/ui/common/FormFooter";
import FormHeader from "../../components/ui/common/FormHeader";
import { ALLOCATION_ENUMS } from "../../constants/stages";
// import { useFileTypes } from "../../hooks/dropdowns/useFileTypes";
import { useRackDropdown } from "../../hooks/dropdowns/useRackDropdown";
import { useVaultDropdown } from "../../hooks/dropdowns/useVaultDropdown";
import { useApi } from "../../hooks/useApi";
import { rackAllocationEditSchema } from "../../utils/schemas/configSchema";
import RackAllocationEditFormFields from "./components/RackAllocationEditFormFields";

/**
 * RackAllocationEditForm
 *
 * Page-level form for editing a single rack allocation record. Reads the record from location.state (passed by the list view on navigation) and falls back to the :id URL param for the record identifier. On success, navigates back to the previous route after a short delay. Follows the same architecture as UserForm and BranchForm. No external props — consumes route state and Redux auth state internally.
 *
 */
const RackAllocationEditForm = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { id } = useParams();
  const { userId: currentUserId } = useSelector((state) => state.user);

  const {
    execute: updateRackAssigned,
    isLoading: isSubmittingAPI,
    error: submitError,
    setError: setSubmitError,
  } = useApi(updateRackAssignedApi);

  const record = location.state?.record;
  const [fetchedRecord, setFetchedRecord] = useState(null);

  // Fetch current record details by rackAssignedId on page refresh or edit mount
  useEffect(() => {
    if (id) {
      getRackAssignedApi({ rackAssignedId: id })
        .then((res) => {
          const rawItem = Array.isArray(res?.data?.data)
            ? res.data.data[0]
            : (res?.data?.data ??
              (Array.isArray(res?.data) ? res.data[0] : res?.data));
          if (rawItem) {
            setFetchedRecord(rawItem);
          }
        })
        .catch((err) => {
          console.error("Failed to fetch rack assigned detail:", err);
        });
    }
  }, [id]);

  const activeRecord = fetchedRecord || record;

  // ── Fetch File Types & Vaults ─────────────────────────────────────────────
  // const { options: fileTypeOptions } = useFileTypes();
  const fileTypeOptions = [];
  const { options: vaultOptions } = useVaultDropdown(true);

  // ── Form Configuration ────────────────────────────────────────────────────
  const defaultValues = useMemo(() => {
    return {
      ageingNo: activeRecord?.ageingNo?.toString() ?? "",
      appNo: activeRecord?.appNo ?? "",
      aggNo: activeRecord?.aggNo ?? "",
      barcode: activeRecord?.barcode ?? "",
      fileTypeId: activeRecord?.fileTypeId ?? "",
      vaultName: activeRecord?.vaultName ?? "V1",
      rackId: activeRecord?.rackId ?? "",
    };
  }, [activeRecord]);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    trigger,
    formState: { errors, isValid },
  } = useForm({
    resolver: zodResolver(rackAllocationEditSchema),
    mode: "onChange",
    defaultValues,
  });

  // Sync form values when activeRecord updates from API (e.g. on page refresh)
  useEffect(() => {
    if (activeRecord) {
      setValue("ageingNo", activeRecord?.ageingNo?.toString() ?? "");
      setValue("appNo", activeRecord?.appNo ?? "");
      setValue("aggNo", activeRecord?.aggNo ?? "");
      setValue("barcode", activeRecord?.barcode ?? "");
      setValue("fileTypeId", activeRecord?.fileTypeId ?? "");
      setValue("vaultName", activeRecord?.vaultName ?? "V1");
      setValue("rackId", activeRecord?.rackId ?? "");
    }
  }, [activeRecord, setValue]);

  // ── Fetch Racks ─────────────────────────────────────────────────
  const currentVaultName = watch("vaultName");
  const [rackSearchTerm, setRackSearchTerm] = useState("");

  const {
    options: rackOptions,
    loading: rackLoading,
    hasMore: rackHasMore,
    fetchPage: fetchRackPage,
    page: rackPage,
  } = useRackDropdown(
    !!currentVaultName,
    rackSearchTerm,
    false,
    true,
    currentVaultName,
    true,
    true,
  );

  const handleRackLoadMore = useCallback(() => {
    if (rackHasMore && !rackLoading) {
      fetchRackPage(rackPage, rackSearchTerm);
    }
  }, [rackHasMore, rackLoading, fetchRackPage, rackPage, rackSearchTerm]);

  const currentRackOption = useMemo(() => {
    if (activeRecord?.rackId) {
      return {
        value: activeRecord.rackId,
        label: activeRecord.rackName ?? "—",
        sublabel: activeRecord.rackPosition
          ? `${activeRecord.rackPosition}`
          : undefined,
      };
    }
    return null;
  }, [activeRecord]);

  // Watch the current rackId so we only inject the pre-loaded option when the user hasn't changed the rack yet.
  const currentRackId = watch("rackId");

  const mergedRackOptions = useMemo(() => {
    const opts = [...rackOptions];
    if (
      currentRackOption &&
      currentRackId === currentRackOption.value &&
      !opts.some((o) => o.value === currentRackOption.value)
    ) {
      opts.unshift(currentRackOption);
    }
    return opts;
  }, [rackOptions, currentRackOption, currentRackId]);

  const onSubmit = useCallback(
    async (data) => {
      if (isSubmittingAPI) return;

      const payload = [
        {
          rackAssignedId: activeRecord?.rackAssignedId ?? id,
          ageingNo: (activeRecord?.ageingNo ?? "").toString().trim(),
          healthcheckUser: null,
          appNo: activeRecord?.appNo || null,
          aggNo: activeRecord?.aggNo || null,
          barcode: activeRecord?.barcode || null,
          assignedUser: null,
          fileTypeId: data.fileTypeId || null,
          rackId: data.rackId,
          modifiedBy: currentUserId,
        },
      ];

      const { error } = await updateRackAssigned(payload, {
        rackAllocationAction: ALLOCATION_ENUMS.UPDATE_RACK_ALLOCATION,
      });

      if (!error) {
        navigate("..", {
          state: {
            savedSuccess: true,
            successMessage:
              "Rack allocation updated successfully and moved to User Allocation",
          },
        });
      }
    },
    [
      currentUserId,
      id,
      navigate,
      activeRecord,
      isSubmittingAPI,
      updateRackAssigned,
    ],
  );

  return (
    <PortraitFormContainer maxWidth="max-w-4xl">
      <FormHeader title="Edit Rack Allocation" onBack={() => navigate("..")} />

      <form onSubmit={handleSubmit(onSubmit)} noValidate>
        <ErrorBanner
          message={submitError}
          onClose={() => setSubmitError(null)}
        />

        <RackAllocationEditFormFields
          register={register}
          setValue={setValue}
          watch={watch}
          trigger={trigger}
          errors={errors}
          fileTypeOptions={fileTypeOptions}
          vaultOptions={vaultOptions}
          mergedRackOptions={mergedRackOptions}
          rackLoading={rackLoading}
          rackHasMore={rackHasMore}
          handleRackLoadMore={handleRackLoadMore}
          rackSearchTerm={rackSearchTerm}
          setRackSearchTerm={setRackSearchTerm}
          assignedStatus={activeRecord?.assignedStatus}
        />

        <FormFooter
          buttons={[
            {
              label: isSubmittingAPI ? "Saving..." : "Update Allocation",
              props: {
                type: "submit",
                disabled: isSubmittingAPI,
              },
            },
          ]}
        />
      </form>
    </PortraitFormContainer>
  );
};

RackAllocationEditForm.displayName = "RackAllocationEditForm";
export default RackAllocationEditForm;
