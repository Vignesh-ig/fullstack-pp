import { useSelector } from "react-redux";
import { Navigate, Route, Routes } from "react-router-dom";
import { ADMIN_ROLES } from "../../constants/roles";
import { ROUTES } from "../../router/routes";
import RackAllocationEditForm from "./RackAllocationEditForm";
import RackAllocationForm from "./RackAllocationForm";
import RackAllocationList from "./RackAllocationList";

/**
 * RackAllocation
 *
 * Renders the RackAllocation component.
 *
 */
const RackAllocation = () => {
  const { roleName } = useSelector((state) => state.user);
  const isAdmin = ADMIN_ROLES.includes(roleName);

  return (
    <Routes>
      <Route path="/" element={<RackAllocationList />} />
      <Route
        path={ROUTES.FEATURES.TRANSACTION.RACK_ALLOCATION.ADD}
        element={isAdmin ? <RackAllocationForm /> : <Navigate to="." replace />}
      />
      <Route
        path={ROUTES.FEATURES.TRANSACTION.RACK_ALLOCATION.EDIT}
        element={
          isAdmin ? <RackAllocationEditForm /> : <Navigate to="." replace />
        }
      />
    </Routes>
  );
};

RackAllocation.displayName = "RackAllocation";
export default RackAllocation;
