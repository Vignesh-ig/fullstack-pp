import { createContext, useContext } from "react";

export const RackAllocationFormContext = createContext(null);

export const useRackAllocationFormContext = () => {
  const context = useContext(RackAllocationFormContext);
  if (!context) {
    throw new Error("useRackAllocationFormContext must be used within a RackAllocationFormProvider");
  }
  return context;
};
