import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  createRackAssignedApi,
  getDespatchDetailsApi,
  getGenexDashboardItemsApi,
} from "../../api/apiConfig";
import LandscapeFormContainer from "../../components/layout/LandscapeFormContainer";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FormFooter from "../../components/ui/common/FormFooter";
import FormHeader from "../../components/ui/common/FormHeader";
import InputField from "../../components/ui/common/InputField";
import SearchableSelectField from "../../components/ui/common/SearchableSelectField";
import SelectField from "../../components/ui/common/SelectField";
// import { useFileTypes } from "../../hooks/dropdowns/useFileTypes";
import {
  RACK_MAX_APP_COUNT,
  useRackDropdown,
} from "../../hooks/dropdowns/useRackDropdown";
import { useVaultDropdown } from "../../hooks/dropdowns/useVaultDropdown";
import { useApi } from "../../hooks/useApi";
import {
  rackAllocationFormSchema,
  rackAllocationRowSchema,
} from "../../utils/schemas/configSchema";
import EditableAllocationTable from "./components/EditableAllocationTable";
import { RackAllocationFormContext } from "./contexts/RackAllocationFormContext";

/**
 * Empty row factory — defines the shape of each allocation entry.
 */
const createEmptyRow = () => ({
  ageingNo: "",
  assignedUser: "",
  despatchId: "", // internal only — used to track selection
  appNo: "",
  aggNo: "",
  barcode: "",
  fileTypeId: "",
  rackId: "",
  podNo: "",
  customerName: "",
  schemaProduct: "",
  scheme: "",
  isESign: "",
  amountFinance: "",
});

/**
 * RackAllocationForm
 *
 * Full-width landscape form that collects one or more rack allocation entries and submits them as an array to POST /rackAssigned. Displays a Dispatch Record multi-select dropdown and an inline editable table.
 *
 */
const RackAllocationForm = () => {
  const { userId: currentUserId } = useSelector((state) => state.user);

  // user dropdown logic removed for bulk rack assignment

  // const { options: fileTypeOptions } = useFileTypes();
  const fileTypeOptions = [];

  const navigate = useNavigate();

  const [rows, setRows] = useState([]);
  const [validationErrors, setValidationErrors] = useState([]);
  const [touchedFields, setTouchedFields] = useState({});
  const [selectedRackOpt, setSelectedRackOpt] = useState(null);

  const [barcodeInput, setBarcodeInput] = useState("");
  const [isFetchingBarcode, setIsFetchingBarcode] = useState(false);
  const [submitWarning, setSubmitWarning] = useState(null);

  const virtuosoRef = useRef(null);
  const barcodeFocusRef = useRef(null);

  // Auto-focus barcode input whenever it becomes enabled
  useEffect(() => {
    if (selectedRackOpt && !isFetchingBarcode) {
      setTimeout(() => {
        if (barcodeFocusRef.current) {
          barcodeFocusRef.current.focus();
        }
      }, 0);
    }
  }, [selectedRackOpt, isFetchingBarcode]);

  const {
    execute: createRackAssigned,
    isLoading: isSubmittingAPI,
    error: submitError,
    setError: setSubmitError,
  } = useApi(createRackAssignedApi);

  const handleClose = () => {
    navigate("..");
  };

  // ── Vault & Rack dropdowns ──────────────────────────────────────────────
  const [selectedVault, setSelectedVault] = useState("V1");
  const [vaultDropdownEnabled, setVaultDropdownEnabled] = useState(false);
  const { options: vaultOptions } = useVaultDropdown(vaultDropdownEnabled);

  const [rackSearchTerm, setRackSearchTerm] = useState("");
  const {
    options: rackOptions,
    loading: rackLoading,
    hasMore: rackHasMore,
    fetchPage: fetchRackPage,
    page: rackPage,
  } = useRackDropdown(
    !!selectedVault,
    rackSearchTerm,
    true,
    true,
    selectedVault,
    true,
    true,
  );

  const handleRackLoadMore = useCallback(() => {
    if (rackHasMore && !rackLoading) {
      fetchRackPage(rackPage, rackSearchTerm);
    }
  }, [rackHasMore, rackLoading, fetchRackPage, rackPage, rackSearchTerm]);

  const dynamicRackOptions = useMemo(() => {
    const activeRackCounts = rows.reduce((acc, r) => {
      if (r.rackId) {
        acc[r.rackId] = (acc[r.rackId] || 0) + 1;
      }
      return acc;
    }, {});

    return rackOptions.map((opt) => {
      const active = activeRackCounts[opt.value] || 0;
      const newCount = (opt.rackAppCount ?? 0) + active;
      const isFull = newCount >= RACK_MAX_APP_COUNT;

      return {
        ...opt,
        disabled: isFull,
      };
    });
  }, [rackOptions, rows]);

  const contextValue = {
    fileTypeOptions,
    rackOptions,
    rackLoading,
    rackHasMore,
    handleRackLoadMore,
    rackSearchTerm,
    setRackSearchTerm,
  };

  const existingAppNos = useMemo(() => {
    const appNoSet = new Set();
    rows.forEach((row) => {
      if (row.appNo) appNoSet.add(row.appNo);
    });
    return appNoSet;
  }, [rows]);

  // ── Row management ────────────────────────────────────────────────────────
  const handleRowChange = (index, field, value) => {
    setRows((prev) => {
      const updatedRows = [...prev];
      updatedRows[index] = { ...updatedRows[index], [field]: value };
      if (field === "rackId") {
        updatedRows[index].rackSelectedAt = value ? Date.now() : undefined;
      }

      // Live validate the single row
      const rowResult = rackAllocationRowSchema.safeParse(updatedRows[index]);
      setValidationErrors((prevErrors) => {
        const nextErrors = [...prevErrors];
        const rowErrors = {};

        if (!rowResult.success) {
          const issues = rowResult.error.issues || rowResult.error.errors || [];
          issues.forEach((issue) => {
            const issueField = issue.path[0];
            if (typeof issueField === "string") {
              rowErrors[issueField] = issue.message;
            }
          });
        }
        nextErrors[index] = rowErrors;
        return nextErrors;
      });

      return updatedRows;
    });
  };

  const handleTopRackChange = (opt) => {
    setSelectedRackOpt(opt || null);
    if (!opt) return;

    const maxAllowed = Math.max(
      0,
      RACK_MAX_APP_COUNT - (opt.rackAppCount ?? 0),
    );

    setRows((prevRows) => {
      let updatedRows = [...prevRows];

      // If we have more rows than the new rack can handle, trim them
      if (updatedRows.length > maxAllowed) {
        updatedRows = updatedRows.slice(0, maxAllowed);
      }

      return updatedRows.map((row, index) => ({
        ...row,
        rackId: opt.value,
        rackSelectedAt: Date.now() + index,
      }));
    });

    // Also trim validationErrors if needed
    setValidationErrors((prev) => {
      if (prev.length > maxAllowed) {
        return prev.slice(0, maxAllowed);
      }
      return prev;
    });
  };

  const handleBlur = (index, field) => {
    const key = `${index}_${field}`;
    setTouchedFields((prev) => {
      if (prev[key]) return prev;
      return { ...prev, [key]: true };
    });

    // Validate the row immediately on focus out to ensure errors are updated
    setRows((prevRows) => {
      const row = prevRows[index];
      if (row) {
        const rowResult = rackAllocationRowSchema.safeParse(row);
        setValidationErrors((prevErrors) => {
          const nextErrors = [...prevErrors];
          const rowErrors = {};
          if (!rowResult.success) {
            const issues =
              rowResult.error.issues || rowResult.error.errors || [];
            issues.forEach((issue) => {
              const issueField = issue.path[0];
              if (typeof issueField === "string") {
                rowErrors[issueField] = issue.message;
              }
            });
          }
          nextErrors[index] = rowErrors;
          return nextErrors;
        });
      }
      return prevRows;
    });
  };

  const removeRow = (index) => {
    setRows((prev) => prev.filter((_, i) => i !== index));
    setValidationErrors((prev) => prev.filter((_, i) => i !== index));
    setTouchedFields((prev) => {
      const next = {};
      Object.keys(prev).forEach((key) => {
        const parts = key.split("_");
        const rIndex = parseInt(parts[0], 10);
        const fieldName = parts.slice(1).join("_");
        if (rIndex < index) {
          next[key] = prev[key];
        } else if (rIndex > index) {
          next[`${rIndex - 1}_${fieldName}`] = prev[key];
        }
      });
      return next;
    });
  };

  // ── Barcode scanning ────────────────────────────────────────────────────────
  const handleBarcodeKeyDown = async (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const val = barcodeInput.trim();
      if (!val) return;

      if (!selectedRackOpt) {
        setSubmitWarning("Please select a rack first.");
        return;
      }

      const remainingCap =
        Math.max(0, RACK_MAX_APP_COUNT - (selectedRackOpt.rackAppCount ?? 0)) -
        rows.length;

      if (remainingCap <= 0) {
        setSubmitError("Rack capacity reached.");
        return;
      }

      setIsFetchingBarcode(true);
      setSubmitError(null);
      try {
        const [res, genexRes] = await Promise.all([
          getDespatchDetailsApi({
            page: 1,
            limit: 100,
            appNoOrBarcode: val,
          }),
          getGenexDashboardItemsApi(val).catch(() => null),
        ]);

        const opt = res?.data || [];
        const hcStage = genexRes?.result?.[0]?.stage || null;
        if (opt.length === 0) {
          setSubmitError(`No record found for barcode: ${val}`);
          return;
        }

        if (opt.dpAppNo && existingAppNos.has(opt.dpAppNo)) {
          setSubmitError(
            `Record with Application No: ${opt.dpAppNo} is already added.`,
          );
          setBarcodeInput(""); // clear input for next scan
          return;
        }

        const newRow = {
          ...createEmptyRow(),
          despatchId: opt.dpId,
          appNo: opt.dpAppNo || "",
          aggNo: opt.dpAgreementNo || "",
          barcode: opt.dpBarcode || "",
          podNo: opt.dpCourierNo || "",
          customerName: opt.dpAppName || "",
          schemaProduct: opt.dpSchema || "",
          scheme: opt.dpScheme || "",
          isESign: opt.dpIsEsign || "",
          amountFinance: opt.amountFinance || null,
          rackId: selectedRackOpt.value,
          fileTypeId: opt.dpFileTypeId || null,
          fileTypeName: opt.dpFileTypeName || null,
          // LEAP Details
          genexFromBranch: opt.genexFromBranch || null,
          leapAgingNo: opt.leapAgingNo || null,
          leapFileType: opt.leapFileType || null,
          branchDesc: opt.branchDesc || null,
          stateDesc: opt.stateDesc || null,
          handOffDate: opt.handOffDate || null,
          leadId: opt.leadId || null,
          stampType: opt.stampType || null,
          leapStampAmount: opt.leapStampAmount || null,
          fundedCustomerType: opt.fundedCustomerType || null,
          rePaymentMode: opt.rePaymentMode || null,
          eStamp: opt.eStamp || null,
          emiEndDate: opt.emiEndDate || null,
          loanId: opt.loanId || null,
          businessDate: opt.businessDate || null,
          sourcingDate: opt.sourcingDate || null,
          tenure: opt.tenure || null,
          birr: opt.birr || null,
          registrableStatus: opt.registrableStatus || null,
          udhayamNumberStatus: opt.udhayamNumberStatus || null,
          pacAmount: opt.pacAmount || null,
          workflowNo: opt.workflowNo || null,
          dmsId: opt.dmsId || null,
          dpSchema: opt.dpSchema || null,
          dpIsEsign: opt.dpIsEsign || null,
          // GENEX Details
          stage: hcStage,
        };

        setRows((prev) => {
          const updated = [...prev, newRow];

          // Validate new row
          const rowResult = rackAllocationRowSchema.safeParse(newRow);
          const rowErrors = {};
          if (!rowResult.success) {
            const issues =
              rowResult.error.issues || rowResult.error.errors || [];
            issues.forEach((issue) => {
              const issueField = issue.path[0];
              if (typeof issueField === "string") {
                rowErrors[issueField] = issue.message;
              }
            });
          }
          setValidationErrors((prevErrs) => [...prevErrs, rowErrors]);

          return updated;
        });

        setBarcodeInput(""); // clear input for next scan
      } catch (err) {
        setSubmitError(
          err?.response?.data?.message ||
            err?.message ||
            "Failed to fetch barcode details",
        );
      } finally {
        setIsFetchingBarcode(false);
      }
    }
  };

  // ── Validation ────────────────────────────────────────────────────────────
  const validate = () => {
    const result = rackAllocationFormSchema.safeParse(rows);
    if (!result.success) {
      const issues = result.error.issues || result.error.errors || [];

      // Set all validation errors in the state array
      const errorsArray = Array.from({ length: rows.length }).map(() => ({}));
      issues.forEach((issue) => {
        const rowIndex = issue.path[0];
        const fieldName = issue.path[1];
        if (typeof rowIndex === "number" && typeof fieldName === "string") {
          errorsArray[rowIndex][fieldName] = issue.message;
        }
      });
      setValidationErrors(errorsArray);

      const firstError = issues[0];
      if (firstError) {
        const pathIndex = firstError.path[0];
        const message = firstError.message;

        if (typeof pathIndex === "number") {
          return `Entry #${pathIndex + 1}: ${message}`;
        }
        return message;
      }
      return "Please fix all validation errors in the table.";
    }
    setValidationErrors([]);
    return null;
  };

  // ── Submission ────────────────────────────────────────────────────────────
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSubmittingAPI) return;

    setSubmitError(null);

    const validationError = validate();
    if (validationError) {
      setSubmitError(validationError);

      // Mark all fields in all rows as touched
      setTouchedFields(() => {
        const allTouched = {};
        rows.forEach((_, rowIndex) => {
          const fields = [
            "ageingNo",
            "appNo",
            "aggNo",
            "barcode",
            "fileTypeId",
            "rackId",
            "podNo",
            "customerName",
            "schemaProduct",
            "scheme",
            "isESign",
            "amountFinance",
          ];
          fields.forEach((fieldName) => {
            allTouched[`${rowIndex}_${fieldName}`] = true;
          });
        });
        return allTouched;
      });
      return;
    }

    const payload = rows.map((row) => ({
      ...row,
      ageingNo: row.ageingNo ? row.ageingNo.trim() : "",
      healthcheckUser: null,
      appNo: row.appNo?.trim() || null,
      aggNo: row.aggNo?.trim() || null,
      barcode: row.barcode?.trim() || null,
      assignedUser: null,
      fileTypeId: row.fileTypeId || null,
      rackId: row.rackId,
      podNo: row.podNo?.trim() || null,
      customerName: row.customerName?.trim() || null,
      schemaProduct: row.schemaProduct?.trim() || null,
      scheme: row.scheme?.trim() || null,
      isESign: row.isESign?.trim() || null,
      amountFinance: row.amountFinance || null,
      createdBy: currentUserId,
      userAssigned: false,
    }));

    const { error } = await createRackAssigned(payload);
    if (!error) {
      navigate("..", {
        state: {
          savedSuccess: true,
          successMessage:
            "Rack allocation updated successfully and moved to User Allocation",
        },
      });
    }
  };

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <LandscapeFormContainer className="mb-4">
      <FormHeader
        title="Allocate to Rack"
        onBack={handleClose}
        rightContent={
          <>
            <div className="flex items-center gap-1.5 whitespace-nowrap">
              <span className="text-sm font-medium text-text-primary">
                Added records:
              </span>
              <span className="text-xl font-bold text-brand-primary leading-none">
                {rows.length}
              </span>
            </div>
            {selectedRackOpt && (
              <div className="flex items-center gap-1.5 whitespace-nowrap border-l border-border-main pl-4 sm:pl-6">
                <span className="text-sm font-medium text-text-primary">
                  Remaining capacity:
                </span>
                <span className="text-xl font-bold text-brand-primary leading-none">
                  {Math.max(
                    0,
                    RACK_MAX_APP_COUNT - (selectedRackOpt.rackAppCount ?? 0),
                  ) - rows.length}
                </span>
              </div>
            )}
          </>
        }
      />

      <form onSubmit={handleSubmit} noValidate>
        {/* Banners */}
        <ErrorBanner
          type="warning"
          message={submitWarning}
          onClose={() => setSubmitWarning(null)}
        />
        <ErrorBanner
          message={submitError}
          onClose={() => setSubmitError(null)}
        />

        <div className="flex flex-col lg:flex-row gap-6 items-start">
          {/* Selectors vertical container (left) */}
          <fieldset className="flex flex-col gap-4 w-full lg:w-1/3 xl:w-1/4">
            {/* 1. Vault Selection */}
            <div>
              <SelectField
                label="1. Select Vault"
                name="top_assigned_vault"
                value={selectedVault}
                onChange={(e) => {
                  setSelectedVault(e.target.value);
                  setSelectedRackOpt(null);
                  setRackSearchTerm("");
                }}
                options={vaultOptions}
                placeholder="Select vault"
                className="mb-0 w-full"
                onOpen={() => setVaultDropdownEnabled(true)}
              />
            </div>

            {/* 2. Rack Selection First */}
            <div>
              <SearchableSelectField
                label="2. Select Rack"
                name="top_assigned_rack"
                value={selectedRackOpt?.value || ""}
                onChange={handleTopRackChange}
                options={dynamicRackOptions}
                placeholder={
                  !selectedVault ? "Select vault first" : "Select rack"
                }
                searchTerm={rackSearchTerm}
                onSearchChange={setRackSearchTerm}
                isLoadingMore={rackLoading}
                hasMore={rackHasMore}
                onLoadMore={handleRackLoadMore}
                className="mb-0 w-full"
                disabled={!selectedVault}
              />
            </div>

            {/* 3. Barcode Scanning */}
            <div>
              <InputField
                label="3. Scan Barcode / Enter Application Number"
                name="barcode_scan"
                value={barcodeInput}
                ref={barcodeFocusRef}
                onChange={(e) => setBarcodeInput(e.target.value)}
                onKeyDown={handleBarcodeKeyDown}
                placeholder="Scan barcode / Enter Application Number"
                disabled={!selectedRackOpt || isFetchingBarcode}
                className="mb-0 w-full"
                onClear={() => {
                  setBarcodeInput("");
                  if (barcodeFocusRef.current) {
                    barcodeFocusRef.current.focus();
                  }
                }}
              />
            </div>
          </fieldset>

          {/* Table View (right) */}
          <section className="w-full lg:w-2/3 xl:w-3/4 lg:mb-4">
            <RackAllocationFormContext.Provider value={contextValue}>
              <EditableAllocationTable
                virtuosoRef={virtuosoRef}
                rows={rows}
                errors={validationErrors}
                touchedFields={touchedFields}
                onBlur={handleBlur}
                onChange={handleRowChange}
                onRemove={removeRow}
              />
            </RackAllocationFormContext.Provider>
          </section>
        </div>

        <FormFooter
          buttons={[
            {
              label: isSubmittingAPI
                ? "Saving..."
                : `Submit ${rows.length > 0 ? `(${rows.length} entries)` : ""}`,
              props: {
                type: "submit",
                disabled: isSubmittingAPI || rows.length === 0,
              },
            },
          ]}
        />
      </form>
    </LandscapeFormContainer>
  );
};

RackAllocationForm.displayName = "RackAllocationForm";
export default RackAllocationForm;
