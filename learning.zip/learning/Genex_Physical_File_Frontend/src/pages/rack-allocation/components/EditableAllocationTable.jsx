import { useCallback, useEffect, useRef } from "react";
import { Virtuoso } from "react-virtuoso";
import DashedEmptyState from "../../../components/ui/common/DashedEmptyState";
import { useRackAllocationFormContext } from "../contexts/RackAllocationFormContext";
import EditableAllocationTableRow from "./EditableAllocationTableRow";

/**
 * EditableAllocationTable
 *
 * Renders an editable list of rack allocation entries inside the creation form as cards.
 *
 * @param {Object[]} props.rows - Array of row objects to render.
 * @param {Object[]} [props.errors=[]] - Array of error objects corresponding to rows.
 * @param {Object} [props.touchedFields={}] - Map of fields that have been focused/blurred.
 * @param {function} props.onBlur - Blur event handler.
 * @param {function} props.onChange - Change event handler (index, field, value).
 * @param {function} props.onRemove - Function to remove a row.
 */
const EditableAllocationTable = ({
  rows,
  errors = [],
  touchedFields = {},
  onBlur,
  onChange,
  onRemove,
  virtuosoRef: externalVirtuosoRef,
}) => {
  const { fileTypeOptions } = useRackAllocationFormContext();
  const internalVirtuosoRef = useRef(null);
  const virtuosoRef = externalVirtuosoRef || internalVirtuosoRef;
  const prevRowsLength = useRef(rows.length);

  useEffect(() => {
    if (rows.length > prevRowsLength.current) {
      // Wait a tick for the new item to be rendered by Virtuoso before scrolling
      setTimeout(() => {
        virtuosoRef.current?.scrollToIndex({
          index: rows.length - 1,
          align: "start",
          behavior: "smooth",
        });
      }, 50);
    }
    prevRowsLength.current = rows.length;
  }, [rows.length, virtuosoRef]);

  const rowContent = useCallback(
    (index, row) => (
      <div className="px-1 pt-1">
        <EditableAllocationTableRow
          index={index}
          row={row}
          onChange={onChange}
          onBlur={onBlur}
          onRemove={onRemove}
          errors={errors} // Pass global array reference
          touchedFields={touchedFields} // Pass global object reference
          fileTypeOptions={fileTypeOptions}
        />
      </div>
    ),
    [onChange, onBlur, onRemove, errors, touchedFields, fileTypeOptions],
  );

  if (rows.length === 0) {
    return (
      <DashedEmptyState
        title="No records added yet."
        description="Select dispatch records above to add them here."
      />
    );
  }

  return (
    <div
      className="bg-white rounded-xl p-2 border border-slate-300"
      style={{
        height: "clamp(400px, calc(100vh - 350px), 800px)",
      }}
    >
      <Virtuoso
        ref={virtuosoRef}
        className="custom-scrollbar"
        style={{ height: "100%", width: "100%" }}
        data={rows}
        itemContent={rowContent}
      />
    </div>
  );
};

EditableAllocationTable.displayName = "EditableAllocationTable";
export default EditableAllocationTable;
