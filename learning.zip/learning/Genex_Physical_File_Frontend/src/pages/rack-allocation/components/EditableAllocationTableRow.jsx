import React from "react";
import StatusBadge from "../../../components/ui/badge/StatusBadge";
import RecordCard from "../../../components/ui/common/RecordCard";
import TableRecordDeleteButton from "../../../components/ui/common/TableRecordDeleteButton";

/**
 * LOADING_FILE_TYPE_OPTIONS
 *
 * Module-level static reference for loading file type options.
 * Avoids inline array instantiations in JSX which trigger unnecessary re-renders.
 */
const LOADING_FILE_TYPE_OPTIONS = [{ value: "", label: "Loading..." }];

/**
 * EditableAllocationTableRow
 *
 * Renders a single optimized row for the EditableAllocationTable.
 * Memoized to prevent re-rendering when other rows change.
 *
 * @note [Architectural Limitation] The rack search state (`rackSearch`, `handleRackSearchChange`, and `rackPage`)
 * is currently shared globally across all rows from the parent component. Initiating a search or page load on one row
 * will temporarily filter the shared options array for all rows.
 *
 * @param {number} props.index - Row index.
 * @param {Object} props.row - Row data object.
 * @param {function} props.onChange - Handler for input changes.
 * @param {function} props.onBlur - Handler for input blur.
 * @param {function} props.onRemove - Handler for row removal.
 * @param {Object[]} [props.errors=[]] - Array of all form errors.
 * @param {Object} [props.touchedFields={}] - Touched fields object mapping string keys to booleans.
 * @param {Object[]} [props.fileTypeOptions=[]] - Array of selectable file type options.
 */
const EditableAllocationTableRow = React.memo(
  ({ index, row, onRemove }) => {
    return (
      <div className="transition-all duration-300 ease-out transform-gpu hover:transform-[perspective(400px)_rotateX(1.5deg)_scale(1)] hover:shadow-2xl rounded-xl">
        <RecordCard
          index={index}
          title={`Application No: ${row.appNo}`}
          details={[
            { label: "Agreement No", value: row.aggNo || "N/A" },
            { label: "Barcode", value: row.barcode || "N/A" },
            { label: "File Type", value: row.leapFileType || "N/A" },
            { label: "Scheme", value: row.dpSchema || "N/A" },
            { label: "Udyam", value: row.udhayamNumberStatus || "N/A" },
            {
              label: "Registrability Status",
              value: row.registrableStatus || "N/A",
            },
            { label: "Customer Name", value: row.customerName || "N/A" },
            {
              label: "Esign",
              value: row.dpIsEsign ? (
                <StatusBadge
                  isActive={String(row.dpIsEsign).toLowerCase() === "true"}
                />
              ) : (
                "N/A"
              ),
            },
            { label: "Ageing", value: row.leapAgingNo ?? "N/A" },
            { label: "Stage", value: row.stage || "N/A" },
          ]}
          action={
            <TableRecordDeleteButton
              recordId={index}
              onDeleteClick={onRemove}
              label="Remove"
              bypassPermissionCheck={true}
            />
          }
        />
      </div>
    );
  },
  (prev, next) => {
    // Top level scalar prop checks
    if (prev.index !== next.index) return false;
    if (prev.row !== next.row) return false;
    if (prev.usersOptions !== next.usersOptions) return false;
    if (prev.usersLoading !== next.usersLoading) return false;
    if (prev.usersHasMore !== next.usersHasMore) return false;
    if (prev.userSearchTerm !== next.userSearchTerm) return false;

    if (prev.onRemove !== next.onRemove) return false;

    return true;
  },
);

EditableAllocationTableRow.displayName = "EditableAllocationTableRow";
export default EditableAllocationTableRow;
