import { FileIcon, ServerIcon } from "../../../components/icons/icons";
import { StatusBadge } from "../../../components/ui/badge/badgeIndex";
import DetailCard from "../../../components/ui/common/DetailCard";
import DetailField from "../../../components/ui/common/DetailField";

/**
 * RackAllocationExpandedRow
 *
 * Renders the full-width expanded detail panel for a rack allocation record.
 * Displays categorised detail cards: Assigned User Details, Despatch Details, Rack Details, Return Assigned User Details, and Created By Details.
 *
 * @param {object} rec - The full rack allocation record object from the API.
 * @param {number} colSpan - Number of columns the detail panel should span.
 * @param {boolean} isExpanded - Whether the row is expanded.
 */
const RackAllocationExpandedRow = ({ rec, colSpan, isExpanded }) => {
  return (
    <tr className="bg-slate-50/40">
      <td colSpan={colSpan} className="p-0 border-0">
        <div
          className={`expandable-row-wrapper ${isExpanded ? "expanded" : ""}`}
        >
          <div className="expandable-row-inner">
            <div className="px-6 py-4 border-b border-border-subtle">
              <section className="bg-white border border-slate-500/70 rounded-xl p-2 sm:p-5 shadow-xs grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 text-left">
                {/* Section 1: Despatch Details */}
                <DetailCard title="Despatch Details" icon={FileIcon}>
                  <dl className="grid grid-cols-3 gap-4">
                    <DetailField label="Agreement No" value={rec.aggNo} />
                    <DetailField label="Barcode" value={rec.barcode} />
                    <DetailField
                      label="Customer Name"
                      value={rec.customerName}
                    />
                  </dl>
                </DetailCard>

                {/* Section 2: Rack Details */}
                <DetailCard title="Rack Details" icon={ServerIcon}>
                  <dl className="grid grid-cols-3 gap-4">
                    <DetailField label="Self" value={rec.rackPosition} />
                    <DetailField
                      label="Count"
                      value={rec.rackAppCount ?? "—"}
                    />
                    <div>
                      <dt className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                        Rack Status
                      </dt>
                      <dd className="mt-1">
                        <StatusBadge isActive={rec.rackStatus} />
                      </dd>
                    </div>
                  </dl>
                </DetailCard>
              </section>
            </div>
          </div>
        </div>
      </td>
    </tr>
  );
};

RackAllocationExpandedRow.displayName = "RackAllocationExpandedRow";
export default RackAllocationExpandedRow;
