import { useCallback, useState } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { deleteRackAssignedApi, getRackAssignedApi } from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import NavigationBanners from "../../components/ui/common/NavigationBanners";
import Pagination from "../../components/ui/common/Pagination";
import { ADMIN_ROLES } from "../../constants/roles";
import { useRackDropdown } from "../../hooks/dropdowns/useRackDropdown";
import { useVaultDropdown } from "../../hooks/dropdowns/useVaultDropdown";
import { useApi } from "../../hooks/useApi";
import useNavigationBanners from "../../hooks/useNavigationBanners";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import { ROUTES } from "../../router/routes";
import RackAllocationTable from "./components/RackAllocationTable";

/**
 * RackAllocationList
 *
 * Fetches and displays rack-assigned records for the currently logged-in user. Supports pagination, status filtering, and refresh.
 *
 */
const RackAllocationList = () => {
  const { userId: currentUserId, roleName } = useSelector(
    (state) => state.user,
  );
  const isAdmin = ADMIN_ROLES.includes(roleName);
  const navigate = useNavigate();

  const {
    successMessage,
    setSuccessMessage,
    warningMessage,
    setWarningMessage,
  } = useNavigationBanners();

  const [vaultFilter, setVaultFilter] = useState("V1");
  const [rackFilter, setRackFilter] = useState("");
  const [rackSearchTerm, setRackSearchTerm] = useState("");
  const [vaultDropdownEnabled, setVaultDropdownEnabled] = useState(false);

  const { options: vaultOptions } = useVaultDropdown(vaultDropdownEnabled);

  const {
    execute: deleteRackAssigned,
    isLoading: isDeleting,
    error: deleteError,
    setError: setDeleteError,
  } = useApi(deleteRackAssignedApi);

  const {
    options: rackOptions,
    page: rackPage,
    hasMore: rackHasMore,
    loading: rackLoading,
    fetchPage: fetchRackPage,
  } = useRackDropdown(!!vaultFilter, rackSearchTerm, true, false, vaultFilter);

  const handleRackLoadMore = useCallback(() => {
    if (rackHasMore && !rackLoading) {
      fetchRackPage(rackPage, rackSearchTerm);
    }
  }, [rackHasMore, rackLoading, fetchRackPage, rackPage, rackSearchTerm]);

  const fetchFn = useCallback(
    async (params) => {
      const { _dummySearchParam, ...restParams } = params; // NOSONAR
      const finalParams = {
        ...restParams,
        userAssigned: false,
        ...(vaultFilter ? { vaultName: vaultFilter } : {}),
        ...(rackFilter ? { assignedRack: rackFilter } : {}),
        ...(!isAdmin ? { assignedUser: currentUserId } : {}),
      };

      return getRackAssignedApi(finalParams);
    },
    [vaultFilter, rackFilter, isAdmin, currentUserId],
  );

  const {
    data: records,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize: handlePageSizeChange,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "likeAppNoOrBarcode");

  const handleRefresh = () => {
    if (vaultFilter === "" && rackFilter === "") {
      refetch();
    } else {
      setVaultFilter("");
      setRackFilter("");
    }
  };

  const handleDeleteOne = useCallback(
    async (id) => {
      if (isDeleting) return;
      try {
        await deleteRackAssigned([id]);
        if (records.length === 1 && page > 1) {
          setPage(page - 1);
        } else {
          refetch();
        }
      } catch (err) {
        console.error("Failed to delete record:", err);
      }
    },
    [isDeleting, deleteRackAssigned, records.length, page, setPage, refetch],
  );

  const handleVaultFilterChange = (e) => {
    setVaultFilter(e.target.value);
    setRackFilter("");
  };

  const handleRackFilterChange = (e) => {
    setRackFilter(e.target.value);
  };

  const handleAllocateClick = () => {
    navigate(ROUTES.FEATURES.TRANSACTION.RACK_ALLOCATION.ADD);
  };

  return (
    <ListContainer>
      {/* Header */}
      <ListHeader
        title="Rack Allocation"
        unit="records"
        count={pagination.totalItems}
        loading={loading}
        search={search}
        setSearch={setSearch}
        refetch={handleRefresh}
        onAddClick={isAdmin ? handleAllocateClick : undefined}
        addLabel="Allocate to Rack"
      >
        {/* Rack Filter */}
        <search className="mt-4 grid grid-cols-1 sm:flex sm:flex-row items-start sm:items-center gap-3 sm:gap-5 w-full">
          <FilterSelectField
            label="Filter by Vault:"
            name="vaultFilter"
            value={vaultFilter}
            onChange={handleVaultFilterChange}
            placeholder="All Vaults"
            options={vaultOptions}
            className="w-full sm:w-auto"
            onOpen={() => setVaultDropdownEnabled(true)}
          />
          <FilterSelectField
            label="Filter by Rack:"
            name="rackFilter"
            value={rackFilter}
            onChange={handleRackFilterChange}
            placeholder="All Racks"
            options={rackOptions}
            className="w-full sm:w-auto"
            disabled={!vaultFilter}
            showSearch={true}
            searchPlaceholder="Search by rack name"
            searchTerm={rackSearchTerm}
            onSearchChange={setRackSearchTerm}
            isLoadingMore={rackLoading}
            hasMore={rackHasMore}
            onLoadMore={handleRackLoadMore}
          />
        </search>
      </ListHeader>

      <NavigationBanners
        successMessage={successMessage}
        setSuccessMessage={setSuccessMessage}
        warningMessage={warningMessage}
        setWarningMessage={setWarningMessage}
        error={error || deleteError}
        setError={(err) => {
          setError(err);
          setDeleteError(err);
        }}
      />

      {/* Table */}
      <RackAllocationTable
        records={records}
        loading={loading}
        error={error}
        page={page}
        pageSize={pageSize}
        onEditClick={
          isAdmin
            ? (rec) =>
                navigate(`edit/${rec.rackAssignedId}`, {
                  state: { record: rec },
                })
            : undefined
        }
        onDeleteClick={handleDeleteOne}
        isDeleting={isDeleting}
      />

      {/* Pagination */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={handlePageSizeChange}
      />
    </ListContainer>
  );
};

RackAllocationList.displayName = "RackAllocationList";
export default RackAllocationList;
