import { useState } from "react";
import EmptyState from "../../../components/ui/common/EmptyState";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { APPLICATIONS_UNLOCK_TABLE_COLUMNS } from "../../../constants/tableHeaders";
import ApplicationsUnlockTableRow from "./ApplicationsUnlockTableRow";

/**
 * ApplicationsUnlockTable
 *
 * Renders the Application Unlock records table with per-row checkboxes, an expand/collapse toggle, and a select-all checkbox in the header.
 * Uses the same columns as Outward.
 *
 * @param {object[]} records - Array of transaction records.
 * @param {boolean} loading - Whether data is being fetched.
 * @param {string} error - Error message if fetch failed.
 * @param {string} search - Active search query.
 * @param {number} page - Current page number.
 * @param {number} pageSize - Current page size.
 * @param {Set<string>} selectedAppNos - Set of selected application numbers.
 * @param {function} onSelectionChange - Called with the updated Set when selection changes.
 */
const ApplicationsUnlockTable = ({
  records = [],
  loading,
  error,
  search,
  page,
  pageSize,
  selectedAppNos,
  onSelectionChange,
}) => {
  const [expandedRows, setExpandedRows] = useState({});

  const allPageIds = records.map((r) => r.appNo).filter(Boolean);
  const isAllSelected =
    allPageIds.length > 0 && allPageIds.every((id) => selectedAppNos.has(id));
  const isIndeterminate =
    !isAllSelected && allPageIds.some((id) => selectedAppNos.has(id));

  const handleSelectAll = () => {
    const next = new Set(selectedAppNos);
    if (isAllSelected) {
      allPageIds.forEach((id) => next.delete(id));
    } else {
      allPageIds.forEach((id) => next.add(id));
    }
    onSelectionChange(next);
  };

  const handleSelectOne = (id) => {
    if (!id) return;
    const next = new Set(selectedAppNos);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    onSelectionChange(next);
  };

  const toggleRow = (id) => {
    if (!id) return;
    setExpandedRows((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const colSpan = APPLICATIONS_UNLOCK_TABLE_COLUMNS.length + 1;

  return (
    <div
      className="overflow-x-auto overflow-y-auto custom-scrollbar rounded-t-xl bg-white"
      style={{ height: "clamp(510px, calc(100vh - 340px), 800px)" }}
    >
      <table className="min-w-full text-left border-collapse">
        <thead className="sticky top-0 z-10">
          <tr className="bg-table-header-bg">
            {/* Empty column for the expand/collapse chevron */}
            <th className="px-4 py-4 w-12 border-b border-slate-100"></th>

            {/* Select-all checkbox */}
            <th className="px-4 py-4 text-xs text-center font-bold uppercase tracking-wider text-table-header-text border-b border-slate-100 w-12">
              <input
                type="checkbox"
                className="w-4 h-4 cursor-pointer accent-brand-primary"
                checked={isAllSelected}
                ref={(el) => {
                  if (el) el.indeterminate = isIndeterminate;
                }}
                onChange={handleSelectAll}
                aria-label="Select all records"
              />
            </th>

            {/* Data column headers */}
            {APPLICATIONS_UNLOCK_TABLE_COLUMNS.slice(1).map((h) => (
              <th
                key={h.label}
                className={`px-6 py-4 text-xs font-bold uppercase tracking-wider text-table-header-text border-b border-slate-100 whitespace-nowrap ${
                  h.align === "center" ? "text-center" : "text-start"
                }`}
              >
                {h.label}
              </th>
            ))}
          </tr>
        </thead>

        <tbody className="divide-y-2 divide-table-header-bg">
          {loading ? (
            Array.from({ length: 10 }).map((_, i) => (
              <TableSkeletonRow key={i} columnsCount={colSpan} />
            ))
          ) : records.length === 0 && !error ? (
            <tr>
              <td colSpan={colSpan} className="h-full">
                <EmptyState
                  title="No records found"
                  description={
                    search
                      ? `No results for "${search}". Try a different search.`
                      : "No locked applications found."
                  }
                />
              </td>
            </tr>
          ) : (
            records.map((record, index) => {
              const recordId = record.appNo || record.transactionId; // Fallback for keying if appNo is missing
              const isChecked = selectedAppNos.has(record.appNo);
              return (
                <ApplicationsUnlockTableRow
                  key={recordId || index}
                  rec={record}
                  serialNumber={(page - 1) * pageSize + index + 1}
                  isExpanded={!!expandedRows[recordId]}
                  onToggle={() => toggleRow(recordId)}
                  colSpan={colSpan}
                  isChecked={isChecked}
                  onSelect={() => handleSelectOne(record.appNo)}
                />
              );
            })
          )}
        </tbody>
      </table>
    </div>
  );
};

ApplicationsUnlockTable.displayName = "ApplicationsUnlockTable";
export default ApplicationsUnlockTable;
