import {
  FileIcon,
  ServerIcon,
  UserIcon,
} from "../../../components/icons/icons";
import { StatusBadge } from "../../../components/ui/badge/badgeIndex";
import DetailCard from "../../../components/ui/common/DetailCard";
import DetailField from "../../../components/ui/common/DetailField";

/**
 * ApplicationsUnlockExpandedRow
 *
 * Renders the expanded details view for a locked application record.
 * Displays additional metadata matching the Outward layout (Assigned User, Application, and Rack Details)
 * and includes all the fields from the Applications Unlock API response.
 *
 * @param {object} rec - The record object containing all application data.
 * @param {number} colSpan - The number of columns to span across the table.
 * @param {boolean} isExpanded - Determines if this row should be visible.
 */
const ApplicationsUnlockExpandedRow = ({ rec, colSpan, isExpanded }) => {
  return (
    <tr className="bg-slate-50/40">
      <td colSpan={colSpan} className="p-0 border-0">
        <div
          className={`expandable-row-wrapper ${isExpanded ? "expanded" : ""}`}
        >
          <div className="expandable-row-inner">
            <div className="px-6 py-4 border-b border-border-subtle">
              <section className="bg-white border border-slate-500/70 rounded-xl p-2 sm:p-5 shadow-xs grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 text-left">
                {/* Section 1: Assigned User Details */}
                <DetailCard title="Assigned User Details" icon={UserIcon}>
                  <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <DetailField
                      label="User"
                      value={
                        rec.assignedUser?.userName
                          ? `${rec.assignedUser.userName}${rec.assignedUser.userEmployeeCode ? ` (${rec.assignedUser.userEmployeeCode})` : ""}`
                          : typeof rec.assignedUser === "string"
                            ? rec.assignedUser
                            : "—"
                      }
                    />
                    <DetailField
                      label="Locked By"
                      value={
                        rec.modifiedBy?.userName ||
                        rec.lockedBy?.userName ||
                        "System"
                      }
                    />
                    <DetailField
                      label="Email"
                      value={rec.assignedUser?.userEmail}
                    />
                  </dl>
                </DetailCard>

                {/* Section 2: Application Details */}
                <DetailCard title="Application Details" icon={FileIcon}>
                  <dl className="grid grid-cols-2 gap-4">
                    <DetailField
                      label="File Type"
                      value={rec.fileType || "—"}
                    />
                    <DetailField label="Scheme" value={rec.schemaProduct} />
                    <div>
                      <dt className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                        Esign Status
                      </dt>
                      <dd className="mt-1">
                        <StatusBadge isActive={rec.isESign} />
                      </dd>
                    </div>
                  </dl>
                </DetailCard>

                {/* Section 3: Rack Details */}
                <DetailCard title="Rack Details" icon={ServerIcon}>
                  <dl className="grid grid-cols-3 gap-4">
                    <DetailField
                      label="Vault Name"
                      value={rec.rack?.vaultName}
                    />
                    <DetailField label="Rack Name" value={rec.rack?.rackName} />
                    <DetailField label="Self" value={rec.rack?.rackPosition} />
                    <div>
                      <dt className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
                        Rack Status
                      </dt>
                      <dd className="mt-1">
                        <StatusBadge isActive={rec.rack?.rackStatus} />
                      </dd>
                    </div>
                  </dl>
                </DetailCard>
              </section>
            </div>
          </div>
        </div>
      </td>
    </tr>
  );
};

ApplicationsUnlockExpandedRow.displayName = "ApplicationsUnlockExpandedRow";
export default ApplicationsUnlockExpandedRow;
