import { useCallback, useState } from "react";
import {
  getTransactionApi,
  updateTransactionLockApi,
} from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import Button from "../../components/ui/common/Button";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import Pagination from "../../components/ui/common/Pagination";
import { useUsersDropdown } from "../../hooks/dropdowns/useUsersDropdown";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import ApplicationsUnlockTable from "./components/ApplicationsUnlockTable";

/**
 * ApplicationsUnlock
 *
 * Container for the Application Unlock records.
 * Provides search, refresh, paginated listing, per-row selection,
 * and bulk-action button ("Unlock Applications").
 */
const ApplicationsUnlock = () => {
  const [assignedUserFilter, setAssignedUserFilter] = useState("");
  const [userSearchTerm, setUserSearchTerm] = useState("");

  const {
    options: userOptions,
    page: usersPage,
    hasMore: usersHasMore,
    loading: usersLoading,
    fetchPage: fetchUsersPage,
  } = useUsersDropdown(true, userSearchTerm);

  const handleUserLoadMore = useCallback(() => {
    if (usersHasMore && !usersLoading) {
      fetchUsersPage(usersPage, userSearchTerm);
    }
  }, [usersHasMore, usersLoading, fetchUsersPage, usersPage, userSearchTerm]);

  const fetchFn = useCallback(
    async (params) => {
      const { ...restParams } = params;
      const finalParams = {
        ...restParams,
        isLocked: true,
        ...(assignedUserFilter ? { assignedUser: assignedUserFilter } : {}),
      };
      return getTransactionApi(finalParams);
    },
    [assignedUserFilter],
  );

  const {
    data: records,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "likeAppNoOrBarcode");

  const [selectedAppNos, setSelectedAppNos] = useState(new Set());
  const [isSubmitting, setIsSubmitting] = useState(false);

  const hasSelection = selectedAppNos.size > 0;

  const handleSubmit = async () => {
    if (!hasSelection) return;

    setIsSubmitting(true);
    setError(null);

    try {
      const appNosArray = Array.from(selectedAppNos);
      await updateTransactionLockApi({
        appNos: appNosArray.join(","),
        isLocked: false,
      });

      setSelectedAppNos(new Set());
      refetch();
    } catch (err) {
      setError(
        err?.response?.data?.message ||
          err?.message ||
          "Failed to unlock applications",
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRefresh = () => {
    if (!assignedUserFilter) {
      refetch();
    } else {
      setAssignedUserFilter("");
      setUserSearchTerm("");
    }
  };

  return (
    <ListContainer>
      <ListHeader
        title="Application Unlock"
        unit="records"
        count={pagination.totalItems}
        loading={loading}
        search={search}
        setSearch={setSearch}
        refetch={handleRefresh}
      >
        {/* Filters */}
        <search className="mt-4 grid grid-cols-1 sm:flex sm:flex-row flex-wrap items-start sm:items-center gap-3 sm:gap-5 w-full">
          <FilterSelectField
            label="Filter by User:"
            name="assignedUserFilter"
            value={assignedUserFilter}
            onChange={(e) => setAssignedUserFilter(e.target.value)}
            placeholder="All Users"
            options={userOptions}
            className="w-full sm:w-auto"
            showSearch={true}
            searchPlaceholder="Search by user name"
            searchTerm={userSearchTerm}
            onSearchChange={setUserSearchTerm}
            isLoadingMore={usersLoading}
            hasMore={usersHasMore}
            onLoadMore={handleUserLoadMore}
          />
        </search>
      </ListHeader>

      {/* Error banner */}
      {error && (
        <section className="px-6 pt-4">
          <ErrorBanner message={error} onClose={() => setError(null)} />
        </section>
      )}

      <ApplicationsUnlockTable
        records={records}
        loading={loading}
        error={error}
        search={search}
        page={page}
        pageSize={pageSize}
        selectedAppNos={selectedAppNos}
        onSelectionChange={setSelectedAppNos}
      />

      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
        showAction={true}
        actionLabel="Unlock Applications"
        actionId="applications-unlock-submit"
        onActionClick={handleSubmit}
        actionDisabled={!hasSelection || isSubmitting}
        actionIsLoading={isSubmitting}
      />
    </ListContainer>
  );
};

ApplicationsUnlock.displayName = "ApplicationsUnlock";
export default ApplicationsUnlock;
