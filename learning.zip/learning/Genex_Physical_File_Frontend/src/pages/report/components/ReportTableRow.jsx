import { useSelector } from "react-redux";
import { ChevronRightIcon } from "../../../components/icons/icons";
import IconButton from "../../../components/ui/common/IconButton";
import { ROLES } from "../../../constants/roles";
import ReportExpandedRow from "./ReportExpandedRow";

const ReportTableRow = ({
  rec,
  serialNumber,
  isExpanded,
  onToggle,
  colSpan,
}) => {
  const { roleName } = useSelector((state) => state.user);
  const isCpu = roleName === ROLES.CPU;

  // Unified mapping for both rackAssigned and transaction APIs
  const appNo = rec.appNo || "—";

  let userDisplay = "—";
  if (rec.assignedUser?.userName) {
    userDisplay = `${rec.assignedUser.userName}${rec.assignedUser.userEmployeeCode ? ` (${rec.assignedUser.userEmployeeCode})` : ""}`;
  }

  const fileType = rec.fileTypeName || rec.fileType || "—";
  const ageingNo =
    rec.ageingNo !== "" && rec.ageingNo != null ? rec.ageingNo : "—";

  const vaultName = rec.vaultName || rec.rack?.vaultName || "—";
  const rackName = rec.rackName || rec.rack?.rackName || "—";

  const status = rec.assignedStatus || rec.stage?.stageName || "—";

  return (
    <>
      <tr
        onClick={onToggle}
        className="hover:bg-slate-200/80 transition-colors cursor-pointer border-b border-border-subtle"
      >
        <td
          className="table-td-center"
          onClick={(e) => {
            e.stopPropagation();
            onToggle();
          }}
        >
          <IconButton
            onClick={(e) => {
              e.stopPropagation();
              onToggle();
            }}
            className="p-1 hover:bg-slate-200 text-text-secondary shadow-none border-none bg-transparent hover:text-text-secondary focus:outline-none"
            ariaLabel={isExpanded ? "Collapse row" : "Expand row"}
            icon={
              <ChevronRightIcon
                className={`w-4 h-4 transition-transform duration-200 ${
                  isExpanded ? "rotate-90" : ""
                }`}
              />
            }
          />
        </td>
        <td className="table-td">{serialNumber}</td>
        <td className="table-td">{appNo}</td>
        <td className="px-3 py-1 text-sm font-medium text-text-primary whitespace-nowrap align-middle">
          {userDisplay}
        </td>
        <td className="table-td">{fileType}</td>
        <td
          className={`table-td ${
            ageingNo !== "—" && Number(ageingNo) > 15
              ? "text-red-600 font-bold"
              : ""
          }`}
        >
          {ageingNo}
        </td>
        <td className="table-td">{vaultName}</td>
        <td className="table-td">{rackName}</td>
        <td className="table-td capitalize font-semibold">{status}</td>
      </tr>

      <ReportExpandedRow rec={rec} colSpan={colSpan} isExpanded={isExpanded} />
    </>
  );
};

ReportTableRow.displayName = "ReportTableRow";

export default ReportTableRow;
