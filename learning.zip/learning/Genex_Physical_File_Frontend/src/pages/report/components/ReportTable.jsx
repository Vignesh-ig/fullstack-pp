import { useState } from "react";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { USER_ALLOCATION_TABLE_COLUMNS } from "../../../constants/tableHeaders";
import ReportTableRow from "./ReportTableRow";

/**
 * ReportTable
 *
 * Renders the paginated list of records inside a scrollable Table. Supports row-level expand/collapse via ReportExpandedRow. 
 * Shows a skeleton loader while fetching and an EmptyState when no records exist.
 * Styled exactly like the User Allocation table.
 */
const ReportTable = ({ records, loading, error, page, pageSize }) => {
  const [expandedRows, setExpandedRows] = useState({});

  const toggleRow = (id) => {
    setExpandedRows((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const displayedHeaders = USER_ALLOCATION_TABLE_COLUMNS.filter(
    (col) => col.label !== "Actions"
  );
  const colSpan = displayedHeaders.length;

  if (error) return null;

  return (
    <Table headers={displayedHeaders} headerColorClass="bg-table-header-bg">
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow key={i} columnsCount={colSpan} />
        ))
      ) : records.length === 0 && !error ? (
        <tr>
          <td colSpan={colSpan} className="h-full">
            <EmptyState
              title="No Data Found"
              description="Try adjusting your filters to find what you're looking for."
            />
          </td>
        </tr>
      ) : (
        records.map((rec, index) => {
          // Use transactionId or rackAssignedId as the unique key, fallback to index
          const recordId = rec.transactionId || rec.rackAssignedId || index;
          
          return (
            <ReportTableRow
              key={recordId}
              rec={rec}
              serialNumber={(page - 1) * pageSize + index + 1}
              isExpanded={!!expandedRows[recordId]}
              onToggle={() => toggleRow(recordId)}
              colSpan={colSpan}
            />
          );
        })
      )}
    </Table>
  );
};

ReportTable.displayName = "ReportTable";
export default ReportTable;
