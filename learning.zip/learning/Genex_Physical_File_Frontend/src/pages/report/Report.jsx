import { useCallback, useEffect, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { getRackAssignedApi, getTransactionApi } from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import Button from "../../components/ui/common/Button";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import InputField from "../../components/ui/common/InputField";
import Pagination from "../../components/ui/common/Pagination";
import SelectField from "../../components/ui/common/SelectField";
import SelectFieldWithCheckbox from "../../components/ui/common/SelectFieldWithCheckbox";
import { ADMIN_ROLES } from "../../constants/roles";
import { APP_STAGES } from "../../constants/stages";
import { useUsersDropdown } from "../../hooks/dropdowns/useUsersDropdown";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import { useStages } from "../../hooks/useStages";
import {
  buildReportFilename,
  exportToCSVWithColumns,
  getTodayInputFormat,
} from "../../utils/utils";
import ReportTable from "./components/ReportTable";
import {
  ALLOCATION_CSV_COLUMNS,
  ENQUIRY_CSV_COLUMNS,
  QUERY_CSV_COLUMNS,
  TRANSACTION_CSV_COLUMNS,
} from "./constants/csvHeaders";

/**
 * MODULE_OPTIONS
 *
 * Module choices available in the Module dropdown.
 * "Productivity Activity" disables the stage dropdown.
 * Order: Productivity Activity first, then Allocations, Stages, etc.
 */
const MODULE_OPTIONS = [
  { value: "PRODUCTIVITY_REPORT", label: "Productivity Report" },
  { value: "Allocations", label: "Allocations" },
  { value: "Stages", label: "Stages" },
  { value: "NON_CRITICAL_QUERY", label: "Non critical query" },
  { value: "APPLICATIONS_UNLOCK", label: "Application unlock" },
  { value: "ENQUIRY", label: "Enquiry" },
];

// Modules whose stage is pre-selected and the Stage dropdown should be locked
const STAGE_LOCKED_MODULES = new Set([
  "NON_CRITICAL_QUERY",
  "APPLICATIONS_UNLOCK",
  "ENQUIRY",
]);

// includeStagesSearch value per module that uses the stage API
const MODULE_STAGE_INCLUDES = {
  Allocations: `${APP_STAGES.RACK_ASSIGNED},${APP_STAGES.USER_ASSIGNED}`,
  Stages: `${APP_STAGES.HEALTH_CHECK},${APP_STAGES.QUERY},${APP_STAGES.QUERY_RESOLVED},${APP_STAGES.OUTWARD},${APP_STAGES.STAMPING},${APP_STAGES.STORAGE}`,
  // Productivity Activity fetches only the ENQUIRY stage from the API
  PRODUCTIVITY_REPORT: APP_STAGES.ENQUIRY,
};

/**
 * Report
 *
 * Main report page.
 * - Module is the first dropdown; Stage is the second.
 * - Selecting "Productivity Activity" locks and clears the Stage dropdown.
 * - Allocations & Stages fetch their options from the /stage API.
 * - NON_CRITICAL_QUERY and APPLICATIONS_UNLOCK use fixed pre-selected stage values.
 * - All data fetch (table + CSV export) is triggered only by clicking Fetch / Export.
 */
const Report = () => {
  const { userId: currentUserId, roleName } = useSelector(
    (state) => state.user,
  );
  const isAdmin = ADMIN_ROLES.includes(roleName);

  // ── Form states ────────────────────────────────────────────────────────
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState(getTodayInputFormat());
  const [selectedModule, setSelectedModule] = useState("");
  const [selectedStages, setSelectedStages] = useState([]);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [userSearchTerm, setUserSearchTerm] = useState("");
  const [isExporting, setIsExporting] = useState(false);

  // Holds filters only when Fetch is clicked
  const [appliedFilters, setAppliedFilters] = useState(null);

  // ── Stage dropdown — driven by selected module via useStages ───────────
  const { stageOptions, stagesLoading } = useStages(
    MODULE_STAGE_INCLUDES[selectedModule] ?? "",
  );

  // ── Users Dropdown ─────────────────────────────────────────────────────
  const {
    options: userOptions,
    page: usersPage,
    hasMore: usersHasMore,
    loading: usersLoading,
    fetchPage: fetchUsersPage,
  } = useUsersDropdown(isAdmin, userSearchTerm, "");

  const handleUserLoadMore = useCallback(() => {
    if (usersHasMore && !usersLoading) {
      fetchUsersPage(usersPage, userSearchTerm);
    }
  }, [usersHasMore, usersLoading, fetchUsersPage, usersPage, userSearchTerm]);

  // ── Module change handler ─────────────────────────────────────────────
  const handleModuleChange = useCallback((e) => {
    const val = e.target.value;
    setSelectedModule(val);

    // Pre-select fixed values for locked modules; clear otherwise
    if (val === "NON_CRITICAL_QUERY") {
      setSelectedStages(["NON_CRITICAL_QUERY"]);
    } else if (val === "APPLICATIONS_UNLOCK") {
      setSelectedStages(["APPLICATIONS_UNLOCK"]);
    } else if (val === "ENQUIRY") {
      setSelectedStages(["ENQUIRY"]);
    } else {
      // For PRODUCTIVITY_ACTIVITY, Allocations, Stages — clear and let
      // the useEffect below auto-select once stageOptions arrive
      setSelectedStages([]);
    }
  }, []);

  // ── Auto-select ENQUIRY stage for Productivity Activity ──────────────────
  // When Productivity Activity is selected, stageOptions will contain exactly
  // the ENQUIRY stage once the API returns. Auto-select it immediately.
  useEffect(() => {
    if (
      selectedModule === "PRODUCTIVITY_REPORT" &&
      stageOptions.length > 0 &&
      selectedStages.length === 0
    ) {
      const enquiryStage = stageOptions.find(
        (opt) => opt.rawName === APP_STAGES.ENQUIRY,
      );
      if (enquiryStage) {
        setSelectedStages([enquiryStage.rawName ?? enquiryStage.value]);
      }
    }
  }, [selectedModule, stageOptions, selectedStages.length]);

  // ── Stage dropdown options (resolved per module) ───────────────────────
  // useStages returns stageId as value; Report needs stageName for API params,
  // so we remap rawName → value for the Allocations / Stages modules.
  const resolvedStageOptions = useMemo(() => {
    if (selectedModule === "NON_CRITICAL_QUERY") {
      return [{ value: "NON_CRITICAL_QUERY", label: "Non critical query" }];
    }
    if (selectedModule === "APPLICATIONS_UNLOCK") {
      return [{ value: "APPLICATIONS_UNLOCK", label: "Application unlock" }];
    }
    if (selectedModule === "ENQUIRY") {
      return [{ value: "ENQUIRY", label: "Enquiry" }];
    }
    // Map rawName as value so selectedStages holds stageName strings
    return stageOptions.map((opt) => ({
      label: opt.label,
      value: opt.rawName ?? opt.value,
    }));
  }, [selectedModule, stageOptions]);

  const isStageDisabled =
    !selectedModule ||
    STAGE_LOCKED_MODULES.has(selectedModule) ||
    stagesLoading;

  // ── 15-day date range validation for Productivity Activity (reactive) ────────
  const MAX_PRODUCTIVITY_DAYS = 15;
  const dateRangeError = useMemo(() => {
    if (selectedModule !== "PRODUCTIVITY_REPORT") return "";
    if (!fromDate || !toDate) return "";
    const diff =
      (new Date(toDate) - new Date(fromDate)) / (1000 * 60 * 60 * 24);
    if (diff > MAX_PRODUCTIVITY_DAYS) {
      return `Productivity Activity report is limited to ${MAX_PRODUCTIVITY_DAYS} days. Please narrow your date range.`;
    }
    return "";
  }, [selectedModule, fromDate, toDate]);

  // ── Whether the Fetch button should be enabled ─────────────────────────
  const isProductivityActivity = selectedModule === "PRODUCTIVITY_REPORT";
  const isEnquiry = selectedModule === "ENQUIRY";
  const isFetchEnabled =
    !!fromDate &&
    !!toDate &&
    !!selectedModule &&
    !dateRangeError &&
    (isProductivityActivity || isEnquiry || selectedStages.length > 0);

  // ── Core data-fetch helper ─────────────────────────────────────────────
  const executeDataFetch = useCallback(
    async (params, isExport = false, activeFilters) => {
      if (!activeFilters) return [];

      const commonParams = {
        ...params,
        startDate: activeFilters.fromDate,
        endDate: activeFilters.toDate,
      };

      if (isExport) {
        commonParams.exportAllRecords = true;
      }

      if (activeFilters.selectedUsers?.length > 0) {
        commonParams.assignedUser = activeFilters.selectedUsers.join(",");
      } else if (!isAdmin) {
        commonParams.assignedUser = currentUserId;
      }

      const { selectedModule: appliedModule, selectedStages: appliedStages } =
        activeFilters;

      const promises = [];

      if (appliedModule === "Allocations") {
        const hasUserAlloc = appliedStages.includes(APP_STAGES.USER_ASSIGNED);
        const hasRackAlloc = appliedStages.includes(APP_STAGES.RACK_ASSIGNED);

        if (hasUserAlloc && hasRackAlloc) {
          promises.push(getRackAssignedApi({ ...commonParams }));
        } else if (hasUserAlloc) {
          promises.push(
            getRackAssignedApi({ ...commonParams, userAssigned: true }),
          );
        } else if (hasRackAlloc) {
          promises.push(
            getRackAssignedApi({ ...commonParams, userAssigned: false }),
          );
        }
      } else if (appliedModule === "Stages") {
        if (appliedStages.length > 0) {
          promises.push(
            getTransactionApi({
              ...commonParams,
              stages: appliedStages.join(","),
            }),
          );
        }
      } else if (appliedModule === "NON_CRITICAL_QUERY") {
        promises.push(
          getTransactionApi({
            ...commonParams,
            queryState: "NON_CRITICAL_QUERY",
          }),
        );
      } else if (appliedModule === "APPLICATIONS_UNLOCK") {
        promises.push(getTransactionApi({ ...commonParams, isLocked: true }));
      } else if (appliedModule === "PRODUCTIVITY_REPORT") {
        promises.push(
          getTransactionApi({
            ...commonParams,
            stages:
              appliedStages.length > 0
                ? appliedStages.join(",")
                : APP_STAGES.ENQUIRY,
          }),
        );
      } else if (appliedModule === "ENQUIRY") {
        promises.push(
          getTransactionApi({ ...commonParams, stages: APP_STAGES.ENQUIRY }),
        );
      }

      return Promise.all(promises);
    },
    [isAdmin, currentUserId],
  );

  // ── Paginated fetch fn for table ───────────────────────────────────────
  const fetchFn = useCallback(
    async (params) => {
      const { _dummySearchParam, ...restParams } = params; // NOSONAR

      const isProductivity =
        appliedFilters?.selectedModule === "PRODUCTIVITY_REPORT";
      const isEnquiryModule = appliedFilters?.selectedModule === "ENQUIRY";

      if (
        !appliedFilters ||
        !appliedFilters.fromDate ||
        !appliedFilters.toDate ||
        !appliedFilters.selectedModule ||
        (!isProductivity &&
          !isEnquiryModule &&
          appliedFilters.selectedStages.length === 0)
      ) {
        return {
          data: { data: [], totalPages: 1, currentPage: 1, totalItems: 0 },
        };
      }

      const results = await executeDataFetch(restParams, false, appliedFilters);

      let mergedData = [];
      let totalItems = 0;
      let maxTotalPages = 1;

      results.forEach((res) => {
        const payload = res?.data ?? res;
        if (payload?.data && Array.isArray(payload.data)) {
          mergedData = [...mergedData, ...payload.data];
        } else if (Array.isArray(payload)) {
          mergedData = [...mergedData, ...payload];
        }
        totalItems += payload?.totalItems || 0;
        maxTotalPages = Math.max(maxTotalPages, payload?.totalPages || 1);
      });

      return {
        data: {
          data: mergedData,
          currentPage: params.page,
          totalPages: maxTotalPages,
          totalItems,
        },
      };
    },
    [appliedFilters, executeDataFetch],
  );

  const {
    data: records,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize: handlePageSizeChange,
  } = usePaginatedFetch(fetchFn, 10, "dummy");

  // ── Fetch button click ─────────────────────────────────────────────────
  const handleFetch = useCallback(() => {
    if (dateRangeError) return;
    setAppliedFilters({
      fromDate,
      toDate,
      selectedModule,
      selectedStages,
      selectedUsers,
    });
  }, [
    fromDate,
    toDate,
    selectedModule,
    selectedStages,
    selectedUsers,
    dateRangeError,
  ]);

  // ── CSV column selection based on active module ────────────────────────
  const resolveCsvColumns = useCallback((module, stages) => {
    if (module === "Allocations") return ALLOCATION_CSV_COLUMNS;
    if (module === "PRODUCTIVITY_REPORT") return ENQUIRY_CSV_COLUMNS;
    if (module === "Stages" && stages.length > 0) {
      const onlyQueryStages = stages.every((s) =>
        [APP_STAGES.QUERY, APP_STAGES.QUERY_RESOLVED].includes(s),
      );
      if (onlyQueryStages) {
        return QUERY_CSV_COLUMNS;
      }
    }
    return TRANSACTION_CSV_COLUMNS;
  }, []);

  // ── CSV Export ────────────────────────────────────────────────────────
  const handleExportCSV = useCallback(async () => {
    if (!fromDate || !toDate || !selectedModule) {
      setError("Please select From Date, To Date, and Module to export.");
      return;
    }
    if (!isProductivityActivity && !isEnquiry && selectedStages.length === 0) {
      setError("Please select at least one Stage / Allocation to export.");
      return;
    }

    try {
      if (dateRangeError) return;
      setIsExporting(true);
      setError(null);

      const activeFiltersForExport = {
        fromDate,
        toDate,
        selectedModule,
        selectedStages,
        selectedUsers,
      };

      const results = await executeDataFetch({}, true, activeFiltersForExport);
      let dataToExport = [];

      results.forEach((res) => {
        const payload = res?.data ?? res;
        if (payload?.data && Array.isArray(payload.data)) {
          dataToExport = [...dataToExport, ...payload.data];
        } else if (Array.isArray(payload)) {
          dataToExport = [...dataToExport, ...payload];
        }
      });

      if (!dataToExport || dataToExport.length === 0) {
        setError("No records found to export for the selected criteria.");
        return;
      }

      const csvColumns = resolveCsvColumns(selectedModule, selectedStages);
      const filename = buildReportFilename(
        selectedModule,
        selectedStages,
        fromDate,
        toDate,
      );
      exportToCSVWithColumns(dataToExport, filename, csvColumns);
    } catch {
      setError("Failed to export records. Please try again.");
    } finally {
      setIsExporting(false);
    }
  }, [
    fromDate,
    toDate,
    selectedModule,
    selectedStages,
    selectedUsers,
    isProductivityActivity,
    isEnquiry,
    dateRangeError,
    executeDataFetch,
    resolveCsvColumns,
    setError,
  ]);

  // ── Stage dropdown label ───────────────────────────────────────────────
  const stageLabel =
    selectedModule === "Allocations" ? "Allocations" : "Stages";
  const stagePlaceholder =
    selectedModule === "Allocations" ? "Select Allocations" : "Select Stages";
  const stageCountText =
    selectedModule === "Allocations" ? "allocations" : "stages";

  return (
    <ListContainer>
      <ListHeader title="Reports" />

      {/* ── Filter Card ─────────────────────────────────────────────── */}
      <section className="bg-white p-6 rounded-xl border border-border-subtle shadow-sm mb-6 mx-6 mt-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
          {/* 1. Module */}
          <div className="w-full">
            <SelectField
              label="Module"
              name="module"
              value={selectedModule}
              onChange={handleModuleChange}
              options={MODULE_OPTIONS}
              required
              placeholder="Select Module"
              className="w-full mb-0!"
            />
          </div>

          {/* 2. Stage (disabled for Productivity Activity) */}
          <div className="w-full">
            <SelectFieldWithCheckbox
              label={stageLabel}
              name="stages"
              value={selectedStages}
              onChange={(e) => setSelectedStages(e.target.value)}
              options={resolvedStageOptions}
              required={!isProductivityActivity}
              countText={stageCountText}
              placeholder={stagesLoading ? "Loading stages…" : stagePlaceholder}
              disabled={isStageDisabled}
              className="w-full"
            />
          </div>

          {/* 3. From Date */}
          <InputField
            label="From Date"
            name="fromDate"
            type="date"
            value={fromDate}
            onChange={(e) => setFromDate(e.target.value)}
            required
          />

          {/* 4. To Date */}
          <InputField
            label="To Date"
            name="toDate"
            type="date"
            value={toDate}
            onChange={(e) => setToDate(e.target.value)}
            required
            min={fromDate}
          />

          {/* 5. User */}
          <div className="w-full">
            <SelectFieldWithCheckbox
              label="User"
              name="users"
              value={selectedUsers}
              onChange={(e) => setSelectedUsers(e.target.value)}
              options={userOptions}
              showSearch={true}
              searchPlaceholder="Search User"
              onSearchChange={setUserSearchTerm}
              isLoadingMore={usersLoading}
              hasMore={usersHasMore}
              onLoadMore={handleUserLoadMore}
              placeholder="Select Users"
              countText="users"
              className="w-full"
            />
          </div>
        </div>

        {dateRangeError && (
          <p className="mt-3 text-sm text-status-error font-medium">
            {dateRangeError}
          </p>
        )}

        <div className="flex justify-end gap-3 mt-6">
          <Button
            variant="primary"
            onClick={handleFetch}
            disabled={!isFetchEnabled}
            className="w-auto px-8"
          >
            Fetch
          </Button>
          <Button
            variant="secondary"
            onClick={handleExportCSV}
            disabled={!records || records.length === 0}
            loading={isExporting}
            className="w-auto px-8 bg-blue-600 text-white hover:bg-blue-700"
          >
            Export as CSV
          </Button>
        </div>
      </section>

      {error && (
        <section className="px-6 mb-4">
          <ErrorBanner message={error} onClose={() => setError(null)} />
        </section>
      )}

      {/* ── Dynamic Table ─────────────────────────────────────────────── */}
      <div className="px-6 pb-6">
        <ReportTable
          records={records}
          loading={loading}
          error={error}
          page={page}
          pageSize={pageSize}
        />
        <Pagination
          currentPage={pagination.currentPage}
          totalPages={pagination.totalPages}
          onPageChange={setPage}
          totalItems={pagination.totalItems}
          pageSize={pageSize}
          onPageSizeChange={handlePageSizeChange}
        />
      </div>
    </ListContainer>
  );
};

Report.displayName = "Report";
export default Report;
