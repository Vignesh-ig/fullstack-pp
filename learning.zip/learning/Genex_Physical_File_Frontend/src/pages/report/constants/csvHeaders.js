import { formatDateOnlyToIST, formatDateToIST } from "../../../utils/utils";

/**
 * csvHeaders.js  (Report-local)
 *
 * Defines CSV column mappings for report exports.
 * Each column entry has:
 *  - header   {string}   - The CSV column heading text
 *  - accessor {Function} - Extracts the cell value from a data record
 *
 * Used by exportToCSVWithColumns in utils.js.
 */

/**
 * CSV column definitions for Rack Allocation & User Allocation reports.
 * Sourced from the getRackAssignedApi response payload.
 *
 * Fields pending backend delivery are included as placeholders that will
 * resolve to "" until the API provides them:
 *   - businessDate, businessMonth  (allocation response, coming soon)
 *   - entryDate                    (rack allocation entry timestamp, coming soon)
 *   - assignedDate                 (user allocation timestamp, coming soon)
 */
export const ALLOCATION_CSV_COLUMNS = [
  {
    header: "APPLICATION NO",
    accessor: (rec) => rec.appNo ?? "",
  },
  {
    header: "AGREEMENT NO",
    accessor: (rec) => rec.aggNo ?? "",
  },
  {
    header: "BARCODE",
    accessor: (rec) => rec.barcode ?? "",
  },
  {
    header: "CUSTOMER NAME",
    accessor: (rec) => rec.customerName ?? "",
  },
  {
    header: "AGEING",
    accessor: (rec) => rec.ageingNo ?? "",
  },
  {
    header: "FILE TYPE",
    accessor: (rec) => rec.fileType ?? "",
  },
  {
    // Will be populated once backend sends this field
    header: "BUSINESS DATE",
    accessor: (rec) => formatDateOnlyToIST(rec.businessDate, ""),
  },
  {
    // Will be populated once backend sends this field
    header: "BUSINESS MONTH",
    accessor: (rec) => rec.businessMonth ?? "",
  },
  {
    header: "VAULT NAME",
    accessor: (rec) => rec.vaultName ?? "",
  },
  {
    header: "RACK NAME",
    accessor: (rec) => rec.rackName ?? "",
  },
  {
    header: "SELF",
    accessor: (rec) => rec.rackPosition ?? "",
  },
  {
    header: "ENTRY USER",
    accessor: (rec) => {
      const name = rec.createdBy?.userName ?? "";
      const empCode = rec.createdBy?.userEmployeeCode ?? "";
      if (!name) return "";
      return empCode ? `${name} (${empCode})` : name;
    },
  },
  {
    // Will be populated once backend sends this field
    header: "ENTRY DATE",
    accessor: (rec) => formatDateOnlyToIST(rec.createdDate, ""),
  },
  {
    header: "ASSIGNED USER",
    accessor: (rec) => {
      const name = rec.assignedUser?.userName ?? "";
      const empCode = rec.assignedUser?.userEmployeeCode ?? "";
      if (!name) return "";
      return empCode ? `${name} (${empCode})` : name;
    },
  },
  {
    // Will be populated once backend sends this field
    header: "ASSIGNED DATE",
    accessor: (rec) => formatDateOnlyToIST(rec.modifiedDate, ""),
  },
];

/**
 * CSV column definitions for Transaction / Stage reports.
 * Sourced from the getTransactionApi response payload.
 *
 * Fields pending backend delivery are included as placeholders that will
 * resolve to "" until the API provides them:
 *   - businessMonth  (transaction response, coming soon)
 */
export const TRANSACTION_CSV_COLUMNS = [
  {
    header: "APPLICATION NO",
    accessor: (rec) => rec.appNo ?? "",
  },
  {
    header: "AGREEMENT NO",
    accessor: (rec) => rec.aggNo ?? "",
  },
  {
    header: "BARCODE",
    accessor: (rec) => rec.barcode ?? "",
  },
  {
    header: "CUSTOMER NAME",
    accessor: (rec) => rec.customerName ?? "",
  },
  {
    header: "AGEING",
    accessor: (rec) => rec.ageingNo ?? "",
  },
  {
    header: "FILE TYPE",
    accessor: (rec) => rec.fileType ?? "",
  },
  {
    header: "BUSINESS DATE",
    accessor: (rec) => formatDateOnlyToIST(rec.businessDate, ""),
  },
  {
    // Will be populated once backend sends this field
    header: "BUSINESS MONTH",
    accessor: (rec) => rec.businessMonth ?? "",
  },
  {
    header: "END DATE",
    accessor: (rec) => formatDateOnlyToIST(rec.emiEndDate, ""),
  },
  {
    header: "STATE",
    accessor: (rec) => rec.stateDesc ?? "",
  },
  {
    header: "BRANCH",
    accessor: (rec) => rec.branchDesc ?? "",
  },
  {
    header: "CURRENT REMARKS",
    accessor: (rec) => rec.currentRemarks ?? "",
  },
  {
    header: "POD NO",
    accessor: (rec) => rec.podNo ?? "",
  },
  {
    header: "QUERY POD NO",
    accessor: (rec) => rec.missingPodNo ?? "",
  },
  {
    header: "LEAD ID",
    accessor: (rec) => rec.leadId ?? "",
  },
  {
    header: "AMOUNT FINANCE",
    accessor: (rec) => rec.amountFinance ?? "",
  },
  {
    header: "SCHEME",
    accessor: (rec) => rec.schemaProduct ?? "",
  },
  {
    header: "REPAYMENT MODE",
    accessor: (rec) => rec.rePaymentMode ?? "",
  },
  {
    header: "WORKFLOW NO",
    accessor: (rec) => rec.workflowNo ?? "",
  },
  {
    header: "STAMP TYPE",
    accessor: (rec) => rec.stampType ?? "",
  },
  {
    header: "LEAP STAMP AMOUNT",
    accessor: (rec) => rec.leapStampAmount ?? "",
  },
  {
    header: "IS E-SIGN",
    accessor: (rec) => (rec.isESign != null ? String(rec.isESign) : ""),
  },
  {
    header: "LOAN ID",
    accessor: (rec) => rec.loanId ?? "",
  },
  {
    header: "SOURCING DATE",
    accessor: (rec) => formatDateOnlyToIST(rec.sourcingDate, ""),
  },
  {
    header: "TENURE",
    accessor: (rec) => rec.tenure ?? "",
  },
  {
    header: "BIRR",
    accessor: (rec) => rec.birr ?? "",
  },
  {
    header: "REGISTRABLE STATUS",
    accessor: (rec) => rec.registrableStatus ?? "",
  },
  {
    header: "UDHAYAM NUMBER STATUS",
    accessor: (rec) => rec.udhayamNumberStatus ?? "",
  },
  {
    header: "PAC AMOUNT",
    accessor: (rec) => rec.pacAmount ?? "",
  },
  {
    header: "QUERY CARTON BARCODE",
    accessor: (rec) => rec.queryCartonBarcode ?? "",
  },
  {
    header: "STAGE",
    accessor: (rec) => rec.stage?.stageName ?? "",
  },
  {
    header: "QUERY CATEGORY",
    accessor: (rec) => rec.queryCategory?.queryCategoryName ?? "",
  },
  {
    header: "ASSIGNED USER",
    accessor: (rec) => {
      const name = rec.assignedUser?.userName ?? "";
      const empCode = rec.assignedUser?.userEmployeeCode ?? "";
      if (!name) return "";
      return empCode ? `${name} (${empCode})` : name;
    },
  },
  {
    header: "ASSIGNED USER EMAIL",
    accessor: (rec) => rec.assignedUser?.userEmail ?? "",
  },
  {
    header: "PREVIOUS STAGE COMPLETED BY",
    accessor: (rec) => {
      const name = rec.modifiedUser?.userName ?? "";
      const empCode = rec.modifiedUser?.userEmployeeCode ?? "";
      if (!name) return "";
      return empCode ? `${name} (${empCode})` : name;
    },
  },
  {
    header: "PREVIOUS STAGE COMPLETED BY EMAIL",
    accessor: (rec) => rec.modifiedUser?.userEmail ?? "",
  },
];

/**
 * CSV column definitions for Query & Query Resolved reports.
 * Sourced from the getTransactionApi response payload (stages=QUERY or QUERY_RESOLVED).
 *
 * Columns marked "— Need backend" will resolve to "" until the API delivers the field.
 */
export const QUERY_CSV_COLUMNS = [
  {
    header: "APPLICATION NUMBER",
    accessor: (rec) => rec.appNo ?? "",
  },
  {
    header: "AGREEMENT NUMBER",
    accessor: (rec) => rec.aggNo ?? "",
  },
  {
    header: "BARCODE",
    accessor: (rec) => rec.barcode ?? "",
  },
  {
    // Agreement Status — not yet in payload; placeholder
    header: "AGREEMENT STATUS",
    accessor: (rec) => rec.transactionStatus ?? "",
  },
  {
    // Product Name / product category — pending Leap integration
    header: "PRODUCT NAME",
    accessor: (rec) => rec.schemaProduct ?? "",
  },
  {
    // Month derived from businessDate
    header: "MONTH",
    accessor: (rec) => rec.businessMonth ?? "",
  },
  {
    header: "BRANCH",
    accessor: (rec) => rec.branchDesc ?? "",
  },
  {
    header: "STATE",
    accessor: (rec) => rec.stateDesc ?? "",
  },
  {
    header: "CUSTOMER NAME",
    accessor: (rec) => rec.customerName ?? "",
  },
  {
    header: "WORKFLOW NUMBER",
    accessor: (rec) => rec.workflowNo ?? "",
  },
  {
    header: "AMOUNT FINANCE",
    accessor: (rec) => rec.amountFinance ?? "",
  },
  {
    header: "CURRENT STAGE",
    accessor: (rec) => rec.stage?.stageName ?? "",
  },
  {
    // Initial Query Raised Date — Need to be done by backend
    header: "INITIAL QUERY RAISED DATE",
    accessor: (rec) => formatDateOnlyToIST(rec.queryRaisedDate, ""),
  },
  {
    // Health Check User Name — Need to be done by backend
    header: "HEALTH CHECK USER NAME",
    accessor: (rec) => rec.healthCheckUserName ?? "",
  },
  {
    // Health Check User ID — Need to be done by backend
    header: "HEALTH CHECK USER ID",
    accessor: (rec) => rec.healthCheckUserId ?? "",
  },
  {
    // Critical / Non Critical derived from query.queryName
    header: "CRITICAL / NON CRITICAL",
    accessor: (rec) => rec.query?.queryName ?? "",
  },
  {
    // Final Query Clearance Date = outwardDate
    header: "FINAL QUERY CLEARANCE DATE",
    accessor: (rec) => formatDateOnlyToIST(rec.outwardDate, ""),
  },
  {
    // Selection of category & sub category added in remarks so only take remarks
    header: "QUERY CATEGORY & QUERY SUB CATEGORY",
    accessor: (rec) => rec.currentRemarks ?? "",
  },
  {
    header: "SCHEME",
    accessor: (rec) => rec.schemaProduct ?? "",
  },
  {
    // Resolution Entry Barcode — placeholder
    header: "QUERY CARTON BARCODE",
    accessor: (rec) => rec.queryCartonBarcode ?? "",
  },
];

// ─────────────────────────────────────────────────────────────────────────────
// ENQUIRY CSV COLUMNS
// Rich per-stage breakdown derived from the transactionsHistory array.
// Falls back to rec.stage.stageName when transactionsHistory is empty
// (e.g. Productivity Report response where history is not returned).
// Mirrors the logic in EnquiryHistory.jsx.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * formatHistoryUser
 *
 * Returns "Name (EmpCode)" or "" from a user DTO object.
 *
 * @param {Object|null} userDto - User DTO with userName and userEmployeeCode.
 * @returns {string}
 */
const formatHistoryUser = (userDto) => {
  if (!userDto) return "";
  const name = userDto.userName ?? "";
  const code = userDto.userEmployeeCode ?? "";
  if (!name) return "";
  return code ? `${name} (${code})` : name;
};

/**
 * Ordered pipeline of stages (earliest → latest).
 * Used to infer completion from rec.stage.stageName when
 * transactionsHistory is empty.
 */
const STAGE_ORDER = [
  "RACK_ASSIGNED",
  "USER_ASSIGNED",
  "HEALTH_CHECK",
  "QUERY",
  "NON_CRITICAL_QUERY",
  "QUERY_RESOLVED",
  "OUTWARD",
  "STAMPING",
  "STORAGE",
];

/**
 * getEnquiryMeta
 *
 * Pre-processes a transaction record for Enquiry CSV export.
 * Caches the result on the record object to avoid redundant iterations.
 *
 * @param {Object} rec - Transaction record from the API.
 * @returns {Object} Pre-processed metadata for the record.
 */
const getEnquiryMeta = (rec) => {
  if (rec._enquiryMeta) return rec._enquiryMeta;

  const history = rec.transactionsHistory || [];

  // Sort chronologically (earliest to latest)
  const sortedHistory = [...history].sort(
    (a, b) => new Date(a.createdDate) - new Date(b.createdDate),
  );

  // Map by stageName for quick lookup
  const stageMap = {};
  sortedHistory.forEach((h, idx) => {
    // If multiple entries for same stage exist, we keep the FIRST one chronologically
    if (!stageMap[h.stageName]) {
      stageMap[h.stageName] = { ...h, _index: idx };
    }
    if (h.stageName === "QUERY" && h.queryName) {
      if (!stageMap[`QUERY_${h.queryName}`]) {
        stageMap[`QUERY_${h.queryName}`] = { ...h, _index: idx };
      }
    }
  });

  // Helper to find who completed a stage (the createdByUserDto of the NEXT chronological entry)
  const getCompletedBy = (stageKey) => {
    let completedBy = "";
    let completedByEmail = "";
    if (stageMap[stageKey]) {
      const nextEntry = sortedHistory[stageMap[stageKey]._index + 1];
      if (nextEntry) {
        completedBy = formatHistoryUser(nextEntry.createdByUserDto);
        completedByEmail = nextEntry.createdByUserDto?.userEmail ?? "";
      }
    }
    return { completedBy, completedByEmail };
  };

  const { completedBy: hcCompletedBy, completedByEmail: hcCompletedByEmail } =
    getCompletedBy("HEALTH_CHECK");
  const {
    completedBy: queryCompletedBy,
    completedByEmail: queryCompletedByEmail,
  } = getCompletedBy("QUERY");
  const {
    completedBy: nonCriticalQueryCompletedBy,
    completedByEmail: nonCriticalQueryCompletedByEmail,
  } = getCompletedBy("QUERY_NON_CRITICAL_QUERY");
  const {
    completedBy: outwardCompletedBy,
    completedByEmail: outwardCompletedByEmail,
  } = getCompletedBy("OUTWARD");
  const {
    completedBy: stampingCompletedBy,
    completedByEmail: stampingCompletedByEmail,
  } = getCompletedBy("STAMPING");
  const {
    completedBy: storageCompletedBy,
    completedByEmail: storageCompletedByEmail,
  } = getCompletedBy("STORAGE");

  // Fallback stage completion logic for when history is empty
  const isStageCompleteFallback = (stageName) => {
    const currentStage = rec.stage?.stageName ?? "";
    const targetIdx = STAGE_ORDER.indexOf(stageName);
    const currentIdx = STAGE_ORDER.indexOf(currentStage);
    return targetIdx !== -1 && currentIdx !== -1 && targetIdx <= currentIdx;
  };

  const isStageComplete = (stageName) => {
    if (history.length > 0) {
      return !!stageMap[stageName];
    }
    return isStageCompleteFallback(stageName);
  };

  const isNonCriticalQueryComplete = () => {
    if (history.length > 0) {
      return !!stageMap["QUERY_NON_CRITICAL_QUERY"];
    }
    return rec.query?.queryName === "NON_CRITICAL_QUERY";
  };

  rec._enquiryMeta = {
    stageMap,
    hcCompletedBy,
    hcCompletedByEmail,
    queryCompletedBy,
    queryCompletedByEmail,
    nonCriticalQueryCompletedBy,
    nonCriticalQueryCompletedByEmail,
    outwardCompletedBy,
    outwardCompletedByEmail,
    stampingCompletedBy,
    stampingCompletedByEmail,
    storageCompletedBy,
    storageCompletedByEmail,
    isStageComplete,
    isNonCriticalQueryComplete,
  };

  return rec._enquiryMeta;
};

/**
 * CSV column definitions for the Enquiry / stage-level report.
 * Each stage block contains: Status, Time (IST), Initiated By user + email,
 * and (where applicable) Completed By user + email.
 *
 * Stages covered:
 *   RACK_ASSIGNED → HEALTH_CHECK → QUERY / NON_CRITICAL_QUERY →
 *   QUERY_RESOLVED → OUTWARD → STAMPING → STORAGE
 */
export const ENQUIRY_CSV_COLUMNS = [
  // ── Basic fields ──────────────────────────────────────────────────────────
  {
    header: "APPLICATION NO",
    accessor: (rec) => rec.appNo ?? "",
  },
  {
    header: "AGREEMENT NO",
    accessor: (rec) => rec.aggNo ?? "",
  },
  {
    header: "BARCODE",
    accessor: (rec) => rec.barcode ?? "",
  },
  {
    header: "CUSTOMER NAME",
    accessor: (rec) => rec.customerName ?? "",
  },
  {
    header: "AGEING",
    accessor: (rec) => rec.ageingNo ?? "",
  },
  {
    header: "FILE TYPE",
    accessor: (rec) => rec.fileType ?? "",
  },
  {
    header: "BUSINESS DATE",
    accessor: (rec) => formatDateOnlyToIST(rec.businessDate, ""),
  },

  // ── RACK ASSIGNED ─────────────────────────────────────────────────────────
  {
    header: "Rack Assigned Status",
    accessor: (rec) =>
      getEnquiryMeta(rec).isStageComplete("RACK_ASSIGNED") ? "true" : "false",
  },
  {
    header: "Rack Assigned Date & Time",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["RACK_ASSIGNED"];
      return h ? formatDateToIST(h.createdDate, "") : "";
    },
  },
  {
    header: "Rack Assigned User",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["RACK_ASSIGNED"];
      return formatHistoryUser(h?.createdByUserDto);
    },
  },
  {
    header: "Rack Assigned User Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["RACK_ASSIGNED"];
      return h?.createdByUserDto?.userEmail ?? "";
    },
  },
  {
    header: "VAULT NAME",
    accessor: (rec) => rec.rack?.vaultName ?? "",
  },
  {
    header: "RACK NAME",
    accessor: (rec) => rec.rack?.rackName ?? "",
  },
  {
    header: "SELF",
    accessor: (rec) => rec.rack?.rackPosition ?? "",
  },

  // ── HEALTH CHECK ──────────────────────────────────────────────────────────
  {
    header: "Health Check Status",
    accessor: (rec) =>
      getEnquiryMeta(rec).isStageComplete("HEALTH_CHECK") ? "true" : "false",
  },
  {
    header: "Health Check Date & Time",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["HEALTH_CHECK"];
      return h ? formatDateToIST(h.createdDate, "") : "";
    },
  },
  {
    // User who INITIATED health check (createdByUserDto on HEALTH_CHECK entry)
    header: "Health Check Initiated By",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["HEALTH_CHECK"];
      return formatHistoryUser(h?.createdByUserDto);
    },
  },
  {
    header: "Health Check Initiated By Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["HEALTH_CHECK"];
      return h?.createdByUserDto?.userEmail ?? "";
    },
  },
  {
    // User assigned to complete health check (assignedToUserDto on HEALTH_CHECK entry)
    header: "Health Check Assigned To",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["HEALTH_CHECK"];
      return formatHistoryUser(h?.assignedToUserDto);
    },
  },
  {
    header: "Health Check Assigned To Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["HEALTH_CHECK"];
      return h?.assignedToUserDto?.userEmail ?? "";
    },
  },
  {
    // User who COMPLETED health check = createdByUserDto on the QUERY or OUTWARD entry that follows
    header: "Health Check Completed By",
    accessor: (rec) => getEnquiryMeta(rec).hcCompletedBy,
  },
  {
    header: "Health Check Completed By Email",
    accessor: (rec) => getEnquiryMeta(rec).hcCompletedByEmail,
  },

  // ── QUERY (CRITICAL) ──────────────────────────────────────────────────────
  {
    header: "Query Status",
    accessor: (rec) =>
      getEnquiryMeta(rec).isStageComplete("QUERY") ? "true" : "false",
  },
  {
    header: "Query Date & Time",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY"];
      return h ? formatDateToIST(h.createdDate, "") : "";
    },
  },
  {
    header: "Query Type",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY"];
      return h?.queryName ?? "";
    },
  },
  {
    header: "Query Raised By",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY"];
      return formatHistoryUser(h?.createdByUserDto);
    },
  },
  {
    header: "Query Raised By Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY"];
      return h?.createdByUserDto?.userEmail ?? "";
    },
  },
  {
    header: "Query Assigned To",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY"];
      return formatHistoryUser(h?.assignedToUserDto);
    },
  },
  {
    header: "Query Assigned To Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY"];
      return h?.assignedToUserDto?.userEmail ?? "";
    },
  },
  {
    header: "Query Remarks",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY"];
      return h?.remarks ?? "";
    },
  },
  {
    header: "Query Completed By",
    accessor: (rec) => getEnquiryMeta(rec).queryCompletedBy,
  },
  {
    header: "Query Completed By Email",
    accessor: (rec) => getEnquiryMeta(rec).queryCompletedByEmail,
  },

  // ── NON-CRITICAL QUERY ────────────────────────────────────────────────────
  {
    header: "Non Critical Query Status",
    accessor: (rec) =>
      getEnquiryMeta(rec).isNonCriticalQueryComplete() ? "true" : "false",
  },
  {
    header: "Non Critical Query Date & Time",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY_NON_CRITICAL_QUERY"];
      return h ? formatDateToIST(h.createdDate, "") : "";
    },
  },
  {
    header: "Non Critical Query Raised By",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY_NON_CRITICAL_QUERY"];
      return formatHistoryUser(h?.createdByUserDto);
    },
  },
  {
    header: "Non Critical Query Raised By Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY_NON_CRITICAL_QUERY"];
      return h?.createdByUserDto?.userEmail ?? "";
    },
  },
  {
    header: "Non Critical Query Remarks",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY_NON_CRITICAL_QUERY"];
      return h?.remarks ?? "";
    },
  },
  {
    header: "Non Critical Query Completed By",
    accessor: (rec) => getEnquiryMeta(rec).nonCriticalQueryCompletedBy,
  },
  {
    header: "Non Critical Query Completed By Email",
    accessor: (rec) => getEnquiryMeta(rec).nonCriticalQueryCompletedByEmail,
  },

  // ── QUERY RESOLVED ────────────────────────────────────────────────────────
  {
    header: "Query Resolved Status",
    accessor: (rec) =>
      getEnquiryMeta(rec).isStageComplete("QUERY_RESOLVED") ? "true" : "false",
  },
  {
    header: "Query Resolved Date & Time",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY_RESOLVED"];
      return h ? formatDateToIST(h.createdDate, "") : "";
    },
  },
  {
    header: "Query Resolved By",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY_RESOLVED"];
      return formatHistoryUser(h?.createdByUserDto);
    },
  },
  {
    header: "Query Resolved By Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY_RESOLVED"];
      return h?.createdByUserDto?.userEmail ?? "";
    },
  },
  {
    header: "Query Resolved Remarks",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["QUERY_RESOLVED"];
      return h?.remarks ?? "";
    },
  },

  // ── OUTWARD ───────────────────────────────────────────────────────────────
  {
    header: "Outward Status",
    accessor: (rec) =>
      getEnquiryMeta(rec).isStageComplete("OUTWARD") ? "true" : "false",
  },
  {
    header: "Outward Date & Time",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["OUTWARD"];
      return h ? formatDateToIST(h.createdDate, "") : "";
    },
  },
  {
    header: "Outward Initiated By",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["OUTWARD"];
      return formatHistoryUser(h?.createdByUserDto);
    },
  },
  {
    header: "Outward Initiated By Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["OUTWARD"];
      return h?.createdByUserDto?.userEmail ?? "";
    },
  },
  {
    header: "Outward Assigned To",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["OUTWARD"];
      return formatHistoryUser(h?.assignedToUserDto);
    },
  },
  {
    header: "Outward Assigned To Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["OUTWARD"];
      return h?.assignedToUserDto?.userEmail ?? "";
    },
  },
  {
    header: "Outward Remarks",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["OUTWARD"];
      return h?.remarks ?? "";
    },
  },
  {
    header: "Outward Completed By",
    accessor: (rec) => getEnquiryMeta(rec).outwardCompletedBy,
  },
  {
    header: "Outward Completed By Email",
    accessor: (rec) => getEnquiryMeta(rec).outwardCompletedByEmail,
  },

  // ── STAMPING ──────────────────────────────────────────────────────────────
  {
    header: "Stamping Status",
    accessor: (rec) =>
      getEnquiryMeta(rec).isStageComplete("STAMPING") ? "true" : "false",
  },
  {
    header: "Stamping Date & Time",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["STAMPING"];
      return h ? formatDateToIST(h.createdDate, "") : "";
    },
  },
  {
    header: "Stamping Initiated By",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["STAMPING"];
      return formatHistoryUser(h?.createdByUserDto);
    },
  },
  {
    header: "Stamping Initiated By Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["STAMPING"];
      return h?.createdByUserDto?.userEmail ?? "";
    },
  },
  {
    header: "Stamping Assigned To",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["STAMPING"];
      return formatHistoryUser(h?.assignedToUserDto);
    },
  },
  {
    header: "Stamping Assigned To Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["STAMPING"];
      return h?.assignedToUserDto?.userEmail ?? "";
    },
  },
  {
    header: "Stamping Remarks",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["STAMPING"];
      return h?.remarks ?? "";
    },
  },
  {
    header: "Stamping Completed By",
    accessor: (rec) => getEnquiryMeta(rec).stampingCompletedBy,
  },
  {
    header: "Stamping Completed By Email",
    accessor: (rec) => getEnquiryMeta(rec).stampingCompletedByEmail,
  },

  // ── STORAGE ───────────────────────────────────────────────────────────────
  {
    header: "Storage Status",
    accessor: (rec) =>
      getEnquiryMeta(rec).isStageComplete("STORAGE") ? "true" : "false",
  },
  {
    header: "Storage Date & Time",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["STORAGE"];
      return h ? formatDateToIST(h.createdDate, "") : "";
    },
  },
  {
    header: "Storage Initiated By",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["STORAGE"];
      return formatHistoryUser(h?.createdByUserDto);
    },
  },
  {
    header: "Storage Initiated By Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["STORAGE"];
      return h?.createdByUserDto?.userEmail ?? "";
    },
  },
  {
    header: "Storage Assigned To",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["STORAGE"];
      return formatHistoryUser(h?.assignedToUserDto);
    },
  },
  {
    header: "Storage Assigned To Email",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["STORAGE"];
      return h?.assignedToUserDto?.userEmail ?? "";
    },
  },
  {
    header: "Storage Remarks",
    accessor: (rec) => {
      const h = getEnquiryMeta(rec).stageMap["STORAGE"];
      return h?.remarks ?? "";
    },
  },
  {
    header: "Storage Completed By",
    accessor: (rec) => getEnquiryMeta(rec).storageCompletedBy,
  },
  {
    header: "Storage Completed By Email",
    accessor: (rec) => getEnquiryMeta(rec).storageCompletedByEmail,
  },
];
