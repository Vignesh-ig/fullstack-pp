import { useNavigate } from "react-router-dom";
import { updateTransactionLockApi } from "../../../api/apiConfig";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { QUERY_TABLE_COLUMNS } from "../../../constants/tableHeaders";
import { ROUTES } from "../../../router/routes";

/**
 * QueryTable
 *
 * @param {object[]} records - Array of query data objects.
 * @param {boolean} loading - Loading state for data fetching.
 * @param {string} error - Error message if fetching fails.
 * @param {string} search - Current search query (for empty state messaging).
 * @param {number} page - Current page number (for serial numbers).
 * @param {number} pageSize - Page size (for serial numbers).
 */
const QueryTable = ({
  records = [],
  loading,
  error,
  search,
  page,
  pageSize,
}) => {
  const navigate = useNavigate();

  const handleRowClick = async (record) => {
    // Navigate using appNo or barcode as requested by the user
    const id = record.appNo || record.barcode;
    if (id) {
      try {
        await updateTransactionLockApi({
          appNos: record.appNo,
          isLocked: true,
        });
        navigate(
          ROUTES.FEATURES.TRANSACTION.QUERY.DETAILS.replace(
            ":id",
            encodeURIComponent(id),
          ),
          { state: { record } },
        );
      } catch (err) {
        console.error("Failed to lock transaction:", err);
        alert(
          err?.response?.data?.message ||
            "This record is already locked by another user or cannot be accessed right now.",
        );
      }
    }
  };

  return (
    <Table headers={QUERY_TABLE_COLUMNS} headerColorClass="bg-table-header-bg">
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow key={i} columnsCount={QUERY_TABLE_COLUMNS.length} />
        ))
      ) : records.length === 0 && !error ? (
        <tr>
          <td colSpan={QUERY_TABLE_COLUMNS.length} className="h-full">
            <EmptyState
              title="No records found"
              description={
                search
                  ? `No results for "${search}". Try a different search.`
                  : "No query records available."
              }
            />
          </td>
        </tr>
      ) : (
        records.map((record, index) => (
          <tr
            key={record.transactionId || index}
            onClick={() => handleRowClick(record)}
            className="hover:bg-brand-primary/5 transition-colors cursor-pointer"
          >
            <td className="table-td">{(page - 1) * pageSize + index + 1}</td>
            <td className="table-td">{record.appNo || "—"}</td>
            <td className="table-td">{record.aggNo || "—"}</td>
            <td className="table-td">{record.customerName || "—"}</td>
          </tr>
        ))
      )}
    </Table>
  );
};

QueryTable.displayName = "QueryTable";
export default QueryTable;
