import { Route, Routes } from "react-router-dom";
import TransactionDetailsPage from "../../components/ui/transaction/TransactionDetailsPage";
import { ROUTES } from "../../router/routes";
import { queryTransactionSchema } from "../../utils/schemas/configSchema";
import QueryFileDetails from "./components/QueryFileDetails";
import QueryList from "./QueryList";

/**
 * QueryMaster
 *
 * Renders the Query routing component.
 */
const QueryMaster = () => {
  return (
    <Routes>
      <Route path="/" element={<QueryList />} />
      <Route
        path={ROUTES.FEATURES.TRANSACTION.QUERY.DETAILS}
        element={
          <TransactionDetailsPage
            schema={queryTransactionSchema}
            isHealthCheck={false}
            isQuery={true}
            title="Query Details"
            FileDetailsComponent={QueryFileDetails}
          />
        }
      />
    </Routes>
  );
};

QueryMaster.displayName = "QueryMaster";
export default QueryMaster;
