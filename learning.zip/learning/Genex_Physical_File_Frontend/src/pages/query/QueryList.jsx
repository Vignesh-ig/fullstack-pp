import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import NavigationBanners from "../../components/ui/common/NavigationBanners";
import Pagination from "../../components/ui/common/Pagination";
import { APP_STAGES } from "../../constants/stages";
import useNavigationBanners from "../../hooks/useNavigationBanners";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import useTransactionFetch from "../../hooks/useTransactionFetch";
import QueryTable from "./components/QueryTable";

/**
 * QueryList
 *
 * Container component for Query data management. Handles fetching, searching, and paginating.
 * Role-based params (assignedUser / branchUser) are resolved centrally by useTransactionFetch.
 */
const QueryList = () => {
  const {
    successMessage,
    setSuccessMessage,
    warningMessage,
    setWarningMessage,
  } = useNavigationBanners();

  const { fetchFn } = useTransactionFetch({ stage: APP_STAGES.QUERY });

  const {
    data: records,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "likeAppNoOrBarcode");

  const handleRefresh = async () => {
    await refetch();
  };

  return (
    <ListContainer>
      <ListHeader
        title="Query"
        unit="records"
        count={pagination.totalItems}
        loading={loading}
        search={search}
        setSearch={setSearch}
        refetch={handleRefresh}
      />

      <NavigationBanners
        successMessage={successMessage}
        setSuccessMessage={setSuccessMessage}
        warningMessage={warningMessage}
        setWarningMessage={setWarningMessage}
        error={error}
        setError={setError}
      />

      <QueryTable
        records={records}
        loading={loading}
        error={error}
        search={search}
        page={page}
        pageSize={pageSize}
      />

      {/* ── Pagination ── */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />
    </ListContainer>
  );
};

QueryList.displayName = "QueryList";
export default QueryList;
