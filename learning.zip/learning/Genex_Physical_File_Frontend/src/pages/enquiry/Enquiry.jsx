import { useState } from "react";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import Button from "../../components/ui/common/Button";
import EmptyState from "../../components/ui/common/EmptyState";
import InputField from "../../components/ui/common/InputField";
import { APP_STAGES } from "../../constants/stages";
import useTransactionFetch from "../../hooks/useTransactionFetch";
import EnquiryFileDetails from "./components/EnquiryFileDetails";

/**
 * Enquiry
 *
 * Page component for the Enquiry feature. Accepts an Application Number or
 * Agreement Number, fetches the matching record from the API, and renders a
 * read-only file-details view. A collapsible history table is available via the
 * "History" button inside the details card.
 */

const Enquiry = () => {
  const [searchInput, setSearchInput] = useState("");
  const [record, setRecord] = useState(null);
  const [searchMessage, setSearchMessage] = useState(null);

  const {
    fetchOne: fetchEnquiry,
    isFetching: isSearching,
    fetchError,
    setFetchError,
  } = useTransactionFetch({
    applyRoleParams: false,
    stage: APP_STAGES.ENQUIRY,
  });

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchInput.trim()) return;

    setRecord(null);
    setSearchMessage(null);
    setFetchError(null);

    const { data: response, error } = await fetchEnquiry({
      appNoOrAggNo: searchInput.trim(),
    });

    if (error) {
      setSearchMessage({ title: "Error", description: error });
    } else {
      const result = response?.data?.data?.[0];
      if (!result) {
        setSearchMessage({
          title: "No record found",
          description: `No results for "${searchInput}". Try a different number.`,
        });
      } else {
        setRecord(result);
      }
    }
  };

  const showEmptyState = !!(fetchError || searchMessage) && !record;

  return (
    <ListContainer>
      <ListHeader title="Enquiry" loading={isSearching} />

      <main className="p-6">
        <form
          onSubmit={handleSearch}
          className="flex flex-col sm:flex-row gap-4 items-end mb-8 max-w-2xl"
        >
          <fieldset className="flex-1 w-full border-0 p-0 m-0">
            <InputField
              label="Application Number / Agreement Number"
              name="searchInput"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Enter Application or Agreement Number"
              className="mb-0"
              onClear={() => setSearchInput("")}
            />
          </fieldset>
          <Button
            type="submit"
            disabled={isSearching || !searchInput.trim()}
            className="w-full sm:w-32"
          >
            {isSearching ? "Searching..." : "Search"}
          </Button>
        </form>

        {showEmptyState && (
          <EmptyState
            title={fetchError ? "No record Found" : searchMessage?.title}
            description={fetchError || searchMessage?.description}
          />
        )}

        {record && <EnquiryFileDetails record={record} />}
      </main>
    </ListContainer>
  );
};

Enquiry.displayName = "Enquiry";
export default Enquiry;
