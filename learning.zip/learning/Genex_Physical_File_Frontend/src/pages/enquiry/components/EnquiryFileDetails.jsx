import { useRef, useState } from "react";
import { FileIcon } from "../../../components/icons/icons";
import { StampTypeBadge } from "../../../components/ui/badge/badgeIndex";
import StatusBadge from "../../../components/ui/badge/StatusBadge";
import DetailCard from "../../../components/ui/common/DetailCard";
import DetailField from "../../../components/ui/common/DetailField";
import DocumentButton from "../../../components/ui/common/DocumentButton";
import TextareaField from "../../../components/ui/common/TextareaField";
import { STAMP_TYPE } from "../../../constants/stampingConstants";
import { formatDateOnlyToIST, toTitleCase } from "../../../utils/utils";
import EnquiryHistory from "./EnquiryHistory";

/**
 * EnquiryFileDetails
 *
 * Renders the full read-only file details card for an enquired record, along with
 * a collapsible vertical timeline that shows the transactionsHistory array.
 *
 * @param {Object} record - The enquired record returned by the API (data field).
 */
const EnquiryFileDetails = ({ record }) => {
  const [showHistory, setShowHistory] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const containerRef = useRef(null);
  const historyRef = useRef(null);
  const expandRef = useRef(null);
  const currentRemarksRef = useRef(null);

  const toggleExpand = () => {
    setIsExpanded((prev) => {
      const next = !prev;

      if (next) {
        // Expand → scroll to expanded section
        setTimeout(() => {
          expandRef.current?.scrollIntoView({
            behavior: "smooth",
            block: "center",
          });
        }, 100);
      } else {
        // Minimize → scroll back to File Details
        containerRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }

      return next;
    });
  };

  const toggleHistory = () => {
    setShowHistory((prev) => {
      const next = !prev;
      if (next) {
        // Wait a tiny bit for the accordion to start expanding, then scroll into view
        setTimeout(() => {
          historyRef.current?.scrollIntoView({
            behavior: "smooth",
            block: "start",
          });
        }, 450);
      } else {
        // Scroll back up to the top of the details card
        containerRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
      return next;
    });
  };

  if (!record) return null;

  const { rack, fileType, stage, query, transactionsHistory = [] } = record;

  return (
    <div ref={containerRef} className="flex flex-col">
      <DetailCard title="File Details" icon={FileIcon}>
        <dl className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-6 pt-2">
          <DetailField
            label="Assigned By"
            value={
              transactionsHistory[0]?.createdByUserDto
                ? `${transactionsHistory[0].createdByUserDto.userName} (${transactionsHistory[0].createdByUserDto.userEmployeeCode ?? "N/A"})`
                : "Unassigned"
            }
          />
          <DetailField
            label="Assigned To"
            value={
              transactionsHistory[0]?.assignedToUserDto
                ? `${transactionsHistory[0].assignedToUserDto.userName} (${transactionsHistory[0].assignedToUserDto.userEmployeeCode ?? "N/A"})`
                : "Unassigned"
            }
          />
          <DetailField label="Application No" value={record.appNo || "N/A"} />
          <DetailField label="Agreement No" value={record.aggNo || "N/A"} />
          <DetailField label="Barcode" value={record.barcode || "N/A"} />
          <DetailField label="Ageing" value={record.ageingNo || "N/A"} />
          <DetailField
            label="Customer Name"
            value={record.customerName || "N/A"}
          />

          <DetailField label="File Type" value={fileType || "N/A"} />
          {isExpanded && (
            <>
              {/* Only this is the scroll target */}
              <div ref={expandRef} className="col-span-full h-0" />

              <DetailField
                label="Vault Name"
                value={rack?.vaultName || "N/A"}
              />

              <DetailField label="Rack Name" value={rack?.rackName || "N/A"} />

              <DetailField label="Self" value={rack?.rackPosition || "N/A"} />

              <DetailField
                label="Rack Status"
                value={
                  typeof rack?.rackStatus === "boolean" ? (
                    <StatusBadge isActive={rack.rackStatus} />
                  ) : (
                    "N/A"
                  )
                }
              />

              <DetailField
                label="Scheme"
                value={record.schemaProduct || "N/A"}
              />

              <DetailField
                label="eSign Status"
                value={
                  typeof record.isESign === "boolean" ? (
                    <StatusBadge isActive={record.isESign} />
                  ) : (
                    "N/A"
                  )
                }
              />

              <DetailField
                label="State"
                value={
                  record.stateDesc
                    ? toTitleCase(record.stateDesc)
                    : record.state || "N/A"
                }
              />

              <DetailField
                label="Branch Name"
                value={record.branchDesc || "N/A"}
              />

              <DetailField
                label="Branch Code"
                value={record.genexFromBranch || "N/A"}
              />

              <DetailField
                label="Stamp Type"
                value={
                  <StampTypeBadge
                    stampType={
                      record.stampType
                        ? record.stampType.toUpperCase()
                        : STAMP_TYPE.NO_STAMPING
                    }
                  />
                }
              />

              <DetailField
                label="Stamp Amount"
                value={record.leapStampAmount || "N/A"}
              />

              <DetailField label="Lead ID" value={record.leadId || "N/A"} />

              <DetailField
                label="Amount Finance"
                value={record.amountFinance || "N/A"}
              />

              <DetailField label="Model No" value={record.modelNo || "N/A"} />

              <DetailField label="Make" value={record.make || "N/A"} />

              <DetailField
                label="Disbursement Date"
                value={formatDateOnlyToIST(record.handOffDate, "N/A")}
              />

              <DetailField
                label="EMI End Date"
                value={formatDateOnlyToIST(record.emiEndDate, "N/A")}
              />

              <DetailField label="POD No" value={record.podNo || "N/A"} />

              <DetailField
                label="Query POD No"
                value={record.missingPodNo || "N/A"}
              />

              <DetailField label="VBarcode" value={record.vbarCode || "N/A"} />

              <DetailField
                label="Current Stage"
                value={stage?.stageName || "N/A"}
              />

              <DetailField
                label="Query Status"
                value={query?.queryName?.replace(/_/g, " ") || "N/A"}
              />

              <DetailField label="Loan ID" value={record.loanId || "N/A"} />

              <DetailField
                label="Business Date"
                value={formatDateOnlyToIST(record.businessDate, "N/A")}
              />

              <DetailField
                label="Sourcing Date"
                value={formatDateOnlyToIST(record.sourcingDate, "N/A")}
              />

              <DetailField label="Tenure" value={record.tenure || "N/A"} />

              <DetailField label="BIRR" value={record.birr || "N/A"} />

              <DetailField
                label="Registrable Status"
                value={record.registrableStatus || "N/A"}
              />

              <DetailField
                label="Udyam Number Status"
                value={record.udhayamNumberStatus || "N/A"}
              />

              <DetailField
                label="PAC Amount"
                value={record.pacAmount || "N/A"}
              />

              <DetailField
                label="Carton Barcode"
                value={record.queryCartonBarcode || "N/A"}
              />

              <div className="sm:col-span-2 md:col-span-2">
                <DetailField
                  label="Query Code"
                  value={record.queryCategory?.queryCategoryName || "N/A"}
                />
              </div>
            </>
          )}
        </dl>
        {isExpanded && record.currentRemarks && (
          <div ref={currentRemarksRef}>
            <TextareaField
              label="Current Remarks"
              value={record.currentRemarks}
              disabled
              className="mt-8 mb-4"
            />
          </div>
        )}

        {/* =====================================================
            BUTTONS
        ===================================================== */}

        <div className="flex justify-end items-center gap-4 mt-4 pt-3 border-t border-slate-200">
          <DocumentButton
            id="enquiry-view-document-btn"
            appNo={record.appNo}
            customerName={record.customerName}
          />

          {/* History */}
          <button
            type="button"
            onClick={toggleHistory}
            className="text-sm font-semibold text-brand-primary underline underline-offset-2 hover:opacity-75 transition-opacity"
          >
            {showHistory ? "Hide History" : "History"}
          </button>

          {/* Expand / Less */}
          <button
            type="button"
            onClick={toggleExpand}
            className="text-sm font-semibold text-brand-primary underline underline-offset-2 hover:opacity-75 transition-opacity"
          >
            {isExpanded ? "Minimize" : "Expand"}
          </button>
        </div>
      </DetailCard>

      {/* =====================================================
          TRANSACTION HISTORY
      ===================================================== */}

      <EnquiryHistory
        showHistory={showHistory}
        historyRef={historyRef}
        transactionsHistory={transactionsHistory}
        stampStackMasterList={record.stampStackMasterList}
      />
    </div>
  );
};

EnquiryFileDetails.displayName = "EnquiryFileDetails";
export default EnquiryFileDetails;
