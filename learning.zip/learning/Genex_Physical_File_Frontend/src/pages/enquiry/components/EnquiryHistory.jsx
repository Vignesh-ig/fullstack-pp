import { useMemo, useState } from "react";
import {
  AlertCircleIcon,
  SortAscendingIcon,
  SortDescendingIcon,
  TimerIcon,
} from "../../../components/icons/icons";
import TaskStatusBadge from "../../../components/ui/badge/TaskStatusBadge";
import DenominationsTable from "../../../components/ui/common/DenominationsTable";
import DetailCard from "../../../components/ui/common/DetailCard";
import HistoryField from "../../../components/ui/common/HistoryField";
import IconButtonWithHover from "../../../components/ui/common/IconButtonWithHover";
import TextareaField from "../../../components/ui/common/TextareaField";
import { APP_STAGES, STAGE_NAMES } from "../../../constants/stages";
import { TASK_STATUS } from "../../../constants/status";
import {
  formatDateToIST,
  getStageDuration,
  getTimeDiff,
} from "../../../utils/utils";

// Maps stageName to "Created By" label.
const CREATED_BY_LABEL = {
  USER_ASSIGNED: "Created By",
  HEALTH_CHECK: "Created By",
  QUERY: "Health Check Complete By",
};

// Maps stageName to static descriptive notes.
const STAGE_STATIC_NOTES = {
  USER_ASSIGNED:
    "Despatch record assign to rack and Awaiting admin to allocate the rack to user.",
  HEALTH_CHECK: "User assigned successfully and Health check got initiated",
  QUERY: "Health check is completed and Query got initiated",
};

/**
 * HistoryStatusField
 *
 * @param {string} label
 * @param {"PENDING"|"COMPLETED"} status
 */
const HistoryStatusField = ({ label, status }) => (
  <div className="flex items-center gap-1.5">
    <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
      {label}:
    </span>
    <TaskStatusBadge status={status} />
  </div>
);

/**
 * EnquiryHistory
 *
 * Renders the transaction history timeline with context-aware fields per stage.
 *
 * @param {boolean} showHistory - Controls visibility of the history section.
 * @param {React.RefObject} historyRef - Ref attached to the outer container.
 * @param {Array} transactionsHistory - Transaction history records from the backend.
 */
const EnquiryHistory = ({
  showHistory,
  historyRef,
  transactionsHistory,
  stampStackMasterList,
}) => {
  const [isNewestFirst, setIsNewestFirst] = useState(true);

  const normalizedHistory = useMemo(() => {
    return (transactionsHistory || []).map((h) => ({
      ...h,
      stageName:
        h.stageName === "RACK_ASSIGNED" ? "USER_ASSIGNED" : h.stageName,
    }));
  }, [transactionsHistory]);

  const { chronologicalHistory, hasQueryStage } = useMemo(() => {
    const sorted = [...normalizedHistory].sort(
      (a, b) => new Date(a.createdDate) - new Date(b.createdDate),
    );
    return {
      chronologicalHistory: sorted,
      hasQueryStage: sorted.some((h) => h.stageName === APP_STAGES.QUERY),
    };
  }, [normalizedHistory]);

  const sortedTransactionsHistory = useMemo(() => {
    if (normalizedHistory.length === 0) return [];
    return isNewestFirst
      ? [...normalizedHistory]
      : [...normalizedHistory].reverse();
  }, [normalizedHistory, isNewestFirst]);

  const denominationsData = useMemo(() => {
    if (
      !stampStackMasterList ||
      !Array.isArray(stampStackMasterList) ||
      stampStackMasterList.length === 0
    ) {
      return [];
    }
    const summaryMap = {};
    stampStackMasterList.forEach((item) => {
      const denoNo = item.denominationAmount;
      if (!summaryMap[denoNo]) {
        summaryMap[denoNo] = {
          denoNo,
          count: 0,
          serials: [],
        };
      }
      summaryMap[denoNo].count += 1;
      summaryMap[denoNo].serials.push({
        id: item.stampStackMasterId,
        label: item.denominationSerialNo,
      });
    });
    return Object.values(summaryMap).sort((a, b) => b.denoNo - a.denoNo);
  }, [stampStackMasterList]);

  /**
   * Pre-compute all per-record derived values in a single pass.
   * Stored in a Map keyed by transactionsHistoryId so the render loop
   * performs O(1) lookups instead of re-deriving on every render.
   */
  const recordMetaMap = useMemo(() => {
    const map = new Map();

    chronologicalHistory.forEach((h, chronoIndex) => {
      const isUserAssigned = h.stageName === APP_STAGES.USER_ASSIGNED;
      const isReturnToRack = h.stageName === APP_STAGES.RETURN_TO_RACK;
      const isHealthCheck = h.stageName === APP_STAGES.HEALTH_CHECK;
      const isQuery = h.stageName === APP_STAGES.QUERY;
      const isQueryResolved = h.stageName === APP_STAGES.QUERY_RESOLVED;
      const isOutward = h.stageName === APP_STAGES.OUTWARD;
      const isStamping = h.stageName === APP_STAGES.STAMPING;
      const isStorage = h.stageName === APP_STAGES.STORAGE;

      const prevRecord =
        chronoIndex > 0 ? chronologicalHistory[chronoIndex - 1] : null;
      const prevStageName = prevRecord ? prevRecord.stageName : null;

      const stageDuration = prevRecord
        ? getStageDuration(prevRecord.createdDate, h.createdDate)
        : null;
      const prevStageFriendlyName = prevRecord
        ? (STAGE_NAMES[prevRecord.stageName] ?? prevRecord.stageName)
        : null;

      // ── Created By label ──────────────────────────────────────────────────
      let createdByLabel;
      if (isReturnToRack) {
        createdByLabel = "Previously assigned user";
      } else if (isQueryResolved) {
        createdByLabel = "Query Resolved By";
      } else if (isOutward) {
        // OUTWARD always shows "Health Check Complete By" regardless of query path
        createdByLabel = "Health Check Complete By";
      } else if (isStamping) {
        createdByLabel = "Outward completed by";
      } else if (isStorage) {
        createdByLabel =
          prevStageName === APP_STAGES.STAMPING
            ? "Stamping completed by"
            : "Outward completed by";
      } else {
        createdByLabel = CREATED_BY_LABEL[h.stageName] ?? "Created By";
      }

      // ── Static note ───────────────────────────────────────────────────────
      let staticNote;
      if (isReturnToRack) {
        staticNote =
          "Despatch record return assigned to rack, Awaiting admin to allocate the rack to user.";
      } else if (isQueryResolved) {
        staticNote = "Query is resolved and Health check got re-initiated.";
      } else if (isOutward) {
        staticNote = "Health check is completed and Moved to outward";
      } else if (isStamping) {
        staticNote = "Outward is completed and Moved to Stamping";
      } else if (isStorage) {
        staticNote =
          prevStageName === APP_STAGES.STAMPING
            ? "Stamping is completed and Moved to Storage."
            : "Outward is completed and Moved to Storage.";
      } else {
        staticNote = STAGE_STATIC_NOTES[h.stageName] ?? null;
      }

      // ── Show / hide Remarks ───────────────────────────────────────────────
      // Hidden for: USER_ASSIGNED, RETURN_TO_RACK, HEALTH_CHECK
      // Shown for: QUERY, QUERY_RESOLVED, OUTWARD, STAMPING, STORAGE
      const showRemarks = !isUserAssigned && !isReturnToRack && !isHealthCheck;

      const showDenominationsTable =
        isStorage && prevStageName === APP_STAGES.STAMPING;

      // ── Rack Assigned Status ──────────────────────────────────────────────
      // Only shown on USER_ASSIGNED. RETURN_TO_RACK no longer shows it.
      const showRackAssignedStatus = isUserAssigned;
      const rackAssignedStatus = TASK_STATUS.COMPLETED;

      // ── User Assigned Status ──────────────────────────────────────────────
      // USER_ASSIGNED → pending, RETURN_TO_RACK → pending, HEALTH_CHECK → completed
      const showUserAssignedStatus =
        isUserAssigned || isReturnToRack || isHealthCheck;
      const userAssignedStatus =
        isUserAssigned || isReturnToRack
          ? TASK_STATUS.PENDING
          : TASK_STATUS.COMPLETED;

      // ── Health Check Status ───────────────────────────────────────────────
      // HEALTH_CHECK → pending
      // QUERY → completed, QUERY_RESOLVED → pending
      // OUTWARD → completed
      // STAMPING / STORAGE → not shown (scoped out)
      const showHCStatus =
        isHealthCheck || isQuery || isQueryResolved || isOutward;
      const hcStatus =
        isHealthCheck || isQueryResolved
          ? TASK_STATUS.PENDING
          : TASK_STATUS.COMPLETED;

      // ── Query Status ──────────────────────────────────────────────────────
      // Only shown on QUERY (pending) and QUERY_RESOLVED (completed).
      // Not shown on OUTWARD / STAMPING / STORAGE.
      const showQueryStatus = isQuery || isQueryResolved;
      const queryStatus = isQuery ? TASK_STATUS.PENDING : TASK_STATUS.COMPLETED;

      // ── Outward Status ────────────────────────────────────────────────────
      // OUTWARD → pending, STAMPING → completed, STORAGE (prev=OUTWARD) → completed
      const showOutwardStatus =
        isOutward ||
        isStamping ||
        (isStorage && prevStageName === APP_STAGES.OUTWARD);
      const outwardStatus = isOutward
        ? TASK_STATUS.PENDING
        : TASK_STATUS.COMPLETED;

      // ── Stamping Status ───────────────────────────────────────────────────
      // STAMPING → pending, STORAGE (prev=STAMPING) → completed
      const showStampingStatus =
        isStamping || (isStorage && prevStageName === APP_STAGES.STAMPING);
      const stampingStatus = isStamping
        ? TASK_STATUS.PENDING
        : TASK_STATUS.COMPLETED;

      map.set(h.transactionsHistoryId, {
        isUserAssigned,
        isReturnToRack,
        isHealthCheck,
        isQueryResolved,
        stageDuration,
        prevStageFriendlyName,
        createdByLabel,
        staticNote,
        showRemarks,
        showRackAssignedStatus,
        rackAssignedStatus,
        showUserAssignedStatus,
        userAssignedStatus,
        showHCStatus,
        hcStatus,
        showQueryStatus,
        queryStatus,
        showOutwardStatus,
        outwardStatus,
        showStampingStatus,
        stampingStatus,
        showDenominationsTable,
      });
    });

    return map;
  }, [chronologicalHistory, hasQueryStage]);

  return (
    <div
      ref={historyRef}
      className={`grid transition-[grid-template-rows,opacity,margin] duration-500 ease-in-out ${
        showHistory
          ? "grid-rows-[1fr] opacity-100 mt-6"
          : "grid-rows-[0fr] opacity-0 mt-0"
      }`}
    >
      <div className="overflow-hidden">
        <DetailCard
          title="Transaction History"
          action={
            <IconButtonWithHover
              onClick={() => setIsNewestFirst((prev) => !prev)}
              icon={
                isNewestFirst ? (
                  <SortDescendingIcon className="w-4 h-4" />
                ) : (
                  <SortAscendingIcon className="w-4 h-4" />
                )
              }
              label={isNewestFirst ? "Newest first" : "Oldest first"}
              colorClass="hover:text-slate-800 hover:bg-slate-200"
              className="bg-white border border-slate-200 shadow-sm"
              tooltipPosition="left"
            />
          }
        >
          {normalizedHistory.length === 0 ? (
            <p className="text-sm text-slate-500 py-4 text-center">
              No history available.
            </p>
          ) : (
            <ol className="relative mt-4 pl-8">
              <span
                aria-hidden="true"
                className="absolute left-3.75 top-2 bottom-2 w-0.5 bg-slate-200"
              />

              {sortedTransactionsHistory.map((h, idx) => {
                const isLatest = isNewestFirst
                  ? idx === 0
                  : idx === sortedTransactionsHistory.length - 1;

                const meta = recordMetaMap.get(h.transactionsHistoryId);
                if (!meta) return null;

                const {
                  isUserAssigned,
                  isReturnToRack,
                  isHealthCheck,
                  isQueryResolved,
                  stageDuration,
                  prevStageFriendlyName,
                  createdByLabel,
                  staticNote,
                  showRemarks,
                  showRackAssignedStatus,
                  rackAssignedStatus,
                  showUserAssignedStatus,
                  userAssignedStatus,
                  showHCStatus,
                  hcStatus,
                  showQueryStatus,
                  queryStatus,
                  showOutwardStatus,
                  outwardStatus,
                  showStampingStatus,
                  stampingStatus,
                  showDenominationsTable,
                } = meta;

                const stageBadges = [
                  {
                    key: "rackAssignedStatus",
                    label: "Rack Assigned Status",
                    status: rackAssignedStatus,
                    show: showRackAssignedStatus,
                  },
                  {
                    key: "userAssignedStatus",
                    label: "User Assigned Status",
                    status: userAssignedStatus,
                    show: showUserAssignedStatus,
                  },
                  {
                    key: "hc",
                    label: "Health Check Status",
                    status: hcStatus,
                    show: showHCStatus,
                  },
                  {
                    key: "query",
                    label: "Query Status",
                    status: queryStatus,
                    show: showQueryStatus,
                  },
                  {
                    key: "outward",
                    label: "Outward Status",
                    status: outwardStatus,
                    show: showOutwardStatus,
                  },
                  {
                    key: "stamping",
                    label: "Stamping Status",
                    status: stampingStatus,
                    show: showStampingStatus,
                  },
                ]
                  .filter((b) => b.show)
                  .sort((a, b) =>
                    a.status === TASK_STATUS.COMPLETED &&
                    b.status !== TASK_STATUS.COMPLETED
                      ? -1
                      : 1,
                  );

                return (
                  <li key={h.transactionsHistoryId} className="relative mb-0">
                    <span
                      aria-hidden="true"
                      className={`absolute -left-6.25 top-3 flex h-5 w-5 items-center justify-center rounded-full ring-4 ring-white ${
                        isLatest
                          ? "bg-brand-accent"
                          : "bg-white border-2 border-slate-300"
                      }`}
                    >
                      {isLatest && (
                        <span className="h-2 w-2 rounded-full bg-white" />
                      )}
                    </span>

                    <div
                      className={`ml-2 mb-6 rounded-xl border p-4 transition-shadow hover:shadow-md bg-white ${
                        isLatest
                          ? "border-brand-primary/30 ring-1 ring-brand-primary/80"
                          : "border-slate-200"
                      }`}
                    >
                      <div className="w-full flex items-center justify-between mb-3">
                        <span className="text-xs font-semibold text-slate-700">
                          <span className="font-bold uppercase tracking-wider text-slate-500 mr-1">
                            Time:
                          </span>
                          <time>{formatDateToIST(h.createdDate)}</time>
                        </span>

                        {stageDuration && (
                          <span className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
                            <TimerIcon className="w-3.5 h-3.5 shrink-0" />
                            {stageDuration} in{" "}
                            <span className="font-semibold text-slate-700">
                              {prevStageFriendlyName}
                            </span>
                          </span>
                        )}

                        <span className="text-xs font-bold">
                          {getTimeDiff(h.createdDate)}
                        </span>
                      </div>

                      {h?.createdByUserDto && (
                        <HistoryField
                          label={createdByLabel}
                          value={`${h.createdByUserDto.userName ?? "N/A"} (${h.createdByUserDto.userEmployeeCode ?? "N/A"})`}
                          isMono
                        />
                      )}

                      {(isHealthCheck || isUserAssigned || isQueryResolved) &&
                        h?.assignedToUserDto && (
                          <HistoryField
                            label="Assigned To"
                            value={`${h.assignedToUserDto.userName ?? "N/A"} (${h.assignedToUserDto.userEmployeeCode ?? "N/A"})`}
                            isMono
                          />
                        )}

                      <div
                        className={`grid ${h.queryName ? "grid-cols-1 sm:grid-cols-3" : "grid-cols-2"} gap-x-4`}
                      >
                        {h.appNo && (
                          <HistoryField label="App No" value={h.appNo} />
                        )}
                        {h.stageName && (
                          <HistoryField
                            label="Stage"
                            value={h.stageName}
                            isMono
                          />
                        )}
                        {h.queryName && (
                          <HistoryField
                            label="Query"
                            value={h.queryName}
                            isMono
                          />
                        )}
                      </div>

                      {showRemarks && (
                        <TextareaField
                          label="Remarks:"
                          value={isHealthCheck ? "N/A" : h.remarks || "—"}
                          disabled
                          className="mb-1"
                          labelClassName="!text-slate-500"
                        />
                      )}

                      {showDenominationsTable &&
                        denominationsData.length > 0 && (
                          <>
                            <h3 className="text-xs font-bold uppercase tracking-wider text-text-secondary mt-8">
                              Denomination Serial Numbers Summary
                            </h3>
                            <DenominationsTable
                              data={denominationsData}
                              isReadOnly={true}
                            />
                          </>
                        )}

                      {stageBadges.length > 0 && (
                        <div className="flex flex-wrap items-center gap-x-5 gap-y-2 mb-3 pt-2 mt-4 border-t border-slate-200/80">
                          {stageBadges.map((b) => (
                            <HistoryStatusField
                              key={b.key}
                              label={b.label}
                              status={b.status}
                            />
                          ))}
                        </div>
                      )}

                      {staticNote && (
                        <span className="text-[12px] text-slate-700 w-fit flex items-center gap-1 mt-2">
                          <AlertCircleIcon className="w-4 h-4 shrink-0" />
                          {staticNote}
                        </span>
                      )}
                    </div>
                  </li>
                );
              })}
            </ol>
          )}
        </DetailCard>
      </div>
    </div>
  );
};

EnquiryHistory.displayName = "EnquiryHistory";
export default EnquiryHistory;
