import { useNavigate } from "react-router-dom";
import JobStatusBadge from "../../../../components/ui/badge/JobStatusBadge";
import EmptyState from "../../../../components/ui/common/EmptyState";
import Table from "../../../../components/ui/common/Table";
import TableSkeletonRow from "../../../../components/ui/common/TableSkeletonRow";
import { File_RETERIAVAL_REQUEST_TABLE_COLUMNS } from "../../../../constants/tableHeaders";
import { ROUTES } from "../../../../router/routes";
import { useSelector } from "react-redux";
import { canEditRetrieval } from "../../../../constants/roles";

const formatDate = (dateString) => {
  const date = new Date(dateString);

  const day = String(date.getDate()).padStart(2, "0");
  const month = date.toLocaleString("en-US", { month: "short" });
  const year = String(date.getFullYear()).slice(-2);

  return `${day}-${month}-${year}`;
};

const FileRetrievalTable = ({
  fileRetrievalList = [],
  loading,
  error,
  search,
  page,
  pageSize,
  canDelete,
  isDeleting,
  onEditClick,
  onDeleteClick,
  selectedIds,
  onSelectionChange
}) => {
  let tableContent;
  const navigate = useNavigate();
  const { roleName: currentRoleName } = useSelector((state) => state.user);
const isDocAdminUser = canEditRetrieval(currentRoleName);
  const columns = File_RETERIAVAL_REQUEST_TABLE_COLUMNS(isDocAdminUser);

  const allPageIds = fileRetrievalList.map((r) => r.track_id);
  const isAllSelected =
allPageIds.length > 0 && allPageIds.every((id) => selectedIds.has(id));
const isIndeterminate =
!isAllSelected && allPageIds.some((id) => selectedIds.has(id));

const handleSelectAll = () => {
const next = new Set(selectedIds);
if (isAllSelected) {
      allPageIds.forEach((id) => next.delete(id));
} else {
      allPageIds.forEach((id) => next.add(id));
}
onSelectionChange(next);
};

const handleSelectOne = (id) => {
const next = new Set(selectedIds);
if (next.has(id)) {
      next.delete(id);
} else {
      next.add(id);
}
onSelectionChange(next);
};

  const tableHeaders = [
{
      id: "selectAll",
      align: "center",
      paddingClass: "px-4 py-4",
      widthClass: "w-12",
      label: (
        <input
          type="checkbox"
          className="w-4 h-4 cursor-pointer accent-brand-primary"
          checked={isAllSelected}
          ref={(el) => {
            if (el) el.indeterminate = isIndeterminate;
          }}
          onChange={handleSelectAll}
          aria-label="Select all records"
        />
      ),
},
...columns.slice(1).map((h) => ({
      ...h,
      id: h.label,
})),
];
  if (loading) {
    tableContent = Array.from({ length: 10 }).map((_, i) => (
      <TableSkeletonRow
        key={i}
        columnsCount={columns.length}
      />
    ));
  } else if (fileRetrievalList.length === 0 && !error) {
    tableContent = (
      <tr>
        <td
          colSpan={columns.length}
          className="h-full"
        >
          <EmptyState
            title="No retrieval file found"
            description={
              search
                ? `No results for "${search}". Try a different search.`
                : "Get started by adding your first rack."
            }
          />
        </td>
      </tr>
    );
  } else {
tableContent = fileRetrievalList.map((retrievalFile, index) => {
  const isChecked = selectedIds.has(retrievalFile.track_id);
  return (
    <tr
      key={retrievalFile.job_no}
      className="hover:bg-slate-200/80 transition-colors"
      onClick={() => {
        navigate(
          ROUTES.FEATURES.TRANSACTION.DOC_ADMIN_RETERIVAL_REQUEST.EDIT.replace(
            ":track_id",
            retrievalFile.track_id,
          ),
          {
            state: {
              isRefilling:
                retrievalFile.retreivedCount === retrievalFile.totalCount,
              agreementType: retrievalFile.agreement_type,
              jobStage: retrievalFile.job_stage,
            },
          }
        );
      }}
    >
         {/* Checkbox cell */}
        <td
          className="table-td w-12"
          onClick={(e) => {
            e.stopPropagation();
           handleSelectOne(retrievalFile.track_id)
          }}
        >
          <input
            type="checkbox"
            className="w-4 h-4 cursor-pointer accent-brand-primary"
            checked={isChecked}
            onChange={() => {}}
            aria-label={`Select record`}
          />
        </td>
      <td className="table-td">
        {(page - 1) * pageSize + index + 1}
      </td>

 
      <td className="table-td-primary-branch text-center">
        {retrievalFile.job_no || "—"}
      </td>

      <td className="table-td-primary-branch text-center">
        {formatDate(retrievalFile.created_date) || "—"}
      </td>

      <td className="table-td-primary-branch text-center">
        {retrievalFile.requester_name || "—"}
      </td>

      <td className="table-td-primary-branch text-center">
        {retrievalFile.department || "—"}
      </td>

      {isDocAdminUser && (
        <>
          <td className="px-6 py-1 text-center">
            {retrievalFile.servicedCount ?? "-"} /{" "}
            {retrievalFile.totalCount ?? "-"}
          </td>

          <td className="px-6 py-1 text-center">
            {retrievalFile.retreivedCount ?? "-"} /{" "}
            {retrievalFile.totalCount ?? "-"}
          </td>
        </>
      )}

      <td className="table-td text-center">
        <JobStatusBadge
          jobStatusName={retrievalFile.job_status ?? "—"}
        />
      </td>
    </tr>
  );
});

  }

  return (
    <Table
      headers={tableHeaders}
      headerColorClass="bg-table-header-bg"
    >
      {tableContent}
    </Table>
  );
};

FileRetrievalTable.displayName = "FileRetrievalTable";
export default FileRetrievalTable;
