import { useCallback, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import {
  allRefillingRequestApi,
  generatedJobReportApi,
  getReterievalRequestApi,
  getScanFileRefillingApi,
} from "../../../../api/apiConfig";
import ListContainer from "../../../../components/layout/ListContainer";
import ListHeader from "../../../../components/layout/ListHeader";
import ErrorBanner from "../../../../components/ui/common/ErrorBanner";
import FilterSelectField from "../../../../components/ui/common/FilterSelectField";
import Pagination from "../../../../components/ui/common/Pagination";
import { canEditRetrieval } from "../../../../constants/roles";
import { getRetrievalForRole } from "../../../../constants/status";
import usePaginatedFetch from "../../../../hooks/usePaginatedFetch";
import FileRetrievalTable from "./FileRetrievalTable";

/**
 * RackList
 *
 * Container component for rack data management. Handles fetching, searching, paginating, and deleting of racks.
 *
 * @param {Object} props
 */

const FileRetrievalList = () => {
  const navigate = useNavigate();
  const { userId: curentUserId } = useSelector((state) => state.user);
  const { roleName: currentRoleName } = useSelector((state) => state.user);
  const { userEmployeeCode: currentEmployeeCode } = useSelector(
    (state) => state.user,
  );

  const statusOptions = getRetrievalForRole(currentRoleName);
  const location = useLocation();
  const jobStage = location.state?.stageJob;
  const [selectedIds, setSelectedIds] = useState(new Set());

  const [assignedStatusFilter, setAssignedStatusFilter] = useState(
    jobStage ?? statusOptions[0]?.value ?? "",
  );
  const [isRequestRefilling, setRequestRefilling] = useState(false);
  const [isScanUploading, setScanUploading] = useState(false);

  const fileInputRef = useRef(null);
  const uploadFileInputRef = useRef(null);

  const isDocAdminUser = canEditRetrieval(currentRoleName);

  const fetchFn = useCallback(
    async (params) => {
      try {
        const rolename = localStorage.getItem("employeeCode");
        let role;

        if (isDocAdminUser) {
          role = currentRoleName === "DOC_ADMIN_USER" ? "docAdmin" : "admin";
        } else {
          role = rolename;
        }
        const response = await getReterievalRequestApi({
          page: params.page,
          limit: params.limit,
          searchKey: params.searchKey, // or params.searchKey based on your hook
          ...(!isDocAdminUser && {
            userId: curentUserId,
          }),
          role: role,
          employeeCode: isDocAdminUser ? "" : currentEmployeeCode,
          jobStage: assignedStatusFilter === "ALL" ? "" : assignedStatusFilter,
        });

        return response;
      } catch (err) {
        console.error(err);
      }
    },
    [isDocAdminUser, curentUserId, assignedStatusFilter],
  );

  const handleStatusFilterChange = async (e) => {
    const selectedJobStage = e.target.value;
    setAssignedStatusFilter(selectedJobStage);
  };

  const {
    data: retrievalRequestFile,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "searchKey");

  const handleRefresh = () => {
    refetch();
  };

  const hasSelection = selectedIds.size > 0;

  const handleGenerateReportJob = async () => {
    if (!hasSelection) return;

    try {
      const selectedRecords = retrievalRequestFile.filter((record) =>
        selectedIds.has(record.track_id),
      );

      const jobIds = selectedRecords
        .map((record) => record.job_no)
        .filter(Boolean);

      if (!jobIds.length) {
        console.warn("No job numbers selected");
        return;
      }

      const blob = await generatedJobReportApi(jobIds);

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");

      a.href = url;
      a.download = "job-report.xlsx";
      document.body.appendChild(a);
      a.click();

      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Generate report failed:", error);
    }
  };

  const handleRequestRefilling = () => {
    fileInputRef.current?.click();
  };

  const handleUploadScanRefilling = () => {
    uploadFileInputRef.current?.click();
  };

  const uploadScanFileApi = async (file) => {
    try {
      setScanUploading(true);
      const formData = new FormData();

      if (file) {
        formData.append("documents", file);
      }

      const response = await getScanFileRefillingApi(formData, curentUserId);

      if (response.status === 200) {
        // Fetch retrieval list again after successful refilling
        refetch();

        // Optional: clear selected rows
        setSelectedIds(new Set());
      }
    } catch (error) {
      console.error("Refilling request failed:", error);
    } finally {
      setScanUploading(false);
    }
  };

  const handleScanFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    uploadScanFileApi(file);

    // Optional: allow selecting the same file again later
    e.target.value = "";
  };

  const allRefillingRequest = async (file) => {
    try {
      setRequestRefilling(true);
      const formData = new FormData();

      if (file) {
        formData.append("documents", file);
      }

      const response = await allRefillingRequestApi(formData, curentUserId);

      if (response.status === 200) {
        // Fetch retrieval list again after successful refilling
        refetch();

        // Optional: clear selected rows
        setSelectedIds(new Set());
      }
    } catch (error) {
      console.error("Refilling request failed:", error);
    } finally {
      setRequestRefilling(false);
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    allRefillingRequest(file);

    // Optional: allow selecting the same file again later
    e.target.value = "";
  };

  const getroleName = localStorage.getItem("employeeCode");

  return (
    <ListContainer>
      <ListHeader
        title="Retrieval Request"
        unit="retrieval"
        count={pagination.total}
        loading={loading}
        showAddButton={!isDocAdminUser}
        addLabel="Add Retrieval Request "
        searchPlaceholder="Search File Name"
        search={search}
        setSearch={setSearch}
        refetch={handleRefresh}
        onAddClick={() => navigate("add")}
      >
        <div className="flex items-center gap-6 w-full sm:w-auto">
          <FilterSelectField
            label="Filter by Status:"
            name="assignedStatusFilter"
            value={assignedStatusFilter}
            onChange={handleStatusFilterChange}
            placeholder=""
            options={getRetrievalForRole(currentRoleName)}
            className="w-full sm:w-auto"
          />

          <div className="flex items-center gap-4">
            {isDocAdminUser && (
              <button
                type="button"
                onClick={handleUploadScanRefilling}
                className="px-4 py-1 bg-brand-primary text-white rounded-md hover:bg-brand-primary/90 transition-colors"
              >
                {isScanUploading ? "Upload Scan File..." : "Upload Scan File"}
              </button>
            )}

            <input
              type="file"
              ref={uploadFileInputRef}
              className="hidden"
              onChange={handleScanFileChange}
            />

            {selectedIds.size > 0 && (
              <button
                type="button"
                onClick={handleGenerateReportJob}
                className="px-4 py-1 bg-brand-primary text-white rounded-md hover:bg-brand-primary/90 transition-colors"
              >
                Generate Report
              </button>
            )}

            {retrievalRequestFile.length > 0 &&
              getroleName === "requester" &&
              !isDocAdminUser && (
                <button
                  type="button"
                  onClick={handleRequestRefilling}
                  className="px-4 py-1 bg-brand-primary text-white rounded-md hover:bg-brand-primary/90 transition-colors"
                >
                  {isRequestRefilling
                    ? "Request Refilling..."
                    : "Request Refilling"}
                </button>
              )}
          </div>
          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            onChange={handleFileChange}
          />
        </div>
      </ListHeader>

      {/* ── Error ── */}
      {error && (
        <section className="px-6 pt-4">
          <ErrorBanner
            message={error}
            onClose={() => {
              setError(null);
            }}
          />
        </section>
      )}

      <FileRetrievalTable
        fileRetrievalList={retrievalRequestFile}
        loading={loading}
        error={error}
        page={page}
        pageSize={pageSize}
        selectedIds={selectedIds}
        onSelectionChange={setSelectedIds}
      />

      {/* ── Pagination ── */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />
    </ListContainer>
  );
};

FileRetrievalList.displayName = "FileRetrievalList";
export default FileRetrievalList;
