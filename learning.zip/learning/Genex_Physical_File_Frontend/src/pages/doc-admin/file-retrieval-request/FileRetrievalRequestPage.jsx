/**
 * FileRetrievalRequestPage
 *
 * Renders the Report component.
 *
 */
import { Route, Routes } from "react-router-dom";
import FileRetrievalList from "./components/FileRetrievalList.jsx";
import { ROUTES } from "../../../router/routes.js";
import CreateRetrievalForm from "../create-retrieval-request/CreateRetrievalForm.jsx";
const FileRetrievalRequestPage = () => {
 return (
    <Routes>
      <Route path="/" element={<FileRetrievalList />} />
      <Route
        path={ROUTES.FEATURES.TRANSACTION.DOC_ADMIN_RETERIVAL_REQUEST.ADD}
        element={<CreateRetrievalForm mode="add" />}
      />
      <Route
        path={ROUTES.FEATURES.TRANSACTION.DOC_ADMIN_RETERIVAL_REQUEST.EDIT}
        element={<CreateRetrievalForm mode="edit" />}
      />
    </Routes>
  );
};

FileRetrievalRequestPage.displayName = "FileRetrievalRequestPage";
export default FileRetrievalRequestPage;
