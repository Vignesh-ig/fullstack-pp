import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { SmartphoneIcon, UserIcon } from "../../../components/icons/icons";
import Button from "../../../components/ui/common/Button";
import InputField from "../../../components/ui/common/InputField";
import Logo from "../../../components/ui/common/Logo";

const EmailActionLogin = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const [mobileNumber, setMobileNumber] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  /**
   * Employee Login
   * Navigate to existing Login.jsx
   */
  const handleEmployeeLogin = () => {
    // Preserve Approve / Reject URL

    navigate("/login", { replace: true });
  };

  /**
   * Mobile Login
   * Send OTP
   */
  const handleMobileLogin = async (e) => {
    e.preventDefault();

    setError("");

    if (!/^[6-9]\d{9}$/.test(mobileNumber)) {
      setError("Please enter a valid 10-digit mobile number");
      return;
    }

    try {
      setLoading(true);

      // TODO: Replace with your actual API call
      //
      // const response = await dispatch(
      //   sendDocAdminOtpThunk({
      //     mobileNumber,
      //   })
      // );

      /**
       * Save mobile number for OTP verification
       */
      sessionStorage.setItem("loginMobileNumber", mobileNumber);

      /**
       * Preserve email action URL
       *
       * Example:
       * /email-action?fileId=123&action=approve
       */
      sessionStorage.setItem(
        "redirectAfterOtp",
        location.pathname + location.search,
      );

      /**
       * Move to OTP screen
       */
      navigate("/verify-otp", {
        replace: true,
      });
    } catch (err) {
      setError("Unable to send OTP. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen flex items-center justify-center bg-slate-950 p-6">
      {/* Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-15 -left-40 h-96 w-96 rounded-full bg-blue-600/20 blur-3xl" />

        <div className="absolute -bottom-15 -right-40 h-96 w-96 rounded-full bg-indigo-600/20 blur-3xl" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo */}
        <div className="mb-5 flex justify-center">
          <Logo />
        </div>

        {/* Card */}
        <div className="rounded-3xl bg-white p-8 shadow-2xl">
          {/* Header */}
          <div className="mb-3 text-center">
            <h1 className="text-3xl font-bold text-slate-800">File Tracking</h1>

            <p className="mt-1 text-slate-500">Sign in to continue</p>
          </div>

          {/* Employee Login */}
          <button
            type="button"
            onClick={handleEmployeeLogin}
            className=" w-full rounded-2xl border border-slate-200 bg-white p-4 text-left transition hover:border-blue-400 hover:bg-blue-50"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-blue-100">
                <UserIcon className="h-5 w-5 text-blue-600" />
              </div>

              <div>
                <h2 className="font-semibold text-slate-800">Employee Login</h2>
              </div>
            </div>
          </button>

          {/* Divider */}
          <div className="my-4 flex items-center gap-2">
            <div className="h-px flex-1 bg-slate-200" />

            <span className="text-xs font-medium text-slate-400">OR</span>

            <div className="h-px flex-1 bg-slate-200" />
          </div>

          {/* Mobile Login */}
          <div className="rounded-2xl border border-slate-200 p-6">
            <div className="mb-3 flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-indigo-100">
                <SmartphoneIcon className="h-5 w-5  text-blue-600" />
              </div>

              <div>
                <h2 className="font-semibold text-slate-800">
                  Login with Mobile Number
                </h2>
              </div>
            </div>

            <form onSubmit={handleMobileLogin}>
              <InputField
                label="Mobile Number"
                type="tel"
                value={mobileNumber}
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, "");

                  if (value.length <= 10) {
                    setMobileNumber(value);
                  }
                }}
                placeholder="Enter 10-digit mobile number"
                required
                maxLength={10}
                error={error}
                // icon={
                //   <SmartphoneIcon className="h-5 w-5 text-slate-500" />
                // }
              />

              <Button
                type="submit"
                disabled={loading || mobileNumber.length !== 10}
              >
                {loading ? "Sending OTP..." : "Send OTP"}
              </Button>
            </form>
          </div>
        </div>
      </div>
    </main>
  );
};

EmailActionLogin.displayName = "EmailActionLogin";

export default EmailActionLogin;
