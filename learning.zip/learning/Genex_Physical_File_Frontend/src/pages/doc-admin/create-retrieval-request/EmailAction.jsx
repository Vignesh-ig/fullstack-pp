import { useEffect } from "react";
import {
  useLocation,
  useNavigate,
  useParams,
} from "react-router-dom";
import { useSelector } from "react-redux";
import { ROUTES } from "../../../router/routes";

const EmailAction = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { trackId } = useParams();

  const searchParams = new URLSearchParams(location.search);
  const action = searchParams.get("action");

  useEffect(() => {
    // Validate email URL
    if (!trackId || !action) {
      console.error("Missing trackId or action");

      navigate(ROUTES.COMMON.NOT_FOUND, {
        replace: true,
      });

      return;
    }

    // Save the original email URL
    const redirectUrl =
      `${location.pathname}${location.search}`;

    sessionStorage.setItem(
      "redirectAfterLogin",
      redirectUrl
    );

    // Always go to EmailActionLogin
    navigate(ROUTES.AUTH.LOGIN, {
      replace: true,
    });
  }, [
    trackId,
    action,
    location.pathname,
    location.search,
    navigate,
  ]);

  return <div>Opening retrieval request...</div>;
};

export default EmailAction;