import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import "react-datepicker/dist/react-datepicker.css";
import { useSelector } from "react-redux";
import localStorage from "redux-persist/es/storage";
import * as XLSX from "xlsx";
import {
  getCsvFileapi,
  getRetrievalDetailApi,
  getStageFlowApi,
} from "../../../../api/apiConfig";
import { CloseIcon } from "../../../../components/icons/icons";
import InputField from "../../../../components/ui/common/InputField";
import SelectField from "../../../../components/ui/common/SelectField";
import SelectFieldWithCheckbox from "../../../../components/ui/common/SelectFieldWithCheckbox";
import { canEditRetrieval } from "../../../../constants/roles";
import { FILE_TRACKING_STATUS, JOB_STATUS } from "../../../../constants/status";

const CreateRetrievalFormFields = ({
  register,
  track_id,
  errors,
  watch,
  setValue,
  trigger,
  isEdit,
  dropdowns,
  touchedFields,
  isSubmitted,
  agreementType,
  setRetrievalDropdownEnabled,
  onJobStageChange,
  onHandoverDateChange,
  onStageChange,
  onRequestTypeChange,
}) => {
  const { roleName: currentRoleName } = useSelector((state) => state.user);
  const isDocAdminEdit = canEditRetrieval(currentRoleName) && isEdit;
  const selectionType = watch("selectionType", "single");
  const file = watch("file");
  const tatValue = watch("tat");

  const [jobStatus, setJobStatus] = useState("");
  const [getL1Assignee, setLocalRoleName] = useState("");
  const [statusJob, setStatusJob] = useState("");

  const [showCsvPreview, setShowCsvPreview] = useState(false);
  const [csvData, setCsvData] = useState([]);
  const [csvLoading, setCsvLoading] = useState(false);
  const [deliveryDate, setDeliveryDate] = useState(null);
  const [jobStageFlow, setJobStageFlow] = useState([]);
  const [dmsId, setDmsId] = useState("");
  const [isDownloading, setIsDownloading] = useState(false);

  // const [documentType, setDocumentType] = useState("");

  const [
    department,
    requestDocument,
    document,
    requestType,
    location,
    purpose,
  ] = watch([
    "department",
    "requestDocument",
    "document",
    "requestType",
    "location",
    "purpose",
  ]);
  const fileInputRef = useRef(null);
  const handleButtonClick = () => {
    fileInputRef.current.click();
  };

  const retrievalDetailsApi = async () => {
    const response = await getRetrievalDetailApi(track_id);

    const data = response.data;

    setValue("selectionType", data.agreement_type);
    setValue("agreementNumber", data.agreement_no);
    setValue("department", data.department_id);
    setValue("requestDocument", data.retreival_doc_type_id);
    setValue("document", data.document_id);
    setValue("requestType", data.request_type_id);
    setValue("location", data.location_id);
    setValue("purpose", data.purpose_id);
    setValue("otherDepartment", data.department_description ?? "");
    setValue("otherRequestType", data.request_type_description ?? "");
    setValue("otherDocument", data.document_description ?? "");
    setValue("otherDelivery", data.location_description ?? "");
    setValue("otherPurpose", data.purpose_description ?? "");
    setValue("products", data.product ?? "");
    setValue("jobstage", data.job_stage ?? "");
    setValue("scanLink", data.scan_file_link ?? "");
    setValue("tat", data.tat_value ?? "");
    setJobStatus(data.job_stage ?? "");
    onJobStageChange?.(data.job_status ?? "");
    onStageChange?.(data.job_stage ?? "");
    // setDocumentType(data.retreival_doc_type_id);

    setStatusJob?.(data.job_status ?? "");
    setDeliveryDate(data.handover_date ?? "");
    onHandoverDateChange?.(data.handover_date ?? "");

    setDmsId(data.dms_id);
  };

  const getStageFlow = async () => {
    try {
      const response = await getStageFlowApi();

      const data = response?.data ?? [];

      setJobStageFlow(data);
    } catch (error) {
      console.error("Failed to fetch stage flow:", error);
      setJobStageFlow([]);
    }
  };

  useEffect(() => {
    register("file");
  }, [register, department]);

  useEffect(() => {
    if (track_id) {
      setValue("selectionType", agreementType);
      retrievalDetailsApi();
      getStageFlow();
    }
  }, [track_id]);

  const handleClear = () => {
    setValue("file", null, {
      shouldDirty: true,
      shouldValidate: true,
    });
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleSampleXlsxView = async () => {
    try {
      setCsvLoading(true);
      setShowCsvPreview(true);

      const response = await fetch("/sample-document.xlsx");

      if (!response.ok) {
        throw new Error("Failed to load sample XLSX");
      }

      const arrayBuffer = await response.arrayBuffer();

      const workbook = XLSX.read(arrayBuffer, {
        type: "array",
      });

      // Get first sheet
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];

      // Convert sheet to array
      const rows = XLSX.utils.sheet_to_json(worksheet, {
        header: 1,
        defval: "",
      });

      setCsvData(rows);
    } catch (error) {
      console.error("Error loading XLSX:", error);
    } finally {
      setCsvLoading(false);
    }
  };

  const handleDownload = () => {
    const link = window.document.createElement("a");

    link.href = "/sample-document.xlsx";
    link.download = "sample_document.xlsx";

    window.document.body.appendChild(link);
    link.click();
    link.remove();
  };

  const handleDownloadXlsx = async () => {
    try {
      setIsDownloading(true);

      const blob = await getCsvFileapi(dmsId);

      if (!blob) {
        throw new Error("No file received from API");
      }

      // Create download URL directly from XLSX blob
      const url = window.URL.createObjectURL(
        new Blob([blob], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        }),
      );

      const link = window.document.createElement("a");
      link.href = url;
      link.download = "Request_Document.xlsx";

      window.document.body.appendChild(link);
      link.click();
      link.remove();

      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("XLSX download failed:", error);
    } finally {
      setIsDownloading(false);
    }
  };

  const toOptions = (response, valueKey, labelKey) => {
    const items = response?.data ?? [];

    return items.map((item) => ({
      value: item[valueKey],
      label: item[labelKey],
    }));
  };

  const departmentOptions = toOptions(
    dropdowns?.departments,
    "department_id",
    "department_name",
  );

  const requestTypeOptions = toOptions(
    dropdowns?.requestTypes,
    "request_type_id",
    "request_type",
  );

  const locationOptions = toOptions(
    dropdowns?.locations,
    "location_id",
    "location_name",
  );

  const purposeOptions = toOptions(
    dropdowns?.purposes,
    "purpose_id",
    "purpose_name",
  );

  const documentOptions = toOptions(
    dropdowns?.documents,
    "document_id",
    "document_name",
  );

  const retreivalDocsTypeOptions = toOptions(
    dropdowns?.retreivalDocsType,
    "retreival_doc_type_id",
    "retreival_doc_type",
  );

  const staticProducts = {
    data: [{ product_id: "1", product_name: "VF" }],
  };

  const jobStatusOptions = [
    {
      value: JOB_STATUS.RefilingInitiated,
      label: JOB_STATUS.RefilingInitiated,
    },
    {
      value: JOB_STATUS.Close,
      label: JOB_STATUS.Close,
    },
  ];

  const productOptions = toOptions(
    staticProducts,
    "product_name",
    "product_name",
  );

  const getWorkingDaysSinceDelivery = (deliveryDate) => {
    if (!deliveryDate) return 0;

    const start = new Date(deliveryDate);
    const today = new Date();

    start.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);

    if (start >= today) return 0;

    let workingDays = 0;
    const current = new Date(start);

    while (current < today) {
      current.setDate(current.getDate() + 1);

      // 0 = Sunday
      if (current.getDay() !== 0) {
        workingDays++;
      }
    }

    return workingDays;
  };

  const daysSinceDelivery = getWorkingDaysSinceDelivery(deliveryDate);

  const tatOptions30 = Array.from({ length: 27 }, (_, index) => ({
    value: `T${index + 4}`,
    label: `T${index + 4}`,
  }));

  const tatOptions90 = Array.from({ length: 87 }, (_, index) => {
    const tatDay = index + 4;

    return {
      value: `T${tatDay}`,
      label: `T${tatDay}`,
      disabled: tatDay <= daysSinceDelivery,
    };
  });

  const selectedDepartment = dropdowns?.departments?.data?.find(
    (item) => String(item.department_id) === String(department),
  );

  const selectedDocument = dropdowns?.documents?.data?.find(
    (item) => String(item.document_id) === String(document),
  );

  const selectedRequestType = dropdowns?.requestTypes?.data?.find(
    (item) => String(item.request_type_id) === String(requestType),
  );

  const selectedDeliveryLocation = dropdowns?.locations?.data?.find(
    (item) => String(item.location_id) === String(location),
  );

  const selectedPurpose = dropdowns?.purposes?.data?.find(
    (item) => String(item.purpose_id) === String(purpose),
  );

  const selectedTypeDocument = dropdowns?.retreivalDocsType?.data?.find(
    (item) => String(item.retreival_doc_type_id) === String(requestDocument),
  );

  const selectDocuments = Array.isArray(document)
    ? document
    : [document || []].flat().filter(Boolean);

  const othersOption = documentOptions.find(
    (option) => option.label.toLowerCase() === "others",
  );

  const updatedDocumentOptions = documentOptions.map((option) => {
    const isOthers = option.label.toLowerCase() === "others";

    const othersSelected =
      othersOption && selectDocuments.includes(othersOption.value);

    const normalSelected = selectDocuments.some(
      (value) => value !== othersOption?.value,
    );

    return {
      ...option,
      disabled: isOthers ? normalSelected : othersSelected,
    };
  });
  const isJobClosed =
    String(jobStatus).toUpperCase() === String(JOB_STATUS.Close).toUpperCase();

  const isScanRequest =
    selectedTypeDocument?.retreival_doc_type === "Scan request";

  const isOriginalRetrievalType =
    selectedTypeDocument?.retreival_doc_type === "Original retrieval";

  useEffect(() => {
    onRequestTypeChange?.(isScanRequest);
  }, [isScanRequest, onRequestTypeChange]);

  useEffect(() => {
    const getRole = async () => {
      const role = await localStorage.getItem("employeeCode");
      setLocalRoleName(role);
    };

    getRole();
  }, []);
  const isL1Tat = getL1Assignee === "assignee" && isOriginalRetrievalType;

  const isDocAdminTat =
    isDocAdminEdit &&
    [
      JOB_STATUS.FileHandedOverToUser,
      JOB_STATUS.RefilingRequestedByDepartment,
      JOB_STATUS.RefilingInitiated,
    ].includes(jobStatus) &&
    isOriginalRetrievalType;

  const showTatDropdown = isL1Tat || isDocAdminTat;
  const tatOptions = isDocAdminTat ? tatOptions90 : tatOptions30;

  const getJobStageOptions = (jobStatus) => {
    if (!jobStageFlow?.length) return [];

    const normalizedJobStatus = String(jobStatus || "")
      .trim()
      .toUpperCase();

    const normalizedReturnType = String(statusJob || "")
      .trim()
      .toUpperCase();

    // No current stage
    if (!normalizedJobStatus) {
      const firstStage = jobStageFlow[0];

      if (!firstStage?.main_stage) return [];

      return [
        {
          value: firstStage.main_stage,
          label: firstStage.main_stage,
        },
      ];
    }

    // Find current stage
    const currentStage = jobStageFlow.find(
      (item) =>
        String(item.main_stage || "")
          .trim()
          .toUpperCase() === normalizedJobStatus,
    );

    if (!currentStage) return [];

    // Special validation for REFILING INITIATED
    if (normalizedJobStatus === "REFILING INITIATED") {
      // Fully returned → show CLOSED
      if (normalizedReturnType === FILE_TRACKING_STATUS.FullyReturned) {
        const closedStage = jobStageFlow.find(
          (item) =>
            String(item.main_stage || "")
              .trim()
              .toUpperCase() === "CLOSED",
        );

        if (!closedStage?.main_stage) return [];

        return [
          {
            value: closedStage.main_stage,
            label: closedStage.main_stage,
          },
        ];
      }

      // Partially returned → show current stage
      // Since REFILING INITIATED has no next_stage
      if (normalizedReturnType === FILE_TRACKING_STATUS.PartiallyReturned) {
        return [
          {
            value: currentStage.main_stage,
            label: currentStage.main_stage,
          },
        ];
      }
    }

    const options = [];

    // Add CURRENT stage
    if (currentStage.main_stage) {
      options.push({
        value: currentStage.main_stage,
        label: currentStage.main_stage,
      });
    }

    // Add NEXT stage
    if (currentStage.next_stage) {
      options.push({
        value: currentStage.next_stage,
        label: currentStage.next_stage,
      });
    }

    if (isScanRequest) {
      if (normalizedReturnType === FILE_TRACKING_STATUS.FullyReturned) {
        return options.filter(
          (stage) => stage.value?.toUpperCase() !== "CLOSED",
        );
      }

      if (normalizedReturnType === FILE_TRACKING_STATUS.PartiallyReturned) {
        return options;
      }
    }
    return options;
  };

  const filteredJobStatusCheck = getJobStageOptions(jobStatus);
  const filteredJobStatusOptions = jobStatusOptions.filter(
    (option) => option.value === JOB_STATUS.Close,
  );

  return (
    <fieldset className="flex flex-col sm:flex-row gap-10">
      <div className="flex-1 space-y-6">
        <div>
          <div className="flex items-center gap-2.5 mb-5">
            <label className="text-sm font-medium text-gray-700">
              AGREEMENT TYPE <span className="text-red-500">*</span>
            </label>

            {showCsvPreview && (
              <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
                <div className="w-full max-w-6xl max-h-[85vh] rounded-xl bg-white shadow-2xl">
                  {/* Header */}
                  <div className="flex items-center justify-between border-b px-6 py-4">
                    <h2 className="text-lg font-semibold text-gray-800">
                      Sample CSV
                    </h2>

                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={handleDownload}
                        className="px-5 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700"
                      >
                        "Download"
                      </button>
                      {/* 
          <button
            type="button"
            onClick={() => setShowCsvPreview(false)}
            title="Close"
            className="rounded-md p-2 text-gray-500
              hover:bg-gray-100 hover:text-gray-800 transition"
          >
            <X className="h-5 w-5" />
          </button> */}
                    </div>
                  </div>

                  {/* CSV Preview */}
                  <div className="max-h-[70vh] overflow-auto p-6">
                    {csvLoading ? (
                      <div className="flex justify-center py-10 text-gray-500">
                        Loading...
                      </div>
                    ) : csvData.length > 0 ? (
                      <table className="w-full border-collapse text-sm">
                        <thead>
                          <tr>
                            {csvData[0].map((header, index) => (
                              <th
                                key={index}
                                className="border border-gray-200 bg-gray-100
                      px-4 py-3 text-left font-semibold
                      text-gray-700 whitespace-nowrap"
                              >
                                {header}
                              </th>
                            ))}
                          </tr>
                        </thead>

                        <tbody>
                          {csvData.slice(1).map((row, rowIndex) => (
                            <tr key={rowIndex} className="hover:bg-gray-50">
                              {row.map((cell, cellIndex) => (
                                <td
                                  key={cellIndex}
                                  className="border border-gray-200
                        px-4 py-3 text-gray-600 whitespace-nowrap"
                                >
                                  {cell}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    ) : (
                      <div className="py-10 text-center text-gray-500">
                        No XLSX data available.
                      </div>
                    )}
                  </div>

                  {/* Footer */}
                  <div className="flex justify-end border-t px-6 py-4">
                    <button
                      type="button"
                      onClick={() => setShowCsvPreview(false)}
                      className="rounded-md bg-gray-600 px-4 py-2
            text-sm text-white hover:bg-gray-700"
                    >
                      Close
                    </button>
                  </div>
                </div>
              </div>
            )}
            {selectionType === "multiple" && !isEdit && (
              <button
                type="button"
                onClick={handleSampleXlsxView}
                className="inline-flex w-fit px-3 py-1.5 text-sm rounded-md border border-blue-600 text-blue-600 hover:bg-blue-50 transition"
              >
                Sample Xlsx for Upload
              </button>
            )}
          </div>
          {/* Radio Buttons */}
          <div className="flex items-center gap-6">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                value="single"
                {...register("selectionType")}
                disabled={isEdit}
              />
              Single
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="radio"
                value="multiple"
                {...register("selectionType")}
                disabled={isEdit}
              />
              Multiple
            </label>
            {selectionType === "multiple" && isEdit && (
              <button
                type="button"
                disabled={isDownloading}
                onClick={handleDownloadXlsx}
                className="inline-flex w-fit px-3 py-1.5 text-sm rounded-md border border-blue-600 text-blue-600 hover:bg-blue-50 transition"
              >
                {isDownloading ? "Downloading..." : "Download"}
              </button>
            )}
          </div>
          {/* Animated Upload Button */}
          <AnimatePresence>
            {selectionType === "multiple" && !isEdit && (
              <motion.div
                initial={{ opacity: 0, height: 0, y: -10 }}
                animate={{ opacity: 1, height: "auto", y: 0 }}
                exit={{ opacity: 0, height: 0, y: -10 }}
                transition={{ duration: 0.4, ease: "easeInOut" }}
                className="overflow-hidden mt-4"
              >
                {!file && (
                  <button
                    type="button"
                    onClick={handleButtonClick}
                    className="px-5 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700"
                  >
                    Upload Document
                  </button>
                )}

                {file && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-700 truncate max-w-xs">
                      {file.name}
                    </span>

                    <button type="button" onClick={handleClear} className="p-1">
                      <CloseIcon className="w-4 h-4 text-gray-600 hover:text-gray-800" />
                    </button>
                  </div>
                )}

                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept=".xlsx"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      setValue("file", file, {
                        shouldDirty: true,
                        shouldValidate: true,
                      });
                    }
                  }}
                />
              </motion.div>
            )}
          </AnimatePresence>
          <AnimatePresence>
            {selectionType !== "multiple" && (
              <motion.div
                initial={{ opacity: 0, height: 0, y: -10 }}
                animate={{ opacity: 1, height: "auto", y: 0 }}
                exit={{ opacity: 0, height: 0, y: -10 }}
                transition={{ duration: 0.4, ease: "easeInOut" }}
                className="overflow-hidden mt-9"
              >
                <InputField
                  label="Agreement Number"
                  {...register("agreementNumber")}
                  error={errors.agreementNumber?.message}
                  placeholder="Enter agreement number"
                  required
                  className="mb-4"
                  disabled={isEdit}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <div
          className={`w-full ${
            selectionType === "multiple" ? "mt-9" : "-mt-3"
          }`}
        >
          {/* <SelectField
            label="PRODUCTS"
            name="products"
            value={watch("products")}
            onChange={(e) => {
              setValue("products", e.target.value, { shouldValidate: true });
            }}
            onBlur={() => trigger?.("products")}
            placeholder="Select products..."
            options={productOptions}
            error={errors.products?.message}
            className="mb-4"
            required
            disabled={isEdit}
          /> */}
        </div>

        <div className="w-full">
          <SelectField
            label="DEPARTMENT"
            name="department"
            value={watch("department")}
            onChange={(e) => {
              setValue("department", e.target.value, { shouldValidate: true });
            }}
            onBlur={() => trigger?.("department")}
            placeholder="Select department..."
            options={departmentOptions}
            error={errors.department?.message}
            className="mb-4"
            required
            disabled={isEdit}
          />

          <AnimatePresence>
            {selectedDepartment?.department_name === "Others" && (
              <motion.div
                initial={{ opacity: 0, height: 0, y: -10 }}
                animate={{ opacity: 1, height: "auto", y: 0 }}
                exit={{ opacity: 0, height: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <InputField
                  label="Enter Other Department"
                  {...register("otherDepartment")}
                  placeholder="Enter Other department name"
                  className="mb-4"
                  error={errors.otherDepartment?.message}
                  required
                  disabled={isEdit}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <SelectField
          label="TYPES OF DOCUMNETS"
          name="requestDocument"
          value={watch("requestDocument")}
          onChange={(e) =>
            setValue("requestDocument", e.target.value, {
              shouldValidate: false,
            })
          }
          placeholder="Select Document Type"
          options={retreivalDocsTypeOptions}
          error={isSubmitted ? errors?.document?.message || "" : ""}
          className="mb-4"
          required
          disabled={isEdit}
        />

        {isEdit && isDocAdminEdit && (
          <div className="w-full  mt-6">
            <SelectField
              label="JOBSTAGE"
              name="jobstage"
              value={watch("jobstage")}
              onChange={(e) => {
                setValue("jobstage", e.target.value, {
                  shouldValidate: true,
                });
              }}
              onBlur={() => trigger?.("jobstage")}
              placeholder="Select jobstage..."
              options={
                isScanRequest
                  ? filteredJobStatusOptions
                  : filteredJobStatusCheck
              }
              error={errors.jobstage?.message}
              className="mb-4"
              required
              disabled={isEdit && isJobClosed}
            />
          </div>
        )}
      </div>
      <div className="flex-1 space-y-6">
        <div className="w-full">
          <SelectFieldWithCheckbox
            label="REQUEST DOCUMENTS"
            name="document"
            value={watch("document") || []}
            onChange={(e) => {
              const value = Array.isArray(e.target.value)
                ? e.target.value
                : e.target.value
                  ? [e.target.value]
                  : [];

              setValue("document", value, {
                shouldValidate: true,
                shouldTouch: true,
                shouldDirty: true,
              });
            }}
            placeholder="Select Document List.."
            options={updatedDocumentOptions}
            error={isSubmitted ? errors?.document?.message || "" : ""}
            className="mb-4"
            required
            disabled={isEdit}
            showSelectAll={false}
          />
          <AnimatePresence>
            {selectedDocument?.document_name === "Others" && (
              <motion.div
                initial={{ opacity: 0, height: 0, y: -10 }}
                animate={{ opacity: 1, height: "auto", y: 0 }}
                exit={{ opacity: 0, height: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <InputField
                  label="Enter Other Document"
                  {...register("otherDocument")}
                  placeholder="Enter Other Document name"
                  className="mb-4"
                  error={errors.otherDocument?.message}
                  required
                  disabled={isEdit}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <div className="w-full">
          <SelectField
            label="REQUEST TYPE"
            name="requestType"
            value={watch("requestType")}
            onChange={(e) =>
              setValue("requestType", e.target.value, { shouldValidate: true })
            }
            onBlur={() => trigger?.("requestType")}
            placeholder="Select Request Type"
            options={requestTypeOptions}
            error={errors.requestType?.message}
            className="mb-4"
            required
            disabled={isEdit}
          />
          <AnimatePresence>
            {selectedRequestType?.request_type === "Others" && (
              <motion.div
                initial={{ opacity: 0, height: 0, y: -10 }}
                animate={{ opacity: 1, height: "auto", y: 0 }}
                exit={{ opacity: 0, height: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <InputField
                  label="Enter Other Request Type"
                  {...register("otherRequestType")}
                  placeholder="Enter other request type name"
                  className="mb-4"
                  error={errors.otherRequestType?.message}
                  required
                  disabled={isEdit}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="w-full">
          <SelectField
            label="DELIVERY LOCATION"
            name="location"
            value={watch("location")}
            onChange={(e) =>
              setValue("location", e.target.value, { shouldValidate: true })
            }
            onBlur={() => trigger?.("location")}
            placeholder="Select Delivery Location"
            options={locationOptions}
            error={errors.location?.message}
            className="mb-4"
            required
            disabled={isEdit}
          />
          <AnimatePresence>
            {selectedDeliveryLocation?.location_name === "Others" && (
              <motion.div
                initial={{ opacity: 0, height: 0, y: -10 }}
                animate={{ opacity: 1, height: "auto", y: 0 }}
                exit={{ opacity: 0, height: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <InputField
                  label="Enter Other delivery location"
                  {...register("otherDelivery")}
                  placeholder="Enter other delivery location"
                  className="mb-4"
                  error={errors.otherDelivery?.message}
                  required
                  disabled={isEdit}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="w-full">
          <SelectField
            label="PURPOSE"
            name="purpose"
            value={watch("purpose")}
            onChange={(e) =>
              setValue("purpose", e.target.value, { shouldValidate: true })
            }
            onBlur={() => trigger?.("purpose")}
            placeholder="Select Purpose"
            options={purposeOptions}
            error={errors.purpose?.message}
            className="mb-4"
            required
            disabled={isEdit}
          />
          <AnimatePresence>
            {selectedPurpose?.purpose_name === "Others" && (
              <motion.div
                initial={{ opacity: 0, height: 0, y: -10 }}
                animate={{ opacity: 1, height: "auto", y: 0 }}
                exit={{ opacity: 0, height: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <InputField
                  label="Enter Other purpose"
                  {...register("otherPurpose")}
                  placeholder="Enter other purpose"
                  className="mb-4"
                  error={errors.otherPurpose?.message}
                  required
                  disabled={isEdit}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* <AnimatePresence>
            { selectedTypeDocument?.retreival_doc_type === "Scan request" && isDocAdminEdit && (
              <motion.div
                initial={{ opacity: 0, height: 0, y: -10 }}
                animate={{ opacity: 1, height: "auto", y: 0 }}
                exit={{ opacity: 0, height: 0, y: -10 }}
                transition={{ duration: 0.4, ease: "easeInOut" }}
                className="overflow-hidden mt-6"
              >
                <InputField
                  label="Scan Link"
                  {...register("scanLink")}
                  error={errors.scanLink?.message}
                  placeholder="Enter the scan Link"
                  required
                  className="mb-4"
                  disabled={isJobClosed}
                />
              </motion.div>
            )}
          </AnimatePresence> */}
        {showTatDropdown && (
          <div className="w-full">
            <SelectField
              label="TAT"
              name="tat"
              value={watch("tat")}
              onChange={(e) => {
                setValue("tat", e.target.value, {
                  shouldValidate: true,
                  shouldDirty: true,
                  shouldTouch: true,
                });
              }}
              onBlur={() => trigger?.("tat")}
              placeholder="Select TAT..."
              options={tatOptions}
              error={errors.tat?.message}
              className="mb-4"
              required
              disabled={
                isEdit && tatValue != null && tatValue != "" && !isDocAdminEdit
              }
            />
          </div>
        )}

        {/* 
         {isDocAdminEdit && isEdit && <div className="mb-4">
        <label className="block text-text-secondary text-xs font-bold uppercase tracking-wider mb-2">
          Tat Date
          <span className="required-asterisk">*</span>
        </label>

        <DatePicker
          selected={watch("tatDate")}
          onChange={(date) =>
            setValue("tatDate", date, { shouldValidate: true })
          }
          onBlur={() => trigger?.("tatDate")}
          // disabled={isEdit}
          placeholderText="Select date"
          dateFormat={"dd/MM/yyyy"}
          className={`
      w-full px-4 py-3.5 bg-surface-tertiary border rounded-xl
      text-text-primary text-sm font-medium
      placeholder:text-text-secondary/70
      shadow-sm
      focus:outline-none focus:ring-2 focus:ring-brand-accent/20
      focus:border-brand-accent
      hover:border-text-secondary/30
      transition-all
      ${errors.tatDate ? "border-status-error" : "border-border-main"}
    `}
        />
        {errors.requesterDate && (
          <p className="mt-1 text-xs text-status-error font-medium">
            {errors.requesterDate.message}
          </p>
        )}
         
      </div>
      
} */}
      </div>
    </fieldset>
  );
};

CreateRetrievalFormFields.displayName = "CreateRetrievalFormFields";
export default CreateRetrievalFormFields;
