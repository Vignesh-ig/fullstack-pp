/**
 * CreateRetrievalForm
 *
 * Full-page form for creating and editing racks. Matches the structure and logic of BranchForm.
 *
 */

import { zodResolver } from "@hookform/resolvers/zod";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import {
  useLocation,
  useNavigate,
  useParams,
  useSearchParams,
} from "react-router-dom";
import {
  approveandRejectApi,
  createRetrievalRequestApi,
  getDepartmentApi,
  getDocumentsApi,
  getLocationsApi,
  getPurposeApi,
  getRequestTypesApi,
  getRetreivalDocsTypeApi,
  getRetrievalDetailApi,
  getRoleApi,
  refillingRequestApi,
  updateRetrievalRequestApi,
} from "../../../api/apiConfig";
import ErrorBanner from "../../../components/ui/common/ErrorBanner";
import FormFooter from "../../../components/ui/common/FormFooter";
import FormHeader from "../../../components/ui/common/FormHeader";
import SuccessBanner from "../../../components/ui/common/SuccessBanner";
import { canEditRetrieval } from "../../../constants/roles";
import { FILE_TRACKING_STATUS, JOB_STATUS } from "../../../constants/status";
import { useApi } from "../../../hooks/useApi";
import { retrievalRequestFormSchema } from "../../../utils/schemas/configSchema";
import CreateRetrievalFormFields from "./components/CreateRetrievalFormField";

const CreateRetrievalForm = ({ mode = "add", defaultValues = {} }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { id } = useParams();
  const { userId: currentUserId } = useSelector((state) => state.user);
  const { userEmployeeCode: currentEmployeeCode } = useSelector(
    (state) => state.user,
  );
  const { userName: currentUserName } = useSelector((state) => state.user);
  const { roleName: currentRoleName } = useSelector((state) => state.user);
  const { userEmail: currentUserEmail } = useSelector((state) => state.user);

  const isEdit = mode === "edit";
  const canShowFormFooter = !isEdit || canEditRetrieval(currentRoleName);
  const isDocAdminEdit = canEditRetrieval(currentRoleName);
  const [stageJob, setJobStage] = useState("");

  //   const canShowFormFooter =
  // currentRoleName === "DOC_ADMIN_USER" ||
  // (currentRoleName === "ADMIN_USER" && !isEdit);
  const { track_id } = useParams();
  const [searchParams] = useSearchParams();

  const action = searchParams.get("action"); // "approve" or "reject"

  const locationRack = location.state?.rack;
  const agreementType = location.state?.agreementType;

  const [isRefilling, setIsRefilling] = useState(
    location.state?.isRefilling ?? false,
  );

  const [retrievalDropdownEnabled, setRetrievalDropdownEnabled] =
    useState(isEdit);
  const { options: dropDownValue } = useApi(retrievalDropdownEnabled);
  const [showDialog, setShowDialog] = useState(false);
  const [remark, setRemark] = useState("");
  const [selectedAction, setSelectedAction] = useState("");
  const [approveSuccess, setApproveSuccess] = useState(false);
  const [rejectSuccess, setRejectSuccess] = useState(false);
  //isloading button usestate
  // const [isApproving, setIsApproving] = useState(false);
  // const [isRejecting, setIsRejecting] = useState(false);
  const [isSubmittingRemark, setIsSubmittingRemark] = useState(false);

  const apiFunction = useCallback(
    async (payload, file) => {
      if (isEdit) {
        return updateRetrievalRequestApi(payload, track_id, currentUserId);
      }

      // 1. Create retrieval request first
      const response = await createRetrievalRequestApi(payload, file);

      // 2. Only after create API succeeds
      if (response?.status >= 200 && response?.status < 300) {
        if (isDocAdminEdit) {
          const rolename = localStorage.getItem("employeeCode");

          // 3. Check if new user
          if (rolename === "new user") {
            const roleResponse = await getRoleApi(currentEmployeeCode);

            // 4. Save employee status
            localStorage.setItem(
              "employeeCode",
              roleResponse?.data?.employee_status ?? "",
            );
          }
        }
      }

      // 5. Return create API response
      return response;
    },
    [isEdit],
  );

  const handleReject = () => {
    setShowDialog(true);
    setSelectedAction("rejected");
  };

  const handleApprove = () => {
    setShowDialog(true);
    setSelectedAction("approved");
  };

  const handleSubmitApproval = async () => {
    if (selectedAction === "rejected" && !remark.trim()) {
      alert("Please enter a remark");
      return;
    }

    if (isSubmittingRemark) return;

    try {
      setIsSubmittingRemark(true);

      const response = await approveandRejectApi(
        track_id,
        currentUserId,
        selectedAction,
        remark,
        tatValue == null || tatValue == undefined || tatValue == ""
          ? "T3"
          : tatValue,
      );

      if (response?.status >= 200 && response?.status < 300) {
        if (selectedAction === "rejected") {
          setRejectSuccess(true);
        } else {
          setApproveSuccess(true);
        }

        setShowDialog(false);
        setRemark("");
      }
    } catch (error) {
      console.error("Approve/Reject API failed:", error);
    } finally {
      setIsSubmittingRemark(false);
    }
  };

  const {
    execute: submitRack,
    isLoading: isSubmittingAPI,
    error: submitError,
    setError: setSubmitError,
    isSuccess: submitSuccess,
  } = useApi(apiFunction);

  const { data: departmentList, execute: getDepartments } =
    useApi(getDepartmentApi);
  const { data: requestTypeList, execute: getRequestTypes } =
    useApi(getRequestTypesApi);
  const { data: locationList, execute: getLocations } = useApi(getLocationsApi);
  const { data: purposeList, execute: getPurposes } = useApi(getPurposeApi);
  const { data: documentList, execute: getDocuments } = useApi(getDocumentsApi);
  const { data: retreivalDocsList, execute: getRetreivalDocsType } = useApi(
    getRetreivalDocsTypeApi,
  );

  const fileInputRef = useRef(null);

  useEffect(() => {
    getDepartments();
    getRequestTypes();
    getLocations();
    getPurposes();
    getDocuments();
    getRetreivalDocsType();
  }, [
    getDepartments,
    getRequestTypes,
    getLocations,
    getPurposes,
    getDocuments,
    getRetreivalDocsType,
  ]);

  useEffect(() => {
    if (action === "approve") {
      // handleApprove();
    }

    if (action === "reject") {
      // handleReject();
    }
  }, [action]);

  const retrievalDetailsApi = async () => {
    const response = await getRetrievalDetailApi(track_id);
    const details = response.data;
    // Update your state from the latest API response
    setIsRefilling(details.is_refiled);
  };

  const refillingApi = async (file) => {
    const formData = new FormData();

    const payload = {
      agreement_type: agreementType,
    };

    if (agreementType === "single") {
      payload.agreement_no = agreementNumber;
    }

    formData.append("data", JSON.stringify(payload));

    if (file) {
      formData.append("documents", file);
    }

    const response = await refillingRequestApi(
      formData,
      track_id,
      currentUserId,
    );
    if (response.status === 200) {
      await retrievalDetailsApi();
    }
  };

  const handleAddRefilling = () => {
    if (agreementType === "single") {
      refillingApi();
    } else {
      fileInputRef.current?.click();
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    refillingApi(file);

    // Optional: allow selecting the same file again later
    e.target.value = "";
  };

  const resolvedDefaultValues = useMemo(
    () => ({
      requesterName:
        defaultValues?.requesterName ?? locationRack?.requesterName ?? id,
      requestTypeId:
        defaultValues?.requestTypeId ?? locationRack?.requestTypeId ?? "",
      departmentId:
        defaultValues?.departmentId ?? locationRack?.departmentId ?? "",
      agreementType:
        defaultValues?.agreementType ?? locationRack?.agreementType ?? "",
      agreementNo:
        defaultValues?.agreementNo ?? locationRack?.agreementNo ?? "",
      retreivalType:
        defaultValues?.requestDocument ?? locationRack?.requestDocument ?? "",
      purposeId: defaultValues?.purposeId ?? locationRack?.purposeId ?? "",
      documentId: defaultValues?.documentId ?? locationRack?.documentId ?? "",
      locationId: defaultValues?.locationId ?? locationRack?.locationId ?? "",
      priority: defaultValues?.priority ?? locationRack?.priority ?? "",
      selectionType:
        defaultValues?.selectionType ?? locationRack?.selectionType ?? "single",
    }),
    [defaultValues, id, locationRack],
  );

  const getOthersId = (list, idKey, nameKey) =>
    String(
      list?.data?.find((item) => item[nameKey] === "Others")?.[idKey] ?? "",
    );

  const othersIds = {
    department: getOthersId(departmentList, "department_id", "department_name"),

    requestType: getOthersId(
      requestTypeList,
      "request_type_id",
      "request_type",
    ),

    location: getOthersId(locationList, "location_id", "location_name"),

    purpose: getOthersId(purposeList, "purpose_id", "purpose_name"),

    document: getOthersId(documentList, "document_id", "document_name"),
  };

  const {
    register,
    handleSubmit,
    setValue,
    trigger,
    watch,
    formState: { errors, isValid, touchedFields, isSubmitted },
  } = useForm({
    resolver: zodResolver(retrievalRequestFormSchema(othersIds)),
    mode: "onTouched",
    defaultValues: {
      mode,
      ...resolvedDefaultValues,
    },
  });

  const agreementNumber = watch("agreementNumber");
  const jobStage = watch("jobstage");
  const tatValue = watch("tat");
  const [handoverDate, setHandoverDate] = useState("");
  const [stage, setStageValue] = useState("");
  const [isScanRequest, setScanRequest] = useState(false);

  const getTatDate = (tatValue, handoverDate) => {
    if (!tatValue) return "";

    // Extract number from T4, T10, etc.
    const days = parseInt(String(tatValue).replace(/^T/i, ""), 10);

    if (Number.isNaN(days)) return "";

    // Use handover date if available, otherwise use current date
    const date = handoverDate ? new Date(handoverDate) : new Date();

    if (Number.isNaN(date.getTime())) return "";

    let daysAdded = 0;

    while (daysAdded < days) {
      date.setDate(date.getDate() + 1);

      // 0 = Sunday, so skip Sunday
      if (date.getDay() !== 0) {
        daysAdded++;
      }
    }

    // Set end of day
    date.setHours(23, 59, 59, 999);

    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");
    const milliseconds = String(date.getMilliseconds()).padStart(3, "0");

    return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}.${milliseconds}+05:30`;
  };

  const onSubmit = async (data) => {
    if (isSubmittingAPI) return;

    const shouldSendTatValue = isDocAdminEdit;

    const shouldSendTatDate =
      isDocAdminEdit &&
      [
        JOB_STATUS.FileHandedOverToUser,
        JOB_STATUS.RefilingRequestedByDepartment,
        JOB_STATUS.RefilingInitiated,
      ].includes(jobStage);

    let payload;

    const tatDate = getTatDate(tatValue, handoverDate);
    if (isEdit) {
      // Payload for Edit API
      payload = {
        request_type_id: data.requestType || "",
        purpose_id: data.purpose || "",
        // document_id: Array.isArray(data.document) ? data.document : [],
        retreival_doc_type_id: data.requestDocument ?? "",
        location_id: data.location || "",
        department_id: data.department || "",
        job_stage: data.jobstage ?? "",
        ...(!isScanRequest &&
          shouldSendTatValue && {
            tat_value: data.tat ?? "T3",
          }),

        ...(!isScanRequest &&
          shouldSendTatDate && {
            tat_date: tatDate,
          }),
      };
    } else {
      payload = {
        user_id: currentUserId ?? "",
        employee_code: currentEmployeeCode ?? "",
        requester_name: currentUserName ?? "",
        product: data.products ?? "",
        request_type_id: data.requestType ?? "",
        department_id: data.department?.trim() || null,
        agreement_type: data.selectionType?.trim() || null,
        retreival_doc_type_id: data.requestDocument?.trim() || null,
        purpose_id: data.purpose?.trim() || null,
        document_id: Array.isArray(data.document) ? data.document : [],
        // document_id: data.document?.trim() || null,
        location_id: data.location?.trim() || null,
        requester_email: currentUserEmail,
      };
      if (data.selectionType === "single") {
        payload.agreement_no = data.agreementNumber?.trim() || "";
      }
    }

    const isOthers = (list, id, idKey, nameKey) =>
      list?.data?.find((item) => String(item[idKey]) === String(id))?.[
        nameKey
      ] === "Others";

    if (
      isOthers(
        departmentList,
        data.department,
        "department_id",
        "department_name",
      )
    ) {
      payload.department_description = data.otherDepartment?.trim();
    }

    if (
      isOthers(documentList, data.document?.[0], "document_id", "document_name")
    ) {
      payload.document_description = data.otherDocument?.trim();
    }

    if (
      isOthers(
        requestTypeList,
        data.requestType,
        "request_type_id",
        "request_type",
      )
    ) {
      payload.request_type_description = data.otherRequestType?.trim();
    }

    if (isOthers(locationList, data.location, "location_id", "location_name")) {
      payload.location_description = data.otherDelivery?.trim();
    }

    if (isOthers(purposeList, data.purpose, "purpose_id", "purpose_name")) {
      payload.purpose_description = data.otherPurpose?.trim();
    }

    const { error } = await submitRack(payload, data.file);
    if (!error) {
      setTimeout(() => navigate(".."), 1000);
    }
  };

  const localRolename = localStorage.getItem("employeeCode");

  const canShowRefillingButton = useMemo(() => {
    // Always show for these statuses
    if (
      jobStage === JOB_STATUS.RetrievalRequestInitiated ||
      jobStage === JOB_STATUS.FileReadyForUse
    ) {
      return false;
    }

    // File handed over
    if (
      agreementType === "single" &&
      jobStage === JOB_STATUS.FileHandedOverToUser
    ) {
      return true;
    }

    if (
      agreementType === "multiple" &&
      (jobStage === JOB_STATUS.FileHandedOverToUser ||
        stageJob === FILE_TRACKING_STATUS.PartiallyReturned)
    ) {
      return true;
    }

    return false;
  }, [agreementType, stageJob, jobStage]);

  const isJobClosed =
    String(stageJob).toUpperCase() === String(JOB_STATUS.Close).toUpperCase();

  return (
    <>
      <FormHeader
        title={isEdit ? "Edit Retrieval Request" : "Add Retrieval Request"}
        onBack={() => navigate("..")}
        rightContent={
          <div className="flex items-center gap-2">
            {(stageJob === FILE_TRACKING_STATUS.open ||
              [
                FILE_TRACKING_STATUS.Approved,
                FILE_TRACKING_STATUS.Inprogress,
                FILE_TRACKING_STATUS.PartiallyReturned,
                FILE_TRACKING_STATUS.FullyReturned,
              ].includes(stageJob)) &&
              localRolename === "assignee" &&
              !rejectSuccess && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleApprove}
                    disabled={
                      approveSuccess ||
                      stageJob === FILE_TRACKING_STATUS.Approved
                    }
                    className={`px-4 py-2 rounded-lg text-white transition-colors ${
                      approveSuccess ||
                      [
                        FILE_TRACKING_STATUS.Approved,
                        FILE_TRACKING_STATUS.Inprogress,
                        FILE_TRACKING_STATUS.PartiallyReturned,
                        FILE_TRACKING_STATUS.FullyReturned,
                      ].includes(stageJob)
                        ? "bg-gray-400 cursor-not-allowed"
                        : "bg-green-600 hover:bg-green-700"
                    }`}
                  >
                    {approveSuccess ||
                    [
                      FILE_TRACKING_STATUS.Approved,
                      FILE_TRACKING_STATUS.Inprogress,
                      FILE_TRACKING_STATUS.PartiallyReturned,
                      FILE_TRACKING_STATUS.FullyReturned,
                    ].includes(stageJob)
                      ? "Approved"
                      : "Approve"}
                  </button>

                  <button
                    type="button"
                    onClick={handleReject}
                    disabled={
                      approveSuccess ||
                      (localRolename === "assignee" &&
                        [
                          FILE_TRACKING_STATUS.Approved,
                          FILE_TRACKING_STATUS.Inprogress,
                          FILE_TRACKING_STATUS.PartiallyReturned,
                          FILE_TRACKING_STATUS.FullyReturned,
                        ].includes(stageJob))
                    }
                    className={`px-4 py-2 rounded-lg text-white ${
                      approveSuccess ||
                      (localRolename === "assignee" &&
                        [
                          FILE_TRACKING_STATUS.Approved,
                          FILE_TRACKING_STATUS.Inprogress,
                          FILE_TRACKING_STATUS.PartiallyReturned,
                          FILE_TRACKING_STATUS.FullyReturned,
                        ].includes(stageJob))
                        ? "bg-gray-400 cursor-not-allowed"
                        : "bg-red-600 hover:bg-red-700"
                    }`}
                  >
                    Reject
                  </button>
                </div>
              )}
            {showDialog && (
              <div
                style={{
                  position: "fixed",
                  inset: 0,
                  backgroundColor: "rgba(0, 0, 0, 0.5)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  zIndex: 9999,
                }}
              >
                <div
                  style={{
                    width: "400px",
                    maxWidth: "90%",
                    backgroundColor: "#fff",
                    padding: "20px",
                    borderRadius: "8px",
                    boxShadow: "0 4px 20px rgba(0, 0, 0, 0.3)",
                  }}
                >
                  <h3
                    style={{
                      marginTop: 0,
                      marginBottom: "15px",
                      fontSize: "18px",
                      fontWeight: "600",
                    }}
                  >
                    Approve Request
                  </h3>

                  <label
                    style={{
                      display: "block",
                      marginBottom: "5px",
                      fontWeight: "500",
                    }}
                  >
                    Enter Remark
                  </label>

                  <textarea
                    value={remark}
                    onChange={(e) => setRemark(e.target.value)}
                    placeholder="Enter your remark..."
                    rows={4}
                    style={{
                      width: "100%",
                      marginTop: "8px",
                      marginBottom: "15px",
                      padding: "10px",
                      boxSizing: "border-box",
                      border: "1px solid #ccc",
                      borderRadius: "5px",
                      resize: "vertical",
                      fontFamily: "inherit",
                      fontSize: "14px",
                    }}
                  />

                  <div
                    style={{
                      display: "flex",
                      justifyContent: "flex-end",
                      gap: "10px",
                    }}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        setShowDialog(false);
                        setRemark("");
                      }}
                      style={{
                        padding: "8px 16px",
                        border: "none",
                        borderRadius: "5px",
                        cursor: "pointer",
                        backgroundColor: "#ddd",
                        color: "#333",
                      }}
                    >
                      Cancel
                    </button>

                    <button
                      type="button"
                      onClick={handleSubmitApproval}
                      disabled={isSubmittingRemark}
                      style={{
                        padding: "8px 16px",
                        border: "none",
                        borderRadius: "5px",
                        cursor: isSubmittingRemark ? "not-allowed" : "pointer",
                        backgroundColor: isSubmittingRemark
                          ? "#6c757d"
                          : "#28a745",
                        color: "#fff",
                        opacity: isSubmittingRemark ? 0.7 : 1,
                      }}
                    >
                      {isSubmittingRemark ? "Submitting..." : "Submit"}
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* {isEdit && canShowRefillingButton && !isDocAdminEdit && (
              <button
                onClick={handleAddRefilling}
                disabled={isRefilling}
                className={`px-4 py-2 rounded-lg text-white ${
                  isRefilling
                    ? "bg-gray-400 cursor-not-allowed"
                    : "bg-blue-600 hover:bg-blue-700"
                }`}
              >
                {agreementType === "multiple"
                  ? "Upload Document"
                  : "Add Refilling"}
              </button>
            )} */}
          </div>
        }
      />
      <input
        type="file"
        ref={fileInputRef}
        className="hidden"
        onChange={handleFileChange}
      />
      <form
        onSubmit={handleSubmit(onSubmit, (err) => {
          console.log("Check validation error", err);
          console.log("Document error:", err.requestDocument?.message);
        })}
      >
        <input type="hidden" {...register("mode")} />
        <ErrorBanner
          message={submitError}
          onClose={() => setSubmitError(null)}
        />

        <SuccessBanner
          message={
            submitSuccess
              ? `Retrieval Request ${isEdit ? "updated" : "created"} successfully!!!`
              : null
          }
        />

        <CreateRetrievalFormFields
          register={register}
          track_id={track_id}
          errors={errors}
          watch={watch}
          setValue={setValue}
          trigger={trigger}
          isEdit={isEdit}
          touchedFields={touchedFields}
          isSubmitted={isSubmitted}
          agreementType={agreementType}
          onJobStageChange={setJobStage}
          onHandoverDateChange={setHandoverDate}
          onStageChange={setStageValue}
          onRequestTypeChange={setScanRequest}
          dropdowns={{
            departments: departmentList,
            requestTypes: requestTypeList,
            locations: locationList,
            purposes: purposeList,
            documents: documentList,
            retreivalDocsType: retreivalDocsList,
          }}
          vaultDropdownEnabled={retrievalDropdownEnabled}
          setVaultDropdownEnabled={setRetrievalDropdownEnabled}
        />

        {canShowFormFooter && (
          <FormFooter
            buttonWidth="350px"
            buttonAlign="center"
            buttons={[
              {
                label: isSubmittingAPI
                  ? isEdit
                    ? "Saving..."
                    : "Creating..."
                  : isEdit
                    ? "Update Retrieval"
                    : "Create Retrieval",
                props: {
                  type: "submit",
                  disabled: isJobClosed,
                },
              },
            ]}
          />
        )}
      </form>
    </>
  );
};

CreateRetrievalForm.displayName = "CreateRetrievalForm";
export default CreateRetrievalForm;
