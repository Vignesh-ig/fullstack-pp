import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { getDashboardApi, getTransactionApi } from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import DashboardStatCard from "../../components/ui/common/DashboardStatCard";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import { OVERVIEW_TAB } from "../../constants/menuHeaders";
import { useApi } from "../../hooks/useApi";
import { getCssVar } from "../../utils/utils";
import DashboardPieChart from "./components/DashboardPieChart";
import DashboardTransactionPanel from "./components/DashboardTransactionPanel";

/**
 * QUERY_CARDS
 *
 * Defines the two clickable stat cards for the Query dashboard.
 * Declared at module level — stable reference.
 */
const QUERY_CARDS = [
  {
    key: "criticalQueryCount",
    label: "Query",
    colorVar: "--color-qry-critical",
    apiFn: getTransactionApi,
    apiParams: { stages: "QUERY" },
  },
  {
    key: "nonCriticalQueryCount",
    label: "Non-Critical Query",
    colorVar: "--color-qry-non-critical",
    apiFn: getTransactionApi,
    apiParams: { queryState: "NON_CRITICAL_QUERY" },
  },
];

/**
 * QueryDashboard
 *
 * Displays query overview metrics as stat cards.
 * Clicking a card opens a paginated drill-down table filtered to that query type.
 * Visible to SUPER_ADMIN, ADMIN, BRANCH_ADMIN roles (enforced in DashboardMaster).
 */
const QueryDashboard = () => {
  const { execute, data, isLoading, error, setError } = useApi(getDashboardApi);

  const [activeCardKey, setActiveCardKey] = useState(null);
  const [isTableOpen, setIsTableOpen] = useState(true);
  const tableRef = useRef(null);

  useEffect(() => {
    execute({ assignedUser: "", overview: OVERVIEW_TAB.QUERY_OVERVIEW });
  }, [execute]);

  // Resolve accent colors from CSS variables once
  const colors = useMemo(() => {
    const result = { total: getCssVar("--color-qry-total") };
    QUERY_CARDS.forEach((c) => {
      result[c.key] = getCssVar(c.colorVar);
    });
    return result;
  }, []);

  // Extract stats from API response
  const stats = useMemo(() => {
    const d = data?.data ?? {};
    return {
      totalQueries: d.totalQueries ?? 0,
      criticalQueryCount: d.criticalQueryCount ?? 0,
      nonCriticalQueryCount: d.nonCriticalQueryCount ?? 0,
    };
  }, [data]);

  const handleCardClick = useCallback((key) => {
    setActiveCardKey(key);
    setIsTableOpen(true);
    requestAnimationFrame(() => {
      tableRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }, []);

  // Prepare data for pie chart
  const pieData = useMemo(() => {
    return QUERY_CARDS.map((c) => ({
      id: c.key,
      label: c.label,
      value: stats[c.key] ?? 0,
      color: colors[c.key],
    })).filter((slice) => slice.value > 0);
  }, [stats, colors]);

  // Find the active card definition for the drill-down panel
  const activeCard = activeCardKey
    ? QUERY_CARDS.find((c) => c.key === activeCardKey)
    : null;

  return (
    <div className="dashboard-page">
      {/* ── Page title ─────────────────────────────────────────────── */}
      <header className="mb-6">
        <h1 className="text-xl font-bold text-text-primary">Query Overview</h1>
      </header>

      {/* ── Error ──────────────────────────────────────────────────── */}
      {error && (
        <section className="mb-6">
          <ErrorBanner message={error} onClose={() => setError(null)} />
        </section>
      )}

      {/* ── Stat Cards ─────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        {/* Total Queries – non-clickable summary card */}
        <DashboardStatCard
          label="Total Queries"
          value={isLoading ? "..." : stats.totalQueries}
          accentColor={colors.total}
        />
        {QUERY_CARDS.map(({ key, label }) => (
          <DashboardStatCard
            key={key}
            label={label}
            value={isLoading ? "..." : stats[key]}
            total={stats.totalQueries}
            accentColor={colors[key]}
            isActive={activeCardKey === key}
            onClick={() => handleCardClick(key)}
          />
        ))}
      </div>

      {/* ── Pie Chart ──────────────────────────────────────────────── */}
      {(stats.totalQueries > 0 || isLoading) && (
        <div className="mb-6">
          <ListContainer>
            <div className="dashboard-chart-title">
              Query Distribution
              {activeCardKey && (
                <span className="ml-2 text-xs font-normal text-text-secondary">
                  — active filter:{" "}
                  {QUERY_CARDS.find((c) => c.key === activeCardKey)?.label}
                </span>
              )}
            </div>
            <DashboardPieChart
              data={pieData}
              isLoading={isLoading}
              onSliceClick={handleCardClick}
            />
          </ListContainer>
        </div>
      )}

      {/* ── Drill-Down Panel ─────────────────────────────────────────── */}
      {activeCard && (
        <DashboardTransactionPanel
          label={activeCard.label}
          apiFn={activeCard.apiFn}
          apiParams={activeCard.apiParams}
          totalCount={stats[activeCard.key]}
          isOpen={isTableOpen}
          onToggle={() => setIsTableOpen((prev) => !prev)}
          panelRef={tableRef}
        />
      )}
    </div>
  );
};

QueryDashboard.displayName = "QueryDashboard";
export default QueryDashboard;
