import { useEffect, useMemo, useRef, useState } from "react";
import { useSelector } from "react-redux";

import { viewDashbardRequestApi } from "../../api/apiConfig";
import ErrorBanner from "../../components/ui/common/ErrorBanner";

import {
  FILE_TRACKING_STATUS,
  getRetrievalStatusesForRole,
} from "../../constants/status";

import { useNavigate } from "react-router-dom";
import { canEditRetrieval } from "../../constants/roles";
import { useApi } from "../../hooks/useApi";
import { getCssVar } from "../../utils/utils";
import DashboardFileTrackingTable from "./components/DashBoardFileTracking.jsx/DashboardFileTrackingTable";

/**
 * DashboardStatCard
 *
 * Displays a single summary metric (label + count + percentage).
 * Clicking it triggers the same slice-click as the pie chart.
 *
 * @param {string}   label        - Human-readable label, e.g. "Pending".
 * @param {number}   value        - Raw count.
 * @param {number}   total        - Grand total (used to derive %).
 * @param {string}   accentColor  - CSS colour for the left border accent.
 * @param {boolean}  isActive     - Whether this card's status is currently selected.
 * @param {Function} onClick      - Called when the card is clicked.
 */
const DashboardStatCard = ({
  label,
  value,
  total,
  accentColor,
  isActive,
  onClick,
}) => {
  const pct = total > 0 ? Math.round((value / total) * 100) : 0;

  return (
    <button
      type="button"
      onClick={onClick}
      className={`dashboard-stat-card text-left w-full transition-shadow duration-150 ${
        isActive ? "ring-2 ring-brand-primary/40 shadow-md" : "hover:shadow-md"
      }`}
      style={{ borderLeft: `4px solid ${accentColor}` }}
    >
      <span className="dashboard-stat-label">{label}</span>
      <span className="dashboard-stat-value">{value}</span>
    </button>
  );
};

const DashboardFileTrackingPage = () => {
  const { execute, data, isLoading, error, setError } = useApi(
    viewDashbardRequestApi,
  );

  // --------------------------------------------------
  // Current logged-in user
  // --------------------------------------------------

  const { roleName, userId, userEmployeeCode } = useSelector(
    (state) => state.user,
  );

  // --------------------------------------------------
  // Table state
  // --------------------------------------------------
  const navigate = useNavigate();

  const [selectedSliceId, setSelectedSliceId] = useState(null);

  const [isTableOpen, setIsTableOpen] = useState(true);

  const tableRef = useRef(null);

  const isDocAdminEdit = canEditRetrieval(roleName);

  useEffect(() => {
    const role = isDocAdminEdit
      ? roleName === "DOC_ADMIN_USER"
        ? "docAdmin"
        : "admin"
      : localStorage.getItem("employeeCode");

    if (!userId || !role || !userEmployeeCode) {
      return;
    }

    execute(userId, role, userEmployeeCode);
  }, [execute, userId, userEmployeeCode]);

  // --------------------------------------------------
  // Get statuses allowed for current role
  // --------------------------------------------------

  const allowedStatuses = useMemo(() => {
    return getRetrievalStatusesForRole(roleName);
  }, [roleName]);

  // --------------------------------------------------
  // Colors
  // --------------------------------------------------

  const colors = useMemo(
    () => ({
      open: getCssVar("--color-file-dashboard-open"),

      approved: getCssVar("--color-file-dashboard-approved"),

      inprogress: getCssVar("--color-file-dashboard-inprogress"),

      partiallyReturned: getCssVar("--color-file-dashboard-partially-returned"),

      fullyReturned: getCssVar("--color-file-dashboard-approved"),

      rejected: getCssVar("--color-file-dashboard-rejected"),

      canceled: getCssVar("--color-file-dashboard-canceled"),

      closed: getCssVar("--color-file-dashboard-closed"),
    }),
    [],
  );

  // --------------------------------------------------
  // API statistics
  // --------------------------------------------------

  const stats = useMemo(() => {
    const d = data?.data;
    return {
      open: d?.openReqCount ?? 0,
      approved: d?.approvedReqCount ?? 0,
      rejected: d?.rejectedReqCount ?? 0,
      cancelled: d?.cancelledReqCount ?? 0,
      inProgress: d?.inprogressReqCount ?? 0,
      partiallyReturned: d?.partiallyReturnedCount ?? 0,
      fullyReturned: d?.fullyReturnedCount ?? 0,
      closed: d?.closedReqCount ?? 0,
    };
  }, [data]);

  // --------------------------------------------------
  // Dashboard statuses
  //
  // These are the statuses returned by dashboard API.
  // Only display them if the current role allows them.
  // --------------------------------------------------

  const dashboardStatusList = useMemo(() => {
    const allowedStatuses = getRetrievalStatusesForRole(roleName);
    const allStatuses = [
      {
        id: FILE_TRACKING_STATUS.open,
        label: "Open",
        value: stats.open,
        color: colors.open,
      },

      {
        id: FILE_TRACKING_STATUS.Approved,
        label: "Approved",
        value: stats.approved,
        color: colors.approved,
      },

      {
        id: FILE_TRACKING_STATUS.Inprogress,
        label: "In Progress",
        value: stats.inProgress,
        color: colors.inprogress,
      },

      {
        id: FILE_TRACKING_STATUS.PartiallyReturned,
        label: "Partially Returned",
        value: stats.partiallyReturned,
        color: colors.partiallyReturned,
      },
      {
        id: FILE_TRACKING_STATUS.FullyReturned,
        label: "Fully Returned",
        value: stats.fullyReturned,
        color: colors.fullyReturned,
      },

      {
        id: FILE_TRACKING_STATUS.Rejected,
        label: "Rejected",
        value: stats.rejected,
        color: colors.rejected,
      },

      {
        id: FILE_TRACKING_STATUS.Canceled,
        label: "Canceled",
        value: stats.cancelled,
        color: colors.canceled,
      },

      {
        id: FILE_TRACKING_STATUS.Closed,
        label: "Closed",
        value: stats.closed,
        color: colors.closed,
      },
    ];
    return allStatuses.filter((status) => allowedStatuses.includes(status.id));
  }, [roleName, stats, colors]);
  // --------------------------------------------------
  // Filter statuses based on role
  // --------------------------------------------------

  const visibleDashboardStatuses = useMemo(() => {
    return dashboardStatusList.filter((status) =>
      allowedStatuses.includes(status.id),
    );
  }, [dashboardStatusList, allowedStatuses]);

  const handleSliceClick = (e) => {
    // const roleBaseRoute = getDashboardRouteForRole(roleName);

    // if (!roleBaseRoute) {
    //   console.error(
    //     "No dashboard route found for role:",
    //     roleName
    //   );
    //   return;
    // }

    const targetUrl = `/doc-admin-reterival-request`;

    navigate(targetUrl, {
      state: {
        stageJob: e.toUpperCase(),
      },
    });
  };

  // --------------------------------------------------
  // Selected status
  // --------------------------------------------------

  const activeStatus = useMemo(() => {
    if (!selectedSliceId) {
      return null;
    }

    // Extra safety check.
    // Don't allow a status outside the user's role.
    if (!allowedStatuses.includes(selectedSliceId)) {
      return null;
    }

    return selectedSliceId;
  }, [selectedSliceId, allowedStatuses]);
  // --------------------------------------------------
  // Render
  // --------------------------------------------------

  return (
    <div className="dashboard-page">
      {/* Page Header */}
      <header className="mb-6">
        <h1 className="text-xl font-bold text-text-primary">Dashboard</h1>

        {/* <p className="text-xs text-text-secondary mt-0.5">
          {isLoading
            ? "Loading"
            : `${stats.total} total application${
                stats.total !== 1
                  ? "s"
                  : ""
              }`}
        </p> */}
      </header>

      {/* Error */}
      {error && (
        <section className="mb-6">
          <ErrorBanner message={error} onClose={() => setError(null)} />
        </section>
      )}

      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        {visibleDashboardStatuses.map(({ id, label, value, color }) => (
          <DashboardStatCard
            key={id}
            label={label}
            value={value}
            total={stats.total}
            accentColor={color}
            isActive={selectedSliceId === id}
            onClick={() => handleSliceClick(label)}
          />
        ))}
      </div>

      {/* Chart */}
      {/* <ListContainer>

        <div className="dashboard-chart-title">
          Application Status

          {selectedSliceId && (
            <span className="ml-2 text-xs font-normal text-text-secondary">
              — click a status to filter
              the table below
            </span>
          )}
        </div> */}

      {/* <DashboardPieChart
          data={pieData}
          isLoading={isLoading}
          onSliceClick={handleSliceClick}
        /> */}

      {/* </ListContainer> */}

      {/* Allocation Table */}
      {activeStatus && (
        <DashboardFileTrackingTable
          status={activeStatus}
          totalCount={selectedStatusCount}
          isOpen={isTableOpen}
          onToggle={() => setIsTableOpen((prev) => !prev)}
          tableRef={tableRef}
        />
      )}
    </div>
  );
};

DashboardFileTrackingPage.displayName = "DashboardFileTrackingPage";

export default DashboardFileTrackingPage;
