import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { getDashboardApi } from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import DashboardStatCard from "../../components/ui/common/DashboardStatCard";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import SelectFieldWithCheckbox from "../../components/ui/common/SelectFieldWithCheckbox";
import { OVERVIEW_TAB } from "../../constants/menuHeaders";
import {
  DENO_STATUS,
  DENO_STATUS_LABELS,
} from "../../constants/stampingConstants";
import { useStates } from "../../hooks/dropdowns/useStates";
import { useApi } from "../../hooks/useApi";
import { getCssVar } from "../../utils/utils";
import DashboardPieChart from "./components/DashboardPieChart";
import DashboardStampingTable from "./components/DashboardStampingTable";

/**
 * PIE_ID_TO_STATUS
 *
 * Maps pie/card id (= DENO_STATUS_LABELS value) → raw DENO_STATUS value.
 * Declared at module level — stable reference, not re-created on every render.
 */
const PIE_ID_TO_STATUS = {
  [DENO_STATUS_LABELS[DENO_STATUS.IN_STOCK]]: DENO_STATUS.IN_STOCK,
  [DENO_STATUS_LABELS[DENO_STATUS.USED]]: DENO_STATUS.USED,
};

/**
 * StampingDashboard
 *
 * Dashboard view for Stamping Users and Admins.
 * Displays overall stamping statistics and a States multi-select filter.
 * Clicking a stat card or pie slice opens a filtered StampStackMaster table below.
 *
 * @param {Function} [onStatesChange] - Optional callback with the selected state values array.
 */
const StampingDashboard = ({ onStatesChange }) => {
  const {
    stateOptions,
    loading: statesLoading,
    error: statesError,
  } = useStates();

  const {
    execute,
    data,
    isLoading: statsLoading,
    error: statsErrorApi,
  } = useApi(getDashboardApi);

  const [selectedStates, setSelectedStates] = useState([]);

  // selectedSliceId is one of the DENO_STATUS_LABELS values ("In-Stock" | "Used")
  const [selectedSliceId, setSelectedSliceId] = useState(null);
  const [isTableOpen, setIsTableOpen] = useState(true);

  const tableRef = useRef(null);

  useEffect(() => {
    const params = {
      assignedUser: "",
      overview: OVERVIEW_TAB.STAMPING_OVERVIEW,
    };
    if (selectedStates?.length > 0) {
      params.states = selectedStates
        .map((s) => s.toUpperCase().replace(/\s/g, ""))
        .join(",");
    }
    execute(params);
  }, [execute, selectedStates]);

  const handleStatesChange = (e) => {
    const values = e.target.value;
    setSelectedStates(values);
    onStatesChange?.(values);
  };

  const totalStampStacks = data?.data?.totalStampStacks ?? 0;
  const availableStampStacks = data?.data?.availableStampStacks ?? 0;
  const usedStampStacks = data?.data?.usedStampStacks ?? 0;

  // Resolve colours once from CSS variables
  const colors = useMemo(
    () => ({
      total: getCssVar("--color-dashboard-total"),
      instock: getCssVar("--color-dashboard-instock"),
      used: getCssVar("--color-dashboard-used"),
    }),
    [],
  );

  const pieChartData = useMemo(
    () => [
      {
        id: DENO_STATUS_LABELS[DENO_STATUS.IN_STOCK],
        label: DENO_STATUS_LABELS[DENO_STATUS.IN_STOCK],
        value: availableStampStacks,
        color: colors.instock,
      },
      {
        id: DENO_STATUS_LABELS[DENO_STATUS.USED],
        label: DENO_STATUS_LABELS[DENO_STATUS.USED],
        value: usedStampStacks,
        color: colors.used,
      },
    ],
    [availableStampStacks, usedStampStacks, colors],
  );

  /**
   * handleSliceClick
   *
   * Called when a pie slice or stat card is clicked.
   * Opens the table (if collapsed) and scrolls to it.
   *
   * @param {string} sliceId - Matches a DENO_STATUS_LABELS value.
   */
  const handleSliceClick = useCallback((sliceId) => {
    setSelectedSliceId(sliceId);
    setIsTableOpen(true);
    requestAnimationFrame(() => {
      tableRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }, []);

  // Resolved raw API status for the selected slice ("IN_STOCK" | "USED" | null)
  const activeStatus = selectedSliceId
    ? PIE_ID_TO_STATUS[selectedSliceId]
    : null;

  // Count passed to the table so it can skip the fetch when 0
  const activeCount =
    pieChartData.find((d) => d.id === selectedSliceId)?.value ?? 0;

  return (
    <div className="p-6">
      {/* ── Page title ─────────────────────────────────────────────── */}
      <header className="mb-6">
        <h1 className="text-xl font-bold text-text-primary">
          Stamping Overview
        </h1>
      </header>

      {statsErrorApi && (
        <div className="mb-6">
          <ErrorBanner message={statsErrorApi} />
        </div>
      )}

      {/* ── Filters ─────────────────────────────────────────────────── */}
      <div className="mb-6 max-w-sm">
        {statesError && (
          <div className="mb-4">
            <ErrorBanner message={statesError} />
          </div>
        )}
        <SelectFieldWithCheckbox
          label="States"
          name="states"
          value={selectedStates}
          onChange={handleStatesChange}
          options={stateOptions}
          placeholder={statesLoading ? "Loading states…" : "Select states"}
          countText="states"
          searchPlaceholder="Search state"
          disabled={statesLoading}
        />
      </div>

      {/* ── Stats Cards ─────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {/* Total Stamp Stacks – non-clickable summary card */}
        <DashboardStatCard
          label="Total Stamp Stacks"
          value={statsLoading ? "..." : totalStampStacks}
          accentColor={colors.total}
        />
        <DashboardStatCard
          label={DENO_STATUS_LABELS[DENO_STATUS.IN_STOCK]}
          value={statsLoading ? "..." : availableStampStacks}
          accentColor={colors.instock}
          isActive={
            selectedSliceId === DENO_STATUS_LABELS[DENO_STATUS.IN_STOCK]
          }
          onClick={() =>
            handleSliceClick(DENO_STATUS_LABELS[DENO_STATUS.IN_STOCK])
          }
        />
        <DashboardStatCard
          label={DENO_STATUS_LABELS[DENO_STATUS.USED]}
          value={statsLoading ? "..." : usedStampStacks}
          accentColor={colors.used}
          isActive={selectedSliceId === DENO_STATUS_LABELS[DENO_STATUS.USED]}
          onClick={() => handleSliceClick(DENO_STATUS_LABELS[DENO_STATUS.USED])}
        />
      </div>

      {/* ── Pie Chart ───────────────────────────────────────────────── */}
      <ListContainer>
        <div className="dashboard-chart-title">
          Stamping Stack Status
          {selectedSliceId && (
            <span className="ml-2 text-xs font-normal text-text-secondary">
              — click a slice to filter the table below
            </span>
          )}
        </div>
        <DashboardPieChart
          data={pieChartData}
          isLoading={statsLoading}
          onSliceClick={handleSliceClick}
        />
      </ListContainer>

      {/* ── Stamp Stack Table (shown after a slice/card click) ───────── */}
      {activeStatus && (
        <DashboardStampingTable
          status={activeStatus}
          selectedStates={selectedStates}
          totalCount={activeCount}
          isOpen={isTableOpen}
          onToggle={() => setIsTableOpen((prev) => !prev)}
          tableRef={tableRef}
        />
      )}
    </div>
  );
};

StampingDashboard.displayName = "StampingDashboard";
export default StampingDashboard;
