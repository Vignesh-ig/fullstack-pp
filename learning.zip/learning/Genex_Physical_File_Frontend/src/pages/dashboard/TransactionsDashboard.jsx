import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  getDashboardApi,
  getRackAssignedApi,
  getTransactionApi,
} from "../../api/apiConfig";
import { AddIcon, MinimizeIcon } from "../../components/icons/icons";
import ListContainer from "../../components/layout/ListContainer";
import DashboardStatCard from "../../components/ui/common/DashboardStatCard";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import { OVERVIEW_TAB } from "../../constants/menuHeaders";
import { useApi } from "../../hooks/useApi";
import { getCssVar } from "../../utils/utils";
import DashboardPieChart from "./components/DashboardPieChart";
import DashboardTransactionPanel from "./components/DashboardTransactionPanel";

/**
 * CARDS
 *
 * Defines each transaction stat card. Declared at module level — stable reference.
 * Each entry contains:
 *   - key       : matches the field name in the dashboard API response.
 *   - label     : displayed on the stat card.
 *   - colorVar  : CSS variable name resolved via getCssVar.
 *   - apiFn     : the API function to call for the drill-down table.
 *   - apiParams : params merged into every fetch call for this card.
 */
const CARDS = [
  {
    key: "rackAssignedTransactions",
    label: "Rack Allocation",
    colorVar: "--color-txn-rack-alloc",
    apiFn: getRackAssignedApi,
    apiParams: { userAssigned: false },
  },
  {
    key: "returnToRackTransactions",
    label: "Return To Rack",
    colorVar: "--color-txn-return-rack",
    apiFn: getRackAssignedApi,
    apiParams: {
      assignedStatus: "PENDING",
      userAssigned: true,
    },
  },
  {
    key: "healthCheckTransactions",
    label: "Health Check",
    colorVar: "--color-txn-health-check",
    apiFn: getTransactionApi,
    apiParams: { stages: "HEALTH_CHECK" },
  },
  {
    key: "queryResolvedTransactions",
    label: "Query Case - Health Check",
    colorVar: "--color-txn-query-resolved",
    apiFn: getTransactionApi,
    apiParams: { stages: "QUERY_RESOLVED" },
  },
  {
    key: "queryTransactions",
    label: "Query",
    colorVar: "--color-txn-query",
    apiFn: getTransactionApi,
    apiParams: { stages: "QUERY" },
  },
  {
    key: "outwardTransactions",
    label: "Outward",
    colorVar: "--color-txn-outward",
    apiFn: getTransactionApi,
    apiParams: { stages: "OUTWARD" },
  },
  {
    key: "stampingTransactions",
    label: "Stamping",
    colorVar: "--color-txn-stamping",
    apiFn: getTransactionApi,
    apiParams: { stages: "STAMPING" },
  },
  {
    key: "storageTransactions",
    label: "Storage",
    colorVar: "--color-txn-storage",
    apiFn: getTransactionApi,
    apiParams: { stages: "STORAGE" },
  },
];

/**
 * TransactionsDashboard
 *
 * Displays transaction overview metrics as stat cards.
 * Clicking a card opens a paginated drill-down table filtered to that transaction type.
 * Uses SUPER_ADMIN and ADMIN roles only (enforced in DashboardMaster).
 */
const TransactionsDashboard = () => {
  const { execute, data, isLoading, error, setError } = useApi(getDashboardApi);

  const [activeCardKey, setActiveCardKey] = useState(null);
  const [isTableOpen, setIsTableOpen] = useState(true);
  const [isCardsExpanded, setIsCardsExpanded] = useState(false);
  const tableRef = useRef(null);

  useEffect(() => {
    execute({ overview: OVERVIEW_TAB.TRANSACTION_OVERVIEW });
  }, [execute]);

  // Resolve accent colors from CSS variables once — stable across renders
  const colors = useMemo(() => {
    const result = { total: getCssVar("--color-txn-total") };
    CARDS.forEach((c) => {
      result[c.key] = getCssVar(c.colorVar);
    });
    return result;
  }, []);

  // Extract stats from API response
  const stats = useMemo(() => {
    const d = data?.data ?? {};
    return {
      totalTransactions: d.totalTransactions ?? 0,
      rackAssignedTransactions: d.rackAssignedTransactions ?? 0,
      returnToRackTransactions: d.returnToRackTransactions ?? 0,
      healthCheckTransactions: d.healthCheckTransactions ?? 0,
      queryResolvedTransactions: d.queryResolvedTransactions ?? 0,
      queryTransactions: d.queryTransactions ?? 0,
      outwardTransactions: d.outwardTransactions ?? 0,
      stampingTransactions: d.stampingTransactions ?? 0,
      storageTransactions: d.storageTransactions ?? 0,
    };
  }, [data]);

  const handleCardClick = useCallback((identifier) => {
    const card = CARDS.find(
      (c) => c.key === identifier || c.label === identifier,
    );
    if (!card) return;

    setActiveCardKey(card.key);
    setIsTableOpen(true);
    requestAnimationFrame(() => {
      tableRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }, []);

  // Prepare data for pie chart
  const pieData = useMemo(() => {
    return CARDS.map((c) => ({
      id: c.label,
      label: c.label,
      value: stats[c.key] ?? 0,
      color: colors[c.key],
    })).filter((slice) => slice.value > 0);
  }, [stats, colors]);

  // Find the active card definition for the drill-down panel
  const activeCard = activeCardKey
    ? CARDS.find((c) => c.key === activeCardKey)
    : null;

  return (
    <div className="dashboard-page">
      {/* ── Page title ─────────────────────────────────────────────── */}
      <header className="mb-6">
        <h1 className="text-xl font-bold text-text-primary">
          Transactions Overview
        </h1>
      </header>

      {/* ── Error ──────────────────────────────────────────────────── */}
      {error && (
        <section className="mb-6">
          <ErrorBanner message={error} onClose={() => setError(null)} />
        </section>
      )}

      {/* ── Toggle & Total Card ────────────────────────────────────── */}
      <div className="flex justify-end mb-2">
        <button
          type="button"
          onClick={() => setIsCardsExpanded((prev) => !prev)}
          className="dashboard-allocation-toggle-btn"
        >
          <span className="flex items-center gap-1 text-xs">
            {isCardsExpanded ? (
              <>
                <MinimizeIcon className="h-4 w-4" />
                Minimize
              </>
            ) : (
              <>
                <AddIcon className="h-4 w-4" />
                Expand
              </>
            )}
          </span>
        </button>
      </div>
      <div className="mb-4">
        <DashboardStatCard
          label="Total Transactions"
          value={isLoading ? "..." : stats.totalTransactions}
          accentColor={colors.total}
        />
      </div>

      {/* ── Stat Cards Grid ─────────────────────────────────────────── */}
      <div
        className={`expandable-row-wrapper mb-6 ${isCardsExpanded ? "expanded" : ""}`}
      >
        <div className="expandable-row-inner min-h-0">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 pt-2">
            {CARDS.map(({ key, label }) => (
              <DashboardStatCard
                key={key}
                label={label}
                value={isLoading ? "..." : stats[key]}
                total={stats.totalTransactions}
                accentColor={colors[key]}
                isActive={activeCardKey === key}
                onClick={() => handleCardClick(key)}
              />
            ))}
          </div>
        </div>
      </div>

      {/* ── Pie Chart ──────────────────────────────────────────────── */}
      {(stats.totalTransactions > 0 || isLoading) && (
        <div className="mb-6">
          <ListContainer>
            <div className="dashboard-chart-title">
              Transactions Distribution
              {activeCardKey && (
                <span className="ml-2 text-xs font-normal text-text-secondary">
                  — active filter:{" "}
                  {CARDS.find((c) => c.key === activeCardKey)?.label}
                </span>
              )}
            </div>
            <DashboardPieChart
              data={pieData}
              isLoading={isLoading}
              onSliceClick={handleCardClick}
            />
          </ListContainer>
        </div>
      )}

      {/* ── Drill-Down Panel ─────────────────────────────────────────── */}
      {activeCard && (
        <DashboardTransactionPanel
          label={activeCard.label}
          apiFn={activeCard.apiFn}
          apiParams={activeCard.apiParams}
          totalCount={stats[activeCard.key]}
          isOpen={isTableOpen}
          onToggle={() => setIsTableOpen((prev) => !prev)}
          panelRef={tableRef}
        />
      )}
    </div>
  );
};

TransactionsDashboard.displayName = "TransactionsDashboard";
export default TransactionsDashboard;
