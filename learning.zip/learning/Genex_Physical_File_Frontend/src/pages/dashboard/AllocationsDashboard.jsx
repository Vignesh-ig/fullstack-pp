import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { getDashboardApi } from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import DashboardStatCard from "../../components/ui/common/DashboardStatCard";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import { OVERVIEW_TAB } from "../../constants/menuHeaders";
import { ROLES } from "../../constants/roles";
import { useApi } from "../../hooks/useApi";
import { getCssVar } from "../../utils/utils";
import DashboardAllocationTable, {
  SLICE_TO_STATUS,
} from "./components/DashboardAllocationTable";
import DashboardPieChart from "./components/DashboardPieChart";

/**
 * Maps a stat-card label to its corresponding pie-slice id.
 * Declared at module level — stable reference, not re-created on every render.
 */
const LABEL_TO_SLICE = {
  Pending: "Pending",
  "In Process": "In Process",
  Completed: "Completed",
};

/**
 * AllocationsDashboard
 *
 * Displays overall application metrics as stat cards and a donut chart.
 * Clicking a pie slice or stat card:
 *   1. Fetches rack-assigned records filtered by that status.
 *   2. Automatically opens and scrolls to the allocation table.
 */
const AllocationsDashboard = () => {
  const { execute, data, isLoading, error, setError } = useApi(getDashboardApi);
  const { roleName, userId } = useSelector((state) => state.user);

  // CPU users scope the dashboard to their own records only
  const isCpu = roleName === ROLES.CPU;

  // selectedSliceId mirrors the pie-slice `id` string (e.g. "Pending", "In Process", "Completed")
  const [selectedSliceId, setSelectedSliceId] = useState(null);
  // isTableOpen controls the collapse toggle independently of selection
  const [isTableOpen, setIsTableOpen] = useState(true);

  const tableRef = useRef(null);

  useEffect(() => {
    // CPU role scopes the call by assignedUser; Admin passes ""
    execute({
      assignedUser: isCpu && userId ? userId : "",
      overview: OVERVIEW_TAB.ALLOCATION_OVERVIEW,
    });
  }, [execute, isCpu, userId]);

  // Resolve colours once from CSS variables
  const colors = useMemo(
    () => ({
      total: getCssVar("--color-dashboard-total"),
      pending: getCssVar("--color-dashboard-pending"),
      inProcess: getCssVar("--color-dashboard-inprocess"),
      completed: getCssVar("--color-dashboard-completed"),
      
    }),
    [],
  );

  // Extract API data
  const stats = useMemo(() => {
    const d = data?.data;
    return {
      total: d?.totalApps ?? 0,
      pending: d?.pendingApps ?? 0,
      completed: d?.completedApps ?? 0,
      inProcess: d?.inProcessApps ?? 0,
    };
  }, [data]);

  // Transform for Nivo pie chart
  const pieData = useMemo(
    () => [
      {
        id: "Pending",
        label: "Pending",
        value: stats.pending,
        color: colors.pending,
      },
      {
        id: "In Process",
        label: "In Process",
        value: stats.inProcess,
        color: colors.inProcess,
      },
      {
        id: "Completed",
        label: "Completed",
        value: stats.completed,
        color: colors.completed,
      },
     
    ],
    [stats, colors],
  );

  /**
   * handleSliceClick
   *
   * Called when a pie slice or stat card is clicked.
   * Opens the table (if collapsed) and scrolls to it.
   *
   * @param {string} sliceId - The datum id matching pieData entries.
   */
  const handleSliceClick = useCallback((sliceId) => {
    setSelectedSliceId(sliceId);
    setIsTableOpen(true);
    requestAnimationFrame(() => {
      tableRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }, []);

  // The mapped API status for the selected slice
  const activeStatus = selectedSliceId
    ? SLICE_TO_STATUS[selectedSliceId]
    : null;

  return (
    <div className="dashboard-page">
      {/* ── Page title ─────────────────────────────────────────────── */}
      <header className="mb-6">
        <h1 className="text-xl font-bold text-text-primary">
          Allocations Overview
        </h1>
      </header>

      {/* ── Error ──────────────────────────────────────────────────── */}
      {error && (
        <section className="mb-6">
          <ErrorBanner message={error} onClose={() => setError(null)} />
        </section>
      )}

      {/* ── Stat cards ─────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* Total Applications – non-clickable summary card */}
        <DashboardStatCard
          label="Total Applications"
          value={isLoading ? "..." : stats.total}
          accentColor={colors.total}
        />
        {[
          { label: "Pending", 
            value: stats.pending,
            color: colors.pending },
          {
            label: "In Process",
            value: stats.inProcess,
            color: colors.inProcess,
          },
          {
            label: "Completed",
            value: stats.completed,
            color: colors.completed,
          },


        ].map(({ label, value, color }) => (
          <DashboardStatCard
            key={label}
            label={label}
            value={isLoading ? "..." : value}
            total={stats.total}
            accentColor={color}
            isActive={selectedSliceId === LABEL_TO_SLICE[label]}
            onClick={() => handleSliceClick(LABEL_TO_SLICE[label])}
          />
        ))}
      </div>

      {/* ── Chart ──────────────────────────────────────────────────── */}
      <ListContainer>
        <div className="dashboard-chart-title">
          Application Status
          {selectedSliceId && (
            <span className="ml-2 text-xs font-normal text-text-secondary">
              — click a slice to filter the table below
            </span>
          )}
        </div>
        <DashboardPieChart
          data={pieData}
          isLoading={isLoading}
          onSliceClick={handleSliceClick}
        />
      </ListContainer>

      {/* ── Allocation Table (shown after a slice/card click) ───────── */}
      {activeStatus && (
        <DashboardAllocationTable
          status={activeStatus}
          totalCount={pieData.find((d) => d.id === selectedSliceId)?.value ?? 0}
          isOpen={isTableOpen}
          onToggle={() => setIsTableOpen((prev) => !prev)}
          tableRef={tableRef}
        />
      )}
    </div>
  );
};

AllocationsDashboard.displayName = "AllocationsDashboard";
export default AllocationsDashboard;
