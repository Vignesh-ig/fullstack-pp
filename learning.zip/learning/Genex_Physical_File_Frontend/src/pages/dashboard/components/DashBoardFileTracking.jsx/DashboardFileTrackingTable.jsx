import { useCallback } from "react";
import { useSelector } from "react-redux";
import { getRackAssignedApi } from "../../../../api";
import { MinimizeIcon } from "../../../../components/icons/icons";
import ListContainer from "../../../../components/layout/ListContainer";
import { ROLES } from "../../../../constants/roles";
import usePaginatedFetch from "../../../../hooks/usePaginatedFetch";


/** Map API status values → human labels for the section header */

/**
 * DashboardAllocationTable
 *
 * Displays a paginated rack-assigned table filtered to a specific `status`.
 * Driven by a pie-slice click from the parent Dashboard page.
 * Provides a collapse/expand toggle button in its header.
 *
 * @param {string} status       - The `assignedStatus` to filter by (e.g. "PENDING").
 * @param {number} totalCount   - The count of records for this status from the dashboard API.
 * @param {boolean} isOpen       - Whether the table panel is expanded.
 * @param {Function} onToggle     - Called when the minimize/maximize button is clicked.
 * @param {object} tableRef     - Forwarded ref attached to the outer wrapper div (for scroll).
 */
const DashboardFileTrackingTable = ({
  status,
  totalCount,
  isOpen,
  onToggle,
  tableRef,
}) => {
  const { userId: currentUserId, roleName } = useSelector(
    (state) => state.user,
  );

  const label = STATUS_LABEL[status] ?? status;

  return (
    <div ref={tableRef} className="dashboard-allocation-table-wrapper">
      <ListContainer>
        {/* ── Header with minimize toggle ─────────────────────────── */}
        <div className="dashboard-allocation-table-header">
          <div>
            <p className="text-xl font-bold text-text-primary">
              {label}
            </p>
            {!loading && (
              <p className="text-xs text-text-secondary mt-0.5">
                {pagination.totalItems} record
                {pagination.totalItems !== 1 ? "s" : ""}
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={onToggle}
            aria-label={isOpen ? "Collapse table" : "Expand table"}
            className="dashboard-allocation-toggle-btn"
          >
            {isOpen ? (
              <span className="flex items-center gap-1 text-xs">
                <MinimizeIcon className="h-4 w-4" />
                Minimize
              </span>
            ) : (
              <span className="flex items-center gap-1 text-xs">
                <AddIcon className="h-4 w-4" />
                Expand
              </span>
            )}
          </button>
        </div>
      </ListContainer>
    </div>
  );
};

DashboardFileTrackingTable.displayName = "DashboardFileTrackingTable";
export default DashboardFileTrackingTable;
