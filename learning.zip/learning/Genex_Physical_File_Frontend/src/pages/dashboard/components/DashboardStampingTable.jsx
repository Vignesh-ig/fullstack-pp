import { useCallback } from "react";
import { getStampStackMasterApi } from "../../../api/apiConfig";
import DashboardTablePanel from "../../../components/ui/common/DashboardTablePanel";
import Pagination from "../../../components/ui/common/Pagination";
import { DENO_STATUS_LABELS } from "../../../constants/stampingConstants";
import usePaginatedFetch from "../../../hooks/usePaginatedFetch";
import StampStackTable from "../../stamp-stack-master/components/StampStackTable";

/**
 * DashboardStampingTable
 *
 * Displays a paginated StampStackTable filtered to a specific `status` and
 * an optional list of `selectedStates`. Driven by a stat-card or pie-slice click
 * from StampingDashboard. Uses DashboardTablePanel for the collapse/expand wrapper.
 *
 * @param {string}   status         - DENO_STATUS value to filter by, e.g. "IN_STOCK".
 * @param {string[]} selectedStates - Array of state display strings (e.g. "Andhra Pradesh").
 * @param {number}   totalCount     - Pre-fetched count; skips the API call when 0.
 * @param {boolean}  isOpen         - Whether the panel is expanded.
 * @param {Function} onToggle       - Called when the minimize/maximize button is clicked.
 * @param {object}   tableRef       - Ref attached to the outer wrapper (for scroll-into-view).
 */
const DashboardStampingTable = ({
  status,
  selectedStates,
  totalCount,
  isOpen,
  onToggle,
  tableRef,
}) => {
  const fetchFn = useCallback(
    async (params) => {
      if (totalCount === 0)
        return { data: [], totalPages: 1, currentPage: 1, totalItems: 0 };

      const { _dummySearchParam, ...restParams } = params; // NOSONAR

      return getStampStackMasterApi({
        ...restParams,
        status,
        ...(selectedStates?.length > 0
          ? {
              state: selectedStates
                .map((s) => s.toUpperCase().replace(/\s/g, ""))
                .join(","),
            }
          : {}),
      });
    },
    [status, selectedStates, totalCount],
  );

  const {
    data: stamps,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
  } = usePaginatedFetch(fetchFn, 10, "_dummySearchParam");

  // Use DENO_STATUS_LABELS directly — status keys match the label map
  const label = DENO_STATUS_LABELS[status] ?? status;

  return (
    <DashboardTablePanel
      label={label}
      totalItems={pagination.totalItems}
      loading={loading}
      error={error}
      onDismissError={() => setError(null)}
      isOpen={isOpen}
      onToggle={onToggle}
      panelRef={tableRef}
    >
      <StampStackTable
        data={stamps}
        loading={loading}
        error={error}
        page={page}
        pageSize={pageSize}
      />
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />
    </DashboardTablePanel>
  );
};

DashboardStampingTable.displayName = "DashboardStampingTable";
export default DashboardStampingTable;
