import { useCallback } from "react";
import DashboardTablePanel from "../../../components/ui/common/DashboardTablePanel";
import Pagination from "../../../components/ui/common/Pagination";
import usePaginatedFetch from "../../../hooks/usePaginatedFetch";
import DashboardTransactionRowTable from "./DashboardTransactionRowTable";

/**
 * DashboardTransactionPanel
 *
 * Reusable collapsible drill-down panel used by both TransactionsDashboard
 * and QueryDashboard. Wraps DashboardTablePanel (existing UI shell) with
 * a paginated DashboardTransactionRowTable and Pagination controls.
 *
 * @param {string}   label      - Section heading (e.g. "Health Check").
 * @param {Function} apiFn     - The API function to call for records (e.g. getTransactionApi).
 * @param {object}   apiParams - Static params merged into every fetch (e.g. { stages: "QUERY" }).
 * @param {number}   totalCount - Pre-fetched count from the dashboard stats API; skips fetch when 0.
 * @param {boolean}  isOpen    - Whether the panel is expanded.
 * @param {Function} onToggle  - Called when the minimize/maximize button is clicked.
 * @param {object}   panelRef  - Ref attached to the outer wrapper (for scroll-into-view).
 */
const DashboardTransactionPanel = ({
  label,
  apiFn,
  apiParams,
  totalCount,
  isOpen,
  onToggle,
  panelRef,
}) => {
  const fetchFn = useCallback(
    async (params) => {
      if (totalCount === 0)
        return { data: [], totalPages: 1, currentPage: 1, totalItems: 0 };

      const { _dummySearchParam, ...restParams } = params; // NOSONAR

      return apiFn({ ...restParams, ...apiParams });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [apiFn, totalCount, JSON.stringify(apiParams)],
  );

  const {
    data: records,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
  } = usePaginatedFetch(fetchFn, 10, "_dummySearchParam");

  return (
    <DashboardTablePanel
      label={label}
      totalItems={pagination.totalItems}
      loading={loading}
      error={error}
      onDismissError={() => setError(null)}
      isOpen={isOpen}
      onToggle={onToggle}
      panelRef={panelRef}
    >
      <DashboardTransactionRowTable
        records={records}
        loading={loading}
        error={error}
        page={page}
        pageSize={pageSize}
      />
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />
    </DashboardTablePanel>
  );
};

DashboardTransactionPanel.displayName = "DashboardTransactionPanel";
export default DashboardTransactionPanel;
