import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { DASHBOARD_TRANSACTION_TABLE_COLUMNS } from "../../../constants/tableHeaders";

/**
 * DashboardTransactionRowTable
 *
 * Shared read-only table used by both TransactionsDashboard and QueryDashboard
 * drill-down panels. Renders 6 columns: App No, Agreement No, Barcode,
 * Customer Name, File Type, Ageing No.
 * Ageing No is rendered in red+bold when greater than 15.
 *
 * @param {object[]} records  - Array of transaction or rackAssigned data objects.
 * @param {boolean}  loading  - Whether data is being fetched.
 * @param {string}   [error]  - Error message if fetch failed.
 * @param {number}   page     - Current page number (for serial number offset).
 * @param {number}   pageSize - Current page size (for serial number offset).
 */
const DashboardTransactionRowTable = ({
  records = [],
  loading,
  error,
  page,
  pageSize,
}) => {
  const colCount = DASHBOARD_TRANSACTION_TABLE_COLUMNS.length;

  return (
    <Table
      headers={DASHBOARD_TRANSACTION_TABLE_COLUMNS}
      headerColorClass="bg-table-header-bg"
    >
      {loading ? (
        Array.from({ length: 5 }).map((_, i) => (
          <TableSkeletonRow key={i} columnsCount={colCount} />
        ))
      ) : records.length === 0 && !error ? (
        <tr>
          <td colSpan={colCount} className="h-full">
            <EmptyState
              title="No records found"
              description="No records available for this selection."
            />
          </td>
        </tr>
      ) : (
        records.map((record, index) => {
          const ageing = record.ageingNo ?? record.ageingNo ?? null;
          const isAgeingHigh = typeof ageing === "number" && ageing > 15;

          return (
            <tr
              key={record.transactionId ?? record.rackAssignedId ?? index}
              className="hover:bg-slate-200/80 transition-colors"
            >
              <td className="table-td-middle">
                {(page - 1) * pageSize + index + 1}
              </td>
              <td className="table-td-middle">{record.appNo || "—"}</td>
              <td className="table-td-middle">{record.aggNo || "—"}</td>
              <td className="table-td-middle">{record.barcode || "—"}</td>
              <td className="table-td-middle">{record.customerName || "—"}</td>
              <td className="table-td-middle">{record.fileType || "—"}</td>
              <td className="px-6 py-2 text-center">
                <span
                  className={
                    isAgeingHigh
                      ? "font-bold text-red-600"
                      : "text-text-primary"
                  }
                >
                  {ageing ?? "—"}
                </span>
              </td>
            </tr>
          );
        })
      )}
    </Table>
  );
};

DashboardTransactionRowTable.displayName = "DashboardTransactionRowTable";
export default DashboardTransactionRowTable;
