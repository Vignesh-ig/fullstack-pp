import FloatingMenu from "../../../components/ui/common/FloatingMenu";

/**
 * DashboardTabs
 *
 * Renders an animated sliding pill tab switcher for the Dashboard, centered on the page.
 * Only rendered when more than one tab is visible for the current user.
 *
 * @param {Array<{id: string, label: string, icon: React.ComponentType}>} tabs - Visible tab definitions.
 * @param {string} activeTab - The currently active tab id.
 * @param {Function} onTabChange - Called with the tab id when a tab is clicked.
 */
const DashboardTabs = ({ tabs, activeTab, onTabChange }) => {
  if (!tabs || tabs.length <= 1) return null;

  return (
    <div className="flex justify-center px-6 pt-4 pb-2">
      <FloatingMenu
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={onTabChange}
      />
    </div>
  );
};

DashboardTabs.displayName = "DashboardTabs";
export default DashboardTabs;
