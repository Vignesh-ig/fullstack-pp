import { useCallback } from "react";
import { useSelector } from "react-redux";
import { getRackAssignedApi } from "../../../api/apiConfig";
import DashboardTablePanel from "../../../components/ui/common/DashboardTablePanel";
import Pagination from "../../../components/ui/common/Pagination";
import { ROLES } from "../../../constants/roles";
import { TASK_STATUS } from "../../../constants/status";
import usePaginatedFetch from "../../../hooks/usePaginatedFetch";
import UserAllocationTable from "../../user-allocation/components/UserAllocationTable";

/** Map pie-slice ids → API assignedStatus values */
const SLICE_TO_STATUS = {
  Pending: TASK_STATUS.PENDING,
  "In Process": TASK_STATUS.IN_PROCESS,
  Completed: TASK_STATUS.COMPLETED,
  
};
 

/** Map API status values → human labels for the section header */
const STATUS_LABEL = {
  [TASK_STATUS.PENDING]: "Pending",
  [TASK_STATUS.IN_PROCESS]: "In Process",
  [TASK_STATUS.COMPLETED]: "Completed",
 
}

/**
 * DashboardAllocationTable
 *
 * Displays a paginated rack-assigned table filtered to a specific `status`.
 * Driven by a pie-slice click from the parent Dashboard page.
 * Provides a collapse/expand toggle button in its header via DashboardTablePanel.
 *
 * @param {string}   status     - The `assignedStatus` to filter by (e.g. "PENDING").
 * @param {number}   totalCount - The count of records for this status from the dashboard API.
 * @param {boolean}  isOpen     - Whether the table panel is expanded.
 * @param {Function} onToggle   - Called when the minimize/maximize button is clicked.
 * @param {object}   tableRef   - Forwarded ref attached to the outer wrapper div (for scroll).
 */
const DashboardAllocationTable = ({
  status,
  totalCount,
  isOpen,
  onToggle,
  tableRef,
}) => {
  const { userId: currentUserId, roleName } = useSelector(
    (state) => state.user,
  );

  // CPU users see only their own records; Admin and other roles see all records
  const isCpu = roleName === ROLES.CPU;

  const fetchFn = useCallback(
    async (params) => {
      // Skip the API call entirely when the dashboard count is already 0
      if (totalCount === 0 || (isCpu && !currentUserId))
        return { data: [], totalPages: 1, currentPage: 1, totalItems: 0 };

      const { _dummySearchParam, ...restParams } = params; // NOSONAR

      const userFilter =
        isCpu && currentUserId ? { assignedUser: currentUserId } : {};

      return getRackAssignedApi({
        ...restParams,
        ...userFilter,
        userAssigned: true,
        assignedStatus: status,
      });
    },
    [currentUserId, isCpu, status, totalCount],
  );

  const {
    data: records,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
  } = usePaginatedFetch(fetchFn, 10, "_dummySearchParam");

  return (
    <DashboardTablePanel
      label={STATUS_LABEL[status] ?? status}
      totalItems={pagination.totalItems}
      loading={loading}
      error={error}
      onDismissError={() => setError(null)}
      isOpen={isOpen}
      onToggle={onToggle}
      panelRef={tableRef}
    >
      <UserAllocationTable
        records={records}
        loading={loading}
        error={error}
        page={page}
        pageSize={pageSize}
        /* No edit/delete actions on the dashboard view */
        onEditClick={undefined}
        onDeleteClick={undefined}
        isDeleting={false}
      />
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />
    </DashboardTablePanel>
  );
};

DashboardAllocationTable.displayName = "DashboardAllocationTable";
export { SLICE_TO_STATUS };
export default DashboardAllocationTable;
