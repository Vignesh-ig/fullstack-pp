import { ResponsivePie } from "@nivo/pie";
import { memo } from "react";

/** Gray placeholder shown when there is no data */
const EMPTY_DATA = [
  { id: "No Data", label: "No Data", value: 1, color: "#e2e8f0" },
];

/**
 * DashboardPieChart
 *
 * Reusable Nivo donut chart for dashboard metrics.
 * Renders a gray placeholder chart when all values are 0 or no data exists.
 * Clicking a slice calls `onSliceClick` with the slice's `id`.
 *
 * @param {Array} data         - Nivo-formatted data: [{ id, label, value, color }].
 * @param {boolean} isLoading    - Shows a spinner overlay when true.
 * @param {Function} onSliceClick - Called with the datum id when a slice is clicked.
 */
const DashboardPieChart = ({ data, isLoading, onSliceClick }) => {
  const hasData = data && data.length > 0 && data.some((d) => d.value > 0);
  const chartData = hasData ? data : EMPTY_DATA;

  return (
    <div className="dashboard-chart-wrapper relative">
      {/* Loading skeleton overlay */}
      {isLoading && (
        <div className="absolute inset-0 z-10 flex items-center justify-center rounded-2xl bg-white/70 backdrop-blur-sm">
          <div className="flex flex-col items-center gap-2">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-border-main border-t-brand-primary" />
            <span className="text-xs text-text-secondary">Loading</span>
          </div>
        </div>
      )}

      <ResponsivePie
        data={chartData}
        margin={{ top: 40, right: 80, bottom: 80, left: 80 }}
        innerRadius={0.5}
        padAngle={0.6}
        cornerRadius={2}
        activeOuterRadiusOffset={8}
        colors={{ datum: "data.color" }}
        arcLinkLabelsSkipAngle={10}
        arcLinkLabelsTextColor="#333333"
        arcLinkLabelsThickness={2}
        arcLinkLabelsColor={{ from: "color" }}
        arcLabelsSkipAngle={10}
        arcLabelsTextColor={{ from: "color", modifiers: [["darker", 2]] }}
        enableArcLinkLabels={hasData}
        enableArcLabels={hasData}
        /* Make slices clickable – only when real data exists */
        onClick={
          hasData && onSliceClick
            ? (datum) => onSliceClick(datum.id)
            : undefined
        }
        /* Disable all interactivity for the gray placeholder (no tooltip "No Data: 1") */
        isInteractive={hasData}
        /* Hide legend for the placeholder – only show it for real data */
        legends={
          hasData
            ? [
                {
                  anchor: "bottom",
                  direction: "row",
                  translateY: 56,
                  itemWidth: 100,
                  itemHeight: 18,
                  symbolShape: "circle",
                  itemTextColor: "#666",
                  effects: [{ on: "hover", style: { itemTextColor: "#000" } }],
                },
              ]
            : []
        }
      />

      {/* "No data" centre label for the gray placeholder */}
      {!hasData && !isLoading && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <span className="text-sm text-text-secondary">No data</span>
        </div>
      )}
    </div>
  );
};

export default memo(DashboardPieChart);
