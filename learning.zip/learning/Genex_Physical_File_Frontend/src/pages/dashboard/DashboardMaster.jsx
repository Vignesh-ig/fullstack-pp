import { useState } from "react";
import { useSelector } from "react-redux";
import { DASHBOARD_TAB, DASHBOARD_TABS } from "../../constants/menuHeaders";
import { ROLES } from "../../constants/roles";
import AllocationsDashboard from "./AllocationsDashboard";
import DashboardTabs from "./components/DashboardTabs";
import DashboardFileTrackingPage from "./DashboardFileTrackingPage";
import QueryDashboard from "./QueryDashboard";
import StampingDashboard from "./StampingDashboard";
import TransactionsDashboard from "./TransactionsDashboard";

/**
 * DashboardMaster
 *
 * Role-aware entry point for the dashboard section.
 * Computes which tabs are visible for the current user's role,
 * then renders the appropriate tab bar and dashboard panel.
 *
 * Tab visibility rules:
 *   - Common roles (sees both): SUPER_ADMIN_USER, ADMIN_USER
 *   - "Allocations Dashboard" only: CPU_ADMIN_USER, CPU_USER
 *   - "Stamping Dashboard" only: STAMPING_ADMIN_USER, STAMPING_USER
 *
 * When only one tab is applicable the tab bar is hidden and
 * the single dashboard renders directly.
 */
const COMMON_DASHBOARD_ROLES = [ROLES.SUPER_ADMIN, ROLES.ADMIN];
const ALLOCATION_DASHBOARD_ROLES = [
  ...COMMON_DASHBOARD_ROLES,
  ROLES.CPU_ADMIN,
  ROLES.CPU,
];
const STAMPING_DASHBOARD_ROLES = [
  ...COMMON_DASHBOARD_ROLES,
  ROLES.STAMPING_ADMIN,
  ROLES.STAMPING_USER,
];
const BRANCH_DASHBOARD_ROLES = [
  ...COMMON_DASHBOARD_ROLES,
  ROLES.BRANCH_ADMIN,
  ROLES.BRANCH,
  ROLES.DOC_ADMIN,
];

// Transactions tab: SUPER_ADMIN and ADMIN only
const TRANSACTIONS_DASHBOARD_ROLES = [...COMMON_DASHBOARD_ROLES];

// Query tab: SUPER_ADMIN, ADMIN, BRANCH_ADMIN
const QUERY_DASHBOARD_ROLES = [...COMMON_DASHBOARD_ROLES, ROLES.BRANCH_ADMIN];

const DashboardMaster = () => {
  const { roleName } = useSelector((state) => state.user);

  // Determine which tabs this role can see
  const visibleTabs = DASHBOARD_TABS.filter(({ id }) => {
    if (id === DASHBOARD_TAB.ALLOCATIONS) {
      return ALLOCATION_DASHBOARD_ROLES.includes(roleName);
    }
    if (id === DASHBOARD_TAB.STAMPING) {
      return STAMPING_DASHBOARD_ROLES.includes(roleName);
    }
    if (id === DASHBOARD_TAB.BRANCH) {
      return BRANCH_DASHBOARD_ROLES.includes(roleName);
    }
    if (id === DASHBOARD_TAB.TRANSACTIONS) {
      return TRANSACTIONS_DASHBOARD_ROLES.includes(roleName);
    }
    if (id === DASHBOARD_TAB.QUERY) {
      return QUERY_DASHBOARD_ROLES.includes(roleName);
    }
    return false;
  });

  // Default to the first visible tab for this role
  const [activeTab, setActiveTab] = useState(
    visibleTabs[0]?.id ?? DASHBOARD_TAB.ALLOCATIONS,
  );

  return (
    <div className="flex flex-col">
      {/* Tab bar — only rendered when the user can access more than one dashboard */}
      <DashboardTabs
        tabs={visibleTabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      {/* Active dashboard panel */}
      <div
        role="tabpanel"
        id={`dashboard-tabpanel-${activeTab}`}
        aria-labelledby={`dashboard-tab-${activeTab}`}
      >
        {activeTab === DASHBOARD_TAB.ALLOCATIONS && <AllocationsDashboard />}
        {activeTab === DASHBOARD_TAB.STAMPING && <StampingDashboard />}
        {activeTab === DASHBOARD_TAB.BRANCH && <DashboardFileTrackingPage />}
        {activeTab === DASHBOARD_TAB.TRANSACTIONS && <TransactionsDashboard />}
        {activeTab === DASHBOARD_TAB.QUERY && <QueryDashboard />}
      </div>
    </div>
  );
};

DashboardMaster.displayName = "DashboardMaster";
export default DashboardMaster;
