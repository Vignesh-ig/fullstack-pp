import { useCallback, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import Pagination from "../../components/ui/common/Pagination";
import { useBranchHierarchy } from "../../hooks/dropdowns/useBranchHierarchy";
import BranchTable from "./components/BranchTable";

/**
 * BranchList
 *
 * Container component for branch data management. Displays branches filtered by
 * the Zone → Region → Area cascade. Branch data is fetched from the selected area.
 *
 */
const PAGE_SIZE_DEFAULT = 10;

const BranchList = () => {
  const { userEmployeeCode: currentUserCode } = useSelector(
    (state) => state.user,
  );

  // ── Cascade filter state ───────────────────────────────────────────────────
  const [zoneDropdownEnabled, setZoneDropdownEnabled] = useState(false);
  const [nameSearch, setNameSearch] = useState("");

  // ── Pagination state ───────────────────────────────────────────────────────
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(PAGE_SIZE_DEFAULT);

  const {
    zoneOptions,
    zoneLoading,
    zoneError,
    selectedZone,
    handleZoneChange: hierarchyZoneChange,
    regionOptions,
    regionLoading,
    selectedRegion,
    handleRegionChange: hierarchyRegionChange,
    areaOptions,
    areaLoading,
    selectedArea,
    handleAreaChange: hierarchyAreaChange,
    branchOptions,
    branchLoading,
    branchError,
    resetHierarchy,
  } = useBranchHierarchy(zoneDropdownEnabled);

  // Wrap hierarchy handlers to also reset page
  const handleZoneChange = useCallback(
    (e) => {
      hierarchyZoneChange(e.target.value);
      setPage(1);
    },
    [hierarchyZoneChange],
  );

  const handleRegionChange = useCallback(
    (e) => {
      hierarchyRegionChange(e.target.value);
      setPage(1);
    },
    [hierarchyRegionChange],
  );

  const handleAreaChange = useCallback(
    (e) => {
      hierarchyAreaChange(e.target.value);
      setPage(1);
    },
    [hierarchyAreaChange],
  );

  // ── Client-side search + pagination over branch rows ──────────────────────
  const allBranchRows = useMemo(
    () =>
      branchOptions.map((o) => ({
        branchId: o.value,
        branchName: o.label,
      })),
    [branchOptions],
  );

  const filteredRows = useMemo(() => {
    if (!nameSearch.trim()) return allBranchRows;
    const q = nameSearch.trim().toLowerCase();
    return allBranchRows.filter((r) => r.branchName?.toLowerCase().includes(q));
  }, [allBranchRows, nameSearch]);

  const totalItems = filteredRows.length;
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  const paginatedRows = filteredRows.slice(
    (page - 1) * pageSize,
    page * pageSize,
  );

  const handleRefresh = useCallback(() => {
    resetHierarchy();
    setNameSearch("");
    setPage(1);
  }, [resetHierarchy]);

  const loading = branchLoading && !!selectedArea;
  const error = zoneError || branchError;

  return (
    <ListContainer>
      <ListHeader
        title="Branch Master"
        unit="branches"
        count={selectedArea ? totalItems : null}
        loading={loading}
        searchPlaceholder="Search branch name"
        search={nameSearch}
        setSearch={(v) => {
          setNameSearch(v);
          setPage(1);
        }}
        refetch={handleRefresh}
      >
        {/* ── Cascade filter bar ── */}
        <search className="mt-4 grid grid-cols-1 sm:flex sm:flex-row items-start sm:items-center gap-3 sm:gap-5 w-full">
          {/* Zone */}
          <FilterSelectField
            label="Zone:"
            name="zoneFilter"
            value={selectedZone}
            onChange={handleZoneChange}
            placeholder="All Zones"
            options={zoneOptions}
            className="w-full lg:w-auto"
            isLoadingMore={zoneLoading}
            onOpen={() => setZoneDropdownEnabled(true)}
          />

          {/* Region */}
          <FilterSelectField
            label="Region:"
            name="regionFilter"
            value={selectedRegion}
            onChange={handleRegionChange}
            placeholder="All Regions"
            options={regionOptions}
            className="w-full lg:w-auto"
            disabled={!selectedZone}
            isLoadingMore={regionLoading}
            showSearch={true}
            searchPlaceholder="Search regions..."
          />

          {/* Area */}
          <FilterSelectField
            label="Area:"
            name="areaFilter"
            value={selectedArea}
            onChange={handleAreaChange}
            placeholder="All Areas"
            options={areaOptions}
            className="w-full lg:w-auto"
            disabled={!selectedRegion}
            isLoadingMore={areaLoading}
            showSearch={true}
            searchPlaceholder="Search areas..."
          />
        </search>
      </ListHeader>

      {/* ── Error ── */}
      {error && (
        <section className="px-6 pt-4">
          <ErrorBanner message={error} onClose={() => {}} />
        </section>
      )}

      <BranchTable
        branches={paginatedRows}
        loading={loading}
        error={error}
        search={nameSearch}
        page={page}
        pageSize={pageSize}
        currentUserCode={currentUserCode}
        areaSelected={!!selectedArea}
      />

      {/* ── Pagination (only visible once area is selected) ── */}
      {selectedArea && (
        <Pagination
          currentPage={page}
          totalPages={totalPages}
          onPageChange={setPage}
          totalItems={totalItems}
          pageSize={pageSize}
          onPageSizeChange={(size) => {
            setPageSize(size);
            setPage(1);
          }}
        />
      )}
    </ListContainer>
  );
};

BranchList.displayName = "BranchList";
export default BranchList;
