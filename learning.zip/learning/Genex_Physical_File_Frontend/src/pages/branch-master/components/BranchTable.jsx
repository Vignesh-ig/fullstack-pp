import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { BRANCH_TABLE_COLUMNS } from "../../../constants/tableHeaders";

/**
 * BranchTable
 *
 * Extracted table rendering logic for BranchList.
 *
 * @param {object[]} branches - Array of branch data objects.
 * @param {boolean} loading - Loading state for data fetching.
 * @param {string} error - Error message if fetching fails.
 * @param {string} search - Current search query.
 * @param {number} page - Current page number.
 * @param {number} pageSize - Page size.
 * @param {boolean} areaSelected - Whether an area has been selected; controls the empty state message.
 */
const BranchTable = ({
  branches,
  loading,
  error,
  search,
  page,
  pageSize,
  areaSelected = false,
}) => {
  const renderEmpty = () => {
    if (!areaSelected) {
      return (
        <EmptyState
          title="No branches to display"
          description="Select the zone, region and area to get the branches."
        />
      );
    }
    return (
      <EmptyState
        title="No branches found"
        description={
          search
            ? `No results for "${search}". Try a different search.`
            : "No branches available for the selected area."
        }
      />
    );
  };

  return (
    <Table headers={BRANCH_TABLE_COLUMNS} headerColorClass="bg-table-header-bg">
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow
            key={i}
            columnsCount={BRANCH_TABLE_COLUMNS.length}
          />
        ))
      ) : branches.length === 0 && !error ? (
        <tr>
          <td colSpan={BRANCH_TABLE_COLUMNS.length} className="h-full">
            {renderEmpty()}
          </td>
        </tr>
      ) : (
        branches.map((branch, index) => (
          <tr
            key={branch.branchId}
            className="hover:bg-slate-200/80 transition-colors"
          >
            <td className="table-td-branch">
              {(page - 1) * pageSize + index + 1}
            </td>
            <td className="table-td-primary-branch">
              {branch.branchName || "—"}
            </td>
            <td className="table-td-primary-branch">{""}</td>
            <td className="table-td-truncate-branch">{""}</td>
            <td className="table-td-truncate-branch">{""}</td>
          </tr>
        ))
      )}
    </Table>
  );
};

BranchTable.displayName = "BranchTable";
export default BranchTable;
