import { Route, Routes } from "react-router-dom";
import BranchList from "./BranchList";

/**
 * BranchMaster
 *
 * Renders the BranchMaster component.
 *
 */
const BranchMaster = () => {
  return (
    <Routes>
      <Route path="/" element={<BranchList />} />
    </Routes>
  );
};

BranchMaster.displayName = "BranchMaster";
export default BranchMaster;
