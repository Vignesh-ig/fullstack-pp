import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import {
  Navigate,
  useLocation,
  useNavigate,
  useParams,
} from "react-router-dom";
import {
  AlertCircleIcon,
  BuildingIcon,
  CpuIcon,
  EyeIcon,
  EyeOffIcon,
  TransferIcon,
  VendorIcon,
} from "../components/icons/icons";
import Button from "../components/ui/common/Button";
import ErrorBanner from "../components/ui/common/ErrorBanner";
import InputField from "../components/ui/common/InputField";
import Logo from "../components/ui/common/Logo";
import { getFirstPermittedPath } from "../constants/featureRegistry";
import { loginThunk } from "../redux/slice/authThunks";
import { loginSchema } from "../utils/schemas/configSchema";
import { REGEX } from "../utils/validation/regex";

/**
 * Login
 *
 * Renders the Login component.
 *
 */
const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const { trackId } = useParams();

  const {
    loading,
    error,
    isAuthenticated,
    roleName,
    permissions,
    sessionExpired,
  } = useSelector((state) => state.user);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isValid },
  } = useForm({
    resolver: zodResolver(loginSchema),
    mode: "onTouched",
  });

  // Watch field values
  const userEmployeeCode = watch("userEmployeeCode");
  const password = watch("password");
  const isFilled = userEmployeeCode && password;

  const [showPassword, setShowPassword] = useState(false);

  const onSubmit = async (data) => {
    const result = await dispatch(
      loginThunk({
        userEmployeeCode: data.userEmployeeCode,
        password: data.password,
      }),
    );
    if (loginThunk.fulfilled.match(result)) {
      const deepLink = sessionStorage.getItem("redirectAfterLogin");

      if (deepLink) {
        const url = new URL(deepLink, window.location.origin);

        const pathParts = url.pathname.split("/").filter(Boolean);

        const trackId = pathParts[1]; // after "email-action"
        const action = url.searchParams.get("action");

        // const roleBaseRoute = getDashboardRouteForRole(result.payload.redirectTo);

        // if (!roleBaseRoute) {
        //   console.error(
        //     "No dashboard route found for role:",
        //     roleName
        //   );
        //   return;
        // }

        const targetUrl =
          `/doc-admin-reterival-request/edit/${encodeURIComponent(trackId)}` +
          `?action=${encodeURIComponent(action || "")}`;

        navigate(targetUrl);

        sessionStorage.removeItem("redirectAfterLogin");
      } else {
        navigate(result.payload.redirectTo, { replace: true });
      }
    }
  };

  if (isAuthenticated && permissions?.length > 0) {
    return (
      <Navigate
        to={getFirstPermittedPath(permissions.map((p) => p.permissionName))}
        replace
      />
    );
  }

  return (
    <main className="min-h-screen flex flex-col lg:flex-row bg-surface-primary text-text-inverse">
      {/* Left Panel: Concept Illustration - Hidden on mobile */}
      <aside className="hidden lg:flex w-full lg:w-1/2 min-h-[40vh] lg:min-h-screen relative flex-col justify-center overflow-hidden bg-surface-primary border-b lg:border-b-0 lg:border-r border-surface-secondary">
        {/* Abstract shapes & glowing effects */}
        <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-brand-primary/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-indigo-500/30 rounded-full blur-3xl"></div>
        <Logo linkClassName="absolute top-10 left-10" />
        <div className="relative z-10 p-8 sm:p-12 lg:p-16 max-w-2xl mx-auto flex flex-col justify-center h-full pt-24 lg:pt-16">
          {/* Title Area */}
          <div>
            <h1 className="text-3xl italic text-center sm:text-4xl lg:text-5xl font-extrabold leading-tight text-transparent bg-clip-text bg-linear-to-r from-brand-accent to-indigo-400 drop-shadow-sm">
              File Tracking System
            </h1>
          </div>

          {/* Abstract File Tracking Visual */}
          <figure className="relative w-full max-w-md h-64">
            {/* Connecting Line */}
            <div className="absolute top-3/4 left-0 w-full h-1 bg-slate-800 -translate-y-1/2 overflow-hidden rounded-full">
              <div className="animate-flow"></div>
            </div>

            {/* Tracking Nodes */}
            <div className="absolute inset-0 flex justify-between items-center px-4">
              {/* Node 1: Branch */}
              <div className="flex flex-col items-center group relative cursor-default animate-float-1">
                <div className="w-16 h-16 rounded-2xl bg-slate-800 border-2 border-role-branch flex items-center justify-center animate-pulse-blue z-10 transition-colors group-hover:bg-role-branch/30">
                  <BuildingIcon className="w-8 h-8 text-role-branch" />
                </div>
                <div className="mt-4 text-sm font-semibold text-role-branch">
                  Branch
                </div>
              </div>

              {/* To/From Arrow 1 */}
              <div className="flex items-center justify-center z-10 -mt-6">
                <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center text-slate-400 animate-pulse">
                  <TransferIcon className="w-4 h-4" />
                </div>
              </div>

              {/* Node 2: CPU */}
              <div className="flex flex-col items-center group relative cursor-default animate-float-2">
                <div className="w-16 h-16 rounded-2xl bg-slate-800 border-2 border-role-cpu flex items-center justify-center animate-pulse-purple z-10 transition-colors group-hover:bg-role-cpu/30">
                  <CpuIcon className="w-8 h-8 text-role-cpu" />
                </div>
                <div className="mt-4 text-sm font-semibold text-role-cpu">
                  CPU
                </div>
              </div>

              {/* To/From Arrow 2 */}
              <div className="flex items-center justify-center z-10 -mt-6">
                <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-600 flex items-center justify-center text-slate-400 animate-pulse">
                  <TransferIcon className="w-4 h-4" />
                </div>
              </div>

              {/* Node 3: Vendor */}
              <div className="flex flex-col items-center group relative cursor-default animate-float-3">
                <div className="w-16 h-16 rounded-2xl bg-slate-800 border-2 border-indigo-400 flex items-center justify-center animate-pulse-indigo z-10 transition-colors group-hover:bg-indigo-400/30">
                  <VendorIcon className="w-8 h-8 text-indigo-400" />
                </div>
                <div className="mt-4 text-sm font-semibold text-indigo-400">
                  Vendor
                </div>
              </div>
            </div>
          </figure>
        </div>
      </aside>

      {/* Right Panel: Login Form */}
      <section className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 bg-white relative overflow-hidden flex-1">
        <div className="w-full max-w-md relative z-10">
          <header className="mb-8 flex flex-col items-start text-left">
            <h2 className="text-3xl font-bold text-slate-800 tracking-tight">
              Welcome to Chola
            </h2>
            <p className="text-slate-500 mt-2">
              Sign in to file tracking system
            </p>
          </header>

          {/* Login Card */}
          <div className="relative rounded-3xl p-[2.5px] shadow-xl overflow-hidden group max-w-md w-full">
            <div className="absolute -inset-full animate-[spin_3s_linear_infinite] bg-[conic-gradient(from_0deg,transparent_0_200deg,rgba(59,130,246,1)_360deg)] opacity-70 group-hover:opacity-100 transition-opacity duration-300" />
            <div className="relative bg-white rounded-[21px] p-8 h-full w-full z-10">
              <form onSubmit={handleSubmit(onSubmit)}>
                {/* Employee Code Field */}
                <InputField
                  label="Employee Code"
                  {...register("userEmployeeCode")}
                  placeholder="Enter your employee code"
                  required={true}
                  error={errors.userEmployeeCode?.message}
                  regex={REGEX.EMPID}
                />

                {/* Password Field */}
                <InputField
                  label="Password"
                  type={showPassword ? "text" : "password"}
                  {...register("password")}
                  placeholder="Enter your password"
                  required={true}
                  className="mb-8"
                  error={errors.password?.message}
                  rightIcon={
                    <button
                      type="button"
                      id="toggle-password-visibility-btn"
                      aria-label={
                        showPassword ? "Hide password" : "Show password"
                      }
                      onClick={() => setShowPassword((prev) => !prev)}
                      className="text-text-secondary opacity-60 hover:opacity-100 transition-opacity focus:outline-none"
                      tabIndex={-1}
                    >
                      {showPassword ? (
                        <EyeOffIcon className="w-5 h-5" />
                      ) : (
                        <EyeIcon className="w-5 h-5" />
                      )}
                    </button>
                  }
                />

                {/* Warning Banner for Session Expiration */}
                <ErrorBanner
                  type="warning"
                  message={
                    sessionExpired
                      ? "Session expired. Please log in again."
                      : null
                  }
                />

                {/* Error Banner */}
                {error && (
                  <div className="mb-4 px-4 py-3 rounded-xl bg-status-error-bg border border-status-error/20 text-status-error text-sm font-medium flex items-center gap-2">
                    <AlertCircleIcon className="w-4 h-4 shrink-0" />
                    {error}
                  </div>
                )}

                {/* Login Button */}
                <Button
                  type="submit"
                  disabled={loading || !isValid || !isFilled}
                >
                  {loading ? "Signing in…" : "Sign In"}
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

Login.displayName = "Login";
export default Login;
