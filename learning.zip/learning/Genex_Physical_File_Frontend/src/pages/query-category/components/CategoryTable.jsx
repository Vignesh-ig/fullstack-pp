import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableRecordDeleteButton from "../../../components/ui/common/TableRecordDeleteButton";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { QUERY_CATEGORY_TABLE_COLUMNS } from "../../../constants/tableHeaders";

/**
 * CategoryTable
 *
 * Renders the query category list table with loading skeletons, empty state,
 * and per-row delete action.
 *
 * @param {object[]} categories - Array of query category data objects.
 * @param {boolean} loading - Whether data is being fetched.
 * @param {string} error - Error message if fetch failed.
 * @param {number} page - Current page number for serial number calculation.
 * @param {number} pageSize - Current page size for serial number calculation.
 * @param {boolean} isDeleting - Whether a delete operation is in progress.
 * @param {function} onDeleteClick - Callback with item info when delete is triggered.
 */
const CategoryTable = ({
  categories = [],
  loading,
  error,
  page,
  pageSize,
  isDeleting,
  onDeleteClick,
}) => {
  return (
    <Table
      headers={QUERY_CATEGORY_TABLE_COLUMNS}
      headerColorClass="bg-table-header-bg"
    >
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow
            key={i}
            columnsCount={QUERY_CATEGORY_TABLE_COLUMNS.length}
          />
        ))
      ) : categories.length === 0 && !error ? (
        <tr>
          <td colSpan={QUERY_CATEGORY_TABLE_COLUMNS.length} className="h-full">
            <EmptyState
              title="No categories found"
              description="No query categories have been configured yet."
            />
          </td>
        </tr>
      ) : (
        categories.map((item, index) => (
          <tr
            key={item.queryCategoryId}
            className="hover:bg-slate-200/80 transition-colors"
          >
            <td className="table-td-middle">
              {(page - 1) * pageSize + index + 1}
            </td>
            <td className="table-td-middle">{item.queryCategoryName || "—"}</td>
            {/* <td className="px-6 py-1 text-center">
              <TableRecordDeleteButton
                recordId={item.queryCategoryId}
                onDeleteClick={() =>
                  onDeleteClick({
                    queryCategoryId: item.queryCategoryId,
                    queryCategoryName: item.queryCategoryName,
                  })
                }
                isDeleting={isDeleting}
                label="Delete Category"
                bypassPermissionCheck
              />
            </td> */}
          </tr>
        ))
      )}
    </Table>
  );
};

CategoryTable.displayName = "CategoryTable";
export default CategoryTable;
