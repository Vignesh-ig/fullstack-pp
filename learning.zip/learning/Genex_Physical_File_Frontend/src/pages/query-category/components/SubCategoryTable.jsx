import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableRecordDeleteButton from "../../../components/ui/common/TableRecordDeleteButton";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { QUERY_SUB_CATEGORY_TABLE_COLUMNS } from "../../../constants/tableHeaders";

/**
 * SubCategoryTable
 *
 * Renders the query sub-category list table with loading skeletons, empty state,
 * and per-row delete action.
 *
 * @param {object[]} subCategories - Array of query sub-category data objects.
 * @param {boolean} loading - Whether data is being fetched.
 * @param {string} error - Error message if fetch failed.
 * @param {string} search - Current search/filter description for empty state message.
 * @param {number} page - Current page number for serial number calculation.
 * @param {number} pageSize - Current page size for serial number calculation.
 * @param {boolean} isDeleting - Whether a delete operation is in progress.
 * @param {function} onDeleteClick - Callback with item info when delete is triggered.
 */
const SubCategoryTable = ({
  subCategories = [],
  loading,
  error,
  search,
  page,
  pageSize,
  isDeleting,
  onDeleteClick,
}) => {
  return (
    <Table
      headers={QUERY_SUB_CATEGORY_TABLE_COLUMNS}
      headerColorClass="bg-table-header-bg"
    >
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow
            key={i}
            columnsCount={QUERY_SUB_CATEGORY_TABLE_COLUMNS.length}
          />
        ))
      ) : subCategories.length === 0 && !error ? (
        <tr>
          <td
            colSpan={QUERY_SUB_CATEGORY_TABLE_COLUMNS.length}
            className="h-full"
          >
            <EmptyState
              title="No sub categories found"
              description={
                search
                  ? `No results for "${search}". Try a different filter.`
                  : "No query sub categories have been configured yet."
              }
            />
          </td>
        </tr>
      ) : (
        subCategories.map((item, index) => (
          <tr
            key={item.queryCategoryId}
            className="hover:bg-slate-200/80 transition-colors"
          >
            <td className="table-td-middle">
              {(page - 1) * pageSize + index + 1}
            </td>
            <td className="table-td-middle">{item.queryCategoryName || "—"}</td>
            <td className="table-td-middle">
              {item.queryCategoryDescription || "—"}
            </td>
            <td className="px-6 py-1 text-center">
              <TableRecordDeleteButton
                recordId={item.queryCategoryId}
                onDeleteClick={() =>
                  onDeleteClick({
                    queryCategoryId: item.queryCategoryId,
                    queryCategoryName: item.queryCategoryName,
                    queryCategoryDescription: item.queryCategoryDescription,
                  })
                }
                isDeleting={isDeleting}
                label="Delete Sub Category"
                bypassPermissionCheck
              />
            </td>
          </tr>
        ))
      )}
    </Table>
  );
};

SubCategoryTable.displayName = "SubCategoryTable";
export default SubCategoryTable;
