import { useState } from "react";
import { Route, Routes, useLocation } from "react-router-dom";
import FloatingMenu from "../../components/ui/common/FloatingMenu";
import { QUERY_CATEGORY_LIST_TABS } from "../../constants/menuHeaders";
import { ROUTES } from "../../router/routes";
import AddSubCategoryForm from "./AddSubCategoryForm";
import CategoryList from "./CategoryList";
import SubCategoryList from "./SubCategoryList";

/**
 * QueryCategoryMain
 *
 * Main list view for the Query Category module.
 * Shows Category and Sub Category tabs using FloatingMenu.
 * Defaults to the "category" tab on load.
 */
const QueryCategoryMain = () => {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState(
    location.state?.defaultTab || "category",
  );

  return (
    <div className="flex flex-col gap-4 relative w-full h-full">
      {/* Top Center Tab Navigation */}
      <div className="flex justify-center w-full pb-2 slide-in-from-top-2 animate-in duration-500">
        <FloatingMenu
          tabs={QUERY_CATEGORY_LIST_TABS}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          className="w-full sm:w-61"
        />
      </div>

      {/* Tab Content */}
      <div className="w-full flex-1">
        {activeTab === "category" && <CategoryList />}
        {activeTab === "sub-category" && <SubCategoryList />}
      </div>
    </div>
  );
};

/**
 * QueryCategory
 *
 * Root component for the Query Category module.
 * Routes to the list view (with tabs) or the Add Sub Category form.
 */
const QueryCategory = () => {
  return (
    <Routes>
      <Route path="/" element={<QueryCategoryMain />} />
      <Route
        path={ROUTES.FEATURES.MASTER.QUERY_CATEGORY.ADD}
        element={<AddSubCategoryForm />}
      />
    </Routes>
  );
};

QueryCategory.displayName = "QueryCategory";
export default QueryCategory;
