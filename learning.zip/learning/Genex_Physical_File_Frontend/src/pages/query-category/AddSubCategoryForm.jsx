import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  createQueryCategoryApi,
  getQueryCategoriesApi,
} from "../../api/apiConfig";
import PortraitFormContainer from "../../components/layout/PortraitFormContainer";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FormFooter from "../../components/ui/common/FormFooter";
import FormHeader from "../../components/ui/common/FormHeader";
import InputField from "../../components/ui/common/InputField";
import SelectField from "../../components/ui/common/SelectField";
import SuccessBanner from "../../components/ui/common/SuccessBanner";
import TextareaField from "../../components/ui/common/TextareaField";
import { useQueryCategoryDropdown } from "../../hooks/dropdowns/useQueryCategoryDropdown";
import { useApi } from "../../hooks/useApi";
import { addQuerySubCategorySchema } from "../../utils/schemas/configSchema";

/**
 * AddSubCategoryForm
 *
 * Dedicated page for adding a new Query Sub Category.
 * No tab switcher — a direct form inside a PortraitFormContainer.
 * Allows selecting a category, then entering a new sub category description.
 * Fetches existing sub categories for the selected category and displays them.
 * Submits a POST to /queryCategory on save.
 */
const AddSubCategoryForm = () => {
  const navigate = useNavigate();
  const { userId: currentUserId } = useSelector((state) => state.user);

  const [existingSubCategories, setExistingSubCategories] = useState([]);
  const [subCategoriesLoading, setSubCategoriesLoading] = useState(false);

  // Tracks the navigate timer so it can be cleared on unmount
  const navTimerRef = useRef(null);

  // Clear the navigation timer when the component unmounts
  useEffect(() => {
    return () => {
      if (navTimerRef.current) clearTimeout(navTimerRef.current);
    };
  }, []);

  const { categoryOptions, categoriesLoading } = useQueryCategoryDropdown();

  const form = useForm({
    resolver: zodResolver(addQuerySubCategorySchema),
    defaultValues: {
      queryCategoryName: "",
      queryCategoryDescription: "",
    },
    mode: "onTouched",
  });

  const selectedCategoryName = form.watch("queryCategoryName");

  // Fetch existing sub categories when a category is selected
  useEffect(() => {
    if (!selectedCategoryName) {
      setExistingSubCategories([]);
      return;
    }

    let isMounted = true;
    setSubCategoriesLoading(true);

    getQueryCategoriesApi({
      page: 1,
      limit: 500,
      queryCategoryName: selectedCategoryName,
    })
      .then((res) => {
        if (!isMounted) return;
        const list = res?.data?.data || res?.data || [];
        setExistingSubCategories(list);
      })
      .catch(() => {})
      .finally(() => {
        if (isMounted) setSubCategoriesLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [selectedCategoryName]);

  const {
    execute: createSubCategory,
    isLoading: isCreating,
    error: apiError,
    setError: setApiError,
    isSuccess,
  } = useApi(createQueryCategoryApi);

  const onSubmit = async (data) => {
    setApiError(null);

    const payload = {
      queryCategoryName: data.queryCategoryName,
      queryCategoryDescription: data.queryCategoryDescription,
      createdBy: currentUserId,
    };

    const { error } = await createSubCategory(payload);
    if (!error) {
      navTimerRef.current = setTimeout(() => {
        navigate("..", { state: { defaultTab: "sub-category" } });
      }, 1000);
    }
  };

  const isInputsDisabled = !selectedCategoryName;

  // Build the existing sub categories display text
  const existingSubCategoriesText = subCategoriesLoading
    ? "Loading existing sub categories..."
    : existingSubCategories.length > 0
      ? existingSubCategories
          .map((item) => item.queryCategoryDescription)
          .filter(Boolean)
          .join(", ")
      : selectedCategoryName
        ? "No sub categories found for this category"
        : "";

  return (
    <>
      <PortraitFormContainer>
        <FormHeader
          title="Add Sub Category"
          onBack={() => navigate("..")}
          showBack={true}
        />

        <div className="p-6">
          <form
            id="add-sub-category-form"
            onSubmit={form.handleSubmit(onSubmit)}
            noValidate
            className="flex flex-col gap-4"
          >
            <SuccessBanner
              message={isSuccess ? "Sub category added successfully!" : null}
            />
            <ErrorBanner message={apiError} onClose={() => setApiError(null)} />

            {/* SELECT CATEGORY NAME */}
            <SelectField
              label="Select Category Name"
              name="queryCategoryName"
              value={form.watch("queryCategoryName")}
              onChange={(e) => {
                form.setValue("queryCategoryName", e.target.value, {
                  shouldValidate: true,
                });
                // Reset sub category input when category changes
                form.setValue("queryCategoryDescription", "", {
                  shouldValidate: false,
                });
              }}
              onBlur={() => form.trigger("queryCategoryName")}
              options={categoryOptions}
              placeholder={
                categoriesLoading
                  ? "Loading categories..."
                  : "Select a category"
              }
              required
              error={form.formState.errors.queryCategoryName?.message}
              disabled={categoriesLoading || isCreating || isSuccess}
            />

            {/* EXISTING SUB CATEGORIES */}
            <TextareaField
              label="Existing Sub Categories"
              name="existingSubCategories"
              value={existingSubCategoriesText}
              placeholder="Existing sub categories will appear here"
              readOnly
              disabled
              className="mb-0 text-text-secondary bg-gray-50"
            />

            {/* SUB CATEGORY INPUT */}
            <InputField
              label="Sub Category"
              name="queryCategoryDescription"
              value={form.watch("queryCategoryDescription")}
              onChange={(e) => {
                form.setValue("queryCategoryDescription", e.target.value, {
                  shouldValidate: true,
                });
              }}
              onBlur={() => form.trigger("queryCategoryDescription")}
              placeholder={
                isInputsDisabled
                  ? "Select a category first"
                  : "Enter sub category description"
              }
              maxLength={120}
              required
              disabled={isInputsDisabled || isCreating || isSuccess}
              error={form.formState.errors.queryCategoryDescription?.message}
            />
          </form>

          <FormFooter
            buttons={[
              {
                label: isCreating ? "Saving..." : "Add Sub Category",
                props: {
                  type: "button",
                  onClick: () => form.handleSubmit(onSubmit)(),
                  disabled: !form.formState.isValid || isCreating || isSuccess,
                },
              },
            ]}
          />
        </div>
      </PortraitFormContainer>
    </>
  );
};

AddSubCategoryForm.displayName = "AddSubCategoryForm";
export default AddSubCategoryForm;
