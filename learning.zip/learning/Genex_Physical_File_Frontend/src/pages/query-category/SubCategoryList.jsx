import { useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  deleteQueryCategoryApi,
  getQueryCategoriesApi,
} from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import ConfirmationDialog from "../../components/ui/common/ConfirmationDialog";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import Pagination from "../../components/ui/common/Pagination";
import SuccessBanner from "../../components/ui/common/SuccessBanner";
import { useQueryCategoryDropdown } from "../../hooks/dropdowns/useQueryCategoryDropdown";
import { useDeleteHandler } from "../../hooks/useDeleteHandler";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import { ROUTES } from "../../router/routes";
import SubCategoryTable from "./components/SubCategoryTable";

/**
 * SubCategoryList
 *
 * Container component for the Query Sub Category page.
 * Handles fetching all records, searching by queryCategoryDescription,
 * filtering by category name, paginating, and deleting sub categories.
 * Shows a confirmation dialog before deletion and a success banner after.
 */
const SubCategoryList = () => {
  const navigate = useNavigate();
  const [categoryFilter, setCategoryFilter] = useState("");

  const { categoryOptions: filterCategoryOptions } = useQueryCategoryDropdown();

  const fetchFn = useCallback(
    async (params) => {
      const { searchByName, ...restParams } = params;
      return getQueryCategoriesApi({
        ...restParams,
        ...(categoryFilter ? { queryCategoryName: categoryFilter } : {}),
        ...(searchByName ? { likeQueryCategoryDescription: searchByName } : {}),
      });
    },
    [categoryFilter],
  );

  const {
    data: subCategories,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "searchByName");

  const {
    pendingDelete,
    deletedItemInfo,
    isDeleting,
    deleteError,
    handleDeleteRequest,
    handleConfirmDelete,
    handleCancelDelete,
    clearDeleteError,
  } = useDeleteHandler(deleteQueryCategoryApi, async () => {
    refetch();
    if (page > 1 && subCategories.length <= 1) {
      setPage((prev) => Math.max(1, prev - 1));
    }
  });

  const handleCategoryFilterChange = (e) => {
    setCategoryFilter(e.target.value);
    setPage(1);
  };

  const handleRefresh = () => {
    setCategoryFilter("");
    refetch();
  };

  const handleAddClick = () => {
    navigate(`${ROUTES.FEATURES.MASTER.QUERY_CATEGORY.ROOT}/add`);
  };

  const searchDesc = [
    search ? `Description: "${search}"` : "",
    categoryFilter
      ? `Category: ${filterCategoryOptions.find((o) => o.value === categoryFilter)?.label || ""}`
      : "",
  ]
    .filter(Boolean)
    .join(", ");

  return (
    <ListContainer>
      <ListHeader
        title="Sub Category"
        unit="sub categories"
        count={pagination.totalItems}
        loading={loading}
        searchPlaceholder="Search by sub category"
        search={search}
        setSearch={setSearch}
        refetch={handleRefresh}
        addLabel="Add Sub Category"
        onAddClick={handleAddClick}
      >
        <div className="mt-4 grid grid-cols-1 sm:flex sm:flex-row items-start sm:items-center gap-3 sm:gap-5 w-full">
          <FilterSelectField
            label="Filter by category:"
            name="categoryFilter"
            value={categoryFilter}
            onChange={handleCategoryFilterChange}
            placeholder="All Categories"
            options={filterCategoryOptions}
            className="w-full sm:w-auto"
          />
        </div>
      </ListHeader>

      {/* ── Banners ── */}
      {(error || deleteError || deletedItemInfo) && (
        <section className="px-6 pt-4 space-y-3">
          {deletedItemInfo && (
            <SuccessBanner
              message={
                <span>
                  You have successfully deleted{" "}
                  <strong>
                    &ldquo;{deletedItemInfo?.queryCategoryDescription}&rdquo;
                  </strong>{" "}
                  from <strong>{deletedItemInfo?.queryCategoryName}</strong>.
                </span>
              }
            />
          )}
          {(error || deleteError) && (
            <ErrorBanner
              message={deleteError || error}
              onClose={() => {
                setError(null);
                clearDeleteError();
              }}
            />
          )}
        </section>
      )}

      <SubCategoryTable
        subCategories={subCategories}
        loading={loading}
        error={error}
        search={searchDesc}
        page={page}
        pageSize={pageSize}
        isDeleting={isDeleting}
        onDeleteClick={handleDeleteRequest}
      />

      {/* ── Pagination ── */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />

      <ConfirmationDialog
        isOpen={!!pendingDelete}
        content={
          <span>
            Are you sure you want to delete{" "}
            <strong className="wrap-break-word">
              &ldquo;{pendingDelete?.queryCategoryDescription}&rdquo;
            </strong>{" "}
            from <strong>{pendingDelete?.queryCategoryName}</strong> ?
          </span>
        }
        confirmText="Delete"
        onConfirm={() => handleConfirmDelete("queryCategoryId")}
        onCancel={handleCancelDelete}
        isSubmitting={isDeleting}
      />
    </ListContainer>
  );
};

SubCategoryList.displayName = "SubCategoryList";
export default SubCategoryList;
