import { useCallback } from "react";
import {
  deleteQueryCategoryApi,
  getQueryCategoriesApi,
} from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import ConfirmationDialog from "../../components/ui/common/ConfirmationDialog";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import Pagination from "../../components/ui/common/Pagination";
import SuccessBanner from "../../components/ui/common/SuccessBanner";
import { useDeleteHandler } from "../../hooks/useDeleteHandler";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import CategoryTable from "./components/CategoryTable";

/**
 * CategoryList
 *
 * Container component for the Query Category (unique categories) page.
 * Fetches categories using queryCategoryName=UNIQUE param.
 * Handles paginating and deleting categories.
 * Shows a confirmation dialog before deletion and a success banner after.
 */
const CategoryList = () => {
  const fetchFn = useCallback(async (params) => {
    return getQueryCategoriesApi({
      ...params,
      queryCategoryName: "UNIQUE",
    });
  }, []);

  const {
    data: categories,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    refetch,
  } = usePaginatedFetch(fetchFn, 10);

  const {
    pendingDelete,
    deletedItemInfo,
    isDeleting,
    deleteError,
    handleDeleteRequest,
    handleConfirmDelete,
    handleCancelDelete,
    clearDeleteError,
  } = useDeleteHandler(deleteQueryCategoryApi, async () => {
    refetch();
    if (page > 1 && categories.length <= 1) {
      setPage((prev) => Math.max(1, prev - 1));
    }
  });

  const handleRefresh = () => {
    refetch();
  };

  return (
    <ListContainer>
      <ListHeader
        title="Category"
        unit="categories"
        count={pagination.totalItems}
        loading={loading}
        refetch={handleRefresh}
        showAddButton={false}
      />

      {/* ── Banners ── */}
      {(error || deleteError || deletedItemInfo) && (
        <section className="px-6 pt-4 space-y-3">
          {deletedItemInfo && (
            <SuccessBanner
              message={
                <span>
                  You have successfully deleted{" "}
                  <strong>
                    &ldquo;{deletedItemInfo.queryCategoryName}&rdquo;
                  </strong>
                  .
                </span>
              }
            />
          )}
          {(error || deleteError) && (
            <ErrorBanner
              message={deleteError || error}
              onClose={() => {
                setError(null);
                clearDeleteError();
              }}
            />
          )}
        </section>
      )}

      <CategoryTable
        categories={categories}
        loading={loading}
        error={error}
        page={page}
        pageSize={pageSize}
        isDeleting={isDeleting}
        onDeleteClick={handleDeleteRequest}
      />

      {/* ── Pagination ── */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />

      {/* ── Confirmation Dialog ── */}
      <ConfirmationDialog
        isOpen={!!pendingDelete}
        content={
          <span>
            Are you sure you want to delete{" "}
            <strong className="wrap-break-word">
              &ldquo;{pendingDelete?.queryCategoryName}&rdquo;
            </strong>{" "}
            ?
          </span>
        }
        confirmText="Delete"
        onConfirm={() => handleConfirmDelete("queryCategoryId")}
        onCancel={handleCancelDelete}
        isSubmitting={isDeleting}
      />
    </ListContainer>
  );
};

CategoryList.displayName = "CategoryList";
export default CategoryList;
