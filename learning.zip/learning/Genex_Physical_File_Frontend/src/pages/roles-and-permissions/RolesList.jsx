import { useCallback } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { deleteRolesApi, getRolesApi } from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import RoleBadge from "../../components/ui/badge/RoleBadge";
import ConfirmationDialog from "../../components/ui/common/ConfirmationDialog";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import Pagination from "../../components/ui/common/Pagination";
import SuccessBanner from "../../components/ui/common/SuccessBanner";
import { useDeleteHandler } from "../../hooks/useDeleteHandler";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import RolesTable from "./components/RolesTable";

/**
 * RolesList
 *
 * Container component for the Roles page.
 * Handles fetching, paginating, and deleting roles.
 * Shows a confirmation dialog before deletion and a success dialog after.
 */
const RolesList = () => {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const fetchFn = useCallback(async (params) => {
    return getRolesApi(params);
  }, []);

  const {
    data: roles,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    refetch,
  } = usePaginatedFetch(fetchFn, 10);

  const {
    pendingDelete,
    deletedItemInfo,
    isDeleting,
    deleteError,
    handleDeleteRequest,
    handleConfirmDelete,
    handleCancelDelete,
    clearDeleteError,
  } = useDeleteHandler(deleteRolesApi, async () => {
    refetch();
    if (page > 1 && roles.length <= 1) {
      setPage((prev) => Math.max(1, prev - 1));
    }
  });

  const handleRefresh = () => {
    refetch();
  };

  const handleAddClick = () => {
    const base = pathname.endsWith("/") ? pathname.slice(0, -1) : pathname;
    navigate(`${base}/add`, { state: { defaultTab: "role" } });
  };

  return (
    <ListContainer>
      <ListHeader
        title="Roles"
        unit="roles"
        count={pagination.totalItems}
        loading={loading}
        refetch={handleRefresh}
        addLabel="Add Roles & Permissions"
        onAddClick={handleAddClick}
      />

      {/* ── Banners ── */}
      {(error || deleteError || deletedItemInfo) && (
        <section className="px-6 pt-4 space-y-3">
          {deletedItemInfo && (
            <SuccessBanner
              message={
                <span>
                  You have successfully deleted{" "}
                  <RoleBadge roleName={deletedItemInfo.roleName} />.
                </span>
              }
            />
          )}
          {(error || deleteError) && (
            <ErrorBanner
              message={deleteError || error}
              onClose={() => {
                setError(null);
                clearDeleteError();
              }}
            />
          )}
        </section>
      )}

      <RolesTable
        roles={roles}
        loading={loading}
        error={error}
        page={page}
        pageSize={pageSize}
        isDeleting={isDeleting}
        onDeleteClick={handleDeleteRequest}
      />

      {/* ── Pagination ── */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />

      {/* ── Confirmation Dialog ── */}
      <ConfirmationDialog
        isOpen={!!pendingDelete}
        content={
          <span>
            Are you sure you want to delete{" "}
            <RoleBadge roleName={pendingDelete?.roleName} /> ?
          </span>
        }
        confirmText="Delete"
        onConfirm={() => handleConfirmDelete("roleId")}
        onCancel={handleCancelDelete}
        isSubmitting={isDeleting}
      />
    </ListContainer>
  );
};

RolesList.displayName = "RolesList";
export default RolesList;
