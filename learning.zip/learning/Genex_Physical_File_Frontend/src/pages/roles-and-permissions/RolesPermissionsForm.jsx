import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import PortraitFormContainer from "../../components/layout/PortraitFormContainer";
import FloatingMenu from "../../components/ui/common/FloatingMenu";
import FormHeader from "../../components/ui/common/FormHeader";
import { ROLES_PERMISSIONS_FORM_TABS } from "../../constants/menuHeaders";
import AddPermissionForm from "./components/AddPermissionForm";
import AddRoleForm from "./components/AddRoleForm";

/**
 * RolesPermissionsForm
 *
 * Dedicated page for adding Roles and Permissions.
 * Uses a pill tab switcher to toggle between two forms.
 */
const RolesPermissionsForm = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const [activeTab, setActiveTab] = useState(
    location.state?.defaultTab || "role",
  );

  const handleTabChange = (tabId) => {
    setActiveTab(tabId);
  };

  const isPermTab = activeTab === "permission";

  return (
    <>
      <div className="px-6 py-4 flex justify-center">
        <FloatingMenu
          tabs={ROLES_PERMISSIONS_FORM_TABS}
          activeTab={activeTab}
          onTabChange={handleTabChange}
          className="w-full sm:w-80"
        />
      </div>
      <PortraitFormContainer>
        <FormHeader
          title={isPermTab ? "Add Permission" : "Add Role"}
          onBack={() => navigate("..")}
          showBack={true}
        />

        <div className="p-6">
          {isPermTab ? <AddPermissionForm /> : <AddRoleForm />}
        </div>
      </PortraitFormContainer>
    </>
  );
};

RolesPermissionsForm.displayName = "RolesPermissionsForm";
export default RolesPermissionsForm;
