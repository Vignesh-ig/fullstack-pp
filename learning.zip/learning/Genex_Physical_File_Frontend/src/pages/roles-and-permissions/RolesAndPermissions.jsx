import { useState } from "react";
import { Route, Routes, useLocation } from "react-router-dom";
import FloatingMenu from "../../components/ui/common/FloatingMenu";
import { ROLES_PERMISSIONS_LIST_TABS } from "../../constants/menuHeaders";
import { ROUTES } from "../../router/routes";
import PermissionsList from "./PermissionsList";
import RolesList from "./RolesList";
import RolesPermissionsForm from "./RolesPermissionsForm";

const RolesPermissionsMain = () => {
  const location = useLocation();
  const [activeTab, setActiveTab] = useState(
    location.state?.defaultTab || "roles",
  );

  return (
    <div className="flex flex-col gap-4 relative w-full h-full">
      {/* Top Center Tab Navigation */}
      <div className="flex justify-center w-full pb-2 slide-in-from-top-2 animate-in duration-500">
        <FloatingMenu
          tabs={ROLES_PERMISSIONS_LIST_TABS}
          activeTab={activeTab}
          onTabChange={setActiveTab}
          className="w-full sm:w-51.5"
        />
      </div>

      {/* Tab Content */}
      <div className="w-full flex-1">
        {activeTab === "roles" && <RolesList />}
        {activeTab === "permissions" && <PermissionsList />}
      </div>
    </div>
  );
};

/**
 * RolesAndPermissions
 *
 * Root component for the Roles & Permissions module.
 * Routes to the list view or the add form.
 *
 */
const RolesAndPermissions = () => {
  return (
    <Routes>
      <Route path="/" element={<RolesPermissionsMain />} />
      <Route
        path={ROUTES.FEATURES.MASTER.ROLES_AND_PERMISSIONS.ADD}
        element={<RolesPermissionsForm />}
      />
    </Routes>
  );
};

RolesAndPermissions.displayName = "RolesAndPermissions";
export default RolesAndPermissions;
