import RoleBadge from "../../../components/ui/badge/RoleBadge";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableRecordDeleteButton from "../../../components/ui/common/TableRecordDeleteButton";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { PERMISSIONS_TABLE_COLUMNS } from "../../../constants/tableHeaders";

/**
 * PermissionsTable
 *
 * Renders the permissions list table with loading skeletons, empty state, and per-row delete action.
 *
 * @param {object[]} permissions - Array of permission data objects.
 * @param {boolean} loading - Whether data is being fetched.
 * @param {string} error - Error message if fetch failed.
 * @param {string} search - Current search/filter description for empty state.
 * @param {number} page - Current page number for serial number calculation.
 * @param {number} pageSize - Current page size for serial number calculation.
 * @param {boolean} isDeleting - Whether a delete operation is in progress.
 * @param {function} onDeleteClick - Callback with permissionId when delete is triggered.
 */
const PermissionsTable = ({
  permissions = [],
  loading,
  error,
  search,
  page,
  pageSize,
  isDeleting,
  onDeleteClick,
}) => {
  return (
    <Table
      headers={PERMISSIONS_TABLE_COLUMNS}
      headerColorClass="bg-table-header-bg"
    >
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow
            key={i}
            columnsCount={PERMISSIONS_TABLE_COLUMNS.length}
          />
        ))
      ) : permissions.length === 0 && !error ? (
        <tr>
          <td colSpan={PERMISSIONS_TABLE_COLUMNS.length} className="h-full">
            <EmptyState
              title="No permissions found"
              description={
                search
                  ? `No results for "${search}". Try a different filter.`
                  : "No permissions have been configured yet."
              }
            />
          </td>
        </tr>
      ) : (
        permissions.map((permission, index) => (
          <tr
            key={permission.permissionId}
            className="hover:bg-slate-200/80 transition-colors"
          >
            <td className="table-td-middle">
              {(page - 1) * pageSize + index + 1}
            </td>
            <td className="table-td-center">
              <RoleBadge roleName={permission.roleName} />
            </td>
            <td className="table-td-middle">
              {permission.permissionName || "—"}
            </td>
            <td className="table-td-middle">{permission.description || "—"}</td>
            <td className="px-6 py-1 text-center">
              <TableRecordDeleteButton
                recordId={permission.permissionId}
                onDeleteClick={() =>
                  onDeleteClick({
                    permissionId: permission.permissionId,
                    permissionName: permission.permissionName,
                    roleName: permission.roleName,
                  })
                }
                isDeleting={isDeleting}
                label="Delete Permission"
                bypassPermissionCheck
              />
            </td>
          </tr>
        ))
      )}
    </Table>
  );
};

PermissionsTable.displayName = "PermissionsTable";
export default PermissionsTable;
