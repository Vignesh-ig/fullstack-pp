import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { createPermissionApi, getPermissionsApi } from "../../../api/apiConfig";
import RoleBadge from "../../../components/ui/badge/RoleBadge";
import ErrorBanner from "../../../components/ui/common/ErrorBanner";
import FormFooter from "../../../components/ui/common/FormFooter";
import SelectField from "../../../components/ui/common/SelectField";
import SelectFieldWithCheckbox from "../../../components/ui/common/SelectFieldWithCheckbox";
import SuccessBanner from "../../../components/ui/common/SuccessBanner";
import TextareaField from "../../../components/ui/common/TextareaField";
import { useRolesDropdown } from "../../../hooks/dropdowns/useRolesDropdown";
import { useApi } from "../../../hooks/useApi";
import { addPermissionSchema } from "../../../utils/schemas/configSchema";
import { toTitleCase } from "../../../utils/utils";

const AddPermissionForm = () => {
  const navigate = useNavigate();
  const { userId: currentUserId } = useSelector((state) => state.user);

  const [permissionOptions, setPermissionOptions] = useState([]);
  const [permissionsLoading, setPermissionsLoading] = useState(false);
  const [assignedPermissionsText, setAssignedPermissionsText] = useState("");

  // Tracks the navigate timer so it can be cleared on unmount
  const navTimerRef = useRef(null);

  // Clear the navigation timer when the component unmounts
  useEffect(() => {
    return () => {
      if (navTimerRef.current) clearTimeout(navTimerRef.current);
    };
  }, []);

  const { roleOptions, rolesLoading } = useRolesDropdown();

  const permForm = useForm({
    resolver: zodResolver(addPermissionSchema),
    defaultValues: { roleId: "", permissionNames: [] },
    mode: "onTouched",
  });

  const selectedRoleId = permForm.watch("roleId");

  useEffect(() => {
    if (!selectedRoleId) {
      setPermissionOptions([]);
      setAssignedPermissionsText("");
      return;
    }

    let isMounted = true;
    setPermissionsLoading(true);

    Promise.all([
      getPermissionsApi({
        page: 1,
        limit: 100,
        uniquePermissionsToRole: selectedRoleId,
      }),
      getPermissionsApi({
        page: 1,
        limit: 100,
        role: selectedRoleId,
      }),
    ])
      .then(([availableRes, assignedRes]) => {
        if (!isMounted) return;

        // Parse available permissions for the dropdown
        const list = availableRes?.data?.data || availableRes?.data || [];
        const optionsMap = new Map();
        list.forEach((p) => {
          if (p.permissionName && !optionsMap.has(p.permissionName)) {
            optionsMap.set(p.permissionName, {
              label: p.permissionName.replace(/_/g, " "),
              value: p.permissionName,
              description: p.description || "",
            });
          }
        });
        setPermissionOptions(Array.from(optionsMap.values()));

        // Parse assigned permissions for the read-only textarea
        const assignedList = assignedRes?.data?.data || assignedRes?.data || [];
        const assignedNames = assignedList
          .map((p) => p.permissionName?.replace(/_/g, " "))
          .filter(Boolean);

        setAssignedPermissionsText(
          assignedNames.length > 0
            ? assignedNames.map(toTitleCase).join(", ")
            : "No permissions are assigned to this role",
        );
      })
      .catch(() => {})
      .finally(() => {
        if (isMounted) setPermissionsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [selectedRoleId]);

  const {
    execute: createPermission,
    isLoading: isCreatingPerm,
    error: permApiError,
    setError: setPermApiError,
    isSuccess: permSuccess,
  } = useApi(createPermissionApi);

  const onPermSubmit = async (data) => {
    setPermApiError(null);

    const payload = data.permissionNames.map((name) => {
      const selectedOption = permissionOptions.find(
        (opt) => opt.value === name,
      );
      return {
        permissionName: name,
        description: selectedOption?.description || "",
        roleId: data.roleId,
        createdBy: currentUserId,
      };
    });
    const { error } = await createPermission(payload);
    if (!error) {
      navTimerRef.current = setTimeout(() => {
        navigate("..", { state: { defaultTab: "permissions" } });
      }, 1000);
    }
  };

  const isInputsDisabled = !selectedRoleId;

  return (
    <>
      <form
        id="perm-form"
        onSubmit={permForm.handleSubmit(onPermSubmit)}
        noValidate
        className="flex flex-col gap-4"
      >
        <SuccessBanner
          message={permSuccess ? "Permission added successfully!" : null}
        />
        <ErrorBanner
          message={permApiError}
          onClose={() => setPermApiError(null)}
        />

        <SelectField
          label="Select Role"
          name="roleId"
          value={permForm.watch("roleId")}
          onChange={(e) => {
            permForm.setValue("roleId", e.target.value, {
              shouldValidate: true,
            });
          }}
          onBlur={() => permForm.trigger("roleId")}
          options={roleOptions}
          placeholder={rolesLoading ? "Loading roles..." : "Select a role"}
          required
          error={permForm.formState.errors.roleId?.message}
          disabled={rolesLoading || isCreatingPerm || permSuccess}
          renderOption={(opt) =>
            opt.roleName ? (
              <RoleBadge roleName={opt.roleName} />
            ) : (
              <span className="text-sm text-text-secondary">{opt.label}</span>
            )
          }
        />

        <TextareaField
          label="Assigned Permissions"
          name="assignedPermissions"
          value={
            permissionsLoading
              ? "Loading assigned permissions..."
              : assignedPermissionsText
          }
          placeholder="Assigned permissions will appear here"
          readOnly
          disabled
          className="mb-0 text-text-secondary bg-gray-50"
        />

        <SelectFieldWithCheckbox
          label="Select Permission"
          name="permissionNames"
          value={permForm.watch("permissionNames")}
          onChange={(e) => {
            permForm.setValue("permissionNames", e.target.value, {
              shouldValidate: true,
            });
          }}
          onBlur={() => permForm.trigger("permissionNames")}
          options={permissionOptions}
          placeholder={
            permissionsLoading
              ? "Loading permissions..."
              : "Select a permission"
          }
          required
          error={permForm.formState.errors.permissionNames?.message}
          disabled={
            permissionsLoading ||
            isInputsDisabled ||
            isCreatingPerm ||
            permSuccess
          }
        />
      </form>
      <FormFooter
        buttons={[
          {
            label: isCreatingPerm ? "Saving..." : "Add Permission",
            props: {
              type: "button",
              onClick: () => permForm.handleSubmit(onPermSubmit)(),
              disabled:
                !permForm.formState.isValid || isCreatingPerm || permSuccess,
            },
          },
        ]}
      />
    </>
  );
};

export default AddPermissionForm;
