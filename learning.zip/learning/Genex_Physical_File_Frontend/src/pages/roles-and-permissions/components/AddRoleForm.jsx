import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { createRoleApi } from "../../../api/apiConfig";
import ErrorBanner from "../../../components/ui/common/ErrorBanner";
import FormFooter from "../../../components/ui/common/FormFooter";
import InputField from "../../../components/ui/common/InputField";
import SuccessBanner from "../../../components/ui/common/SuccessBanner";
import TextareaField from "../../../components/ui/common/TextareaField";
import { useApi } from "../../../hooks/useApi";
import { addRoleSchema } from "../../../utils/schemas/configSchema";

const AddRoleForm = () => {
  const navigate = useNavigate();
  const { userId: currentUserId } = useSelector((state) => state.user);

  // Tracks the navigate timer so it can be cleared on unmount
  const navTimerRef = useRef(null);

  // Clear the navigation timer when the component unmounts
  useEffect(() => {
    return () => {
      if (navTimerRef.current) clearTimeout(navTimerRef.current);
    };
  }, []);

  const roleForm = useForm({
    resolver: zodResolver(addRoleSchema),
    defaultValues: { roleName: "", description: "" },
    mode: "onTouched",
  });

  const {
    execute: createRole,
    isLoading: isCreatingRole,
    error: roleApiError,
    setError: setRoleApiError,
    isSuccess: roleSuccess,
  } = useApi(createRoleApi);

  const onRoleSubmit = async (data) => {
    setRoleApiError(null);
    const payload = {
      roleName: data.roleName.trim().toUpperCase(),
      description: data.description.trim(),
      createdBy: currentUserId,
    };
    const { error } = await createRole(payload);
    if (!error) {
      navTimerRef.current = setTimeout(() => {
        navigate("..", { state: { defaultTab: "roles" } });
      }, 1000);
    }
  };

  return (
    <>
      <form
        id="role-form"
        onSubmit={roleForm.handleSubmit(onRoleSubmit)}
        noValidate
        className="flex flex-col gap-4"
      >
        <SuccessBanner
          message={roleSuccess ? "Role added successfully!" : null}
        />
        <ErrorBanner
          message={roleApiError}
          onClose={() => setRoleApiError(null)}
        />

        <InputField
          label="Role Name"
          name="roleName"
          {...roleForm.register("roleName")}
          placeholder="Enter role name"
          required
          maxLength={50}
          error={roleForm.formState.errors.roleName?.message}
          disabled={isCreatingRole || roleSuccess}
          className="mb-0"
        />

        <TextareaField
          label="Description"
          name="description"
          {...roleForm.register("description")}
          placeholder="Enter role description"
          required
          maxLength={200}
          error={roleForm.formState.errors.description?.message}
          disabled={isCreatingRole || roleSuccess}
          className="mb-0"
        />
      </form>
      <FormFooter
        buttons={[
          {
            label: isCreatingRole ? "Saving..." : "Add Role",
            props: {
              type: "button",
              onClick: () => roleForm.handleSubmit(onRoleSubmit)(),
              disabled:
                !roleForm.formState.isValid || isCreatingRole || roleSuccess,
            },
          },
        ]}
      />
    </>
  );
};

export default AddRoleForm;
