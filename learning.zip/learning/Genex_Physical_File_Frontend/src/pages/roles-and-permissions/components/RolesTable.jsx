import RoleBadge from "../../../components/ui/badge/RoleBadge";
import EmptyState from "../../../components/ui/common/EmptyState";
import Table from "../../../components/ui/common/Table";
import TableRecordDeleteButton from "../../../components/ui/common/TableRecordDeleteButton";
import TableSkeletonRow from "../../../components/ui/common/TableSkeletonRow";
import { ROLES_TABLE_COLUMNS } from "../../../constants/tableHeaders";

/**
 * RolesTable
 *
 * Renders the roles list table with loading skeletons, empty state, and per-row delete action.
 *
 * @param {object[]} roles - Array of role data objects.
 * @param {boolean} loading - Whether data is being fetched.
 * @param {string} error - Error message if fetch failed.
 * @param {number} page - Current page number for serial number calculation.
 * @param {number} pageSize - Current page size for serial number calculation.
 * @param {boolean} isDeleting - Whether a delete operation is in progress.
 * @param {function} onDeleteClick - Callback with roleId when delete is triggered.
 */
const RolesTable = ({
  roles = [],
  loading,
  error,
  page,
  pageSize,
  isDeleting,
  onDeleteClick,
}) => {
  return (
    <Table headers={ROLES_TABLE_COLUMNS} headerColorClass="bg-table-header-bg">
      {loading ? (
        Array.from({ length: 10 }).map((_, i) => (
          <TableSkeletonRow key={i} columnsCount={ROLES_TABLE_COLUMNS.length} />
        ))
      ) : roles.length === 0 && !error ? (
        <tr>
          <td colSpan={ROLES_TABLE_COLUMNS.length} className="h-full">
            <EmptyState
              title="No roles found"
              description="No roles have been configured yet."
            />
          </td>
        </tr>
      ) : (
        roles.map((role, index) => (
          <tr
            key={role.roleId}
            className="hover:bg-slate-200/80 transition-colors"
          >
            <td className="table-td-middle">
              {(page - 1) * pageSize + index + 1}
            </td>
            <td className="table-td-center">
              <RoleBadge roleName={role.roleName} />
            </td>
            <td className="table-td-middle">{role.description || "—"}</td>
            <td className="px-6 py-1 text-center">
              <TableRecordDeleteButton
                recordId={role.roleId}
                onDeleteClick={() =>
                  onDeleteClick({
                    roleId: role.roleId,
                    roleName: role.roleName,
                  })
                }
                isDeleting={isDeleting}
                label="Delete Role"
                bypassPermissionCheck
              />
            </td>
          </tr>
        ))
      )}
    </Table>
  );
};

RolesTable.displayName = "RolesTable";
export default RolesTable;
