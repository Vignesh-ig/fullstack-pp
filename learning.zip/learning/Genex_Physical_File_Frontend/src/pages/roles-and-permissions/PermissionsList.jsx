import { useCallback, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { deletePermissionApi, getPermissionsApi } from "../../api/apiConfig";
import ListContainer from "../../components/layout/ListContainer";
import ListHeader from "../../components/layout/ListHeader";
import RoleBadge from "../../components/ui/badge/RoleBadge";
import ConfirmationDialog from "../../components/ui/common/ConfirmationDialog";
import ErrorBanner from "../../components/ui/common/ErrorBanner";
import FilterSelectField from "../../components/ui/common/FilterSelectField";
import Pagination from "../../components/ui/common/Pagination";
import SuccessBanner from "../../components/ui/common/SuccessBanner";
import { useRolesDropdown } from "../../hooks/dropdowns/useRolesDropdown";
import { useDeleteHandler } from "../../hooks/useDeleteHandler";
import usePaginatedFetch from "../../hooks/usePaginatedFetch";
import PermissionsTable from "./components/PermissionsTable";

/**
 * PermissionsList
 *
 * Container component for the Permissions page.
 * Handles fetching, searching, role filtering, paginating, and deleting permissions.
 * Shows a confirmation dialog before deletion and a success dialog after.
 */
const PermissionsList = () => {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const [roleFilter, setRoleFilter] = useState("");

  const { roleOptions: filterRoleOptions } = useRolesDropdown({
    formatForSelect: true,
  });

  const fetchFn = useCallback(
    async (params) => {
      const { searchByName, ...restParams } = params;
      return getPermissionsApi({
        ...restParams,
        ...(roleFilter ? { role: roleFilter } : {}),
        ...(searchByName ? { likePermissionName: searchByName } : {}),
      });
    },
    [roleFilter],
  );

  const {
    data: permissions,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize,
    search,
    setSearch,
    refetch,
  } = usePaginatedFetch(fetchFn, 10, "searchByName");

  const {
    pendingDelete,
    deletedItemInfo,
    isDeleting,
    deleteError,
    handleDeleteRequest,
    handleConfirmDelete,
    handleCancelDelete,
    clearDeleteError,
  } = useDeleteHandler(deletePermissionApi, async () => {
    refetch();
    if (page > 1 && permissions.length <= 1) {
      setPage((prev) => Math.max(1, prev - 1));
    }
  });

  const handleRoleFilterChange = (e) => {
    setRoleFilter(e.target.value);
    setPage(1);
  };

  const handleRefresh = () => {
    setRoleFilter("");
    refetch();
  };

  const handleAddClick = () => {
    const base = pathname.endsWith("/") ? pathname.slice(0, -1) : pathname;
    navigate(`${base}/add`, { state: { defaultTab: "permission" } });
  };

  const searchDesc = [
    search ? `Permission: "${search}"` : "",
    roleFilter
      ? `Role: ${filterRoleOptions.find((o) => o.value === roleFilter)?.label || ""}`
      : "",
  ]
    .filter(Boolean)
    .join(", ");

  return (
    <ListContainer>
      <ListHeader
        title="Permission"
        unit="permissions"
        count={pagination.totalItems}
        loading={loading}
        searchPlaceholder="Search by permission name"
        search={search}
        setSearch={setSearch}
        refetch={handleRefresh}
        addLabel="Add Roles & Permissions"
        onAddClick={handleAddClick}
      >
        <div className="mt-4 grid grid-cols-1 sm:flex sm:flex-row items-start sm:items-center gap-3 sm:gap-5 w-full">
          <FilterSelectField
            label="Filter by role:"
            name="roleFilter"
            value={roleFilter}
            onChange={handleRoleFilterChange}
            placeholder="All Roles"
            options={filterRoleOptions}
            className="w-full sm:w-auto"
            renderOption={(opt) => <RoleBadge roleName={opt.roleName} />}
            renderSelected={(opt) => <RoleBadge roleName={opt.roleName} />}
          />
        </div>
      </ListHeader>

      {/* ── Banners ── */}
      {(error || deleteError || deletedItemInfo) && (
        <section className="px-6 pt-4 space-y-3">
          {deletedItemInfo && (
            <SuccessBanner
              message={
                <span>
                  You have successfully deleted{" "}
                  <strong>
                    &ldquo;{deletedItemInfo?.permissionName}&rdquo;
                  </strong>{" "}
                  for <RoleBadge roleName={deletedItemInfo?.roleName} />.
                </span>
              }
            />
          )}
          {(error || deleteError) && (
            <ErrorBanner
              message={deleteError || error}
              onClose={() => {
                setError(null);
                clearDeleteError();
              }}
            />
          )}
        </section>
      )}

      <PermissionsTable
        permissions={permissions}
        loading={loading}
        error={error}
        search={searchDesc}
        page={page}
        pageSize={pageSize}
        isDeleting={isDeleting}
        onDeleteClick={handleDeleteRequest}
      />

      {/* ── Pagination ── */}
      <Pagination
        currentPage={pagination.currentPage}
        totalPages={pagination.totalPages}
        onPageChange={setPage}
        totalItems={pagination.totalItems}
        pageSize={pageSize}
        onPageSizeChange={setPageSize}
      />

      <ConfirmationDialog
        isOpen={!!pendingDelete}
        content={
          <span>
            Are you sure you want to delete{" "}
            <strong className="wrap-break-word">
              &ldquo;{pendingDelete?.permissionName}&rdquo;
            </strong>{" "}
            for <RoleBadge roleName={pendingDelete?.roleName} /> ?
          </span>
        }
        confirmText="Delete"
        onConfirm={() => handleConfirmDelete("permissionId")}
        onCancel={handleCancelDelete}
        isSubmitting={isDeleting}
      />
    </ListContainer>
  );
};

PermissionsList.displayName = "PermissionsList";
export default PermissionsList;
