import { forwardRef } from "react";

/**
 * DropdownPanel
 *
 * Wrapper for the select dropdown listbox. Handles absolute positioning, top/bottom collision detection animations, and ARIA attributes for accessibility.
 *
 * @param {boolean} props.isOpen - Whether the dropdown panel is visible.
 * @param {string} props.position - Dropdown position relative to trigger ("top" or "bottom").
 * @param {function} props.onMouseDown - Click handler to prevent focus loss via stopPropagation.
 * @param {ReactNode} props.children - Content rendered inside the panel.
 * @param {string} props.id - HTML ID for the listbox container (accessibility).
 * @param {string} props.ariaActiveDescendant - ID of the currently focused option (accessibility).
 * @param {Ref} props.ref - Forwarded ref attached to the dropdown container.
 */
const DropdownPanel = forwardRef(
  (
    { isOpen, position, onMouseDown, children, id, ariaActiveDescendant },
    ref,
  ) => {
    if (!isOpen) return null;

    return (
      <div
        ref={ref}
        id={id}
        role="listbox"
        aria-multiselectable="true"
        aria-activedescendant={ariaActiveDescendant}
        onMouseDown={onMouseDown}
        className={`absolute left-0 w-full z-40 bg-white border border-border-main rounded-xl shadow-2xl overflow-hidden flex flex-col ${
          position === "top"
            ? "bottom-full mb-2 animate-in fade-in slide-in-from-bottom-2 duration-200"
            : "top-full mt-2 animate-in fade-in slide-in-from-top-2 duration-200"
        }`}
      >
        {children}
      </div>
    );
  },
);

DropdownPanel.displayName = "DropdownPanel";
export default DropdownPanel;
