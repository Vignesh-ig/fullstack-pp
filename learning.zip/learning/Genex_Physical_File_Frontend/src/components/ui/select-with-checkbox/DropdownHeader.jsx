import { useSelectContext } from "../../../context/SelectContext";
import { CheckmarkSolidIcon } from "../../icons/icons";

/**
 * DropdownHeader
 *
 * Header component for the dropdown panel. Displays the selected count and a bulk "Select all" / "Unselect all" toggle action. Uses SelectContext to avoid prop drilling.
 *
 */
const DropdownHeader = ({ showSelectAll = true }) => {
  const {
    selectedCount,
    options,
    totalItems,
    isAllLoadedSelected,
    handleGlobalToggle,
    showSearch = true,

  } = useSelectContext();

  return (
    <div
      className={`px-4 py-1 border-b border-border-main grid grid-cols-3 items-center bg-surface-tertiary/60 sticky ${showSearch ? "top-13" : "top-0"} z-10`}
    >
      <span className="text-xs font-bold text-text-secondary tracking-wider uppercase">
        {selectedCount} Selected
      </span>

      <div className="text-center">
        {totalItems != null && (
          <>
            <span
              className={`text-xs font-medium ${options.length === totalItems ? "text-brand-accent" : "text-text-secondary"} whitespace-nowrap`}
            >
              {options.length}
            </span>
            <span className="text-xs font-medium text-text-secondary whitespace-nowrap">
              {" "}
              of {totalItems} Loaded
            </span>
          </>
        )}
      </div>

      <div className="flex justify-end">
        {showSelectAll && options.length > 0 && (
          <label className="flex items-center gap-2 group/all cursor-pointer select-none">
            <input
              type="checkbox"
              className="sr-only"
              checked={isAllLoadedSelected}
              onChange={handleGlobalToggle}
              aria-label={
                isAllLoadedSelected
                  ? "Unselect all loaded options"
                  : "Select all loaded options"
              }
            />
            <span className="text-xs font-semibold text-text-secondary group-hover/all:text-brand-accent transition-colors">
              {isAllLoadedSelected ? "Unselect all" : "Select all"}
            </span>
            <span
              className={`shrink-0 w-4 h-4 rounded border-2 flex items-center justify-center transition-all ${
                isAllLoadedSelected
                  ? "bg-brand-accent border-brand-accent"
                  : "border-border-main bg-white group-hover/all:border-brand-accent/50"
              }`}
            >
              {isAllLoadedSelected && (
                <CheckmarkSolidIcon className="w-2.5 h-2.5 text-white" />
              )}
            </span>
          </label>
        )}
      </div>
    </div>
  );
};

DropdownHeader.displayName = "DropdownHeader";
export default DropdownHeader;
