import { useEffect, useRef } from "react";
import { Virtuoso } from "react-virtuoso";
import { useSelectContext } from "../../../context/SelectContext";
import { SpinnerIcon } from "../../icons/icons";
import OptionItem from "./OptionItem";

Virtuoso.displayName = "Virtuoso";

/**
 * OptionList
 *
 * Renders the scrollable list of OptionItems using react-virtuoso. Gets its state from SelectContext to avoid prop drilling.
 *
 */
const OptionList = () => {
  const {
    options,
    hasMore,
    isLoadingMore,
    fetchError,
    localSearch,
    onLoadMore,
    focusedIndex,
  } = useSelectContext();

  const virtuosoRef = useRef(null);

  useEffect(() => {
    if (focusedIndex >= 0 && virtuosoRef.current) {
      virtuosoRef.current.scrollToIndex({
        index: focusedIndex,
        align: "center",
      });
    }
  }, [focusedIndex]);

  const renderItemContent = (index, opt) => (
    <OptionItem index={index} opt={opt} />
  );

  return (
    <div className="h-52 flex flex-col py-1">
      <div className="flex-1 min-h-0">
        {options.length === 0 && !isLoadingMore ? (
          <div className="px-4 py-4 text-sm text-text-secondary italic text-center">
            {fetchError
              ? "Could not load options."
              : localSearch
                ? `No results for "${localSearch}"`
                : "No options available"}
          </div>
        ) : (
          <Virtuoso
            ref={virtuosoRef}
            className="h-full w-full"
            data={options}
            computeItemKey={(index, item) => item.value}
            endReached={() => {
              if (hasMore && !isLoadingMore && !fetchError) {
                onLoadMore?.();
              }
            }}
            itemContent={renderItemContent}
            components={{
              Footer: ListFooter,
            }}
          />
        )}
      </div>
    </div>
  );
};

/**
 * ListFooter
 *
 * Renders the loading indicator at the bottom of the virtualized list.
 */
const ListFooter = () => {
  const { hasMore, fetchError, isLoadingMore } = useSelectContext();

  if (!hasMore || fetchError) return <div className="h-1 shrink-0" />;

  return (
    <>
      <div className="flex items-center justify-center py-3 gap-2 text-xs text-text-secondary">
        {isLoadingMore && (
          <>
            <SpinnerIcon className="w-4 h-4 text-brand-accent" />
            Loading
          </>
        )}
      </div>
    </>
  );
};
ListFooter.displayName = "ListFooter";

OptionList.displayName = "OptionList";
export default OptionList;
