import { memo } from "react";
import { useSelectContext } from "../../../context/SelectContext";
import { CheckmarkSolidIcon } from "../../icons/icons";

/**
 * OptionItemContent
 *
 * Renders individual checkbox list item content.
 *
 * @param {Object} opt - Option object containing label and value.
 * @param {number} index - Option item index.
 */
const OptionItemContent = ({ opt, index }) => {
  const { safeValue, handleToggle, focusedIndex, listboxId } =
    useSelectContext();

  const isChecked = safeValue.includes(opt.value);
  const isFocused = index === focusedIndex;
  const id = `${listboxId}-option-${index}`;

  return (
    <div
      id={id}
      role="option"
      aria-selected={isChecked}
      aria-disabled={opt.disabled}
      onClick={() => {
        if (!opt.disabled) handleToggle(opt.value);
      }}
      onKeyDown={(e) => {
        if (!opt.disabled && (e.key === "Enter" || e.key === " ")) {
          handleToggle(opt.value);
        }
      }}
      className={`w-full px-4 py-2.5 text-left text-sm transition-colors flex items-center gap-3 select-none relative ${
        opt.disabled
          ? "opacity-50 cursor-not-allowed"
          : isChecked
            ? "bg-brand-primary/5 text-brand-primary cursor-pointer"
            : "text-text-primary hover:bg-surface-tertiary cursor-pointer"
      } ${isFocused && !opt.disabled ? "bg-surface-tertiary ring-2 ring-inset ring-brand-accent/20" : ""}`}
    >
      {/* Custom checkbox visual */}
      <span
        className={`shrink-0 w-4 h-4 rounded border-2 flex items-center justify-center transition-all ${
          isChecked
            ? opt.disabled
              ? "bg-brand-accent/50 border-brand-accent/50"
              : "bg-brand-accent border-brand-accent"
            : "border-border-main bg-white"
        }`}
      >
        {isChecked && <CheckmarkSolidIcon className="w-2.5 h-2.5 text-white" />}
      </span>
      <span className={isChecked ? "font-semibold" : "font-normal"}>
        {opt.label}
      </span>
    </div>
  );
};

OptionItemContent.displayName = "OptionItemContent";

const OptionItem = memo(OptionItemContent);
OptionItem.displayName = "OptionItem";

export default OptionItem;
