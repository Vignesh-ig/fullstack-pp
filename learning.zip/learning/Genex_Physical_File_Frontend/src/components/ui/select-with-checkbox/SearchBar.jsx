import { forwardRef } from "react";
import { useSelectContext } from "../../../context/SelectContext";
import { SearchIcon, SpinnerIcon } from "../../icons/icons";
import ClearSearchButton from "../common/ClearSearchButton";

/**
 * SearchBar
 *
 * Search input component for dropdowns. Includes a clear button and a loading spinner. Uses SelectContext if available, or accepts props.
 *
 * @param {string} [props.value] - Controlled search input value.
 * @param {function} [props.onChange] - Callback on input value change.
 * @param {boolean} [props.isLoadingMore] - Whether to show the loading spinner inside search input.
 * @param {string} [props.placeholder] - Placeholder text for search input.
 * @param {function} [props.onClear] - Callback on clearing search input.
 * @param {Ref} props.ref - Forwarded input element ref.
 */
const SearchBar = forwardRef(
  (
    { value, onChange, isLoadingMore: propIsLoadingMore, placeholder, onClear },
    ref,
  ) => {
    const context = useSelectContext();

    const localSearch =
      value !== undefined ? value : (context?.localSearch ?? "");
    const setLocalSearch = onChange || context?.setLocalSearch;
    const isLoadingMore =
      propIsLoadingMore !== undefined
        ? propIsLoadingMore
        : (context?.isLoadingMore ?? false);
    const searchPlaceholder =
      placeholder !== undefined
        ? placeholder
        : (context?.searchPlaceholder ?? "Search");
    const searchInputRef = context?.searchInputRef;

    const handleClear = () => {
      if (onClear) {
        onClear();
      } else if (setLocalSearch) {
        setLocalSearch("");
      }
      const inputEl =
        (ref && "current" in ref ? ref.current : ref) ||
        searchInputRef?.current;
      if (inputEl && typeof inputEl.focus === "function") {
        inputEl.focus();
      }
    };

    const handleInputChange = (e) => {
      if (setLocalSearch) {
        setLocalSearch(e.target.value);
      }
    };

    return (
      <div className="px-3 pt-2.5 pb-2 border-b border-border-main bg-white sticky top-0 z-20">
        <div className="relative flex items-center gap-2 px-2.5 py-1.5 bg-surface-tertiary border border-border-main rounded-lg focus-within:ring-2 focus-within:ring-brand-accent/20 focus-within:border-brand-accent transition-all">
          <SearchIcon className="w-3.5 h-3.5 text-text-secondary shrink-0" />
          <input
            ref={ref || searchInputRef}
            type="text"
            value={localSearch}
            onChange={handleInputChange}
            placeholder={searchPlaceholder}
            className="flex-1 bg-transparent text-sm text-text-primary placeholder-text-secondary outline-none"
            aria-label="Search options"
          />
          {isLoadingMore && localSearch && (
            <SpinnerIcon className="w-3.5 h-3.5 text-brand-accent shrink-0" />
          )}
          {!isLoadingMore && localSearch && (
            <ClearSearchButton onClick={handleClear} />
          )}
        </div>
      </div>
    );
  },
);

SearchBar.displayName = "SearchBar";
export default SearchBar;
