import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useState } from "react";
import { Controller, useForm, useWatch } from "react-hook-form";
import { getQueryCategoriesApi } from "../../../api/apiConfig";
import { APP_STAGES } from "../../../constants/stages";
import { useDebounce } from "../../../hooks/useDebounce";
import { useTransactionStageLogic } from "../../../hooks/useTransactionStageLogic";
import { REGEX } from "../../../utils/validation/regex";
import Button from "../common/Button";
import ErrorBanner from "../common/ErrorBanner";
import InputField from "../common/InputField";
import SearchableSelectField from "../common/SearchableSelectField";
import SelectField from "../common/SelectField";
import TextareaField from "../common/TextareaField";

/**
 * TransactionUpdateForm
 *
 * Shared "Update Status" form used by both the Query and Health Check detail pages.
 * Controlled entirely via props so each feature can configure its own field behaviour
 * without duplicating form markup.
 *
 * @param {Function} onSubmit                 - Submission handler for the form.
 * @param {boolean} isSaving                  - Whether the form is currently submitting.
 * @param {Array} queryOptions                - Options for the Decision Update dropdown.
 * @param {Array} stageOptions                - Options for the Stage dropdown.
 * @param {Object} schema                     - Zod schema for useForm validation.
 * @param {boolean} [isDecisionRequired=false]- Whether the Decision Update field is required.
 * @param {boolean} [isDecisionDisabled=false]- Whether the Decision Update field is disabled.
 * @param {boolean} [isStageRequired=false]   - Whether the Stage field is required.
 * @param {boolean} [isHealthCheck=false]     - Whether the current flow is Health Check.
 * @param {boolean} [isNonCriticalQuery=false]- Whether the current flow is Non Critical Query.
 * @param {boolean} [hideStage=false]         - Whether to hide the Stage field entirely.
 * @param {Object|null} [currentRecord=null]  - The active transaction/file record.
 * @param {string} [priorRemarks]             - Prior remarks string to display as read-only.
 * @param {string} [priorRemarksLabel]        - Label for prior remarks field.
 * @param {string} [formId]                   - HTML form id attribute.
 * @param {boolean} [isQuery=false]           - Whether the current flow is Query.
 * @param {string|null} [globalError]         - Global submission error message.
 */
const TransactionUpdateForm = ({
  onSubmit,
  isSaving,
  queryOptions,
  stageOptions,
  schema,
  isDecisionRequired = false,
  isDecisionDisabled = false,
  isStageRequired = false,
  isHealthCheck = false,
  isNonCriticalQuery = false,
  isQuery = false,
  hideStage = false,
  currentRecord = null,
  priorRemarks,
  priorRemarksLabel = "Health Check Remarks",
  formId = "transactionUpdateForm",
  globalError,
}) => {
  const {
    control,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm({
    mode: "onBlur",
    resolver: zodResolver(schema),
    defaultValues: {
      decisionUpdate: "",
      stageId: "",
      currentRemarks: "",
      missingPodNo: "",
      queryCategoryId: "",
      querySubCategoryId: [],
      queryCartonBarcode: "",
    },
  });

  const [queryCategoryOptions, setQueryCategoryOptions] = useState([]);

  const [querySubCategoryOptions, setQuerySubCategoryOptions] = useState([]);
  const [isSubCategoryLoading, setIsSubCategoryLoading] = useState(false);
  const [queryCategorySearchTerm, setQueryCategorySearchTerm] = useState("");

  const debouncedQueryCategorySearchTerm = useDebounce(
    queryCategorySearchTerm,
    500,
  );

  // useEffect(() => {
  //   if (isHealthCheck) {
  //     getQueryCategoriesApi({
  //       page: 1,
  //       limit: 500,
  //       ...(debouncedQueryCategorySearchTerm
  //         ? { queryCategoryName: debouncedQueryCategorySearchTerm }
  //         : {}),
  //     })
  //       .then((res) => {
  //         const items = res?.data?.data || [];
  //         setQueryCategoryOptions(
  //           items.map((item) => ({
  //             label: item.queryCategoryName,
  //             value: item.queryCategoryId,
  //             description: item.queryCategoryDescription,
  //           })),
  //         );
  //       })
  //       .catch((err) => console.error("Failed to fetch query categories", err));
  //   }
  // }, [isHealthCheck, debouncedQueryCategorySearchTerm]);

  useEffect(() => {
    if (!isHealthCheck) return;

    getQueryCategoriesApi({
      page: 1,
      limit: 500,
      queryCategoryName: "UNIQUE",
      ...(debouncedQueryCategorySearchTerm
        ? {
            queryCategoryName: debouncedQueryCategorySearchTerm,
          }
        : {}),
    })
      .then((res) => {
        const items = res?.data?.data || [];

        // Show each Query Category only once
        const uniqueCategories = Array.from(
          new Map(
            items.map((item) => [
              item.queryCategoryName,
              {
                label: item.queryCategoryName,
                value: item.queryCategoryName,
                queryCategoryType: item.queryCategoryType,
              },
            ]),
          ).values(),
        );

        setQueryCategoryOptions(uniqueCategories);
      })
      .catch((err) => {
        console.error("Failed to fetch query categories", err);
        setQueryCategoryOptions([]);
      });
  }, [isHealthCheck, debouncedQueryCategorySearchTerm]);

  const currentRemarks = useWatch({
    control,
    name: "currentRemarks",
    defaultValue: "",
  });

  const selectedQueryCategory = useWatch({
    control,
    name: "queryCategoryId",
    defaultValue: "",
  });

  const selectedDecisionUpdate = useWatch({
    control,
    name: "decisionUpdate",
    defaultValue: "",
  });

  const selectedDecisionOption = queryOptions?.find(
    (option) => option.value === selectedDecisionUpdate,
  );

  const selectedStageId = useWatch({
    control,
    name: "stageId",
    defaultValue: "",
  });

  const selectedStageOption = stageOptions?.find(
    (option) => option.value === selectedStageId,
  );

  const isCompleted = selectedDecisionOption?.label === "Completed";
  const isOutwardStage = selectedStageOption?.rawName === APP_STAGES.OUTWARD;

  // Clear query category and sub category when decision update is completed and stage is outward
  useEffect(() => {
    if (isCompleted && isOutwardStage) {
      if (selectedQueryCategory) {
        setValue("queryCategoryId", "", {
          shouldValidate: true,
          shouldDirty: true,
        });
      }
      setValue("querySubCategoryId", [], {
        shouldValidate: true,
        shouldDirty: true,
      });
      setQuerySubCategoryOptions([]);
    }
  }, [isCompleted, isOutwardStage, setValue, selectedQueryCategory]);

  const { isStageDisabled } = useTransactionStageLogic(
    watch,
    setValue,
    queryOptions,
    stageOptions,
    isHealthCheck,
    isNonCriticalQuery,
    currentRecord,
  );

  // Show acknowledgement only on Health Check page when the record's current stage is QUERY_RESOLVED.
  const isQueryResolved =
    isHealthCheck &&
    currentRecord?.stage?.stageName === APP_STAGES.QUERY_RESOLVED;

  //  const fetchQuerySubCategories = async (categoryName) => {
  //   if (!categoryName) {
  //     setQuerySubCategoryOptions([]);
  //     return;
  //   }

  //   try {
  //     setIsSubCategoryLoading(true);

  //     const res = await getQueryCategoriesApi({
  //       page: 1,
  //       limit: 250,
  //       queryCategoryName: categoryName,
  //     });

  //     const items = res?.data?.data || [];

  //     setQuerySubCategoryOptions(
  //       items
  //         .filter((item) => item.queryCategoryDescription)
  //         .map((item) => ({
  //           label: item.queryCategoryDescription,
  //           value: item.queryCategoryId,
  //         })),
  //     );
  //   } catch (error) {
  //     console.error("Failed to fetch query sub categories", error);
  //     setQuerySubCategoryOptions([]);
  //   } finally {
  //     setIsSubCategoryLoading(false);
  //   }
  // };

  const fetchQuerySubCategories = async (categoryNames) => {
    if (!categoryNames?.length) {
      setQuerySubCategoryOptions([]);
      return;
    }

    try {
      setIsSubCategoryLoading(true);

      const responses = await Promise.all(
        categoryNames.map((categoryName) =>
          getQueryCategoriesApi({
            page: 1,
            limit: 250,
            queryCategoryName: categoryName,
          }),
        ),
      );

      const allItems = responses.flatMap((res) => res?.data?.data || []);

      const uniqueSubCategories = Array.from(
        new Map(
          allItems
            .filter((item) => item.queryCategoryDescription)
            .map((item) => [
              item.queryCategoryId,
              {
                label: item.queryCategoryDescription,
                value: item.queryCategoryId,
                queryCategoryName: item.queryCategoryName,
                queryCategoryType: item.queryCategoryType,
              },
            ]),
        ).values(),
      );

      setQuerySubCategoryOptions(uniqueSubCategories);
    } catch (error) {
      console.error("Failed to fetch query sub categories", error);

      setQuerySubCategoryOptions([]);
    } finally {
      setIsSubCategoryLoading(false);
    }
  };

  return (
    <form
      id={formId}
      onSubmit={handleSubmit(onSubmit)}
      className="bg-white p-6 rounded-xl border border-border-main flex flex-col gap-5 shadow-sm"
    >
      <legend className="text-sm font-bold text-text-secondary uppercase tracking-wider mb-2">
        Update Status
      </legend>

      {/* Global error from submission */}
      {globalError && <ErrorBanner message={globalError} />}

      <fieldset className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Decision Update */}
        <Controller
          name="decisionUpdate"
          control={control}
          render={({ field: { onChange, value, ...rest } }) => (
            <SelectField
              {...rest}
              value={value}
              onChange={(val) => {
                onChange(val);
              }}
              label="Decision Update"
              options={queryOptions}
              required={isDecisionRequired}
              disabled={isDecisionDisabled}
              error={errors.decisionUpdate?.message}
              className="mb-0"
            />
          )}
        />

        {/* Stage */}
        {!hideStage && !isNonCriticalQuery && (
          <Controller
            name="stageId"
            control={control}
            render={({ field: { onChange, value, ...rest } }) => (
              <SelectField
                {...rest}
                value={value}
                onChange={(val) => onChange(val)}
                label="Stage"
                options={stageOptions}
                required={isStageRequired}
                disabled={isStageDisabled}
                error={errors.stageId?.message}
                className="mb-0"
              />
            )}
          />
        )}

        {/* Query POD No — only visible for Query flow */}
        {isQuery && (
          <Controller
            name="missingPodNo"
            control={control}
            render={({ field: { onChange, ...rest } }) => (
              <InputField
                {...rest}
                onChange={(e) => {
                  const val = e.target.value;
                  if (val === "" || REGEX.ALPHANUMERIC.test(val)) {
                    onChange(e);
                  }
                }}
                label="Query POD No"
                required={false}
                maxLength={25}
                error={errors.missingPodNo?.message}
                className="mb-0"
              />
            )}
          />
        )}

        {/* Carton Barcode — only visible for Query Resolved */}
        {isQueryResolved && (
          <Controller
            name="queryCartonBarcode"
            control={control}
            render={({ field: { onChange, ...rest } }) => (
              <InputField
                {...rest}
                onChange={(e) => {
                  const val = e.target.value;

                  if (val === "" || REGEX.ALPHANUMERIC.test(val)) {
                    onChange(e);
                  }
                }}
                label="Carton Barcode"
                required={false}
                maxLength={25}
                error={errors.queryCartonBarcode?.message}
                className="mb-0"
              />
            )}
          />
        )}

        {isHealthCheck && !isCompleted && (
          <Controller
            name="queryCategoryId"
            control={control}
            render={({ field: { onChange, value, ...rest } }) => (
              <SearchableSelectField
                {...rest}
                value={value}
                onChange={(selectedOption) => {
                  const categoryName = selectedOption?.value || "";

                  // Query Category is SINGLE SELECT.
                  // Selecting a new category replaces the previous one.
                  onChange(categoryName);

                  // Automatically map queryCategoryType to Decision Update
                  const categoryType =
                    selectedOption?.queryCategoryType || "CRITICAL_QUERY";
                  const matchedDecision = queryOptions?.find(
                    (opt) => opt.rawName === categoryType,
                  );

                  if (matchedDecision) {
                    setValue("decisionUpdate", matchedDecision.value, {
                      shouldValidate: true,
                      shouldDirty: true,
                    });
                  }

                  // Clear previous sub-category selections.
                  setValue("querySubCategoryId", [], {
                    shouldValidate: true,
                    shouldDirty: true,
                  });

                  // Clear previous sub-category options.
                  setQuerySubCategoryOptions([]);

                  // Load sub-categories for the newly selected category.
                  if (categoryName) {
                    fetchQuerySubCategories([categoryName]);
                  }
                }}
                label="Query Category"
                options={queryCategoryOptions}
                required={false}
                error={errors.queryCategoryId?.message}
                className="mb-0"
                placeholder="Select Query Category"
                searchTerm={queryCategorySearchTerm}
                onSearchChange={setQueryCategorySearchTerm}
                dropdownScrollX={true}
              />
            )}
          />
        )}

        {isHealthCheck && !isCompleted && (
          <div className="lg:col-span-2">
            <Controller
              name="querySubCategoryId"
              control={control}
              render={({ field: { onChange, value, ...rest } }) => (
                <SearchableSelectField
                  {...rest}
                  value={value}
                  onChange={(selectedOptions) => {
                    const selectedSubCategoryIds = selectedOptions.map(
                      (opt) => opt.value,
                    );

                    // Store selected Sub Category IDs
                    onChange(selectedSubCategoryIds);

                    // Create Category - Sub Category format
                    const selectedRemarks = selectedOptions.map((opt) => {
                      return `${opt.queryCategoryName} - ${opt.label}`;
                    });

                    // Keep previous remarks
                    const existingRemarks = currentRemarks || "";

                    const existingRemarksList = existingRemarks
                      .split("\n")
                      .map((item) => item.trim())
                      .filter(Boolean);

                    // Add new remarks without duplicates
                    const combinedRemarks = Array.from(
                      new Set([...existingRemarksList, ...selectedRemarks]),
                    ).join("\n");

                    setValue("currentRemarks", combinedRemarks, {
                      shouldValidate: true,
                      shouldDirty: true,
                    });

                    // Evaluate queryCategoryType across all selected sub-categories
                    if (selectedOptions.length > 0) {
                      const hasCritical = selectedOptions.some(
                        (opt) => opt.queryCategoryType !== "NON_CRITICAL_QUERY",
                      );

                      const newType = hasCritical
                        ? "CRITICAL_QUERY"
                        : "NON_CRITICAL_QUERY";

                      const matchedDecision = queryOptions?.find(
                        (opt) => opt.rawName === newType,
                      );

                      if (matchedDecision) {
                        setValue("decisionUpdate", matchedDecision.value, {
                          shouldValidate: true,
                          shouldDirty: true,
                        });
                      }
                    } else {
                      // If no subcategories selected, fallback to the main category's type
                      const mainCategoryOption = queryCategoryOptions?.find(
                        (opt) => opt.value === selectedQueryCategory,
                      );
                      const fallbackType =
                        mainCategoryOption?.queryCategoryType ||
                        "CRITICAL_QUERY";

                      const matchedFallbackDecision = queryOptions?.find(
                        (opt) => opt.rawName === fallbackType,
                      );

                      if (matchedFallbackDecision) {
                        setValue(
                          "decisionUpdate",
                          matchedFallbackDecision.value,
                          {
                            shouldValidate: true,
                            shouldDirty: true,
                          },
                        );
                      }
                    }
                  }}
                  label="Query Sub Category"
                  options={querySubCategoryOptions}
                  error={errors.querySubCategoryId?.message}
                  className="mb-0"
                  placeholder={
                    isSubCategoryLoading
                      ? "Loading..."
                      : "Select Query Sub Category"
                  }
                  disabled={!selectedQueryCategory || isSubCategoryLoading}
                  multiSelect
                  dropdownScrollX={true}
                />
              )}
            />
          </div>
        )}
      </fieldset>

      {/* Remarks — prior stage read-only + current editable */}

      <div className="flex flex-col">
        {priorRemarks && (
          <TextareaField
            label={priorRemarksLabel}
            value={priorRemarks}
            disabled
            className="mb-4"
          />
        )}

        <Controller
          name="currentRemarks"
          control={control}
          render={({ field }) => (
            <TextareaField
              {...field}
              label="Remarks"
              required
              maxLength={500}
              error={errors.currentRemarks?.message}
              className="mb-4 min-h-12.5"
            />
          )}
        />
      </div>

      <footer className={`mt-2 flex items-center justify-end gap-4`}>
        {/* {isQueryResolved && (
        // ${isQueryResolved ? "justify-between" : "justify-end"}
          <label className="flex items-center gap-2 cursor-pointer select-none text-sm text-text-secondary">
            <input
              type="checkbox"
              id="acknowledgement"
              className="w-5 h-5 shrink-0 rounded border border-border-main accent-primary cursor-pointer"
            />
            <span className="text-sm font-medium break-all mt-0.5">
              Acknowledgement — I confirm I have received the physical copy of
              the document.
            </span>
          </label>
        )} */}
        <Button type="submit" disabled={isSaving} className="w-36">
          {isSaving ? "Saving..." : "Save"}
        </Button>
      </footer>
    </form>
  );
};

TransactionUpdateForm.displayName = "TransactionUpdateForm";
export default TransactionUpdateForm;
