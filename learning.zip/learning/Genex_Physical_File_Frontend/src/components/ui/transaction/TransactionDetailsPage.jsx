import { useCallback, useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { updateTransactionLockApi } from "../../../api/apiConfig";
import { APP_STAGES } from "../../../constants/stages";
import { useQueries } from "../../../hooks/useQueries";
import { useStages } from "../../../hooks/useStages";
import { useTransactionSubmit } from "../../../hooks/useTransactionSubmit";
import EmptyState from "../common/EmptyState";
import FormHeader from "../common/FormHeader";
import TransactionUpdateForm from "./TransactionUpdateForm";

/**
 * TransactionDetailsPage
 *
 * Generic details-page shell shared by Health Check and Query (and any future
 * transaction-based feature). Handles all common concerns:
 *   - Reading the record from router location.state
 *   - Form initialization + reset via react-hook-form
 *   - Fetching queryOptions + stageOptions
 *   - Submission via useTransactionSubmit
 *   - Global error display
 *   - Rendering TransactionUpdateForm with feature-specific config
 *
 * Feature-specific differences are injected through props:
 *   - `schema`               — zod validation schema
 *   - `isHealthCheck`        — drives form field config + payload-building logic
 *   - `title`                — page header title
 *   - `FileDetailsComponent` — renders the read-only file-details card
 *
 * @param {Object} schema               - Zod schema for form validation.
 * @param {boolean} isHealthCheck         - Whether this is the health-check flow.
 * @param {boolean} isStamping          - Whether this is the stamping flow.
 * @param {boolean} isNonCriticalQuery   - Whether this is the non-critical query flow.
 * @param {string} title                 - Page header title text.
 * @param {React.ElementType} FileDetailsComponent  - Component for the read-only file details card.
 */
const TransactionDetailsPage = ({
  schema,
  isHealthCheck,
  isStamping = false,
  isNonCriticalQuery = false,
  isQuery = false,
  title,
  // eslint-disable-next-line no-unused-vars
  FileDetailsComponent: Component,
  UpdateFormComponent = TransactionUpdateForm,
}) => {
  const navigate = useNavigate();
  const location = useLocation();

  const { queryOptions } = useQueries();
  const { stageOptions } = useStages();

  const currentRecord = location.state?.record || null;
  const [globalError, setGlobalError] = useState(null);

  useEffect(() => {
    if (!currentRecord) {
      // Record state lost (e.g. page refresh) — return to list
      navigate("..", { replace: true });
    }
  }, [currentRecord, navigate]);

  const handleRecordSaved = useCallback(
  (successMessage) => {
    navigate("..", {
      state: {
        savedSuccess: true,
        successMessage,
        appNo: currentRecord?.appNo || null,
        aggNo: currentRecord?.aggNo || null,
      },
    });
  },
  [navigate, currentRecord],
);

  const { onSubmit, isSaving } = useTransactionSubmit(
    currentRecord,
    queryOptions,
    stageOptions,
    setGlobalError,
    handleRecordSaved,
    isHealthCheck,
    isStamping,
    false,
    isNonCriticalQuery,
  );

  const handleBack = async () => {
    if (currentRecord?.appNo) {
      await updateTransactionLockApi({
        appNos: currentRecord.appNo,
        isLocked: false,
      });
    }

    navigate("..", {
      state: {
        exitWithoutSave: true,
        appNo: currentRecord?.appNo || null,
        aggNo: currentRecord?.aggNo || null,
      },
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <FormHeader title={title} onBack={handleBack} />

      <main className="pt-2">
        {globalError && !currentRecord && (
          <EmptyState title="Error" description={globalError} />
        )}

        {currentRecord && (
          <section className="flex flex-col gap-8">
            {/* Feature-specific read-only file details */}
            <Component currentRecord={currentRecord} />

            {/* Shared transaction update form — configured per feature via isHealthCheck, isNonCriticalQuery or custom component */}
            <UpdateFormComponent
              currentRecord={currentRecord}
              schema={schema}
              onSubmit={onSubmit}
              isSaving={isSaving}
              queryOptions={queryOptions}
              stageOptions={stageOptions}
              isDecisionRequired={isHealthCheck}
              isDecisionDisabled={!isHealthCheck || isNonCriticalQuery}
              isStageRequired={isHealthCheck}
              isHealthCheck={isHealthCheck}
              isNonCriticalQuery={isNonCriticalQuery}
              isQuery={isQuery}
              priorRemarks={currentRecord?.currentRemarks || ""}
              priorRemarksLabel={
                isNonCriticalQuery
                  ? "Health Check Remarks"
                  : isHealthCheck &&
                      currentRecord?.stage?.stageName ===
                        APP_STAGES.QUERY_RESOLVED
                    ? "Query resolved remarks"
                    : "Health Check Remarks"
              }
              formId={
                isHealthCheck
                  ? "healthCheckTransactionForm"
                  : isNonCriticalQuery
                    ? "nonCriticalQueryTransactionForm"
                    : "queryTransactionForm"
              }
              globalError={globalError}
            />
          </section>
        )}
      </main>
    </div>
  );
};

TransactionDetailsPage.displayName = "TransactionDetailsPage";
export default TransactionDetailsPage;
