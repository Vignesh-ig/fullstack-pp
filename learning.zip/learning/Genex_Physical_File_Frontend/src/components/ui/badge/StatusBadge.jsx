import { STATUS } from "../../../constants/status";
import BaseBadge from "./BaseBadge";

/**
 * StatusBadge
 *
 * Renders a badge for active/inactive status. Returns null if isActive is not boolean.
 *
 * @param {boolean} isActive - Whether the status is active.
 */
const StatusBadge = ({ isActive }) => {
  if (typeof isActive !== "boolean") return null;

  const statusLabel = isActive ? STATUS.ACTIVE : STATUS.INACTIVE;
  const colorClasses = isActive ? "badge-status-success" : "badge-status-error";
  return <BaseBadge className={colorClasses}>{statusLabel}</BaseBadge>;
};

StatusBadge.displayName = "StatusBadge";
export default StatusBadge;
