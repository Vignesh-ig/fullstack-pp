import { ROLE_BADGE_WIDTH, ROLE_STYLES } from "../../../constants/roles";
import { getRoleBadgeColor } from "../../../utils/utils";
import BaseBadge from "./BaseBadge";

/**
 * RoleBadge
 *
 * Renders a badge for user roles. Returns null if roleName is falsy.
 * Admin roles with longer display names get a wider width via ROLE_BADGE_WIDTH.
 * Unknown/new roles automatically get a deterministic color generated from the role name.
 *
 * @param {string} roleName - The role name of the user (e.g. ADMIN_USER).
 */
const RoleBadge = ({ roleName }) => {
  if (!roleName) return null;

  const displayName = roleName.replace(/_/g, " ");
  const knownStyle = ROLE_STYLES[roleName];
  const widthClass = ROLE_BADGE_WIDTH[roleName] ?? "";

  // Known roles use pre-defined CSS classes; unknown/new roles get dynamic inline styles
  if (knownStyle) {
    return (
      <BaseBadge className={`${knownStyle} ${widthClass}`.trim()}>
        {displayName}
      </BaseBadge>
    );
  }

  const { bg, text, border, minWidth } = getRoleBadgeColor(roleName);
  return (
    <BaseBadge
      className={widthClass}
      style={{
        backgroundColor: bg,
        color: text,
        borderColor: border,
        minWidth,
      }}
    >
      {displayName}
    </BaseBadge>
  );
};

RoleBadge.displayName = "RoleBadge";
export default RoleBadge;
