import React from "react";

/**
 * BaseBadge
 *
 * A reusable, UI-only base component for badges.
 *
 * @param {React.ReactNode} children - The contents to be rendered inside the badge.
 * @param {string} className - Additional CSS class names.
 * @param {React.CSSProperties} style - Optional inline styles (used for dynamic role colors).
 */
const BaseBadge = ({ children, className = "", style }) => {
  return (
    <span className={`badge-base ${className}`.trim()} style={style}>
      {children}
    </span>
  );
};

BaseBadge.displayName = "BaseBadge";
export default BaseBadge;
