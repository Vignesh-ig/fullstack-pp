
/**
 * JobStatusBadge
 *
 *
 */

import { DEFAULT_JOB_STATUS_STYLE, JOB_STATUS_STYLES } from "../../../constants/roles";
import { FILE_TRACKING_STATUS } from "../../../constants/status";
import BaseBadge from "./BaseBadge";


const JobStatusBadge = ({ jobStatusName }) => {
  if (!jobStatusName) return null;

  const displayName = jobStatusName.replaceAll("_", " ");

  let colorClass;
     switch (jobStatusName) {
       case FILE_TRACKING_STATUS.open:
         colorClass = JOB_STATUS_STYLES.Open
         break;
      case FILE_TRACKING_STATUS.Approved:
         colorClass = JOB_STATUS_STYLES.approved;
         break;
       case FILE_TRACKING_STATUS.Inprogress:
         colorClass = JOB_STATUS_STYLES.inprogress;
         break;
       case FILE_TRACKING_STATUS.Rejected:
         colorClass = JOB_STATUS_STYLES.rejected;
         break;
       case FILE_TRACKING_STATUS.Canceled:
         colorClass = JOB_STATUS_STYLES.cancelled;
         break;

       default:
         colorClass = DEFAULT_JOB_STATUS_STYLE;
     }
   
  return <BaseBadge className={`${colorClass} inline-block w-35 text-center`}>{displayName}</BaseBadge>;
};


JobStatusBadge.displayName = "JobStatusBadge";
export default JobStatusBadge;
