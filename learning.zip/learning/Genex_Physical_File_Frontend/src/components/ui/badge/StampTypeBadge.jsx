import {
  DEFAULT_STAMP_TYPE_STYLE,
  STAMP_TYPE_LABELS,
  STAMP_TYPE_STYLES,
} from "../../../constants/stampingConstants";
import BaseBadge from "./BaseBadge";

/**
 * StampTypeBadge
 *
 * Renders a colour-coded badge for a stamp type value.
 * Falls back to a neutral badge when the type is unrecognised.
 *
 * @param {string} stampType - The raw stamp type value from the API (e.g. "FIXED", "VARIABLE").
 */
const StampTypeBadge = ({ stampType }) => {
  if (!stampType) return null;

  const colorClass = STAMP_TYPE_STYLES[stampType] ?? DEFAULT_STAMP_TYPE_STYLE;
  const label = STAMP_TYPE_LABELS[stampType] ?? stampType.replace(/_/g, " ");

  return <BaseBadge className={colorClass}>{label}</BaseBadge>;
};

StampTypeBadge.displayName = "StampTypeBadge";
export default StampTypeBadge;
