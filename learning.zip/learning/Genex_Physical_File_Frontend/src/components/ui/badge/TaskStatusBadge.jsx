import { TASK_STATUS } from "../../../constants/status";
import BaseBadge from "./BaseBadge";

/**
 * TaskStatusBadge
 *
 * Renders a badge for task statuses (e.g. Completed, Pending).
 *
 * @param {string} status - The task status value used to derive the badge color.
 * @param {string} [label]  - Optional override for the displayed text.
 *                           When omitted the text is derived from `status`.
 */
const TaskStatusBadge = ({ status, label }) => {
  const normalized = status ? status.trim().toUpperCase() : "";
  if (!status) return null;

  const displayStatus = label ?? status.replace(/_/g, " ");

  let colorClasses;
  switch (normalized) {
    case TASK_STATUS.COMPLETED:
      colorClasses = "badge-status-completed";
      break;
    case TASK_STATUS.PENDING:
      colorClasses = "badge-status-pending";
      break;
    case TASK_STATUS.IN_PROCESS:
      colorClasses = "badge-status-in-process";
      break;
    default:
      colorClasses = "badge-default";
  }

  return <BaseBadge className={colorClasses}>{displayStatus}</BaseBadge>;
};

TaskStatusBadge.displayName = "TaskStatusBadge";
export default TaskStatusBadge;
