import {
  DENO_STATUS,
  DENO_STATUS_LABELS,
} from "../../../constants/stampingConstants";
import BaseBadge from "./BaseBadge";

/**
 * StampStackStatusBadge
 *
 * Renders a badge for stamp stack status (In Stock or Used).
 * Compares the raw CAPS API value directly against DENO_STATUS constants.
 *
 * @param {string} status - The stamp stack status from the API (e.g. "IN_STOCK", "USED").
 */
const StampStackStatusBadge = ({ status }) => {
  if (!status) return null;

  let colorClasses;
  switch (status) {
    case DENO_STATUS.IN_STOCK:
      colorClasses = "badge-status-success";
      break;
    case DENO_STATUS.USED:
      colorClasses = "badge-status-error";
      break;
    default:
      colorClasses = "badge-default";
  }

  const label = DENO_STATUS_LABELS[status] ?? status.replace(/_/g, " ");

  return <BaseBadge className={colorClasses}>{label}</BaseBadge>;
};

StampStackStatusBadge.displayName = "StampStackStatusBadge";
export default StampStackStatusBadge;
