import { ChevronLeftIcon, ChevronRightIcon } from "../../icons/icons";
import Button from "./Button";
import IconButton from "./IconButton";
import PerPageSelectField from "./PerPageSelectField";

/**
 * Pagination
 *
 * Renders page size selection, optional left-side action buttons, and page navigation buttons.
 *
 * @param {number} currentPage - 1-indexed current page.
 * @param {number} totalPages - Total number of pages.
 * @param {function} onPageChange - Called with the target page number.
 * @param {number} totalItems - Total record count (for meta text).
 * @param {number} pageSize - Items per page.
 * @param {Array<number>} pageSizeOptions - Options for the page size selector.
 * @param {function} onPageSizeChange - Callback when page size changes.
 * @param {boolean} showMeta - Whether to show "X–Y of Z" text between nav buttons.
 * @param {ReactNode} actions - Optional custom elements rendered on the left side (e.g. SelectField).
 * @param {boolean} [showAction=false] - Whether to show the standard primary action button.
 * @param {string} [actionLabel] - Label for the primary action button.
 * @param {string} [actionId] - ID attribute for the primary action button.
 * @param {function} [onActionClick] - Callback for the primary action button.
 * @param {boolean} [actionDisabled] - Disabled state for the primary action button.
 * @param {boolean} [actionIsLoading] - Loading state for the primary action button.
 */
const Pagination = ({
  currentPage,
  totalPages,
  onPageChange,
  totalItems,
  pageSize,
  pageSizeOptions = [10, 50, 100, 250, 500],
  onPageSizeChange,
  showMeta = true,
  actions,
  showAction = false,
  actionLabel,
  actionId,
  onActionClick,
  actionDisabled,
  actionIsLoading,
  paginationDivClass = "",
}) => {
  if (totalPages <= 1 && totalItems === 0) return null;

  const startItem = totalItems === 0 ? 0 : (currentPage - 1) * pageSize + 1;
  const endItem = Math.min(currentPage * pageSize, totalItems);

  const btnBase =
    "h-8 min-w-[2rem] px-2.5 rounded-lg text-xs font-semibold transition-all duration-150 focus:outline-none";
  const btnInactive = "text-text-secondary hover:scale-105";
  const btnDisabled = "opacity-40 cursor-not-allowed";

  return (
    <div
      className={`flex flex-row items-center justify-between gap-4 px-6 py-4 border-t border-border-subtle ${paginationDivClass}`}
    >
      {/* Left: action buttons (e.g. "Move to Storage", "Move to Stamping") */}
      {actions || showAction ? (
        <div className="flex items-center gap-4">
          {actions}
          {showAction && actionLabel && (
            <Button
              id={actionId}
              onClick={onActionClick}
              disabled={actionDisabled}
              isLoading={actionIsLoading}
              className="w-auto! py-2.5! px-6! rounded-xl! text-sm! bg-brand-primary! text-white!"
            >
              {actionLabel}
            </Button>
          )}
        </div>
      ) : (
        <div />
      )}

      {/* Right: page size + navigation */}
      <div className="flex items-center gap-4">
        {onPageSizeChange && (
          <PerPageSelectField
            value={pageSize}
            onChange={onPageSizeChange}
            options={pageSizeOptions}
          />
        )}

        {totalPages > 1 && (
          <div className="flex items-center gap-1">
            {/* Previous */}
            <IconButton
              onClick={() => onPageChange(currentPage - 1)}
              disabled={currentPage === 1}
              icon={<ChevronLeftIcon className="w-3.5 h-3.5" />}
              ariaLabel="Previous page"
              className={`${btnBase} ${currentPage === 1 ? btnDisabled : btnInactive + " bg-white border border-border-main shadow-sm hover:border-brand-primary/50"}`}
            />

            {/* Meta text */}
            {showMeta && (
              <span className="text-xs font-semibold text-text-secondary px-2 whitespace-nowrap">
                {totalItems === 0
                  ? "No results"
                  : `${startItem}–${endItem} of ${totalItems}`}
              </span>
            )}

            {/* Next */}
            <IconButton
              onClick={() => onPageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              icon={<ChevronRightIcon className="w-3.5 h-3.5" />}
              ariaLabel="Next page"
              className={`${btnBase} ${currentPage === totalPages ? btnDisabled : btnInactive + " bg-white border border-border-main shadow-sm hover:border-brand-primary/50"}`}
            />
          </div>
        )}
      </div>
    </div>
  );
};

Pagination.displayName = "Pagination";
export default Pagination;
