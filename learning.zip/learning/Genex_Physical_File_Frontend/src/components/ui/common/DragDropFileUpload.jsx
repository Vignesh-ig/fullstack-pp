import { useRef } from "react";
import { FileIcon } from "../../icons/icons";

/**
 * DragDropFileUpload
 *
 * A reusable, aesthetic drag-and-drop file upload component.
 *
 * @param {string} id - Unique identifier for the input element.
 * @param {string} label - The label for the upload zone.
 * @param {string} accept - File types to accept (e.g., ".csv").
 * @param {Function} onChange - Handler for file selection.
 * @param {File} file - Currently selected file.
 * @param {string} hint - Subtext hint (e.g., "CSV files up to 10MB").
 */
const DragDropFileUpload = ({
  id,
  label = "Choose file",
  accept,
  onChange,
  onRemove,
  file,
  hint = "CSV files up to 10MB",
}) => {
  const inputRef = useRef(null);

  const handleContainerClick = () => {
    if (inputRef.current) {
      inputRef.current.click();
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      handleContainerClick();
    }
  };

  return (
    <div className="w-full">
      <div
        className="mt-2 flex justify-center rounded-xl border-2 border-dashed border-border-main bg-surface-tertiary px-6 py-12 transition-all hover:bg-slate-100 hover:border-brand-primary cursor-pointer group"
        onClick={handleContainerClick}
        onKeyDown={handleKeyDown}
        role="button"
        tabIndex={0}
      >
        <div className="text-center">
          <FileIcon className="mx-auto h-12 w-12 text-text-secondary group-hover:text-brand-primary transition-colors mb-4" />
          <div className="mt-4 flex text-sm leading-6 text-text-primary justify-center items-center">
            <span className="relative cursor-pointer rounded-md font-semibold text-brand-primary focus-within:outline-none focus-within:ring-2 focus-within:ring-brand-accent focus-within:ring-offset-2 hover:text-brand-hover">
              {label}
            </span>
            <p className="pl-1 text-text-secondary">or drag and drop</p>
          </div>
          <p className="text-xs leading-5 text-text-secondary mt-2">{hint}</p>
          <input
            id={id}
            name={id}
            type="file"
            accept={accept}
            className="sr-only"
            ref={inputRef}
            onChange={onChange}
          />
        </div>
      </div>

      {file && (
        <div className="mt-4 p-4 bg-surface-tertiary rounded-xl border border-border-main flex items-center justify-between shadow-sm">
          <div className="flex items-center space-x-3">
            <FileIcon className="h-6 w-6 text-brand-primary" />
            <span className="text-sm font-medium text-text-primary truncate max-w-xs">
              {file.name}
            </span>
          </div>
          <div className="flex flex-row gap-2 items-center">
            <span className="text-xs font-semibold text-text-secondary bg-slate-200 px-2 py-1 rounded-md">
              {(file.size / 1024).toFixed(2)} KB
            </span>
            {onRemove && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  if (inputRef.current) inputRef.current.value = "";
                  onRemove();
                }}
                className="text-xs font-bold text-status-error/70 hover:text-status-error hover:bg-red-100 bg-status-error/10 px-2 py-1 rounded-md transition-colors flex items-center justify-center cursor-pointer"
                title="Remove file"
              >
                ✕
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

DragDropFileUpload.displayName = "DragDropFileUpload";
export default DragDropFileUpload;
