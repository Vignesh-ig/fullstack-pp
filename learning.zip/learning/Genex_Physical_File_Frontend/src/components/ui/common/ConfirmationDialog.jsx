/**
 * A reusable confirmation dialog component.
 *
 * @param {boolean} isOpen - Whether the dialog is open.
 * @param {string|React.ReactNode} content - The message content to display.
 * @param {string} confirmText - Text for the confirm button.
 * @param {string} cancelText - Text for the cancel button.
 * @param {Function} onConfirm - Callback when the confirm button is clicked.
 * @param {Function} onCancel - Callback when the cancel button is clicked.
 * @param {boolean} isSubmitting - Whether the form/action is currently submitting.
 */
const ConfirmationDialog = ({
  isOpen,
  content,
  confirmText = "Sure",
  cancelText = "Cancel",
  onConfirm,
  onCancel,
  isSubmitting = false,
}) => {
  if (!isOpen) return null;

  return (
    <div className="dialog-overlay">
      <div className="dialog-content">
        <div className="dialog-body">{content}</div>
        <div className="dialog-footer">
          <button
            type="button"
            onClick={onCancel}
            disabled={isSubmitting}
            className="dialog-btn-cancel"
          >
            {cancelText}
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={isSubmitting}
            className="dialog-btn-confirm"
          >
            {isSubmitting ? "Processing..." : confirmText}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationDialog;
