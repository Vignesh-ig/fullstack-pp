/**
 * Button
 *
 * A full-width, styled primary action button.
 *
 * @param {ReactNode} children - Button label or content.
 * @param {any} type - type
 * @param {any} onClick - onClick
 * @param {any} className - className
 * @param {any} disabled - disabled
 */
const Button = ({
  children,
  type = "button",
  onClick,
  className = "",
  disabled = false,
}) => {
  const hasWidth = /(^|\s)w-/.test(className);

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${
        hasWidth ? "" : "w-full"
      } bg-brand-primary text-white font-bold py-3.5 px-4 rounded-xl shadow-lg transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-brand-accent focus:ring-offset-2 
        ${
          disabled
            ? "opacity-30 cursor-not-allowed"
            : "cursor-pointer hover:bg-brand-hover shadow-brand-primary/20 hover:shadow-xl hover:shadow-brand-hover/40 transform hover:-translate-y-0.5"
        } ${className}`}
    >
      {children}
    </button>
  );
};

Button.displayName = "Button";
export default Button;
