import { ChevronLeftIcon } from "../../icons/icons";
import IconButton from "./IconButton";

/**
 * FormHeader
 *
 * A reusable header component for forms, displaying a back navigation button, a dynamic title,
 * and optional right-aligned content (e.g., counters or actions). Includes a bottom divider line.
 *
 * @param {string} title - The main title displayed in the header.
 * @param {function} onBack - Callback fired when the back navigation button is clicked.
 * @param {React.ReactNode} rightContent - Optional content to display on the right side.
 */
const FormHeader = ({ title, onBack, rightContent }) => {
  return (
    <>
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-3">
        <div className="flex items-center gap-3">
          <IconButton
            onClick={onBack}
            className="px-3 h-10 gap-1.5 border border-border-main text-text-secondary hover:text-blue-600 hover:bg-blue-50 hover:border-blue-200 text-sm font-medium rounded-full transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center justify-center shrink-0"
            ariaLabel="Back"
            icon={<ChevronLeftIcon className="w-4 h-4" />}
          />
          <h2 className="text-lg sm:text-xl font-bold text-text-primary">
            {title}
          </h2>
        </div>
        {rightContent && (
          <div className="flex items-center justify-end gap-4">
            {rightContent}
          </div>
        )}
      </header>
      <div className="h-px w-full bg-border-main mb-4" />
    </>
  );
};

FormHeader.displayName = "FormHeader";
export default FormHeader;
