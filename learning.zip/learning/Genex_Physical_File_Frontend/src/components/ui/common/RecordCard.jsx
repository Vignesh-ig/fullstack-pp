/**
 * RecordCard
 *
 * A reusable, professional-looking card component for displaying record details
 * with an index, main title, badges, secondary details, and action buttons.
 *
 * @param {any} index - index
 * @param {string} title - The primary identifier/title for the card (e.g., Application Number)
 * @param {any} badges - badges
 * @param {any} details - details
 * @param {any} action - action
 * @param {any} className - className
 */
const RecordCard = ({
  index,
  title,
  badges = [],
  details = [],
  action,
  className,
}) => {
  return (
    <div
      className={`rounded-xl shadow-md p-3 sm:p-4 mb-3 transition-all border hover:shadow-md flex items-start sm:items-center justify-between gap-3 sm:gap-4 relative ${className || "bg-white border-brand-accent/40 hover:border-brand-accent"}`}
    >
      {/* Left side: Main details */}
      <div className="flex items-start gap-3 sm:gap-4 flex-1 min-w-0">
        {/* Index badge */}
        {index !== undefined && index !== null && (
          <div className="shrink-0 w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-gray-200/80 flex items-center justify-center  font-bold text-xs mt-0.5 sm:mt-0">
            {index + 1}
          </div>
        )}

        <div className="flex flex-col gap-1.5 flex-1 min-w-0">
          {/* Primary Identifier & Badges */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-base font-bold text-slate-800 wrap-break-word max-w-full">
              {title || "N/A"}
            </span>
            {badges.map((badge, idx) => {
              if (!badge) return null;
              return (
                <span
                  key={idx}
                  className="px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wider uppercase bg-brand-primary/10 text-brand-primary whitespace-nowrap"
                >
                  {badge}
                </span>
              );
            })}
          </div>

          {/* Secondary details */}
          {details.length > 0 && (
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-slate-500 font-medium">
              {details.map((detail, idx) => (
                <span
                  key={idx}
                  className="flex items-center gap-1 min-w-0 max-w-full"
                >
                  <span className="text-slate-700 shrink-0">
                    {detail.label}:
                  </span>
                  <span
                    className={`${
                      detail.value && typeof detail.value === "object"
                        ? "flex items-center"
                        : "bg-white px-1.5 py-0.5 rounded border border-slate-300"
                    } truncate sm:whitespace-normal sm:break-all max-w-30 sm:max-w-none ${
                      detail.label === "Assigned To"
                        ? "text-brand-primary/90 font-semibold text-md"
                        : detail.label === "Stage" &&
                            detail.value === "Rejected"
                          ? "text-red-500 font-bold"
                          : detail.label === "Stage" &&
                              detail.value === "Completed"
                            ? "text-green-500 font-bold"
                            : detail.label === "Ageing" &&
                                Number(detail.value) > 15 &&
                                detail.value !== "N/A"
                              ? "text-red-600 font-bold"
                              : "text-slate-900"
                    }`}
                  >
                    {detail.value || "N/A"}
                  </span>
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Right side: Actions */}
      {action && (
        <div className="shrink-0 flex items-center justify-end">{action}</div>
      )}
    </div>
  );
};

RecordCard.displayName = "RecordCard";
export default RecordCard;
