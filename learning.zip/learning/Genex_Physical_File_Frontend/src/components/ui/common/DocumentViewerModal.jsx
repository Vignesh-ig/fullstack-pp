import { useEffect, useRef, useState } from "react";
import {
  downloadPFDmsDocumentApi,
  getPFDmsListApi,
} from "../../../api/apiConfig";
import { CloseIcon, FileIcon, SpinnerIcon } from "../../icons/icons";
import EmptyState from "./EmptyState";
import ErrorBanner from "./ErrorBanner";
import IconButton from "./IconButton";

/**
 * DocumentViewerModal
 *
 * Fetches a list of DMS document IDs by appNo, then renders a grid of
 * clickable PDF boxes. Selecting a box downloads and renders that PDF inline.
 *
 * @param {boolean} isOpen - Whether the modal is visible.
 * @param {Function} onClose - Callback to close the modal.
 * @param {string} appNo - Application number used to fetch the DMS list.
 * @param {string} customerName - Customer name displayed in the modal title.
 */
const DocumentViewerModal = ({ isOpen, onClose, appNo, customerName }) => {
  const [dmsList, setDmsList] = useState([]);
  const [listLoading, setListLoading] = useState(false);
  const [listError, setListError] = useState(null);

  const [selectedIndex, setSelectedIndex] = useState(null);
  const [pdfUrl, setPdfUrl] = useState(null);
  const [pdfLoading, setPdfLoading] = useState(false);
  const [pdfError, setPdfError] = useState(null);

  const prevPdfUrl = useRef(null);

  const loadDocument = async (dmsId, index) => {
    if (prevPdfUrl.current) {
      URL.revokeObjectURL(prevPdfUrl.current);
      prevPdfUrl.current = null;
    }

    setSelectedIndex(index);
    setPdfUrl(null);
    setPdfError(null);
    setPdfLoading(true);

    try {
      const blob = await downloadPFDmsDocumentApi(dmsId);
      const objectUrl = URL.createObjectURL(blob);
      prevPdfUrl.current = objectUrl;
      setPdfUrl(objectUrl);
    } catch (err) {
      setPdfError(err?.message ?? "Failed to load the document.");
    } finally {
      setPdfLoading(false);
    }
  };

  // Fetch DMS list when modal opens
  useEffect(() => {
    if (!isOpen || !appNo) return;

    setDmsList([]);
    setListError(null);
    setSelectedIndex(null);
    setPdfUrl(null);
    setPdfError(null);
    setListLoading(true);

    getPFDmsListApi(appNo)
      .then((res) => {
        // Handle successful response or "Failed" status if Data is empty array
        if (Array.isArray(res?.Data)) {
          // Deduplicate DMS IDs while preserving order
          const seen = new Set();
          const unique = res.Data.filter(({ dms }) => {
            if (seen.has(dms)) return false;
            seen.add(dms);
            return true;
          });
          setDmsList(unique);

          // By default, load the first document if available
          if (unique.length > 0) {
            loadDocument(unique[0].dms, 0);
          }
        } else {
          setDmsList([]);
        }
      })
      .catch((err) => {
        setListError(err?.message ?? "Failed to load documents.");
      })
      .finally(() => setListLoading(false));

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, appNo]);

  // Revoke previous blob URL on unmount to prevent memory leaks
  useEffect(() => {
    return () => {
      if (prevPdfUrl.current) {
        URL.revokeObjectURL(prevPdfUrl.current);
      }
    };
  }, []);

  const handleDocBoxClick = (dmsId, index) => {
    if (selectedIndex === index && pdfUrl) return; // already loaded
    loadDocument(dmsId, index);
  };

  const handleClose = () => {
    if (prevPdfUrl.current) {
      URL.revokeObjectURL(prevPdfUrl.current);
      prevPdfUrl.current = null;
    }
    setPdfUrl(null);
    setSelectedIndex(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      className="doc-viewer-overlay"
      role="dialog"
      aria-modal="true"
      aria-label="Document Viewer"
      onClick={(e) => {
        if (e.target === e.currentTarget) handleClose();
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          if (e.target === e.currentTarget) handleClose();
        }
      }}
    >
      <div className="doc-viewer-modal">
        {/* ── Header ── */}
        <div className="doc-viewer-header">
          <h2 className="doc-viewer-title">
            Application No:{" "}
            <span className="text-brand-primary">{appNo || "N/A"}</span> |{" "}
            Customer Name:{" "}
            <span className="text-brand-primary">{customerName || "N/A"}</span>
          </h2>
          <IconButton
            icon={<CloseIcon className="w-4 h-4" />}
            onClick={handleClose}
            ariaLabel="Close document viewer"
            className="doc-viewer-close-btn"
          />
        </div>

        {/* ── Body ── */}
        <div className="doc-viewer-body">
          {/* ── PDF viewer area ── */}
          <div className="doc-viewer-pdf-section">
            {selectedIndex === null && !listLoading ? (
              <EmptyState
                title="No document selected"
                description="Select a document below to preview it."
                icon={<FileIcon className="w-8 h-8" />}
              />
            ) : pdfLoading ? (
              <div className="doc-viewer-empty">
                <SpinnerIcon className="w-8 h-8 text-brand-primary" />
                <p className="text-sm text-text-secondary">Loading document…</p>
              </div>
            ) : pdfError ? (
              <div className="px-2 pt-2">
                <ErrorBanner
                  message={pdfError}
                  onClose={() => setPdfError(null)}
                />
              </div>
            ) : pdfUrl ? (
              <iframe
                src={pdfUrl}
                className="doc-viewer-pdf-frame"
                title={`Document ${selectedIndex + 1}`}
              />
            ) : null}
          </div>

          {/* ── Document grid ── */}
          <div className="doc-viewer-grid-section">
            <p className="doc-viewer-grid-label">Documents</p>

            {listLoading ? (
              <div className="flex items-center gap-2 text-sm text-text-secondary py-2">
                <SpinnerIcon className="w-4 h-4 text-brand-primary" />
                Loading documents…
              </div>
            ) : listError ? (
              <ErrorBanner message={listError} />
            ) : dmsList.length === 0 ? (
              <p className="text-md text-text-secondary py-2">
                No documents available.
              </p>
            ) : (
              <div className="doc-viewer-grid">
                {dmsList.map(({ dms }, index) => {
                  const isActive = selectedIndex === index;
                  const isThisLoading = pdfLoading && selectedIndex === index;
                  return (
                    <button
                      key={`${dms}-${index}`}
                      type="button"
                      id={`doc-box-${index}`}
                      className={[
                        "doc-viewer-doc-box",
                        isActive ? "doc-viewer-doc-box-active" : "",
                        isThisLoading ? "doc-viewer-doc-box-loading" : "",
                      ]
                        .filter(Boolean)
                        .join(" ")}
                      onClick={() => handleDocBoxClick(dms, index)}
                      disabled={isThisLoading}
                      aria-pressed={isActive}
                      aria-label={`Document ${index + 1}`}
                    >
                      {isThisLoading ? (
                        <SpinnerIcon className="w-5 h-5 text-brand-primary" />
                      ) : (
                        <FileIcon
                          className={`w-7 h-7 ${isActive ? "text-brand-primary" : "text-slate-400"}`}
                        />
                      )}
                      <span className="doc-viewer-doc-box-label">
                        Doc {index + 1}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

DocumentViewerModal.displayName = "DocumentViewerModal";
export default DocumentViewerModal;
