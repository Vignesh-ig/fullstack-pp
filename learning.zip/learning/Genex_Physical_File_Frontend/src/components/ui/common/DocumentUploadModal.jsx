import { useRef, useState } from "react";
import { CloseIcon, FileIcon, SpinnerIcon } from "../../icons/icons";

import ErrorBanner from "./ErrorBanner";
import IconButton from "./IconButton";
import SuccessBanner from "./SuccessBanner";

const MAX_FILE_SIZE_MB = 25;
const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;
const ALLOWED_MIME_TYPES = [
  "application/pdf",
  "image/jpeg",
  "image/png",
  "image/jpg",
];
const ALLOWED_EXTENSIONS = [".pdf", ".jpg", ".jpeg", ".png"];

/**
 * DocumentUploadModal
 *
 * Generic modal for picking and uploading a single PDF or image (≤ 25 MB).
 * All API/business payload logic must be handled by the caller via `onUpload`.
 *
 * @param {boolean}  isOpen    - Whether the modal is visible.
 * @param {Function} onClose   - Callback to close the modal.
 * @param {string}   appNo     - Application number displayed in the header.
 * @param {Function} onUpload  - Async function `(file: File) => Promise<void>` that
 *                               performs the actual upload. Receives the validated File
 *                               object. Must throw on failure so the modal can display
 *                               the error message.
 */
const DocumentUploadModal = ({ isOpen, onClose, appNo, onUpload }) => {
  const [file, setFile] = useState(null);
  const [fileError, setFileError] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const inputRef = useRef(null);

  const resetState = () => {
    setFile(null);
    setFileError(null);
    setUploadError(null);
    setUploadSuccess(false);
    if (inputRef.current) inputRef.current.value = "";
  };

  const handleClose = () => {
    resetState();
    onClose();
  };

  const validateFile = (selected) => {
    if (!selected) return "Please select a file.";
    if (!ALLOWED_MIME_TYPES.includes(selected.type)) {
      return `Invalid file type. Only PDF and images (${ALLOWED_EXTENSIONS.join(", ")}) are allowed.`;
    }
    if (selected.size > MAX_FILE_SIZE_BYTES) {
      return `File size exceeds ${MAX_FILE_SIZE_MB} MB limit. Please choose a smaller file.`;
    }
    return null;
  };

  const handleFileChange = (e) => {
    const selected = e.target.files?.[0] ?? null;
    setUploadError(null);
    setUploadSuccess(false);
    const err = validateFile(selected);
    setFileError(err);
    setFile(err ? null : selected);
  };

  const handleUpload = async () => {
    if (!file || !onUpload) return;

    setIsUploading(true);
    setUploadError(null);
    setUploadSuccess(false);

    try {
      await onUpload(file);
      setUploadSuccess(true);
      setFile(null);
      if (inputRef.current) inputRef.current.value = "";
      
      setTimeout(() => {
        handleClose();
      }, 1500);
    } catch (err) {
      setUploadError(
        err?.message ?? "Failed to upload document. Please try again.",
      );
    } finally {
      setIsUploading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="doc-viewer-overlay"
      role="dialog"
      aria-modal="true"
      aria-label="Upload Document"
      onClick={(e) => {
        if (e.target === e.currentTarget) handleClose();
      }}
      onKeyDown={(e) => {
        if (
          (e.key === "Enter" || e.key === " ") &&
          e.target === e.currentTarget
        )
          handleClose();
      }}
    >
      <div className="doc-upload-modal">
        {/* ── Header ── */}
        <div className="doc-viewer-header">
          <h2 className="doc-viewer-title">
            Upload Document —{" "}
            <span className="text-brand-primary">{appNo || "N/A"}</span>
          </h2>
          <IconButton
            icon={<CloseIcon className="w-4 h-4" />}
            onClick={handleClose}
            ariaLabel="Close upload modal"
            className="doc-viewer-close-btn"
          />
        </div>

        {/* ── Body ── */}
        <div className="doc-upload-body">
          <p className="doc-upload-hint">
            Select a <strong>PDF or image</strong> file (max{" "}
            <strong>{MAX_FILE_SIZE_MB} MB</strong>). Only one file at a time.
          </p>

          {/* Drop zone / file input */}
          <label
            htmlFor="doc-upload-input"
            className={`doc-upload-dropzone${file ? " doc-upload-dropzone-active" : ""}`}
          >
            <input
              ref={inputRef}
              id="doc-upload-input"
              type="file"
              accept={ALLOWED_EXTENSIONS.join(",")}
              className="sr-only"
              onChange={handleFileChange}
              disabled={isUploading}
            />
            <div className="doc-upload-dropzone-inner">
              {file ? (
                <>
                  <span className="doc-upload-file-name">{file.name}</span>
                  <span className="doc-upload-file-size">
                    {(file.size / (1024 * 1024)).toFixed(2)} MB
                  </span>
                </>
              ) : (
                <>
                  <span className="doc-upload-placeholder-icon">
                    <FileIcon className="w-10 h-10" />
                  </span>
                  <span className="doc-upload-placeholder-text">
                    Click to browse or drag &amp; drop
                  </span>
                  <span className="doc-upload-placeholder-sub">
                    PDF, JPG, JPEG, PNG — max {MAX_FILE_SIZE_MB} MB
                  </span>
                </>
              )}
            </div>
          </label>

          {/* File validation error */}
          {fileError && <p className="doc-upload-field-error">{fileError}</p>}

          {/* Upload API error */}
          {uploadError && (
            <ErrorBanner
              message={uploadError}
              onClose={() => setUploadError(null)}
            />
          )}

          {/* Success */}
          {uploadSuccess && (
            <SuccessBanner message="Document uploaded successfully!" />
          )}
        </div>

        {/* ── Footer ── */}
        <div className="doc-upload-footer">
          <button
            type="button"
            id="doc-upload-cancel-btn"
            onClick={handleClose}
            className="dialog-btn-cancel"
            disabled={isUploading}
          >
            Cancel
          </button>
          <button
            type="button"
            id="doc-upload-submit-btn"
            onClick={handleUpload}
            className="dialog-btn-confirm"
            disabled={!file || !!fileError || isUploading}
          >
            {isUploading ? (
              <span className="flex items-center justify-center gap-2">
                <SpinnerIcon className="w-4 h-4" />
                Uploading…
              </span>
            ) : (
              "Upload"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

DocumentUploadModal.displayName = "DocumentUploadModal";
export default DocumentUploadModal;
