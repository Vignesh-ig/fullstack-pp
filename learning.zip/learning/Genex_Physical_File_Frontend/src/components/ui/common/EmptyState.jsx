import { UsersGroupIcon } from "../../icons/icons";

/**
 * EmptyState
 *
 * Centered placeholder shown when a list has no items.
 *
 * @param {string} title - Heading text (default "No data found").
 * @param {string} description - Supporting text.
 * @param {ReactNode} icon - Optional SVG/icon to display above the text.
 */
const EmptyState = ({ title = "No data found", description, icon }) => {
  const defaultIcon = <UsersGroupIcon className="w-8 h-8" />;

  return (
    <section className="p-12 text-center">
      <figure className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-50 text-slate-300 mb-4 m-0">
        {icon ?? defaultIcon}
      </figure>
      <h3 className="text-lg font-bold text-text-primary">{title}</h3>
      {description && <p className="text-text-secondary mt-1">{description}</p>}
    </section>
  );
};

EmptyState.displayName = "EmptyState";
export default EmptyState;
