/**
 * DashboardStatCard
 *
 * Unified, reusable stat card used across dashboard panels.
 * Renders as an interactive <button> when onClick is provided, or a read-only
 * <div> otherwise. Optionally shows a "% of total" sub-label.
 *
 * @param {string}             label       - Human-readable metric label.
 * @param {number|string}      value       - Metric value, or "..." while loading.
 * @param {number}             [total]     - Grand total; when provided shows % of total line.
 * @param {string}             accentColor - CSS colour for the left border accent.
 * @param {boolean}            [isActive]  - Highlights the card when true (active selection).
 * @param {Function|undefined} [onClick]   - Click handler. Omit for a non-interactive card.
 */
const DashboardStatCard = ({
  label,
  value,
  total,
  accentColor,
  isActive = false,
  onClick,
}) => {
  const isClickable = typeof onClick === "function";
  const pct =
    total > 0 && typeof value === "number"
      ? Math.round((value / total) * 100)
      : null;

  const cardClass = `dashboard-stat-card w-full transition-shadow duration-150 ${
    isActive
      ? "ring-2 ring-brand-primary/40 shadow-md"
      : isClickable
        ? "hover:shadow-md"
        : "shadow-sm"
  }`;
  const cardStyle = { borderLeft: `4px solid ${accentColor}` };

  const content = (
    <>
      <span className="dashboard-stat-label">{label}</span>
      <span className="dashboard-stat-value">{value}</span>
      {pct !== null && (
        <span className="text-xs text-text-secondary mt-1">
          {pct}% of total
        </span>
      )}
    </>
  );

  if (!isClickable) {
    return (
      <div className={cardClass} style={cardStyle}>
        {content}
      </div>
    );
  }

  return (
    <button
      type="button"
      onClick={onClick}
      className={`${cardClass} text-left`}
      style={cardStyle}
    >
      {content}
    </button>
  );
};

DashboardStatCard.displayName = "DashboardStatCard";
export default DashboardStatCard;
