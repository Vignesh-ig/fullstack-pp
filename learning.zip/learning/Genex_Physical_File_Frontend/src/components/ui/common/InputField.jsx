import { forwardRef, useEffect, useRef, useState } from "react";
import { validateInputCharacters } from "../../../utils/utils";
import ClearSearchButton from "./ClearSearchButton";

/**
 * InputField
 *
 * A labelled text input with optional leading icon, error state, and disabled styling. Integrates with react-hook-form via `forwardRef`.
 *
 * @param {string} props.label - Optional label rendered above the input.
 * @param {string} props.type - HTML input type (e.g. "text", "password"). Default: "text".
 * @param {string} props.value - Controlled value.
 * @param {function} props.onChange - Change handler.
 * @param {function} props.onBlur - Blur handler (used by react-hook-form).
 * @param {string} props.name - Input name attribute (used by react-hook-form).
 * @param {string} props.placeholder - Placeholder text.
 * @param {number} [props.maxLength] - Maximum length of the input.
 * @param {boolean} props.required - Marks the input as required. Default: false.
 * @param {boolean} props.disabled - Disables the input with visual feedback. Default: false.
 * @param {ReactNode} props.icon - Optional SVG/element rendered as a leading icon.
 * @param {ReactNode} [props.rightIcon] - Optional element rendered as a trailing icon/button on the right.
 * @param {string} props.className - Optional extra classes on the wrapper div.
 * @param {string} props.error - Error message shown below the input.
 * @param {RegExp} props.regex - Optional regular expression to filter inputs on change.
 * @param {Ref} props.ref - Forwarded ref passed directly to the <input> element.
 */
const InputField = forwardRef(
  (
    {
      label,
      type = "text",
      value,
      onChange,
      onBlur,
      name,
      placeholder,
      maxLength,
      required = false,
      disabled = false,
      icon,
      rightIcon,
      className = "",
      error,
      regex,
      onClear,
      inputClassName = "",
      ...rest
    },
    ref,
  ) => {
    const wrapperClass = className.includes("mb-")
      ? className
      : `mb-6 ${className}`;
    const lastValidValueRef = useRef(value ?? "");
    const internalRef = useRef(null);

    const setRefs = (node) => {
      internalRef.current = node;
      if (typeof ref === "function") {
        ref(node);
      } else if (ref) {
        ref.current = node;
      }
    };

    const [internalLength, setInternalLength] = useState(0);

    useEffect(() => {
      if (internalRef.current) {
        setInternalLength(internalRef.current.value.length);
      }
    }, [value]); // run on mount and if value prop changes programmatically

    useEffect(() => {
      lastValidValueRef.current = value ?? "";
    }, [value]);

    const handleInputChange = (e) => {
      const val = e.target.value;
      if (regex && !validateInputCharacters(val, regex)) {
        const start = e.target.selectionStart;
        e.target.value = lastValidValueRef.current;
        try {
          if (start !== null) {
            e.target.setSelectionRange(start - 1, start - 1);
          }
        } catch {
          // ignore if input type does not support selection range
        }
        return;
      }
      lastValidValueRef.current = val;
      setInternalLength(val.length);
      if (onChange) {
        onChange(e);
      }
    };

    const displayLength =
      value !== undefined ? String(value).length : internalLength;

    return (
      <div className={`flex flex-col ${wrapperClass}`}>
        {label && (
          <label className="block text-text-secondary text-xs font-bold uppercase tracking-wider mb-2 min-h-5">
            {label}
            {required && <span className="required-asterisk">*</span>}
          </label>
        )}
        <div className="relative">
          {icon && (
            <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none text-text-secondary opacity-70">
              {icon}
            </div>
          )}
          <input
            {...rest}
            ref={setRefs}
            type={type}
            name={name}
            value={value}
            onChange={handleInputChange}
            onBlur={onBlur}
            className={`w-full ${icon ? "pl-11" : "pl-4"} 
            ${
              disabled
                ? "text-text-secondary/80 cursor-not-allowed border-surface-tertiary"
                : ""
            }
            ${onClear || rightIcon ? "pr-11" : "pr-4"} py-3.5 bg-surface-tertiary border ${error ? "border-status-error" : "border-border-main"} rounded-xl text-text-primary text-sm font-medium placeholder:font-normal placeholder:text-text-secondary/70 focus:outline-none focus:ring-2 ${error ? "focus:ring-status-error/20 focus:border-status-error" : "focus:ring-brand-accent/20 focus:border-brand-accent"} focus:bg-white transition-all hover:border-text-secondary/30 shadow-sm ${inputClassName}`}
            placeholder={placeholder}
            required={required}
            disabled={disabled}
            maxLength={maxLength}
          />
          {onClear && value && !disabled && (
            <ClearSearchButton onClick={onClear} />
          )}
          {rightIcon && (
            <div className="absolute inset-y-0 right-0 flex items-center pr-3">
              {rightIcon}
            </div>
          )}
        </div>

        {maxLength && (
          <span
            className={`text-[10px] self-end mt-1 ${
              displayLength >= maxLength
                ? "text-status-error"
                : "text-text-secondary"
            }`}
          >
            {displayLength}/{maxLength} characters
          </span>
        )}

        {error && (
          <p className="mt-1 text-xs text-status-error font-medium">{error}</p>
        )}
      </div>
    );
  },
);

InputField.displayName = "InputField";

export default InputField;