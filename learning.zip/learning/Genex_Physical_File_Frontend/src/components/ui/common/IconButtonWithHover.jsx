/**
 * IconButtonWithHover
 *
 * IconButton A reusable icon-only action button with a hover-revealed tooltip label.
 *
 * @param {function} onClick - Click handler.
 * @param {ReactNode} icon - SVG / element to render as the icon.
 * @param {string} label - Tooltip text shown on hover.
 * @param {string} colorClass - Tailwind hover text+bg classes (default: edit style).
 * @param {string} className - Optional extra wrapper classes.
 * @param {boolean} disabled - Disables the button.
 * @param {string} type - Button type (default "button").
 * @param {string} tooltipPosition - Position of the tooltip ("top", "bottom", "left", "right").
 */
const IconButtonWithHover = ({
  onClick,
  icon,
  label = "",
  colorClass = "hover:text-brand-primary hover:bg-brand-primary/5",
  className = "",
  disabled = false,
  type = "button",
  tooltipPosition = "top",
}) => {
  const tooltipPositionClass =
    {
      top: "bottom-full left-1/2 -translate-x-1/2 mb-1.5",
      bottom: "top-full left-1/2 -translate-x-1/2 mt-1.5",
      left: "right-full top-1/2 -translate-y-1/2 mr-1.5",
      right: "left-full top-1/2 -translate-y-1/2 ml-1.5",
    }[tooltipPosition] || "bottom-full left-1/2 -translate-x-1/2 mb-1.5";

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`relative p-2 text-slate-400 ${colorClass} rounded-lg transition-all duration-200 active:scale-95 group disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
    >
      {icon}
      {label && (
        <span
          className={`z-50 absolute ${tooltipPositionClass} bg-tooltip-bg text-white p-1.5 rounded-md text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-all duration-300 pointer-events-none shadow-lg`}
        >
          {label}
        </span>
      )}
    </button>
  );
};

IconButtonWithHover.displayName = "IconButtonWithHover";
export default IconButtonWithHover;
