const HistoryField = ({ label, value, isMono = false }) => {
  if (!value) return null;

  return (
    <div className="mb-3">
      <div className="flex items-center gap-1.5 text-xs">
        <span className="font-bold uppercase tracking-wider text-slate-500 text-xs">
          {label}:
        </span>
        <span className={`font-bold ${isMono ? "font-mono" : ""}`}>
          {value}
        </span>
      </div>
    </div>
  );
};

export default HistoryField;
