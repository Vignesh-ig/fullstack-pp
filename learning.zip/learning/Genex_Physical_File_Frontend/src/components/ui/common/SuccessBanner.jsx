import { useEffect } from "react";
import { CheckCircleIcon, CloseIcon } from "../../icons/icons";
import IconButton from "./IconButton";
 
/**
 * SuccessBanner
 *
 * A reusable banner for displaying success messages.
 *
 * @param {string} message - The success message to display.
 * @param {function} [onClose] - Optional callback to dismiss the banner.
 */
const SuccessBanner = ({ message, onClose }) => {
  useEffect(() => {
    if (!message || !onClose) return;
 
    const timer = setTimeout(() => {
      onClose();
    }, 3000);
 
    return () => clearTimeout(timer);
  }, [message, onClose]);
 
  if (!message) return null;
 
  return (
    <div className="mb-3 px-4 py-3 rounded-xl bg-status-success/10 border border-status-success/20 text-status-success text-sm font-medium flex items-center gap-2 slide-in-from-top-1 animate-in duration-300">
      <CheckCircleIcon className="w-4 h-4 shrink-0" />
 
      <span className="flex-1">{message}</span>
 
      {onClose && (
        <IconButton
          icon={<CloseIcon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
          onClick={onClose}
          ariaLabel="Dismiss message"
          className="ml-auto text-status-success/70 hover:text-status-success"
        />
      )}
    </div>
  );
};
 
SuccessBanner.displayName = "SuccessBanner";
export default SuccessBanner;
 