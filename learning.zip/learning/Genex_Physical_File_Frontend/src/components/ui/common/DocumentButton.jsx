import { useState } from "react";
import DocumentUploadModal from "./DocumentUploadModal";
import DocumentViewerModal from "./DocumentViewerModal";

/**
 * DocumentButton
 *
 * Renders document action buttons inside a File Details card footer.
 *
 * - Always renders a "View Document" button when `appNo` is truthy.
 * - Optionally renders an "Upload Document" button when `showUpload` is true.
 *
 * Each button manages its own modal open/close state internally.
 *
 * @param {string}   appNo           - Application number. Both buttons are hidden when falsy.
 * @param {string}   customerName    - Customer Name displayed in the view modal title.
 * @param {string}   [id]            - Optional id for the "View Document" button.
 * @param {boolean}  [showView=true]  - Whether to show the "View Document" button and modal.
 * @param {boolean}  [showUpload=false] - Whether to show the "Upload Document" button.
 * @param {Function} [onUpload]      - Async `(file: File) => Promise<void>` handler that
 *                                    performs the actual DMS upload. Required when
 *                                    `showUpload` is true. Must throw on failure.
 */
const DocumentButton = ({
  appNo,
  customerName,
  id = "view-document-btn",
  showView = true,
  showUpload = false,
  onUpload,
}) => {
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);

  if (!appNo) return null;

  return (
    <>
      {showUpload && (
        <button
          type="button"
          id="upload-document-btn"
          onClick={() => setIsUploadOpen(true)}
          className="text-sm font-semibold text-brand-primary underline underline-offset-2 hover:opacity-75 transition-opacity"
        >
          Upload Document
        </button>
      )}

      {showView && (
        <button
          type="button"
          id={id}
          onClick={() => setIsViewOpen(true)}
          className="text-sm font-semibold text-brand-primary underline underline-offset-2 hover:opacity-75 transition-opacity"
        >
          View Document
        </button>
      )}

      {showView && (
        <DocumentViewerModal
          isOpen={isViewOpen}
          onClose={() => setIsViewOpen(false)}
          appNo={appNo}
          customerName={customerName}
        />
      )}

      {showUpload && (
        <DocumentUploadModal
          isOpen={isUploadOpen}
          onClose={() => setIsUploadOpen(false)}
          appNo={appNo}
          onUpload={onUpload}
        />
      )}
    </>
  );
};

DocumentButton.displayName = "DocumentButton";
export default DocumentButton;
