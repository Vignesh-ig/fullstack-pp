import { useEffect, useRef, useState } from "react";
import { ChevronDownIcon } from "../../icons/icons";

/**
 * PerPageSelectField
 *
 * A custom-styled dropdown for selecting items per page. Follows the pattern of SelectField to ensure consistent behavior and avoid native select positioning issues on mobile.
 *
 * @param {number} value - Current selected items per page.
 * @param {function} onChange - Callback when a new value is selected.
 * @param {any} options - options
 * @param {any} 20 - 20
 * @param {any} 30] - 30]
 */
const PerPageSelectField = ({ value, onChange, options = [10, 50, 100, 250, 500] }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [dropdownPosition, setDropdownPosition] = useState("bottom");
  const containerRef = useRef(null);

  // Handle outside clicks to close the dropdown
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Calculate if the dropdown should open upwards or downwards
  useEffect(() => {
    if (isOpen && containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      const spaceBelow = window.innerHeight - rect.bottom;
      const spaceAbove = rect.top;

      requestAnimationFrame(() => {
        // If less than 150px below and more space above, open upwards
        if (spaceBelow < 150 && spaceAbove > spaceBelow) {
          setDropdownPosition("top");
        } else {
          setDropdownPosition("bottom");
        }
      });
    }
  }, [isOpen]);

  const handleSelect = (option) => {
    if (onChange) {
      onChange(option);
    }
    setIsOpen(false);
  };

  return (
    <div className="flex items-center gap-2" ref={containerRef}>
      <label
        htmlFor="per-page-trigger"
        className="text-xs text-text-secondary font-medium whitespace-nowrap"
      >
        Per page:
      </label>
      <div className="relative">
        <button
          id="per-page-trigger"
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="appearance-none bg-surface-tertiary border border-border-main text-text-primary text-[11px] font-semibold rounded-lg pl-3 pr-8 py-1.5 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary transition-all cursor-pointer flex items-center min-w-14 justify-between shadow-xs hover:border-text-secondary/30"
          aria-haspopup="listbox"
          aria-expanded={isOpen}
        >
          <span>{value}</span>
          <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none text-text-secondary">
            <ChevronDownIcon className="w-3.5 h-3.5" />
          </div>
        </button>

        {/* Options Dropdown */}
        {isOpen && (
          <div
            className={`absolute right-0 w-full min-w-14 z-50 bg-white border border-border-main rounded-lg shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 ${
              dropdownPosition === "top" ? "bottom-full mb-1" : "top-full mt-1"
            }`}
          >
            <div className="py-1">
              {options.map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => handleSelect(option)}
                  className={`w-full px-3 py-1.5 text-left text-[11px] transition-colors flex items-center justify-between ${
                    value === option
                      ? "bg-brand-primary/10 text-brand-primary font-bold"
                      : "text-text-primary hover:bg-surface-tertiary"
                  }`}
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

PerPageSelectField.displayName = "PerPageSelectField";
export default PerPageSelectField;
