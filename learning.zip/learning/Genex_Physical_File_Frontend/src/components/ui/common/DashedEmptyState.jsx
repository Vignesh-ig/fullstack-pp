/**
 * DashedEmptyState
 *
 * A compact, dashed-bordered empty state placeholder.
 *
 * @param {string} title - Main placeholder message.
 * @param {any} description - description
 */
const DashedEmptyState = ({ title, description }) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 bg-surface-tertiary border border-dashed border-border-main rounded-xl">
      <p className="text-sm font-medium text-text-secondary">{title}</p>
      {description && (
        <p className="text-xs text-text-secondary/70 mt-1">{description}</p>
      )}
    </div>
  );
};

DashedEmptyState.displayName = "DashedEmptyState";
export default DashedEmptyState;
