import { useRef } from "react";

/**
 * FileUploadField
 *
 * A styled file input with label, selected-file preview, and error state.
 * Follows the same visual pattern as InputField and TextareaField.
 *
 * @param {string} id - Unique id for the input element (links the label).
 * @param {string} label - Label text rendered above the input.
 * @param {Function} onChange - Change handler receiving the native ChangeEvent.
 * @param {File|null} file - Currently selected File object (for preview).
 * @param {any} accept - accept
 * @param {any} required - required
 * @param {any} error - error
 * @param {any} className - className
 */
const FileUploadField = ({
  id,
  label,
  onChange,
  file = null,
  accept,
  required = false,
  error,
  className = "",
}) => {
  const fileInputRef = useRef(null);

  const wrapperClass = className.includes("mb-")
    ? className
    : `mb-6 ${className}`;

  return (
    <div className={wrapperClass}>
      {label && (
        <label
          className="block text-text-secondary text-xs font-bold uppercase tracking-wider mb-2 min-h-5"
          htmlFor={id}
        >
          {label}
          {required && <span className="required-asterisk">*</span>}
        </label>
      )}

      <input
        id={id}
        type="file"
        ref={fileInputRef}
        onChange={onChange}
        accept={accept}
        className="file-upload-input"
      />

      {file && (
        <p className="mt-1.5 text-xs text-text-secondary truncate">
          Selected: <span className="font-medium">{file.name}</span>
        </p>
      )}

      {error && <p className="file-upload-error">{error}</p>}
    </div>
  );
};

FileUploadField.displayName = "FileUploadField";
export default FileUploadField;
