import { forwardRef, useEffect, useId, useRef, useState } from "react";
import { SelectProvider } from "../../../context/SelectContext";
import { useDebounce } from "../../../hooks/useDebounce";
import { useMultiSelect } from "../../../hooks/useMultiSelect";
import { ChevronDownIcon, CloseIcon } from "../../icons/icons";
import IconButton from "./IconButton";
import DropdownHeader from "../select-with-checkbox/DropdownHeader";
import DropdownPanel from "../select-with-checkbox/DropdownPanel";
import OptionList from "../select-with-checkbox/OptionList";
import SearchBar from "../select-with-checkbox/SearchBar";

/**
 * SelectFieldWithCheckbox
 *
 * A fully custom-styled multi-select dropdown with checkboxes and built-in search, integrated with react-hook-form via `forwardRef`. Features: - Viewport-aware repositioning (flips above trigger when space is tight). - Infinite scroll: calls `onLoadMore` when the user nears the bottom. - Built-in debounced search input (500 ms); emits `onSearchChange` to let the parent fetch filtered results server-side. - Displays a fetch error banner when `fetchError` is provided.
 *
 * @param {string} props.label - Optional label. Selected count shown inline.
 * @param {string} props.name - Field name (react-hook-form).
 * @param {string[]} props.value - Controlled array of selected option values.
 * @param {function} props.onChange - `{ target: { name, value: string[] } }`.
 * @param {function} props.onBlur - Called when focus leaves the dropdown.
 * @param {Array} props.options - `{ label, value }` objects loaded so far.
 * @param {string} props.countText - Noun in count badge, e.g. "branches".
 * @param {string} props.placeholder - Trigger text when nothing is selected.
 * @param {string} props.className - Extra classes on the wrapper div.
 * @param {string} props.error - Validation error shown below the field.
 * @param {string} props.fetchError - API/fetch error shown inside the dropdown.
 * @param {boolean} props.hasMore - Whether more pages exist.
 * @param {boolean} props.isLoadingMore - Show spinner at list bottom while fetching.
 * @param {function} props.onLoadMore - Called when user scrolls to the bottom.
 * @param {number} props.totalItems - Total record count from API.
 * @param {function} props.onSearchChange - Called with the debounced search string.
 * @param {string} props.searchPlaceholder - Placeholder inside the search input.
 * @param {Object[]} [props.selectedOptions] - Pre-selected options detail array.
 * @param {boolean} [props.showSearch=true] - Whether to render search input inside dropdown.
 * @param {boolean} [props.required=false] - Marks the input as required (shows * in label).
 * @param {Function} [props.onOpen] - Called when the dropdown opens.
 * @param {Ref} props.ref - Forwarded ref for hidden input.
 */
const SelectFieldWithCheckbox = forwardRef(
  (
    {
      label,
      name,
      value = [],
      onChange,
      onBlur,
      options = [],
      countText = "selected",
      placeholder = "Select options",
      className = "",
      error,
      fetchError,
      hasMore = false,
      isLoadingMore = false,
      onLoadMore,
      totalItems,
      onSearchChange,
      searchPlaceholder = "Search",
      selectedOptions,
      showSearch = true,
      required = false,
      disabled = false,
      maxSelections,
      showChips = false,
      onOpen,
      showSelectAll = true,
    },
    ref,
  ) => {
    const listboxId = useId();
    const triggerRef = useRef(null);
    const containerRef = useRef(null);
    const searchInputRef = useRef(null);

    const [isOpen, setIsOpen] = useState(false);
    const [dropdownPosition, setDropdownPosition] = useState("bottom");
    const [localSearch, setLocalSearch] = useState("");
    const [focusedIndex, setFocusedIndex] = useState(-1);

    // ── External hooks ────────────────────────────────────────────────────────
    const debouncedSearch = useDebounce(localSearch, 500);

    const onSearchChangeRef = useRef(onSearchChange);
    useEffect(() => {
      onSearchChangeRef.current = onSearchChange;
    });

    useEffect(() => {
      onSearchChangeRef.current?.(debouncedSearch);
    }, [debouncedSearch]);

    const {
      safeValue,
      selectedCount,
      isAllLoadedSelected,
      handleToggle,
      handleGlobalToggle,
      selectedLabels,
      knownLabels,
    } = useMultiSelect({
      value,
      onChange,
      options,
      selectedOptions,
      name,
      maxSelections,
    });

    // Frontend filtering: when no onSearchChange is provided, filter options
    // locally by localSearch so the search bar actually narrows the list.
    const displayOptions = onSearchChange
      ? options
      : options.filter((o) =>
          o.label.toLowerCase().includes(localSearch.toLowerCase()),
        );

    // ── Viewport positioning ──────────────────────────────────────────────────
    useEffect(() => {
      if (isOpen && containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        const spaceBelow = window.innerHeight - rect.bottom;
        const spaceAbove = rect.top;
        requestAnimationFrame(() => {
          setDropdownPosition(
            spaceBelow < 340 && spaceAbove > spaceBelow ? "top" : "bottom",
          );
          searchInputRef.current?.focus();
        });
      }
    }, [isOpen]);

    // Reset state on close
    useEffect(() => {
      if (!isOpen) {
        requestAnimationFrame(() => {
          setLocalSearch("");
          setFocusedIndex(-1);
        });
      }
    }, [isOpen]);

    // ── Outside click ─────────────────────────────────────────────────────────
    useEffect(() => {
      const handleClickOutside = (event) => {
        if (
          containerRef.current &&
          !containerRef.current.contains(event.target)
        ) {
          setIsOpen(false);
          onBlur?.();
        }
      };
      document.addEventListener("mousedown", handleClickOutside);
      return () =>
        document.removeEventListener("mousedown", handleClickOutside);
    }, [onBlur]);

    // ── Keyboard Accessibility ────────────────────────────────────────────────
    const handleKeyDown = (e) => {
      if (!isOpen) {
        if (e.key === "Enter" || e.key === " " || e.key === "ArrowDown") {
          e.preventDefault();
          setIsOpen(true);
        }
        return;
      }

      switch (e.key) {
        case "ArrowDown":
          e.preventDefault();
          setFocusedIndex((prev) =>
            prev < options.length - 1 ? prev + 1 : prev,
          );
          break;
        case "ArrowUp":
          e.preventDefault();
          setFocusedIndex((prev) => (prev > 0 ? prev - 1 : prev));
          break;
        case "Enter":
          if (focusedIndex >= 0 && focusedIndex < options.length) {
            e.preventDefault();
            handleToggle(options[focusedIndex].value);
          } else {
            e.preventDefault(); // prevent form submission from search bar
          }
          break;
        case " ":
          if (document.activeElement === searchInputRef.current) return;
          if (focusedIndex >= 0 && focusedIndex < options.length) {
            e.preventDefault();
            handleToggle(options[focusedIndex].value);
          }
          break;
        case "Escape":
          e.preventDefault();
          setIsOpen(false);
          triggerRef.current?.focus();
          break;
        default:
          break;
      }
    };

    // ── Trigger Display Label ─────────────────────────────────────────────────
    const displayLabel = (() => {
      if (selectedCount === 0) return null;
      if (selectedLabels.length === 0)
        return `${selectedCount} ${countText} selected`;
      if (selectedLabels.length === 1) return selectedLabels[0];
      return `${selectedLabels[0]} +${selectedLabels.length - 1} more`;
    })();

    const ariaActiveDescendant =
      focusedIndex >= 0 ? `${listboxId}-option-${focusedIndex}` : undefined;

    return (
      <div
        className={`mb-6 ${className}`}
        ref={containerRef}
        onKeyDown={handleKeyDown}
      >
        {label && (
          <label className="block text-text-secondary text-xs font-bold uppercase tracking-wider mb-2 min-h-5">
            {label}
            {required && <span className="required-asterisk">*</span>}
            {selectedCount > 0 && (
              <span className="ml-1.5 normal-case font-semibold text-brand-accent animate-in fade-in slide-in-from-left-1 duration-300">
                ({selectedCount} {countText} selected)
              </span>
            )}
          </label>
        )}

        <div className="relative group">
          {/* Trigger button */}
          <button
            type="button"
            ref={(node) => {
              triggerRef.current = node;
              if (typeof ref === "function") ref(node);
              else if (ref) ref.current = node;
            }}
            aria-haspopup="listbox"
            aria-expanded={isOpen}
            aria-controls={listboxId}
            aria-label={label ?? placeholder}
            onClick={() => {
              if (!isOpen && onOpen) onOpen();
              setIsOpen((o) => !o);
            }}
            disabled={disabled}
            className={`w-full px-4 py-3.5 border ${
              disabled
                ? " text-text-secondary/80 cursor-not-allowed border-border-main"
                : error
                  ? "bg-surface-tertiary border-status-error focus:ring-status-error/20 focus:border-status-error focus:bg-white hover:border-text-secondary/30"
                  : "bg-surface-tertiary border-border-main focus:ring-brand-accent/20 focus:border-brand-accent focus:bg-white hover:border-text-secondary/30"
            } rounded-xl text-left flex justify-between items-center focus:outline-none focus:ring-2 transition-all shadow-sm ${!disabled ? "cursor-pointer" : ""}`}
          >
            <span
              className={
                disabled
                  ? "text-inherit font-medium text-sm truncate pr-2"
                  : displayLabel
                    ? "text-text-primary font-medium text-sm truncate pr-2"
                    : "text-text-secondary/70 text-sm"
              }
            >
              {displayLabel ?? placeholder}
            </span>
            <ChevronDownIcon
              className={`w-5 h-5 text-text-secondary transition-transform duration-200 shrink-0 ${
                isOpen ? "rotate-180" : ""
              }`}
            />
          </button>

          <SelectProvider
            value={{
              options: displayOptions,
              safeValue,
              selectedCount,
              isAllLoadedSelected,
              handleToggle,
              handleGlobalToggle,
              hasMore,
              isLoadingMore,
              onLoadMore,
              totalItems,
              localSearch,
              setLocalSearch,
              focusedIndex,
              listboxId,
              fetchError,
              searchPlaceholder,
              searchInputRef,
              showSearch,
            }}
          >
            {/* Dropdown panel */}
            <DropdownPanel
              isOpen={isOpen}
              position={dropdownPosition}
              id={listboxId}
              ariaActiveDescendant={ariaActiveDescendant}
              onMouseDown={(e) => e.stopPropagation()}
            >
              {showSearch && <SearchBar />}
              <DropdownHeader showSelectAll={showSelectAll} />
              {/* Fetch error banner */}
              {fetchError && (
                <div className="px-4 py-2.5 bg-status-error/5 border-b border-status-error/20 text-xs text-status-error flex items-center gap-2">
                  <span className="shrink-0">⚠</span>
                  {fetchError}
                  <button
                    type="button"
                    onClick={() => onLoadMore?.()}
                    className="ml-auto font-semibold underline hover:no-underline"
                  >
                    Retry
                  </button>
                </div>
              )}

              <OptionList />
            </DropdownPanel>
          </SelectProvider>
        </div>

        {/* Selected Chips Area */}
        {showChips && safeValue.length > 0 && (
          <div className="mt-3 p-3 bg-slate-50/80 rounded-lg border border-slate-300 max-h-48 overflow-y-auto custom-scrollbar">
            <div className="flex flex-wrap gap-2">
              {safeValue.map((id) => (
                <div
                  key={id}
                  className="inline-flex items-center gap-1.5 pl-2.5 pr-1 py-1 rounded-full bg-white border border-border-main text-xs font-medium text-slate-700 shadow-sm"
                >
                  <span
                    className="truncate max-w-50"
                    title={knownLabels[id] || id}
                  >
                    {knownLabels[id] || id}
                  </span>
                  <IconButton
                    onClick={(e) => {
                      e.preventDefault();
                      handleToggle(id);
                    }}
                    icon={<CloseIcon className="w-3.5 h-3.5" />}
                    ariaLabel={`Remove ${knownLabels[id] || id}`}
                    className="p-1 bg-transparent text-status-error/70 hover:text-status-error hover:bg-status-error/10 border-none shadow-none"
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {error && (
          <p className="mt-1 text-xs text-status-error font-medium">{error}</p>
        )}
      </div>
    );
  },
);

SelectFieldWithCheckbox.displayName = "SelectFieldWithCheckbox";
export default SelectFieldWithCheckbox;
