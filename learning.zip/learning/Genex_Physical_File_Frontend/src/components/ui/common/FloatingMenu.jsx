import React, { useEffect, useRef, useState } from "react";

/**
 * FloatingMenu
 *
 * A reusable animated sliding pill tab switcher.
 *
 * @param {Array<{id: string, label: string, icon?: React.ComponentType}>} tabs - Tab definitions.
 * @param {string} activeTab - The currently active tab id.
 * @param {Function} onTabChange - Called with the tab id when a tab is clicked.
 * @param {string} className - Optional className for the outer container.
 */
const FloatingMenu = ({ tabs, activeTab, onTabChange, className = "" }) => {
  const [pillStyle, setPillStyle] = useState({ left: 4, width: 0 });
  const containerRef = useRef(null);

  useEffect(() => {
    if (!containerRef.current || !tabs || tabs.length === 0) return;

    const updatePill = () => {
      const activeIndex = tabs.findIndex((t) => t.id === activeTab);
      const safeIndex = activeIndex === -1 ? 0 : activeIndex;

      const buttons = containerRef.current.querySelectorAll("button[role='tab']");
      const activeButton = buttons[safeIndex];

      if (activeButton) {
        setPillStyle({
          left: activeButton.offsetLeft,
          width: activeButton.offsetWidth,
        });
      }
    };

    // Initial positioning
    updatePill();

    // Reposition on window resize (e.g. font loaded, device rotated)
    window.addEventListener("resize", updatePill);
    return () => window.removeEventListener("resize", updatePill);
  }, [activeTab, tabs]);

  if (!tabs || tabs.length === 0) return null;

  return (
    <div
      ref={containerRef}
      className={`relative inline-flex bg-slate-50 p-1 border border-slate-400/60 rounded-xl shadow-md shadow-slate-400/50 ${className}`}
      role="tablist"
    >
      {/* Animated sliding pill */}
      <div
        className="absolute top-1 bottom-1 rounded-[10px] bg-brand-primary shadow-md transition-all duration-300 ease-in-out"
        style={{
          left: `${pillStyle.left}px`,
          width: `${pillStyle.width}px`,
        }}
      />

      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        const Icon = tab.icon;

        return (
          <button
            key={tab.id}
            type="button"
            role="tab"
            id={`tab-${tab.id}`}
            aria-selected={isActive}
            aria-controls={`tabpanel-${tab.id}`}
            onClick={() => onTabChange(tab.id)}
            className={`relative z-10 flex items-center justify-center gap-2 px-6 py-2 text-xs font-bold rounded-[10px] transition-colors duration-300 whitespace-nowrap ${
              isActive ? "text-white" : "text-black hover:text-text-primary"
            }`}
          >
            {Icon && <Icon className="w-4 h-4" />}
            {tab.label}
          </button>
        );
      })}
    </div>
  );
};

FloatingMenu.displayName = "FloatingMenu";
export default FloatingMenu;
