import { useSelector } from "react-redux";
import { canPerformOperation } from "../../../constants/roles";
import { DeleteIcon } from "../../icons/icons";
import IconButtonWithHover from "./IconButtonWithHover";

/**
 * TableRecordDeleteButton
 *
 * A reusable delete action button for table records. Renders conditionally based on case-insensitive permissions of the logged-in user.
 *
 * @param {string} recordId - Unique ID of the record to delete.
 * @param {function} onDeleteClick - Callback function called with recordId.
 * @param {boolean} isDeleting - Deletion loading state to disable interactions.
 * @param {string} label - Action accessibility/tooltip label.
 * @param {any} bypassPermissionCheck - bypassPermissionCheck
 */
const TableRecordDeleteButton = ({
  recordId,
  onDeleteClick,
  isDeleting,
  label = "Delete Record",
  bypassPermissionCheck = false,
}) => {
  const { userEmployeeCode: currentUserCode } = useSelector(
    (state) => state.user,
  );

  if (!bypassPermissionCheck && !canPerformOperation(currentUserCode))
    return null;

  return (
    <IconButtonWithHover
      onClick={() => onDeleteClick(recordId)}
      icon={<DeleteIcon />}
      label={label}
      colorClass="hover:text-status-error hover:bg-status-error/5"
      disabled={isDeleting}
    />
  );
};

TableRecordDeleteButton.displayName = "TableRecordDeleteButton";
export default TableRecordDeleteButton;
