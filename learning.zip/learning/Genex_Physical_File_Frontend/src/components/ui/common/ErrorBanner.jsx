import { AlertCircleIcon, CloseIcon } from "../../icons/icons";
import IconButton from "./IconButton";

/**
 * ErrorBanner
 *
 * Displays a styled error or warning message with an optional close button.
 *
 * @param {string} message - Message text to display.
 * @param {function} onClose - Optional callback to dismiss the banner.
 * @param {string} type - 'error' (default) or 'warning'
 */
const BANNERTYPE = {
  ERROR: "error",
  WARNING: "warning",
};

const ErrorBanner = ({ message, onClose, type = BANNERTYPE.ERROR }) => {
  if (!message) return null;

  const isWarning = type === BANNERTYPE.WARNING;
  const containerClasses = isWarning
    ? "bg-amber-50 border-status-warning/20 text-status-warning"
    : "bg-status-error-bg border-status-error/20 text-status-error";

  const buttonClasses = isWarning
    ? "text-status-warning/70 hover:text-status-warning"
    : "text-status-error/70 hover:text-status-error";

  return (
    <div
      className={`mb-4 px-4 py-3 rounded-xl border text-sm font-medium flex items-center gap-2 ${containerClasses}`}
    >
      <AlertCircleIcon className="w-4 h-4 shrink-0" />
      <span className="flex-1">{message}</span>
      {onClose && (
        <IconButton
          icon={<CloseIcon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
          onClick={onClose}
          ariaLabel="Dismiss message"
          className={`ml-auto ${buttonClasses}`}
        />
      )}
    </div>
  );
};

ErrorBanner.displayName = "ErrorBanner";
export default ErrorBanner;
