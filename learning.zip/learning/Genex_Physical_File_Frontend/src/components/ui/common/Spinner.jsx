/**
 * Spinner
 *
 * Full-screen animated loading spinner. Takes no props.
 */
const Spinner = () => (
  <div className="min-h-screen flex flex-col items-center justify-center">
    <div className="relative flex items-center justify-center">
      <div className="w-16 h-16 border-4 border-brand-primary/20 rounded-full"></div>
      <div className="w-16 h-16 border-4 border-t-brand-primary rounded-full animate-spin absolute top-0 left-0"></div>
    </div>
    <div className="mt-6 flex items-center gap-2 text-brand-primary font-bold tracking-[0.25em] text-sm">
      <span>LOADING</span>
      <span className="flex gap-1">
        <span className="w-1.5 h-1.5 bg-brand-primary rounded-full animate-bounce-high [animation-delay:-0.3s]"></span>
        <span className="w-1.5 h-1.5 bg-brand-primary rounded-full animate-bounce-high [animation-delay:-0.15s]"></span>
        <span className="w-1.5 h-1.5 bg-brand-primary rounded-full animate-bounce-high"></span>
      </span>
    </div>
  </div>
);

Spinner.displayName = "Spinner";
export default Spinner;
