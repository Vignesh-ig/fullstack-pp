import { CloseIcon } from "../../icons/icons";
import IconButton from "./IconButton";

/**
 * DenominationsTable
 *
 * Renders a summary table of selected stamp denominations.
 *
 * @param {Array} data - Array of denomination summary objects: [{ denoNo, count, serials: [{ id, label }] }]
 * @param {Function} onRemoveSerial - Optional callback to remove a serial. Signature: (denoNo, serialId) => void
 * @param {boolean} isReadOnly - If true, hides the remove buttons.
 */
const DenominationsTable = ({ data, onRemoveSerial, isReadOnly = false }) => {
  if (!data || data.length === 0) return null;

  return (
    <div className="rounded-xl border border-border-main overflow-hidden bg-white mt-4">
      <div className="overflow-x-auto custom-scrollbar">
        <table className="min-w-full text-left border-collapse bg-white">
          <thead className="sticky top-0 z-10">
            <tr className="bg-table-header-bg">
              {["Denomination", "Count", "Serial Numbers"].map((h) => (
                <th
                  key={h}
                  className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-table-header-text border-b border-slate-100 whitespace-nowrap text-start"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y-2 divide-table-header-bg bg-white">
            {data.map((row) => (
              <tr key={row.denoNo} className="bg-white">
                <td className="table-td font-semibold text-text-primary">
                  ₹ {row.denoNo}
                </td>
                <td className="table-td">
                  <span className="inline-flex items-center justify-center w-6 h-6 text-brand-primary text-md font-bold">
                    {row.count}
                  </span>
                </td>
                <td className="table-td">
                  <div className="flex flex-wrap gap-1.5">
                    {row.serials.map((serial) => (
                      <span
                        key={serial.id}
                        className="inline-flex items-center gap-1 pl-2.5 pr-1 py-0.5 rounded-md bg-surface-tertiary border border-border-main text-text-primary text-xs font-medium"
                      >
                        <span className={isReadOnly ? "pr-1.5" : ""}>
                          {serial.label}
                        </span>
                        {!isReadOnly && onRemoveSerial && (
                          <IconButton
                            onClick={(e) => {
                              e.preventDefault();
                              onRemoveSerial(row.denoNo, serial.id);
                            }}
                            icon={<CloseIcon className="w-3.5 h-3.5" />}
                            ariaLabel={`Remove ${serial.label}`}
                            className="p-0.5 bg-transparent text-text-secondary hover:text-status-error hover:bg-status-error/10 border-none shadow-none focus:ring-0"
                          />
                        )}
                      </span>
                    ))}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DenominationsTable;
