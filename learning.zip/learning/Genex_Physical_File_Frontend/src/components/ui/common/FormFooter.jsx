import Button from "./Button";

/**
 * FormFooter
 *
 * Reusable footer for forms with dynamic buttons (up to 4).
 *
 * @param {any} buttons - buttons
 */
const FormFooter = ({
  buttons = [],
  className = "",
  buttonWidth = "200px",
  buttonAlign = "right",
}) => {
  const visibleButtons = buttons.slice(0, 4);

  const alignmentClasses = {
    left: "justify-start",
    center: "justify-center",
    right: "justify-end",
  };

  return (
    <footer
      className={`mt-4 flex w-full items-center border-t border-border-subtle pt-4 ${className}`}
    >
      <div
        className={`flex w-full items-center ${alignmentClasses[buttonAlign]}`}
      >
        {visibleButtons.map((btn, index) => (
          <div
            key={index}
            style={{
              width: buttonWidth,
              flexShrink: 0,
            }}
          >
            <Button
              {...(btn.props || {})}
             disabled={btn.disabled ?? btn.props?.disabled ?? false}
              className="!w-full"
            >
              {btn.label}
            </Button>
          </div>
        ))}
      </div>
    </footer>
  );
};

FormFooter.displayName = "FormFooter";

export default FormFooter;