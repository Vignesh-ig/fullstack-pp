import { useState } from "react";
import { RefreshIcon } from "../../icons/icons";

/**
 * SlidingButton
 *
 * Compact circular icon button that expands horizontally on hover to reveal a label.
 * Supports loading state, multiple sizes, and custom colour theming.
 *
 * @param {function} [props.onClick] - Click handler. Not invoked while disabled or loading.
 * @param {ReactNode} props.icon - SVG / element shown inside the circular icon area.
 * @param {string} props.label - Text revealed on hover and shown during loading.
 * @param {boolean} [props.isLoading=false] - Replaces icon with a spinner and shows loadingText.
 * @param {string} [props.loadingText] - Text shown while isLoading is true. Falls back to label.
 * @param {string} [props.color="bg-brand-primary"] - Tailwind background colour class.
 * @param {string} [props.textColor="text-white"] - Tailwind text colour class.
 * @param {"sm"|"md"|"lg"} [props.size="md"] - Size variant.
 * @param {string} [props.className=""] - Optional extra classes on the outer wrapper div.
 * @param {boolean} [props.disabled=false] - Prevents clicks and dims the button.
 */
const SIZE_CONFIG = {
  sm: {
    width: "w-8",
    maxWidth: "max-w-[2rem]",
    height: "h-8",
    iconSize: "w-4 h-4",
    labelSize: "text-xs",
    pl: "pl-10",
  },
  md: {
    width: "w-10",
    maxWidth: "max-w-[2.5rem]",
    height: "h-10",
    iconSize: "w-5 h-5",
    labelSize: "text-sm",
    pl: "pl-11",
  },
  lg: {
    width: "w-12",
    maxWidth: "max-w-[3rem]",
    height: "h-12",
    iconSize: "w-6 h-6",
    labelSize: "text-base",
    pl: "pl-14",
  },
};

const SlidingButton = ({
  onClick,
  icon,
  label,
  isLoading = false,
  loadingText,
  color = "bg-brand-primary",
  textColor = "text-white",
  size = "md",
  className = "",
  disabled = false,
}) => {
  const config = SIZE_CONFIG[size];
  const [isHovered, setIsHovered] = useState(false);
  const finalLoadingText = loadingText || label;

  return (
    <div
      className={`relative ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div
        className={`relative flex items-center cursor-pointer transition-all duration-500 ease-out ${
          isHovered ? "max-w-75" : config.maxWidth
        } ${config.height}`}
        style={{ width: "max-content" }}
        onClick={disabled || isLoading ? undefined : onClick}
      >
        {/* Button icon */}
        <button
          type="button"
          disabled={disabled || isLoading}
          className={`absolute left-0 top-1/2 -translate-y-1/2 ${config.width} ${config.height} ${color} ${textColor} rounded-full flex items-center justify-center shadow-lg transition-all duration-200 z-10 hover:scale-105 active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed`}
        >
          {isLoading ? (
            <RefreshIcon className={`${config.iconSize} animate-spin`} />
          ) : (
            icon
          )}
        </button>

        {/* Label — slides in on hover */}
        <div
          className={`ml-0 ${config.pl} pr-4 h-10 ${config.labelSize} ${color} ${textColor} rounded-full flex items-center whitespace-nowrap shadow-sm transition-all duration-300 ${
            isHovered ? "opacity-100 visible" : "opacity-0 invisible"
          }`}
          style={{ height: config.height.replace("h-", "") }}
        >
          {isLoading ? finalLoadingText : label}
        </div>
      </div>
    </div>
  );
};

SlidingButton.displayName = "SlidingButton";
export default SlidingButton;
 