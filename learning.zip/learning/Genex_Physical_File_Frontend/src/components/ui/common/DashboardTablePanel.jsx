import { AddIcon, MinimizeIcon } from "../../icons/icons";
import ListContainer from "../../layout/ListContainer";
import ErrorBanner from "./ErrorBanner";

/**
 * DashboardTablePanel
 *
 * Shared minimize/maximize panel wrapper used by both DashboardAllocationTable
 * and DashboardStampingTable. Handles the collapsible header and body layout.
 * The actual table and pagination are passed as children.
 *
 * @param {string}    label      - Section heading shown in the panel header.
 * @param {number}    totalItems - Record count shown below the heading when loaded.
 * @param {boolean}   loading    - Hides the record count while fetching.
 * @param {string}    [error]    - Error message to display inside the panel body.
 * @param {Function}  onDismissError - Called when the error banner is closed.
 * @param {boolean}   isOpen     - Controls the expand/collapse state.
 * @param {Function}  onToggle   - Called when the minimize/maximize button is clicked.
 * @param {object}    panelRef   - Ref attached to the outer wrapper (for scroll-into-view).
 * @param {React.ReactNode} children - Table + pagination content rendered inside the panel.
 */
const DashboardTablePanel = ({
  label,
  totalItems,
  loading,
  error,
  onDismissError,
  isOpen,
  onToggle,
  panelRef,
  children,
}) => (
  <div ref={panelRef} className="dashboard-allocation-table-wrapper">
    <ListContainer>
      {/* ── Header with minimize/maximize toggle ─────────────────── */}
      <div className="dashboard-allocation-table-header">
        <div>
          <h2 className="text-xl font-bold text-text-primary">{label}</h2>
          {!loading && (
            <p className="text-xs text-text-secondary mt-0.5">
              {totalItems} record{totalItems !== 1 ? "s" : ""}
            </p>
          )}
        </div>
        <button
          type="button"
          onClick={onToggle}
          aria-label={isOpen ? "Collapse table" : "Expand table"}
          className="dashboard-allocation-toggle-btn"
        >
          <span className="flex items-center gap-1 text-xs">
            {isOpen ? (
              <>
                <MinimizeIcon className="h-4 w-4" />
                Minimize
              </>
            ) : (
              <>
                <AddIcon className="h-4 w-4" />
                Expand
              </>
            )}
          </span>
        </button>
      </div>

      {/* ── Collapsible body ─────────────────────────────────────── */}
      <div className={`expandable-row-wrapper ${isOpen ? "expanded" : ""}`}>
        <div className="expandable-row-inner">
          {error && (
            <section className="px-6 pt-4">
              <ErrorBanner message={error} onClose={onDismissError} />
            </section>
          )}
          {children}
        </div>
      </div>
    </ListContainer>
  </div>
);

DashboardTablePanel.displayName = "DashboardTablePanel";
export default DashboardTablePanel;
