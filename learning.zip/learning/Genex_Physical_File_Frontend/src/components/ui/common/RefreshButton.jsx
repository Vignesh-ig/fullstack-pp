import { useState } from "react";
import { RefreshIcon } from "../../icons/icons";
import IconButton from "./IconButton";

/**
 * RefreshButton
 *
 * Circular icon button that triggers a data refresh with a 360° spin animation on each click.
 *
 * @param {function} [props.onRefresh] - Callback invoked when the button is clicked.
 * @param {string} [props.className=""] - Optional extra Tailwind classes on the button element.
 * @param {string} [props.title="Refresh"] - Tooltip text shown on hover.
 * @param {string} [props.ariaLabel="Refresh"] - Accessible label for screen readers.
 * @param {"sm"|"md"|"lg"} [props.size="md"] - Size variant.
 */
const SIZE_CONFIG = {
  sm: { buttonSize: "w-8 h-8", iconSize: "w-4 h-4" },
  md: { buttonSize: "w-10 h-10", iconSize: "w-5 h-5" },
  lg: { buttonSize: "w-12 h-12", iconSize: "w-6 h-6" },
};

const RefreshButton = ({
  onRefresh,
  className = "",
  title = "Refresh",
  ariaLabel = "Refresh",
  size = "md",
}) => {
  const [rotationDeg, setRotationDeg] = useState(0);
  const config = SIZE_CONFIG[size];

  const handleClick = () => {
    setRotationDeg((prev) => prev + 360);
    onRefresh?.();
  };

  return (
    <IconButton
      onClick={handleClick}
      ariaLabel={ariaLabel}
      title={title}
      className={`${config.buttonSize} bg-brand-primary text-white shadow-lg hover:scale-105 transition-all duration-200 ${className}`}
      icon={
        <div
          className={`${config.iconSize} transition-transform duration-500 ease-out`}
          style={{ transform: `rotate(${rotationDeg}deg)` }}
        >
          <RefreshIcon className="w-full h-full" />
        </div>
      }
    />
  );
};

RefreshButton.displayName = "RefreshButton";
export default RefreshButton;
