import { useRef } from "react";
import { CloseIcon, SearchIcon } from "../../icons/icons";
import IconButton from "./IconButton";

/**
 * SearchInput
 *
 * A search input with a leading search icon and a clear button that appears when the input has a value.
 *
 * @param {string} value - Controlled input value.
 * @param {function} onChange - Called with the new string value on change.
 * @param {string} placeholder - Placeholder text (default "Search").
 * @param {string} className - Optional extra classes on the wrapper div.
 * @param {boolean} expandable - Compact icon mode that expands on hover/focus.
 * @param {function} onKeyDown - Optional key down event handler.
 */
const SearchInput = ({
  value,
  onChange,
  placeholder = "Search",
  className = "",
  expandable = false,
  onKeyDown,
}) => {
  const inputRef = useRef(null);
  const hasValue = Boolean(value);

  return (
    <div className={`relative group/search ${className}`}>
      <div
        className={`relative h-10 transition-all duration-500 ease-out ${
          expandable
            ? `w-10 ${hasValue ? "sm:w-72" : "sm:group-hover/search:w-72 sm:focus-within:w-72"}`
            : "w-full"
        }`}
      >
        <button
          type="button"
          onClick={() => inputRef.current?.focus()}
          className={`absolute left-0 top-0 w-10 h-10 rounded-full z-20 flex items-center justify-center transition-all duration-300 ${
            expandable
              ? "bg-brand-primary text-white shadow-md"
              : "text-text-secondary/60 hover:text-brand-primary"
          } `}
          aria-label="Search"
        >
          <SearchIcon
            className={`w-5 h-5 transition-transform duration-300 ${expandable && !hasValue ? "scale-100" : "scale-90"}`}
          />
        </button>

        <input
          ref={inputRef}
          id="user-search"
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={placeholder}
          autoComplete="off"
          className={`w-full h-full pl-11 pr-10 text-sm text-text-primary placeholder-text-secondary/40 bg-surface-tertiary shadow-sm transition-all duration-500 ease-[cubic-bezier(0.23,1,0.32,1)] focus:outline-none focus:ring-2 focus:ring-brand-accent/20 focus:border-brand-accent ${
            expandable
              ? `${hasValue ? "opacity-100" : "opacity-0 group-hover/search:opacity-100 focus:opacity-100"} rounded-full border border-brand-primary`
              : "bg-surface-tertiary border border-border-main rounded-xl"
          }`}
        />

        {hasValue && (
          <IconButton
            icon={<CloseIcon className="w-3.5 h-3.5" />}
            onClick={() => {
              onChange("");
              inputRef.current?.focus();
            }}
            ariaLabel="Clear search"
            className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 text-text-secondary/80 hover:text-text-primary hover:bg-slate-200/50 transition-all z-30 animate-in fade-in zoom-in duration-300"
          />
        )}
      </div>
    </div>
  );
};

SearchInput.displayName = "SearchInput";
export default SearchInput;
