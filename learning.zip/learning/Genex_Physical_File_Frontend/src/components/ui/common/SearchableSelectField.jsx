import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Virtuoso } from "react-virtuoso";
import {
  CheckmarkSolidIcon,
  ChevronDownIcon,
  SpinnerIcon,
} from "../../icons/icons";
import SearchBar from "../select-with-checkbox/SearchBar";

/**
 * SearchableSelectField
 *
 * A searchable single-select dropdown. Supports React Portal rendering to avoid container clipping inside tables.
 * Falls back to client-side filtering if onSearchChange is not provided.
 *
 * @param {string} label
 * @param {string} subLabel
 * @param {string} name
 * @param {string} value
 * @param {Function} onChange
 * @param {Function} onBlur
 * @param {Array} options
 * @param {string} placeholder
 * @param {string} searchTerm
 * @param {Function} onSearchChange
 * @param {boolean} hasMore
 * @param {boolean} isLoadingMore
 * @param {Function} onLoadMore
 * @param {any} error
 * @param {boolean} disabled
 * @param {boolean} required
 * @param {string} className
 * @param {Function} [onOpen] - Called each time the dropdown opens.
 */
const SearchableSelectField = ({
  label,
  subLabel,
  name,
  value,
  onChange,
  onBlur,
  options = [],
  placeholder = "Select",
  searchTerm = "",
  onSearchChange,
  hasMore = false,
  isLoadingMore = false,
  onLoadMore,
  error,
  disabled = false,
  required = false,
  multiSelect= false,
  className = "",
  triggerClassName = "py-3.5",
  onOpen,
  dropdownScrollX = false,
  
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [coords, setCoords] = useState(null);

  const containerRef = useRef(null);
  const portalRef = useRef(null);
  const searchRef = useRef(null);

  const [cachedOption, setCachedOption] = useState(null);

  const [prevValue, setPrevValue] = useState(value);
  const [prevOptions, setPrevOptions] = useState(options);

  if (value !== prevValue || options !== prevOptions) {
    setPrevValue(value);
    setPrevOptions(options);
    if (value) {
      const found = options.find((o) => o.value === value);
      if (found) {
        setCachedOption(found);
      }
    } else {
      setCachedOption(null);
    }
  }

  // const selectedOption = options.find((o) => o.value === value) ?? cachedOption;
  
  const selectedOption = !multiSelect
  ? options.find((o) => o.value === value) ?? cachedOption
  : null;
 
const selectedOptions = multiSelect
  ? options.filter(
      (option) =>
        Array.isArray(value) && value.includes(option.value),
    )
  : [];
 
  

  const [localSearch, setLocalSearch] = useState("");
  const displaySearchTerm = onSearchChange ? searchTerm : localSearch;

  const handleSearchInputChange = (val) => {
    if (onSearchChange) {
      onSearchChange(val);
    } else {
      setLocalSearch(val);
    }
  };

  const clearSearchValue = useCallback(() => {
    if (onSearchChange) {
      onSearchChange("");
    } else {
      setLocalSearch("");
    }
  }, [onSearchChange]);

  const handleClearSearch = () => {
    clearSearchValue();
    searchRef.current?.focus();
  };

  const filteredOptions = onSearchChange
    ? options
    : options.filter(
        (o) =>
          o.label.toLowerCase().includes(localSearch.toLowerCase()) ||
          o.sublabel?.toLowerCase().includes(localSearch.toLowerCase()),
      );

  // Close on outside click
  useEffect(() => {
    const handler = (e) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target) &&
        portalRef.current &&
        !portalRef.current.contains(e.target)
      ) {
        if (isOpen) {
          onBlur?.();
          clearSearchValue();
        }
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [isOpen, onBlur, clearSearchValue]);

  // Handle tabbing out while dropdown is open
  useEffect(() => {
    const handleFocusOut = () => {
      setTimeout(() => {
        const active = document.activeElement;
        const inPortal =
          portalRef.current && portalRef.current.contains(active);
        const inContainer =
          containerRef.current && containerRef.current.contains(active);
        if (!inPortal && !inContainer) {
          if (isOpen) {
            onBlur?.();
            clearSearchValue();
            setIsOpen(false);
          }
        }
      }, 50);
    };
    if (isOpen) {
      document.addEventListener("focusout", handleFocusOut);
    }
    return () => document.removeEventListener("focusout", handleFocusOut);
  }, [isOpen, onBlur, clearSearchValue]);

  // Viewport-aware positioning + Portal Coords updates
  const updateCoords = () => {
    if (containerRef.current) {
      const buttonEl = containerRef.current.querySelector("button");
      const rect = buttonEl
        ? buttonEl.getBoundingClientRect()
        : containerRef.current.getBoundingClientRect();
      const spaceBelow = window.innerHeight - rect.bottom;
      const willShowTop = spaceBelow < 280 && rect.top > spaceBelow;

      setCoords({
        top: rect.top,
        bottom: rect.bottom,
        viewportBottom: window.innerHeight - rect.bottom,
        viewportTopDistance: window.innerHeight - rect.top,
        left: rect.left,
        width: rect.width,
        placement: willShowTop ? "top" : "bottom",
      });
    }
  };

  useEffect(() => {
    if (isOpen) {
      requestAnimationFrame(() => {
        updateCoords();
      });
      window.addEventListener("scroll", updateCoords, true);
      window.addEventListener("resize", updateCoords);
    } else {
      requestAnimationFrame(() => {
        setCoords(null);
      });
    }
    return () => {
      window.removeEventListener("scroll", updateCoords, true);
      window.removeEventListener("resize", updateCoords);
    };
  }, [isOpen]);

  // Auto-focus search when opened
  useEffect(() => {
    if (isOpen && coords && searchRef.current) {
      setTimeout(() => searchRef.current?.focus(), 50);
    }
  }, [isOpen, coords]);

  // const handleSelect = (opt) => {
  //   onChange?.(opt);
  //   setIsOpen(false);
  //   clearSearchValue();
  //   onBlur?.();
  // };

const handleSelect = (opt) => {
  if (opt.disabled) return;
 
  if (multiSelect) {
  const currentValues = Array.isArray(value) ? value : [];
 
  const isSelected = currentValues.includes(opt.value);
 
  const newValues = isSelected
    ? currentValues.filter((item) => item !== opt.value)
    : [...currentValues, opt.value];
 
  const selectedOptionObjects = options.filter((option) =>
    newValues.includes(option.value),
  );
 
  onChange?.(selectedOptionObjects);
 
  // Clear search text after selecting
  clearSearchValue();
 
  return;
}
 
 
  onChange?.(opt);
  setIsOpen(false);
  clearSearchValue();
  onBlur?.();
};
 

  const handleToggle = () => {
    if (!disabled) {
      setIsOpen((prev) => {
        if (!prev && onOpen) onOpen();
        if (prev) {
          clearSearchValue();
        }
        return !prev;
      });
    }
  };

  const wrapperClass = className.includes("mb-")
    ? className
    : `mb-6 ${className}`;

  return (
    <div className={wrapperClass} ref={containerRef}>
      {label && (
        <label className="block text-text-secondary text-xs font-bold uppercase tracking-wider mb-2 min-h-5">
          {label}
          {required && <span className="required-asterisk">*</span>}
          {subLabel && (
            <span className="ml-2 font-normal normal-case tracking-normal text-[10px] text-text-secondary/80">
              ({subLabel})
            </span>
          )}
        </label>
      )}

      <div className="relative">
        {/* Trigger */}
        <button
          type="button"
          onClick={handleToggle}
          disabled={disabled}
          onBlur={() => {
            if (!isOpen) {
              onBlur?.();
            }
          }}
          className={`w-full px-4 ${triggerClassName} bg-surface-tertiary border ${
            error ? "border-status-error" : "border-border-main"
          } rounded-xl text-left flex justify-between items-center focus:outline-none focus:ring-2 ${
            error
              ? "focus:ring-status-error/20 focus:border-status-error"
              : "focus:ring-brand-accent/20 focus:border-brand-accent"
          } focus:bg-white transition-all shadow-sm ${
            disabled
              ? "opacity-60 cursor-not-allowed"
              : "cursor-pointer hover:border-text-secondary/30"
          }`}
        >
          <span
            className={
              (multiSelect ? selectedOptions.length > 0 : selectedOption)
  ? "text-text-primary font-medium text-sm truncate pr-2"
  : "text-text-secondary/70 text-sm"
            }
          >
          {multiSelect
 
    ? placeholder
  : selectedOption
    ? selectedOption.label
    : placeholder}

          </span>
          <ChevronDownIcon
            className={`w-4 h-4 text-text-secondary shrink-0 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}
          />
        </button>

        {/* Hidden input for form compat */}
  <input
  type="hidden"
  name={name}
  value={
    multiSelect
      ? Array.isArray(value)
        ? value.join(",")
        : ""
      : value ?? ""
  }
/>

        {/* Portaled Dropdown */}
        {isOpen &&
          coords &&
          createPortal(
            <div
              ref={portalRef}
              className="fixed z-9999 bg-white border border-border-main rounded-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col"
              style={{
                left: `${coords.left}px`,
                width: `${coords.width}px`,
                ...(coords.placement === "top"
                  ? { bottom: `${coords.viewportTopDistance + 8}px` }
                  : { top: `${coords.bottom + 8}px` }),
              }}
            >
              {/* Search box */}
              <SearchBar
                ref={searchRef}
                value={displaySearchTerm}
                onChange={handleSearchInputChange}
                isLoadingMore={isLoadingMore}
                placeholder="Type to search"
                onClear={handleClearSearch}
              />

              {/* Options list */}
              <div
                className="flex flex-col py-1"
                style={{
                  height:
                    filteredOptions.length === 0
                      ? isLoadingMore
                        ? "12rem"
                        : "auto"
                      : `${Math.min(
                          filteredOptions.length * 75 + (hasMore ? 48 : 0),
                          224,
                        )}px`,
                }}
              >
                
                <div className={`flex-1 min-h-0 ${dropdownScrollX ? "overflow-x-auto" : ""}`}>
                  {filteredOptions.length === 0 && !isLoadingMore ? (
                    <div className="px-4 py-4 text-sm text-text-secondary text-center italic">
                      {displaySearchTerm
                        ? `No results for "${displaySearchTerm}"`
                        : "No options available"}
                    </div>
                  ) : (
                    <Virtuoso
                      className="h-full w-full"
                      data={filteredOptions}
                      computeItemKey={(index, item) => item.value}
                      endReached={() => {
                        if (hasMore && !isLoadingMore) {
                          onLoadMore?.();
                        }
                      }}
                      itemContent={(index, opt) => {
  const isSelected = multiSelect
    ? Array.isArray(value) && value.includes(opt.value)
    : value === opt.value;
 
  return (
    <button
      key={opt.value}
      type="button"
      onClick={() => !opt.disabled && handleSelect(opt)}
      disabled={opt.disabled}
      className={`px-4 py-2.5 text-left transition-colors flex items-start justify-between gap-2 ${
        dropdownScrollX
          ? "w-max min-w-full pr-8"
          : "w-full"
      } ${
        opt.disabled
          ? "opacity-50 cursor-not-allowed text-text-secondary bg-surface-tertiary/50"
          : isSelected
            ? "bg-brand-primary/5 text-brand-primary"
            : "text-text-primary hover:bg-surface-tertiary"
      }`}
    >
      <span
        className={`flex flex-col ${
          dropdownScrollX ? "" : "min-w-0"
        }`}
      >
        <span
          className={`text-sm font-medium ${
            dropdownScrollX
              ? "whitespace-nowrap pr-4"
              : "truncate"
          } ${isSelected ? "text-brand-primary" : ""}`}
        >
          {opt.label}
        </span>
 
        {opt.sublabel && (
          <span className="text-xs text-text-secondary truncate">
            {opt.sublabel}
          </span>
        )}
      </span>
 
      {isSelected && (
        <CheckmarkSolidIcon className="w-4 h-4 shrink-0 mt-0.5" />
      )}
    </button>
  );
}}
 
                      components={{
                        Footer: () => {
                          if (!hasMore) return <div className="h-1 shrink-0" />;
                          return (
                            <div className="flex items-center justify-center py-3">
                              {isLoadingMore && (
                                <SpinnerIcon className="w-4 h-4 text-brand-primary animate-spin" />
                              )}
                            </div>
                          );
                        },
                      }}
                    />
                  )}
                </div>
              </div>
            </div>,
            document.body,
          )}
      </div>

      {error && (
        <p className="mt-1 text-xs text-status-error font-medium">{error}</p>
      )}
    </div>
  );
};

SearchableSelectField.displayName = "SearchableSelectField";
export default SearchableSelectField;
