/**
 * TableSkeletonRow
 *
 * Renders a single animated skeleton placeholder row for tables. Used during the loading state.
 *
 * @param {number} columnsCount - The number of columns in the table to render skeleton cells for.
 */
const TableSkeletonRow = ({ columnsCount = 1 }) => (
  <tr className="animate-pulse">
    {Array.from({ length: columnsCount }).map((_, i) => (
      <td key={i} className="px-4 py-4">
        <div className="h-3.5 bg-border-subtle rounded-full w-full max-w-30" />
      </td>
    ))}
  </tr>
);

TableSkeletonRow.displayName = "TableSkeletonRow";
export default TableSkeletonRow;
