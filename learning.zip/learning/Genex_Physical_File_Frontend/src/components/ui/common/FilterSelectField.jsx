import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ChevronDownIcon } from "../../icons/icons";
import SearchBar from "../select-with-checkbox/SearchBar";

/**
 * FilterSelectField
 *
 * A compact, custom-styled dropdown for filter bars.
 * look and feel, but accepts label/value option objects.
 *
 * @param {string} label - Label shown before the dropdown.
 * @param {string} name - Input name attribute.
 * @param {string} value - Currently selected value.
 * @param {function} onChange - Callback (e) => {} mimicking native select change.
 * @param {any} options - options
 * @param {any} placeholder - placeholder
 * @param {any} className - className
 * @param {any} showSearch - showSearch
 * @param {any} searchPlaceholder - searchPlaceholder
 * @param {any} searchTerm - searchTerm
 * @param {any} onSearchChange - onSearchChange
 * @param {any} isLoadingMore - isLoadingMore
 * @param {any} hasMore - hasMore
 * @param {any} onLoadMore - onLoadMore
 * @param {any} buttonClass - buttonClass
 * @param {any} disabled - disabled
 * @param {any} onOpen - onOpen
 */
const FilterSelectField = ({
  label,
  name,
  value,
  onChange,
  options = [],
  placeholder = "All",
  className = "",
  showSearch = false,
  searchPlaceholder = "Search...",
  searchTerm = "",
  onSearchChange,
  isLoadingMore = false,
  hasMore = false,
  onLoadMore,
  buttonClass = "md:min-w-57.5",
  disabled = false,
  onOpen,
  renderOption,
  renderSelected,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [coords, setCoords] = useState(null);
  const [localSearch, setLocalSearch] = useState("");
  const displaySearchTerm = onSearchChange ? searchTerm : localSearch;
  const containerRef = useRef(null);
  const portalRef = useRef(null);

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target) &&
        portalRef.current &&
        !portalRef.current.contains(event.target)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Viewport-aware positioning
  const updateCoords = () => {
    if (containerRef.current) {
      const buttonEl = containerRef.current.querySelector("button");
      const rect = buttonEl
        ? buttonEl.getBoundingClientRect()
        : containerRef.current.getBoundingClientRect();
      const spaceBelow = window.innerHeight - rect.bottom;
      const willShowTop = spaceBelow < 150 && rect.top > spaceBelow;

      setCoords({
        left: rect.left,
        width: rect.width,
        top: rect.top,
        bottom: rect.bottom,
        viewportTopDistance: window.innerHeight - rect.top,
        placement: willShowTop ? "top" : "bottom",
      });
    }
  };

  useEffect(() => {
    if (isOpen) {
      requestAnimationFrame(() => {
        updateCoords();
      });
      window.addEventListener("scroll", updateCoords, true);
      window.addEventListener("resize", updateCoords);
    } else {
      requestAnimationFrame(() => {
        setCoords(null);
      });
    }
    return () => {
      window.removeEventListener("scroll", updateCoords, true);
      window.removeEventListener("resize", updateCoords);
    };
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) {
      const timer = setTimeout(() => {
        if (onSearchChange) {
          onSearchChange("");
        } else {
          setLocalSearch("");
        }
      }, 0);
      return () => clearTimeout(timer);
    }
  }, [isOpen, onSearchChange]);

  const [cachedOption, setCachedOption] = useState(null);
  const [prevValue, setPrevValue] = useState(value);
  const [prevOptions, setPrevOptions] = useState(options);

  if (value !== prevValue || options !== prevOptions) {
    setPrevValue(value);
    setPrevOptions(options);
    if (value) {
      const found = options.find((o) => o.value === value);
      if (found) setCachedOption(found);
    } else {
      setCachedOption(null);
    }
  }

  const allOptions = [{ value: "", label: placeholder }, ...options];

  const filteredOptions = onSearchChange
    ? allOptions
    : allOptions.filter((o) =>
        String(o?.label || "").toLowerCase().includes(String(localSearch || "").toLowerCase()),
      );

  const selectedOption =
    allOptions.find((o) => o.value === value) ?? cachedOption;
  const displayLabel = selectedOption ? selectedOption.label : placeholder;

  const handleScroll = (e) => {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    if (scrollHeight - scrollTop <= clientHeight + 10) {
      if (hasMore && !isLoadingMore && onLoadMore) {
        onLoadMore();
      }
    }
  };

  const handleSelect = (optionValue) => {
    if (onChange) {
      onChange({ target: { name, value: optionValue } });
    }
    setIsOpen(false);
  };

  return (
    <div
      className={`flex flex-col lg:flex-row lg:items-center items-start gap-1.5 lg:gap-2 ${className}`}
      ref={containerRef}
    >
      {label && (
        <span className="text-xs font-bold capitalize tracking-wider text-text-secondary whitespace-nowrap">
          {label}
        </span>
      )}

      <div className="relative w-full sm:w-auto">
        {/* Trigger button */}
        <button
          id={`filter-select-${name}`}
          type="button"
          disabled={disabled}
          onClick={() => {
            if (!disabled) {
              setIsOpen((prev) => {
                const next = !prev;
                if (next && onOpen) {
                  onOpen();
                }
                return next;
              });
            }
          }}
          className={`appearance-none w-full sm:w-auto bg-surface-tertiary border border-border-main text-text-primary text-[11px] font-semibold rounded-lg pl-3 pr-8 py-1.5 focus:outline-none focus:ring-2 focus:ring-brand-primary/20 focus:border-brand-primary transition-all flex items-center sm:min-w-40 justify-between shadow-xs hover:border-text-secondary/30 whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed ${buttonClass}`}
          aria-haspopup="listbox"
          aria-expanded={isOpen}
          title={typeof displayLabel === "string" ? displayLabel : undefined}
        >
          <span className="truncate flex-1 text-left">
            {renderSelected && selectedOption && selectedOption.value !== ""
              ? renderSelected(selectedOption)
              : displayLabel}
          </span>
          <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none text-text-secondary">
            <ChevronDownIcon
              className={`w-3.5 h-3.5 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}
            />
          </div>
        </button>

        {/* Options Dropdown */}
        {isOpen &&
          coords &&
          createPortal(
            <div
              ref={portalRef}
              className="fixed z-9999 bg-white border border-border-main rounded-lg shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-200"
              style={{
                left: `${coords.left}px`,
                minWidth: `${coords.width}px`,
                width: "max-content",
                maxWidth: "90vw",
                ...(coords.placement === "top"
                  ? { bottom: `${coords.viewportTopDistance + 4}px` }
                  : { top: `${coords.bottom + 4}px` }),
              }}
            >
              {showSearch && (
                <SearchBar
                  value={displaySearchTerm}
                  onChange={(e) => {
                    const val = e.target?.value ?? e;
                    if (onSearchChange) onSearchChange(val);
                    else setLocalSearch(val);
                  }}
                  placeholder={searchPlaceholder}
                  onClear={() => {
                    if (onSearchChange) onSearchChange("");
                    else setLocalSearch("");
                  }}
                />
              )}
              <div
                className="py-1 max-h-60 overflow-y-auto custom-scrollbar"
                onScroll={handleScroll}
              >
                {filteredOptions.length === 0 && !isLoadingMore ? (
                  <div className="px-3 py-2 text-[11px] text-text-secondary text-center italic">
                    No options found
                  </div>
                ) : (
                  filteredOptions.map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => handleSelect(option.value)}
                      className={`w-full px-3 py-1.5 text-left text-[11px] transition-colors flex items-center gap-2 whitespace-nowrap ${
                        value === option.value
                          ? "bg-brand-primary/10 text-brand-primary font-bold"
                          : "text-text-primary hover:bg-surface-tertiary"
                      }`}
                    >
                      {renderOption && option.value !== ""
                        ? renderOption(option)
                        : option.label}
                    </button>
                  ))
                )}
                {/* Show when API returned empty data (not a search-miss, not loading) */}
                {options.length === 0 &&
                  !isLoadingMore &&
                  !displaySearchTerm && (
                    <div className="px-3 py-2 text-[11px] text-text-secondary text-center italic">
                      No options available
                    </div>
                  )}
                {isLoadingMore && (
                  <div className="px-3 py-2 text-[11px] text-text-secondary text-center italic">
                    Loading...
                  </div>
                )}
              </div>
            </div>,
            document.body,
          )}
      </div>
    </div>
  );
};

FilterSelectField.displayName = "FilterSelectField";
export default FilterSelectField;
