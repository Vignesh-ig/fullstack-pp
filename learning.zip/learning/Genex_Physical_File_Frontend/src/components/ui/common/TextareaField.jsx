import { forwardRef, useEffect, useRef, useState } from "react";

/**
 * TextareaField
 *
 * A labelled textarea with error state and adjustable width. Integrates with react-hook-form via `forwardRef`.
 *
 * @param {string} props.label - Optional label rendered above the textarea.
 * @param {string} props.value - Controlled value.
 * @param {function} props.onChange - Change handler.
 * @param {function} props.onBlur - Blur handler (used by react-hook-form).
 * @param {string} props.name - Textarea name attribute (used by react-hook-form).
 * @param {string} props.placeholder - Placeholder text.
 * @param {boolean} props.required - Marks the input as required (shows * in label).
 * @param {boolean} props.disabled - Disables the textarea.
 * @param {number} props.maxLength - Maximum length of the textarea.
 * @param {string} props.className - Optional extra classes on the wrapper div.
 * @param {string} props.error - Error message shown below the textarea.
 * @param {number} props.rows - Number of visible text lines. Default: 3.
 * @param {Ref} props.ref - Forwarded ref passed directly to the <textarea> element.
 */
const TextareaField = forwardRef(
  (
    {
      label,
      labelClassName = "",
      value,
      onChange,
      onBlur,
      name,
      placeholder,
      required = false,
      disabled = false,
      maxLength,
      className = "",
      error,
      rows = 3,
      ...rest
    },
    ref,
  ) => {
    const internalRef = useRef(null);
    const setRefs = (node) => {
      internalRef.current = node;
      if (typeof ref === "function") {
        ref(node);
      } else if (ref) {
        ref.current = node;
      }
    };

    const [internalLength, setInternalLength] = useState(0);

    useEffect(() => {
      if (internalRef.current) {
        setInternalLength(internalRef.current.value.length);
      }
    }, [value]);

    const handleTextareaChange = (e) => {
      setInternalLength(e.target.value.length);
      if (onChange) {
        onChange(e);
      }
    };

    const displayLength =
      value !== undefined ? String(value).length : internalLength;

    return (
      <div className={`flex flex-col gap-2 ${className}`}>
        {label && (
          <label
            className={`text-text-secondary text-xs font-bold uppercase tracking-wider min-h-5 ${labelClassName}`}
          >
            {label}
            {required && <span className="required-asterisk">*</span>}
          </label>
        )}
        <textarea
          {...rest}
          ref={setRefs}
          name={name}
          value={value}
          onChange={handleTextareaChange}
          onBlur={onBlur}
          rows={rows}
          placeholder={placeholder}
          disabled={disabled}
          maxLength={maxLength}
          className={`w-full px-4 py-3.5 min-h-[150px] bg-surface-tertiary border ${
            error ? "border-status-error" : "border-border-main"
          } rounded-xl text-sm font-medium text-text-primary placeholder:font-normal placeholder:text-text-secondary/70 focus:outline-none focus:ring-2 ${
            error
              ? "focus:ring-status-error/20 focus:border-status-error"
              : "focus:ring-brand-accent/20 focus:border-brand-accent"
          } focus:bg-white transition-all resize-none ${
            disabled ? "opacity-70 cursor-not-allowed" : ""
          }`}
        />

        {maxLength && (
          <span
            className={`text-[10px] self-end -mt-1 ${
              displayLength >= maxLength
                ? "text-status-error"
                : "text-text-secondary"
            }`}
          >
            {displayLength}/{maxLength} characters
          </span>
        )}

        {error && (
          <p className="text-xs text-status-error font-medium -mt-1">{error}</p>
        )}
      </div>
    );
  },
);

TextareaField.displayName = "TextareaField";
export default TextareaField;
