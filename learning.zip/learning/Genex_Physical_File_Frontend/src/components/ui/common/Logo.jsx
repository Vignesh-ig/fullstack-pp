import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { getFirstPermittedPath } from "../../../constants/featureRegistry";

/**
 * Logo
 *
 * Renders the Chola logo as a clickable link. Navigates the user to their role-specific Enquiry page.
 *
 * @param {string} className - Tailwind classes applied to the <img> element.
 * @param {string} linkClassName - Tailwind classes applied to the wrapping <Link>.
 * @param {function} onClick - Optional click handler.
 */
const Logo = ({ className = "", linkClassName = "", onClick }) => {
  const { permissions } = useSelector((state) => state.user);

  const targetPath = getFirstPermittedPath(
    (permissions ?? []).map((p) => p.permissionName),
  );

  return (
    <Link
      to={targetPath}
      onClick={onClick}
      className={`inline-flex items-center justify-center transition-transform duration-200 hover:scale-105 active:scale-95 z-20 ${linkClassName}`}
    >
      <img alt="Chola Logo" src="/src/assets/logo.svg" className={className} />
    </Link>
  );
};

Logo.displayName = "Logo";
export default Logo;
