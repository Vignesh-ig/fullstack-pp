/**
 * DetailCard
 *
 * Reusable card that groups metadata fields under a titled, icon-labelled section block.
 *
 * @param {string} title - Heading text displayed at the top of the card.
 * @param {any} icon: Icon - icon: Icon
 * @param {React.ReactNode} children - Field content rendered inside the card body.
 * @param {any} action - action
 */
const DetailCard = ({ title, icon: Icon, children, action }) => {
  return (
    <section className="space-y-3 p-4 bg-slate-100/50 rounded-lg border border-card-border">
      <div className="flex items-center justify-between pb-1.5 border-b border-slate-400/50">
        <div className="flex items-center gap-2">
          {Icon && typeof Icon === "function" ? (
            <Icon className="w-4 h-4 text-slate-500" />
          ) : (
            Icon
          )}
          <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
            {title}
          </h4>
        </div>
        {action && <div>{action}</div>}
      </div>
      {children}
    </section>
  );
};

DetailCard.displayName = "DetailCard";
export default DetailCard;
