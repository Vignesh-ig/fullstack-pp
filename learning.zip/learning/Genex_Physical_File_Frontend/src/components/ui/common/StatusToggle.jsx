/**
 * StatusToggle
 *
 * Renders the StatusToggle component.
 *
 * @param {boolean} isActive - The current status.
 * @param {function} onChange - Callback when the status changes.
 * @param {boolean} disabled - Whether the toggle is disabled.
 * @param {string} label - Optional label shown above the toggle.
 * @param {boolean} isEdit - If false, shows the "Active by default" message.
 * @param {string} className
 */
const StatusToggle = ({
  isActive,
  onChange,
  disabled = false,
  label,
  isEdit = true,
  className = "",
}) => {
  return (
    <div className={`mb-4 ${className}`}>
      {label && (
        <label className="block text-text-secondary text-xs font-bold uppercase tracking-wider mb-2">
          {label}
        </label>
      )}
      <div
        title={disabled ? "Active status is locked during creation" : undefined}
        className="h-13.5 px-3 rounded-xl border border-border-main bg-surface-tertiary flex items-center justify-between"
      >
        <span className="text-sm text-text-secondary font-medium">
          {isActive ? "Active" : "Inactive"}
        </span>
        <button
          type="button"
          disabled={disabled}
          onClick={onChange}
          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 focus:outline-none ${
            isActive ? "bg-status-success" : "bg-status-error"
          } ${disabled ? "opacity-60 cursor-not-allowed" : "cursor-pointer"}`}
        >
          <span
            className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform duration-200 ${
              isActive ? "translate-x-6" : "translate-x-1"
            }`}
          />
        </button>
      </div>
      {!isEdit && (
        <p className="mt-2 text-[10px] text-text-secondary italic mb-2">
          * Status is set to Active by default during creation.
        </p>
      )}
    </div>
  );
};

StatusToggle.displayName = "StatusToggle";
export default StatusToggle;
