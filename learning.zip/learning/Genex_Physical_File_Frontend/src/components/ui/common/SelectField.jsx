import { forwardRef, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Virtuoso } from "react-virtuoso";
import { CheckmarkSolidIcon, ChevronDownIcon } from "../../icons/icons";

/**
 * SelectField
 *
 * A fully custom-styled dropdown select field that integrates with react-hook-form via `forwardRef`. Automatically repositions above the trigger when there is insufficient space below (viewport-aware).
 *
 * @param {string} props.label - Optional label rendered above the select trigger.
 * @param {string} props.name - Field name attribute (used by react-hook-form).
 * @param {string} props.value - Currently selected option value (controlled).
 * @param {function} props.onChange - Called with a synthetic event `{ target: { name, value } }`
 * @param {function} props.onBlur - Called when focus leaves the dropdown (used by react-hook-form).
 * @param {Array} props.options - Array of `{ label: string, value: string }` option objects.
 * @param {string} props.className - Optional extra Tailwind classes on the wrapper div.
 * @param {string} props.error - Error message rendered below the field.
 * @param {boolean} [props.required=false] - Marks the select as required (displays asterisk).
 * @param {string} [props.triggerClassName="py-3.5"] - Optional override for the trigger button's padding/height classes.
 * @param {Function} [props.renderOption] - Optional custom renderer for each dropdown option. Receives `(option, isSelected)`.
 * @param {Ref} props.ref - Forwarded ref attached to a hidden <input> for form compatibility.
 */
const SelectField = forwardRef(
  (
    {
      label,
      name,
      value,
      onChange,
      onBlur,
      options = [],
      className = "",
      error,
      placeholder = "Select option",
      disabled = false,
      required = false,
      onOpen,
      triggerClassName = "py-3.5",
      renderOption,
    },
    ref,
  ) => {
    const [isOpen, setIsOpen] = useState(false);
    const [coords, setCoords] = useState(null);
    const containerRef = useRef(null);
    const portalRef = useRef(null);
    const optionsRef = useRef(null);

    // Handle outside clicks
    useEffect(() => {
      const handleClickOutside = (event) => {
        if (
          containerRef.current &&
          !containerRef.current.contains(event.target) &&
          portalRef.current &&
          !portalRef.current.contains(event.target)
        ) {
          if (isOpen) {
            if (onBlur) onBlur();
          }
          setIsOpen(false);
        }
      };
      document.addEventListener("mousedown", handleClickOutside);
      return () =>
        document.removeEventListener("mousedown", handleClickOutside);
    }, [isOpen, onBlur]);

    // Handle tabbing out while dropdown is open
    useEffect(() => {
      const handleFocusOut = () => {
        setTimeout(() => {
          const active = document.activeElement;
          const inPortal =
            portalRef.current && portalRef.current.contains(active);
          const inContainer =
            containerRef.current && containerRef.current.contains(active);
          if (!inPortal && !inContainer) {
            if (isOpen) {
              if (onBlur) onBlur();
              setIsOpen(false);
            }
          }
        }, 50);
      };
      if (isOpen) {
        document.addEventListener("focusout", handleFocusOut);
      }
      return () => document.removeEventListener("focusout", handleFocusOut);
    }, [isOpen, onBlur]);

    // Calculate position (above or below) when the dropdown opens
    const updateCoords = () => {
      if (containerRef.current) {
        const buttonEl = containerRef.current.querySelector("button");
        const rect = buttonEl
          ? buttonEl.getBoundingClientRect()
          : containerRef.current.getBoundingClientRect();
        const spaceBelow = window.innerHeight - rect.bottom;
        const willShowTop = spaceBelow < 250 && rect.top > spaceBelow;

        setCoords({
          left: rect.left,
          width: rect.width,
          top: rect.top,
          bottom: rect.bottom,
          viewportTopDistance: window.innerHeight - rect.top,
          placement: willShowTop ? "top" : "bottom",
        });
      }
    };

    useEffect(() => {
      if (isOpen) {
        requestAnimationFrame(() => {
          updateCoords();
        });
        window.addEventListener("scroll", updateCoords, true);
        window.addEventListener("resize", updateCoords);
      } else {
        requestAnimationFrame(() => {
          setCoords(null);
        });
      }
      return () => {
        window.removeEventListener("scroll", updateCoords, true);
        window.removeEventListener("resize", updateCoords);
      };
    }, [isOpen]);

    // Simulate react-hook-form-compatible onChange event
    const handleSelect = (optionValue) => {
      if (onChange) {
        onChange({
          target: {
            name,
            value: optionValue,
          },
        });
      }
      setIsOpen(false);
      if (onBlur) onBlur();
    };

    const selectedOption = options.find((opt) => opt.value === value);
    const wrapperClass = className.includes("mb-")
      ? className
      : `mb-6 ${className}`;

    return (
      <div className={wrapperClass} ref={containerRef}>
        {label && (
          <label className="block text-text-secondary text-xs font-bold uppercase tracking-wider mb-2 min-h-5">
            {label}
            {required && <span className="required-asterisk">*</span>}
          </label>
        )}
        <div className={`relative group ${isOpen ? "z-60" : ""}`}>
          {/* Custom Select Trigger */}
          <button
            type="button"
            onClick={() => {
              if (!disabled) {
                if (!isOpen && onOpen) onOpen();
                setIsOpen(!isOpen);
              }
            }}
            disabled={disabled}
            onBlur={() => {
              if (!isOpen) {
                if (onBlur) onBlur();
              }
            }}
            className={`w-full px-4 ${triggerClassName} bg-surface-tertiary border ${
              error ? "border-status-error" : "border-border-main"
            } rounded-xl text-left flex justify-between items-center focus:outline-none focus:ring-2 ${
              error
                ? "focus:ring-status-error/20 focus:border-status-error"
                : "focus:ring-brand-accent/20 focus:border-brand-accent"
            } focus:bg-white transition-all shadow-sm ${
              disabled
                ? "opacity-80 cursor-not-allowed"
                : "cursor-pointer hover:border-text-secondary/30"
            }`}
          >
            <span
              className={
                selectedOption
                  ? "text-text-primary font-medium text-sm truncate pr-2"
                  : "text-text-secondary/70 text-sm"
              }
            >
              {selectedOption ? selectedOption.label : placeholder}
            </span>
            <ChevronDownIcon
              className={`w-4 h-4 text-text-secondary shrink-0 transition-transform duration-200 ${
                isOpen ? "rotate-180" : ""
              }`}
            />
          </button>

          {/* Hidden Input for Form Submission/Ref */}
          <input type="hidden" name={name} value={value || ""} ref={ref} />

          {/* Options Dropdown */}
          {isOpen &&
            coords &&
            createPortal(
              <div
                ref={(node) => {
                  portalRef.current = node;
                  optionsRef.current = node;
                }}
                className="fixed z-9999 bg-white border border-border-main rounded-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 flex flex-col"
                style={{
                  left: `${coords.left}px`,
                  width: `${coords.width}px`,
                  ...(coords.placement === "top"
                    ? { bottom: `${coords.viewportTopDistance + 8}px` }
                    : { top: `${coords.bottom + 8}px` }),
                }}
              >
                <div
                  className="flex flex-col py-1"
                  style={{
                    height:
                      options.length > 5
                        ? 240
                        : Math.max(options.length * 44 + 8, 50),
                  }}
                >
                  <div className="flex-1 min-h-0">
                    {options.length === 0 ? (
                      <div className="px-4 py-3 text-sm text-text-secondary italic text-center">
                        No options available
                      </div>
                    ) : (
                      <Virtuoso
                        className="h-full w-full"
                        data={options}
                        computeItemKey={(index, item) => item.value}
                        itemContent={(index, opt) => (
                          <button
                            key={opt.value}
                            type="button"
                            onClick={() =>
                              !opt.disabled && handleSelect(opt.value)
                            }
                            disabled={opt.disabled}
                            className={`w-full px-4 py-2.5 text-left transition-colors flex items-start justify-between gap-2 ${
                              opt.disabled
                                ? "opacity-50 cursor-not-allowed text-text-secondary bg-surface-tertiary/50"
                                : value === opt.value
                                  ? "bg-brand-primary/5 text-brand-primary"
                                  : "text-text-primary hover:bg-surface-tertiary"
                            }`}
                          >
                            <span className="flex flex-col min-w-0">
                              {renderOption ? (
                                renderOption(opt, value === opt.value)
                              ) : (
                                <>
                                  <span
                                    className={`text-sm font-medium truncate ${
                                      value === opt.value
                                        ? "text-brand-primary"
                                        : ""
                                    }`}
                                  >
                                    {opt.label}
                                  </span>
                                  {opt.sublabel && (
                                    <span className="text-xs text-text-secondary truncate">
                                      {opt.sublabel}
                                    </span>
                                  )}
                                </>
                              )}
                            </span>
                            {value === opt.value && (
                              <CheckmarkSolidIcon className="w-4 h-4 shrink-0 mt-0.5" />
                            )}
                          </button>
                        )}
                      />
                    )}
                  </div>
                </div>
              </div>,
              document.body,
            )}
        </div>
        {error && (
          <p className="mt-1 text-xs text-status-error font-medium">{error}</p>
        )}
      </div>
    );
  },
);

SelectField.displayName = "SelectField";

export default SelectField;