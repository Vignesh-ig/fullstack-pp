/**
 * Table
 *
 * A reusable, responsive table wrapper.
 *
 * @param {Array} headers - Array of header strings or objects `{ label, align, widthClass }`.
 * @param {any} headerColorClass - headerColorClass
 * @param {ReactNode} children - Rows (<tr>) to render in the tbody.
 * @param {any} tableClassName - tableClassName
 */
const Table = ({
  headers = [],
  headerColorClass = "bg-table-header-bg",
  children,
  tableClassName = "min-w-full text-left border-collapse",
  tableDivClass = "",
}) => {
  return (
    <div
      className={`overflow-x-scroll overflow-y-auto custom-scrollbar rounded-lg bg-white border-2 border-table-header-bg ${tableDivClass}`}
      style={{
        height: "clamp(510px, calc(100vh - 335px), 800px)",
      }}
    >
      <table className={tableClassName}>
        <thead className="sticky top-0 z-10">
          <tr className={headerColorClass}>
            {headers.map((h, index) => {
              const isObj = typeof h === "object";
              const key = isObj
                ? h.id || (typeof h.label === "string" ? h.label : index)
                : h;
              const content = isObj ? h.label : h;
              const alignClass =
                isObj && h.align === "center" ? "text-center" : "text-start";
              const widthClass = isObj && h.widthClass ? h.widthClass : "";
              const paddingClass =
                isObj && h.paddingClass ? h.paddingClass : "px-6 py-4";
              const customClasses =
                isObj && h.customClasses ? h.customClasses : "";

              return (
                <th
                  key={key}
                  className={`${paddingClass} text-xs font-bold uppercase tracking-wider text-table-header-text border-b border-slate-100 whitespace-nowrap ${alignClass} ${widthClass} ${customClasses}`}
                >
                  {content}
                </th>
              );
            })}
          </tr>
        </thead>
        <tbody className="divide-y-2 divide-table-header-bg">{children}</tbody>
      </table>
    </div>
  );
};

Table.displayName = "Table";
export default Table;
