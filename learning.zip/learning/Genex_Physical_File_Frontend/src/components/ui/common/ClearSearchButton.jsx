import { CloseIcon } from "../../icons/icons";
import IconButton from "./IconButton";

/**
 * ClearSearchButton
 *
 * A reusable icon button for clearing search input fields. Includes absolute positioning styles suitable for placing inside an input wrapper.
 *
 * @param {function} onClick - Click handler to clear the search text
 */
const ClearSearchButton = ({ onClick }) => {
  return (
    <IconButton
      icon={<CloseIcon className="w-3 h-3" />}
      onClick={onClick}
      ariaLabel="Clear search"
      className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 text-text-secondary/80 hover:text-text-primary hover:bg-slate-200/50 transition-all z-30 animate-in fade-in zoom-in duration-300"
    />
  );
};

ClearSearchButton.displayName = "ClearSearchButton";
export default ClearSearchButton;
