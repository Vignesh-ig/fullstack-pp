import ErrorBanner from "./ErrorBanner";
import SuccessBanner from "./SuccessBanner";

/**
 * NavigationBanners
 *
 * Renders the success, warning, and fetch-error banners that appear at the top
 * of list pages after returning from a detail page. Designed to be used
 * together with the useNavigationBanners hook.
 *
 * @param {string|null}  successMessage     - Success banner text; null hides the banner.
 * @param {Function}     setSuccessMessage  - Setter to dismiss the success banner.
 * @param {string|null}  warningMessage     - Warning banner text (left without saving); null hides it.
 * @param {Function}     setWarningMessage  - Setter to dismiss the warning banner.
 * @param {string|null}  error              - Fetch/API error text from usePaginatedFetch; null hides it.
 * @param {Function}     setError           - Setter to dismiss the error banner.
 */
const NavigationBanners = ({
  successMessage,
  setSuccessMessage,
  warningMessage,
  setWarningMessage,
  error,
  setError,
}) => {
  return (
    <>
      {/* ── Success ── */}
      {successMessage && (
        <section className="px-6 pt-4">
          <SuccessBanner
            message={successMessage}
            onClose={() => setSuccessMessage(null)}
          />
        </section>
      )}

      {/* ── Warning / Error ── */}
      {(warningMessage || error) && (
        <section className="px-6 pt-4">
          {warningMessage && (
            <ErrorBanner
              message={warningMessage}
              type="warning"
              onClose={() => setWarningMessage(null)}
            />
          )}
          {error && (
            <ErrorBanner message={error} onClose={() => setError(null)} />
          )}
        </section>
      )}
    </>
  );
};

NavigationBanners.displayName = "NavigationBanners";
export default NavigationBanners;
