/**
 * IconButton
 *
 * A reusable button used for navigation arrows, back buttons, etc.
 *
 * @param {function} onClick - Click handler.
 * @param {boolean} disabled - Disables the button. Default: false.
 * @param {ReactNode} icon - SVG icon to render inside the button.
 * @param {string} ariaLabel - Accessible label for screen readers.
 * @param {string} className - Optional extra classes.
 * @param {string} type - Button type attribute. Default: "button".
 * @param {string} title - Tooltip text.
 */
const IconButton = ({
  onClick,
  disabled = false,
  icon,
  ariaLabel,
  className = "p-1 bg-surface-tertiary hover:bg-brand-primary text-text-secondary hover:text-white shadow-lg border border-slate-700/60",
  type = "button",
  title,
}) => {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`rounded-full transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed inline-flex items-center justify-center shrink-0 ${className}`}
      aria-label={ariaLabel}
      title={title}
    >
      {icon}
    </button>
  );
};

IconButton.displayName = "IconButton";
export default IconButton;
