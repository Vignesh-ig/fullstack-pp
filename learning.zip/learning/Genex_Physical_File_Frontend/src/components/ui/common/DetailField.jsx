/**
 * DetailField
 *
 * Reusable label-value pair for use inside a description list.
 *
 * @param {string} label - Display label shown above the value.
 * @param {any} value - value
 * @param {any} className - className
 */
const DetailField = ({ label, value, className = "" }) => {
  return (
    <div>
      <dt className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider">
        {label}
      </dt>
      <dd
        className={`text-sm font-medium break-all mt-0.5 ${className} ${
          label === "Ageing" &&
          Number(value) > 15 &&
          value !== "N/A" &&
          value !== "—"
            ? "text-red-600 font-bold"
            : "text-slate-800"
        }`}
      >
        {value !== "" && value != null ? value : "—"}
      </dd>
    </div>
  );
};

DetailField.displayName = "DetailField";
export default DetailField;
