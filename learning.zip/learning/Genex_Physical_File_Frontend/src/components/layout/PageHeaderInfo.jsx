/**
 * PageHeaderInfo
 *
 * A reusable component for the title and record count in list headers.
 *
 * @param {string} title - The main heading text (e.g., "System Users").
 * @param {number} count - The total number of records.
 * @param {string} unit - The unit label (e.g., "users", "branches").
 * @param {boolean} loading - When true, hides the count.
 */
const PageHeaderInfo = ({ title, count, unit, loading }) => {
  return (
    <aside>
      <div className="flex items-center gap-2">
        <h2 className="text-xl font-bold text-text-primary">{title}</h2>
      </div>
      {!loading && count > 0 && (
        <p className="text-xs text-text-secondary mt-0.5">
          {count} {unit}
        </p>
      )}
    </aside>
  );
};

PageHeaderInfo.displayName = "PageHeaderInfo";
export default PageHeaderInfo;
