/**
 * ListContainer
 *
 * A reusable layout container for data lists and tables. Handles background styling, rounding, shadows, and entry animations.
 *
 * @param {ReactNode} children - The list content (usually ListHeader, Table, Pagination).
 */
const ListContainer = ({ children }) => {
  return (
    <main className="bg-surface-tertiary rounded-2xl shadow-sm border border-border-subtle ring-1 ring-slate-900/5 overflow-hidden slide-in-from-bottom-2 animate-in duration-500">
      {children}
    </main>
  );
};

ListContainer.displayName = "ListContainer";
export default ListContainer;
