import React, { useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { NavLink, useLocation } from "react-router-dom";
import { MENU_CATEGORIES as categories } from "../../constants/roles";
import { useLogout } from "../../hooks/useLogout";
import { ChevronDownIcon, CloseIcon, LogoutIcon } from "../icons/icons";
import IconButton from "../ui/common/IconButton";

/**
 * SidebarMenu
 *
 * Renders the left sidebar navigation menu.
 * Reads user identity directly from Redux for the mobile footer.
 *
 * @param {boolean} isOpen
 * @param {Function} onClose
 * @param {any[]} navItems
 */
const SidebarMenu = ({ isOpen, onClose, navItems }) => {
  const location = useLocation();
  const { userName, roleName } = useSelector((state) => state.user);
  const roleLabel = roleName?.replace(/_/g, " ") ?? "";

  const handleLogout = useLogout();

  // Group nav items by category — memoized so it's only recomputed when navItems changes.
  const groupedItems = useMemo(
    () =>
      navItems.reduce((acc, item) => {
        const cat = item.category || "Others";
        if (!acc[cat]) acc[cat] = [];
        acc[cat].push(item);
        return acc;
      }, {}),
    [navItems],
  );

  // Derive which category is open based on the current URL.
  // This reacts to every navigation (logo click, sidebar link, back button, refresh).
  const urlDerivedOpen = useMemo(
    () =>
      categories.reduce((acc, cat) => {
        const items = groupedItems[cat] || [];
        acc[cat] = items.some(
          (item) =>
            location.pathname === item.path ||
            location.pathname.startsWith(item.path + "/"),
        );
        return acc;
      }, {}),
    [location.pathname, groupedItems],
  );

  // Manual override lets the user toggle categories independently.
  // Resets to null whenever the URL changes so URL-derived state wins on navigation.
  const [manualOverride, setManualOverride] = useState(null);
  const [lastPathname, setLastPathname] = useState(location.pathname);

  if (location.pathname !== lastPathname) {
    setLastPathname(location.pathname);
    setManualOverride(null);
  }

  const openCategories = manualOverride ?? urlDerivedOpen;

  const toggleCategory = (cat) => {
    setManualOverride((prev) => ({
      ...(prev ?? urlDerivedOpen),
      [cat]: !(prev ?? urlDerivedOpen)[cat],
    }));
  };

  return (
    <>
      {/* Sidebar Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 transition-opacity duration-300"
          onClick={onClose}
        />
      )}

      {/* Sidebar Drawer */}
      <aside
        className={`fixed top-0 z-50 h-full w-64 bg-surface-primary shadow-2xl transform transition-transform duration-300 ease-in-out flex flex-col right-0 border-l border-slate-700/60 sm:right-auto sm:left-0 sm:border-l-0 sm:border-r ${
          isOpen ? "translate-x-0" : "translate-x-full sm:-translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between p-4 border-b border-slate-700/40 shrink-0">
          <span className="font-bold text-lg text-white">Menu</span>
          <IconButton
            onClick={onClose}
            className="p-2 text-text-secondary hover:text-white rounded-lg hover:bg-surface-secondary/50 transition-colors"
            icon={<CloseIcon className="w-6 h-6" />}
            ariaLabel="Close Menu"
          />
        </div>

        <nav className="flex-1 overflow-y-auto px-4 py-4 space-y-2 custom-scrollbar">
          {categories.map((cat) => {
            const items = groupedItems[cat] || [];
            if (items.length === 0) return null;

            const isOpenCat = openCategories[cat];

            return (
              <div key={cat} className="flex flex-col">
                <button
                  type="button"
                  onClick={() => toggleCategory(cat)}
                  className="flex items-center justify-between w-full text-xs font-semibold text-white px-2 py-3 uppercase tracking-wider hover:bg-surface-secondary/40 rounded-lg transition-colors cursor-pointer"
                >
                  <span>{cat}</span>
                  <ChevronDownIcon
                    className={`w-4 h-4 transition-transform duration-300 ${
                      isOpenCat ? "rotate-180" : ""
                    }`}
                  />
                </button>
                <div
                  className={`overflow-hidden transition-all duration-500 ease-in-out ${
                    isOpenCat
                      ? "max-h-200 opacity-100 mt-1"
                      : "max-h-0 opacity-0"
                  }`}
                >
                  <div className="ml-2 pl-2 border-l border-slate-700/60 flex flex-col space-y-1">
                    {items.map((item) => (
                      <NavLink
                        key={item.path}
                        to={item.path}
                        onClick={(e) => {
                          onClose();
                          if (
                            location.pathname === item.path ||
                            location.pathname.startsWith(item.path + "/")
                          ) {
                            e.preventDefault();
                            window.location.href = item.path;
                          }
                        }}
                        className={({ isActive }) =>
                          `block px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                            isActive
                              ? "bg-brand-primary/70 text-white"
                              : "text-text-inverse/70 hover:text-white hover:bg-surface-secondary/60"
                          }`
                        }
                      >
                        {item.label}
                      </NavLink>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </nav>

        {/* Mobile Profile & Logout (hidden on desktop) */}
        <div className="sm:hidden border-t border-slate-700/40 p-4 shrink-0 bg-surface-secondary/30 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-text-inverse font-semibold">
              {userName ?? "User"}
            </span>
            {roleLabel && (
              <span className="bg-brand-primary/15 text-brand-accent text-[8px] sm:text-xs font-bold px-2 py-1 rounded-full uppercase tracking-widest">
                {roleLabel}
              </span>
            )}
          </div>
          <IconButton
            onClick={() => {
              onClose();
              handleLogout();
            }}
            className="w-full flex items-center justify-center gap-2 text-sm font-semibold text-white bg-red-500 border border-red-500/20 p-2 hover:scale-[1.05] rounded-lg transition-all duration-200 cursor-pointer"
            ariaLabel="Sign out"
            icon={
              <>
                <LogoutIcon className="w-4 h-4" />
                <span>Sign out</span>
              </>
            }
          />
        </div>
      </aside>
    </>
  );
};

SidebarMenu.displayName = "SidebarMenu";
export default React.memo(SidebarMenu);
