/**
 * LandscapeFormContainer
 *
 * A full-width layout container for wide / landscape forms (e.g. Rack Allocation). Unlike PortraitFormContainer it does NOT cap the width, filling the available space like a table/list page. Shares the same bg, border, shadow, and animation tokens.
 *
 * @param {ReactNode} children - The form content.
 * @param {string} className - Optional extra Tailwind classes.
 */
const LandscapeFormContainer = ({ children, className = "" }) => {
  return (
    <main className="h-full px-4 py-3">
      <section
        className={`w-full bg-surface-tertiary rounded-2xl shadow-sm border border-border-subtle p-4 sm:p-6 slide-in-from-top-2 animate-in duration-500 ${className}`}
      >
        {children}
      </section>
    </main>
  );
};

LandscapeFormContainer.displayName = "LandscapeFormContainer";
export default LandscapeFormContainer;
