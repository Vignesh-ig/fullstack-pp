import { AddIcon } from "../icons/icons";
import RefreshButton from "../ui/common/RefreshButton";
import SearchInput from "../ui/common/SearchInput";
import SlidingButton from "../ui/common/SlidingButton";
import PageHeaderInfo from "./PageHeaderInfo";

/**
 * ListHeader
 *
 * A shared header component for list pages.
 *
 * @param {string} title - Page heading text.
 * @param {string} unit - Record unit label (e.g. "users", "racks").
 * @param {number} count - Total record count shown beside the title.
 * @param {boolean} loading - When true, hides the count.
 * @param {string} addLabel - Label for the add/create button.
 * @param {string} searchPlaceholder - Placeholder text for the search input.
 * @param {string} search - Current search value.
 * @param {function} setSearch - Setter for search value.
 * @param {function} refetch - Callback to refetch data (shows RefreshButton when provided).
 * @param {function} onAddClick - Callback to open create form (shows SlidingButton when provided).
 * @param {any} children - children
 */
const ListHeader = ({
  title,
  unit,
  count,
  loading,
  addLabel,
  searchPlaceholder = "Search by App No or Barcode",
  search,
  setSearch,
  refetch,
  onAddClick,
  children,
  showAddButton = true,

}) => {
  return (
    <header className="p-4 sm:p-6 border-b border-border-subtle bg-surface-tertiary/50">
      <div className="flex items-start justify-between gap-4">
        <PageHeaderInfo
          title={title}
          count={count}
          unit={unit}
          loading={loading}
        />

        {/* Desktop action buttons */}
        <section className="hidden lg:flex items-center gap-3">
          {refetch && <RefreshButton onRefresh={refetch} size="md" />}
          {setSearch && (
            <SearchInput
              value={search}
              onChange={setSearch}
              placeholder={searchPlaceholder}
              expandable
            />
          )}
          {showAddButton && onAddClick && (
            <SlidingButton
              onClick={onAddClick}
              icon={<AddIcon />}
              label={addLabel}
              color="bg-brand-primary"
              size="md"
            />
          )}
        </section>

        {/* Mobile/tablet action buttons */}
        <section className="flex flex-row items-center gap-3 lg:hidden">
          {refetch && <RefreshButton onRefresh={refetch} size="sm" />}
          {showAddButton && onAddClick && (
            <SlidingButton
              onClick={onAddClick}
              icon={<AddIcon />}
              label={addLabel}
              color="bg-brand-primary"
              size="sm"
            />
          )}
        </section>
      </div>

      {/* Mobile/tablet search input */}
      {setSearch && (
        <section className="mt-3 lg:hidden">
          <SearchInput
            value={search}
            onChange={setSearch}
            placeholder={searchPlaceholder}
            className="w-full"
          />
        </section>
      )}

      {children}
    </header>
  );
};

ListHeader.displayName = "ListHeader";
export default ListHeader;
