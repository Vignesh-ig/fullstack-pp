/**
 * PortraitFormContainer
 *
 * A reusable layout container for full-page forms. Handles centering, max-width, background styling, and entry animations.
 *
 * @param {ReactNode} children - The form content (usually FormHeader, form, etc.).
 * @param {string} maxWidth - Optional Tailwind max-width class (default: 'max-w-xl').
 */
const PortraitFormContainer = ({ children, maxWidth = "max-w-xl" }) => {
  return (
    <main className="h-full flex items-start justify-center px-4 py-3">
      <section
        className={`w-full ${maxWidth} bg-surface-tertiary rounded-2xl shadow-sm border border-border-subtle p-4 sm:p-5 slide-in-from-bottom-2 animate-in duration-500`}
      >
        {children}
      </section>
    </main>
  );
};

PortraitFormContainer.displayName = "PortraitFormContainer";
export default PortraitFormContainer;
