import { useState } from "react";
import { useSelector } from "react-redux";
import {
  FEATURE_REGISTRY,
  getRegistryPath,
} from "../../constants/featureRegistry";
import { MenuIcon } from "../icons/icons";
import IconButton from "../ui/common/IconButton";
import Logo from "../ui/common/Logo";
import ProfileDropdown from "./ProfileDropdown";
import SidebarMenu from "./SidebarMenu";

/**
 * Navbar
 *
 * Renders the Navbar component.
 *
 */
const Navbar = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { permissions } = useSelector((state) => state.user);

  // Build nav items dynamically from FEATURE_REGISTRY, strictly preserving registry order.
  const userPermissionNames = new Set(
    (permissions ?? []).map((p) => p.permissionName),
  );

  const navItems = Object.keys(FEATURE_REGISTRY)
    .filter((key) => userPermissionNames.has(key))
    .map((key) => {
      const entry = FEATURE_REGISTRY[key];
      const rawPath = getRegistryPath(key, entry);
      return {
        label: entry.label,
        path: `/${rawPath.replace(/^\//, "")}`,
        category: entry.category,
      };
    });

  return (
    <header className="bg-surface-secondary shadow-md border-b border-slate-700/60 sticky top-0 z-50">
      <div className="max-w-screen-2xl mx-auto sm:px-6 md:px-4">
        {/* Top Row: Brand & User Profile */}
        <section className="h-16 flex items-center justify-between gap-4">
          {/* Left: Hamburger & Logo */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="hidden sm:block">
              <IconButton
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-surface-secondary/50 transition-colors"
                ariaLabel="Menu"
                icon={<MenuIcon className="w-6 h-6" />}
              />
            </div>
            <div className="flex items-center gap-1">
              <Logo className="h-16 w-16 sm:h-24 sm:w-24" />
            </div>
          </div>

          <section className="sm:text-lg md:text-xl lg:text-3xl font-extrabold text-white">
            File Tracking System
          </section>

          {/* Right: Desktop profile dropdown & Mobile Hamburger */}
          <aside className="flex items-center gap-2 shrink-0">
            <div className="hidden sm:block">
              <ProfileDropdown />
            </div>

            {/* Mobile Hamburger Button */}
            <div className="sm:hidden">
              <IconButton
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                className="p-2 text-text-secondary hover:text-white rounded-lg hover:bg-surface-secondary/50 transition-colors"
                ariaLabel="Menu"
                icon={<MenuIcon className="w-6 h-6" />}
              />
            </div>
          </aside>
        </section>
      </div>

      <SidebarMenu
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        navItems={navItems}
      />
    </header>
  );
};

Navbar.displayName = "Navbar";
export default Navbar;
