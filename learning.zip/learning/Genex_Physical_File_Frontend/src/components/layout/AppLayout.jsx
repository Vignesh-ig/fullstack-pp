import { Outlet } from "react-router-dom";
import ErrorBoundary from "../error/ErrorBoundary";
import Navbar from "./Navbar";

/**
 * AppLayout
 *
 * Renders the AppLayout component.
 *
 */
const AppLayout = () => (
  <div className="h-screen flex flex-col bg-surface-tertiary text-text-primary overflow-hidden">
    <Navbar />
    <main className="flex-1 w-full max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 lg:py-8 overflow-y-auto custom-scrollbar animate-in fade-in duration-500">
      <ErrorBoundary>
        <Outlet />
      </ErrorBoundary>
    </main>
  </div>
);

AppLayout.displayName = "AppLayout";
export default AppLayout;
