import { useEffect, useRef, useState } from "react";
import { useSelector } from "react-redux";
import { useLogout } from "../../hooks/useLogout";
import { LogoutIcon, UserIcon } from "../icons/icons";
import IconButton from "../ui/common/IconButton";

/**
 * ProfileDropdown
 *
 * Renders the desktop profile dropdown. Reads user data directly from Redux
 * and handles logout internally — no props required.
 */
const ProfileDropdown = () => {
  const { userName, roleName } = useSelector((state) => state.user);
  const roleLabel = roleName?.replace(/_/g, " ") ?? "";

  const handleLogout = useLogout();
  const [isOpen, setIsOpen] = useState(false);
  const profileRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (profileRef.current && !profileRef.current.contains(e.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="relative hidden sm:block" ref={profileRef}>
      <IconButton
        id="profile-menu-btn"
        onClick={() => setIsOpen((prev) => !prev)}
        className="flex items-center gap-2 px-3 py-2 rounded-lg text-text-secondary border border-slate-700/60 hover:border-slate-500/60 hover:bg-surface-primary transition-all duration-200 cursor-pointer shadow-sm shadow-slate-950"
        ariaLabel="Profile"
        icon={
          <span className="w-8 h-8 rounded-full bg-brand-primary/20 border border-brand-primary flex items-center justify-center text-brand-accent">
            <UserIcon className="w-4 h-4" />
          </span>
        }
      />

      {isOpen && (
        <div
          id="profile-dropdown"
          className="absolute right-0 top-full mt-2 w-56 bg-surface-primary border border-slate-700/60 rounded-xl shadow-2xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-1 duration-150"
        >
          <div className="px-4 py-3 border-b border-slate-700/40">
            <div className="flex items-center justify-between">
              <span className="text-sm text-text-inverse font-semibold truncate">
                {userName ?? "User"}
              </span>
              {roleLabel && (
                <span className="bg-brand-primary/15 text-brand-accent text-[8px] font-bold px-2 py-1 rounded-full uppercase tracking-widest border border-brand-primary/25 shrink-0 ml-2">
                  {roleLabel}
                </span>
              )}
            </div>
          </div>
          <div className="p-4">
            <IconButton
              onClick={() => {
                setIsOpen(false);
                handleLogout();
              }}
              className="w-full flex items-center justify-center gap-2 text-sm font-semibold text-white bg-red-500 border border-red-500/20 p-2 hover:scale-[1.05] rounded-lg transition-all duration-200 cursor-pointer"
              ariaLabel="Sign out"
              icon={
                <>
                  <LogoutIcon className="w-4 h-4" />
                  <span>Sign out</span>
                </>
              }
            />
          </div>
        </div>
      )}
    </div>
  );
};

ProfileDropdown.displayName = "ProfileDropdown";
export default ProfileDropdown;
