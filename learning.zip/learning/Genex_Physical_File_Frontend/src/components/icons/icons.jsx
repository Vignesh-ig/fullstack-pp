/**
 * icons.jsx — Central icon barrel
 *
 * All reusable SVG icons in the application are defined and exported here
 * as React functional components. Import from this file anywhere you need an icon:
 *
 *   import { EditIcon, DeleteIcon, AddIcon } from "../../components/icons/icons";
 *
 * Each icon accepts:
 *  - className {string} - Tailwind size/color classes. Default: "w-5 h-5".
 *
 * ── Icon index ────────────────────────────────────────────────────────────────
 *  EditIcon            — Pencil / edit action
 *  DeleteIcon          — Trash can / delete action
 *  AddIcon             — Plus / create action
 *  RefreshIcon         — Circular arrows / reload
 *  SearchIcon          — Magnifying glass
 *  EyeIcon             — Open eye / show password - Not used yet
 *  EyeOffIcon          — Closed eye / hide password - Not used yet
 *  UserIcon            — Single person outline
 *  LogoutIcon          — Arrow-out-of-box / sign out
 *  MenuIcon            — Hamburger (3 lines)
 *  CloseIcon           — X / close / dismiss
 *  ChevronDownIcon     — Downward caret (dropdowns)
 *  ChevronRightIcon    — Rightward caret (breadcrumbs / navigation)
 *  ChevronLeftIcon     — Leftward caret (breadcrumbs / navigation)
 *  ChevronsLeftIcon    — Double leftward caret (pagination)
 *  ChevronsRightIcon   — Double rightward caret (pagination)  - Will get changed/removed in the future
 *  CheckIcon           — Checkmark circle / success - Will get changed/removed in the future
 *  CheckmarkSolidIcon  — Solid filled checkmark (no circle; used in selects)
 *  AlertIcon           — Exclamation triangle / warning
 *  AlertCircleIcon     — Exclamation circle / error
 *  CheckCircleIcon     — Checkmark circle / success
 *  FileIcon            — Document / file - Will get changed/removed in the future
 *  BuildingIcon        — Office building (branch / organisation)
 *  ServerIcon          — Server / rack hardware - Will get changed/removed in the future
 *  TransferIcon        — Two arrows (data transfer / outward query)
 *  StampIcon           — Stamp / approval - Will get changed/removed in the future
 *  UsersGroupIcon      — Multiple people group outline
 *  CpuIcon             — CPU chip outline
 *  VendorIcon          — Shopping bag / vendor organization
 *  LockIcon            — Padlock outline
 *  SpinnerIcon         — Loading spinner
 *  MinimizeIcon        — Horizontal dash / collapse / minimize panel
 */

/**
 * EditIcon
 *
 * Renders the EditIcon component.
 *
 * @param {any} className - className
 */
export const EditIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M11 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-5M16.5 3.5a2.121 2.121 0 113 3L7 19l-4 1 1-4L16.5 3.5z"
    />
  </svg>
);
EditIcon.displayName = "EditIcon";

/**
 * DeleteIcon
 *
 * Renders the DeleteIcon component.
 *
 * @param {any} className - className
 */
export const DeleteIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6M9 7h6m-1-3h-4a1 1 0 00-1 1v2h6V5a1 1 0 00-1-1z"
    />
  </svg>
);
DeleteIcon.displayName = "DeleteIcon";

/**
 * AddIcon
 *
 * Renders the AddIcon component.
 *
 * @param {any} className - className
 */
export const AddIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M12 6v6m0 0v6m0-6h6m-6 0H6"
    />
  </svg>
);
AddIcon.displayName = "AddIcon";

/**
 * RefreshIcon
 *
 * Renders the RefreshIcon component.
 *
 * @param {any} className - className
 */
export const RefreshIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
    />
  </svg>
);
RefreshIcon.displayName = "RefreshIcon";

/**
 * SearchIcon
 *
 * Renders the SearchIcon component.
 *
 * @param {any} className - className
 */
export const SearchIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
    />
  </svg>
);
SearchIcon.displayName = "SearchIcon";

/**
 * EyeIcon
 *
 * Renders the EyeIcon component.
 *
 * @param {any} className - className
 */
export const EyeIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
    />
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
    />
  </svg>
);
EyeIcon.displayName = "EyeIcon";

/**
 * EyeOffIcon
 *
 * Renders the EyeOffIcon component.
 *
 * @param {any} className - className
 */
export const EyeOffIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"
    />
  </svg>
);
EyeOffIcon.displayName = "EyeOffIcon";

/**
 * UserIcon
 *
 * Renders the UserIcon component.
 *
 * @param {any} className - className
 */
export const UserIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
    />
  </svg>
);
UserIcon.displayName = "UserIcon";

/**
 * LogoutIcon
 *
 * Renders the LogoutIcon component.
 *
 * @param {any} className - className
 */
export const LogoutIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
    />
  </svg>
);
LogoutIcon.displayName = "LogoutIcon";

/**
 * MenuIcon
 *
 * Renders the MenuIcon component.
 *
 * @param {any} className - className
 */
export const MenuIcon = ({ className = "w-6 h-6" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M4 6h16M4 12h16M4 18h16"
    />
  </svg>
);
MenuIcon.displayName = "MenuIcon";

/**
 * CloseIcon
 *
 * Renders the CloseIcon component.
 *
 * @param {any} className - className
 */
export const CloseIcon = ({ className = "w-6 h-6" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M6 18L18 6M6 6l12 12"
    />
  </svg>
);
CloseIcon.displayName = "CloseIcon";

/**
 * ChevronDownIcon
 *
 * Renders the ChevronDownIcon component.
 *
 * @param {any} className - className
 */
export const ChevronDownIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M19 9l-7 7-7-7"
    />
  </svg>
);
ChevronDownIcon.displayName = "ChevronDownIcon";

/**
 * ChevronRightIcon
 *
 * Renders the ChevronRightIcon component.
 *
 * @param {any} className - className
 */
export const ChevronRightIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M9 5l7 7-7 7"
    />
  </svg>
);
ChevronRightIcon.displayName = "ChevronRightIcon";

/**
 * ChevronLeftIcon
 *
 * Renders the ChevronLeftIcon component.
 *
 * @param {any} className - className
 */
export const ChevronLeftIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M15 19l-7-7 7-7"
    />
  </svg>
);
ChevronLeftIcon.displayName = "ChevronLeftIcon";

/**
 * ChevronsLeftIcon
 *
 * Renders the ChevronsLeftIcon component.
 *
 * @param {any} className - className
 */
export const ChevronsLeftIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M11 19l-7-7 7-7m8 14l-7-7 7-7"
    />
  </svg>
);
ChevronsLeftIcon.displayName = "ChevronsLeftIcon";

/**
 * ChevronsRightIcon
 *
 * Renders the ChevronsRightIcon component.
 *
 * @param {any} className - className
 */
export const ChevronsRightIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M13 5l7 7-7 7M5 5l7 7-7 7"
    />
  </svg>
);
ChevronsRightIcon.displayName = "ChevronsRightIcon";

/**
 * CheckIcon
 *
 * Renders the CheckIcon component.
 *
 * @param {any} className - className
 */
export const CheckIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
);
CheckIcon.displayName = "CheckIcon";

/**
 * AlertIcon
 *
 * Renders the AlertIcon component.
 *
 * @param {any} className - className
 */
export const AlertIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
    />
  </svg>
);
AlertIcon.displayName = "AlertIcon";

/**
 * AlertCircleIcon
 *
 * Renders the AlertCircleIcon component.
 *
 * @param {any} className - className
 */
export const AlertCircleIcon = ({ className = "w-5 h-5" }) => (
  <svg className={className} fill="currentColor" viewBox="0 0 20 20">
    <path
      fillRule="evenodd"
      d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z"
      clipRule="evenodd"
    />
  </svg>
);
AlertCircleIcon.displayName = "AlertCircleIcon";

/**
 * CheckCircleIcon
 *
 * Renders the CheckCircleIcon component.
 *
 * @param {any} className - className
 */
export const CheckCircleIcon = ({ className = "w-5 h-5" }) => (
  <svg className={className} fill="currentColor" viewBox="0 0 20 20">
    <path
      fillRule="evenodd"
      d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
      clipRule="evenodd"
    />
  </svg>
);
CheckCircleIcon.displayName = "CheckCircleIcon";

/**
 * FileIcon
 *
 * Renders the FileIcon component.
 *
 * @param {any} className - className
 */
export const FileIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
    />
  </svg>
);
FileIcon.displayName = "FileIcon";

/**
 * BuildingIcon
 *
 * Renders the BuildingIcon component.
 *
 * @param {any} className - className
 */
export const BuildingIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
    />
  </svg>
);
BuildingIcon.displayName = "BuildingIcon";

/**
 * ServerIcon
 *
 * Renders the ServerIcon component.
 *
 * @param {any} className - className
 */
export const ServerIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01"
    />
  </svg>
);
ServerIcon.displayName = "ServerIcon";

/**
 * TransferIcon
 *
 * Renders the TransferIcon component.
 *
 * @param {any} className - className
 */
export const TransferIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"
    />
  </svg>
);
TransferIcon.displayName = "TransferIcon";

/**
 * StampIcon
 *
 * Renders the StampIcon component.
 *
 * @param {any} className - className
 */
export const StampIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"
    />
  </svg>
);
StampIcon.displayName = "StampIcon";

/**
 * UsersGroupIcon
 *
 * Renders the UsersGroupIcon component.
 *
 * @param {any} className - className
 */
export const UsersGroupIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z"
    />
  </svg>
);
UsersGroupIcon.displayName = "UsersGroupIcon";

/**
 * CpuIcon
 *
 * Renders the CpuIcon component.
 *
 * @param {any} className - className
 */
export const CpuIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"
    />
  </svg>
);
CpuIcon.displayName = "CpuIcon";

/**
 * VendorIcon
 *
 * Renders the VendorIcon component.
 *
 * @param {any} className - className
 */
export const VendorIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
    />
  </svg>
);
VendorIcon.displayName = "VendorIcon";

/**
 * LockIcon
 *
 * Renders the LockIcon component.
 *
 * @param {any} className - className
 */
export const LockIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
    />
  </svg>
);
LockIcon.displayName = "LockIcon";

/**
 * SpinnerIcon
 *
 * Renders the SpinnerIcon component.
 *
 * @param {any} className - className
 */
export const SpinnerIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={`${className} animate-spin`}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <circle
      className="opacity-25"
      cx="12"
      cy="12"
      r="10"
      stroke="currentColor"
      strokeWidth="4"
    />
    <path
      className="opacity-75"
      fill="currentColor"
      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
    />
  </svg>
);
SpinnerIcon.displayName = "SpinnerIcon";

/**
 * CheckmarkSolidIcon
 *
 * Renders the CheckmarkSolidIcon component.
 *
 * @param {any} className - className
 */
export const CheckmarkSolidIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="currentColor" viewBox="0 0 20 20">
    <path
      fillRule="evenodd"
      d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
      clipRule="evenodd"
    />
  </svg>
);
CheckmarkSolidIcon.displayName = "CheckmarkSolidIcon";

/**
 * SortDescendingIcon
 *
 * Renders the SortDescendingIcon component (e.g. Newest first).
 *
 * @param {any} className - className
 */
export const SortDescendingIcon = ({ className = "w-4 h-4" }) => (
  <svg fill="none" viewBox="0 0 16 16" className={className}>
    <path
      fill="currentColor"
      fillRule="evenodd"
      d="M15 3.5H1V2h14zm-1.75 3.75v5.19l1.72-1.72 1.06 1.06-3 3a.75.75 0 0 1-1.06 0l-3-3 1.06-1.06 1.72 1.72V7.25zM8 8.75H1v-1.5h7zM6 14H1v-1.5h5z"
      clipRule="evenodd"
    />
  </svg>
);
SortDescendingIcon.displayName = "SortDescendingIcon";

/**
 * SortAscendingIcon
 * * SortDescendingIcon   — Downward sort arrow
 * * SortAscendingIcon    — Upward sort arrow
 * * TimerIcon            — Clock face / stage duration
 *
 * Renders the SortAscendingIcon component (e.g. Oldest first).
 *
 * @param {any} className - className
 */
export const SortAscendingIcon = ({ className = "w-4 h-4" }) => (
  <svg fill="none" viewBox="0 0 16 16" className={className}>
    <path
      fill="currentColor"
      fillRule="evenodd"
      d="M15 12.5H1V14h14zm-1.75-3.75V3.56l1.72 1.72 1.06-1.06-3-3a.75.75 0 0 0-1.06 0l-3 3 1.06 1.06 1.72-1.72v5.19zM8 7.25H1v1.5h7zM6 2H1v1.5h5z"
      clipRule="evenodd"
    />
  </svg>
);
SortAscendingIcon.displayName = "SortAscendingIcon";

/**
 * TimerIcon
 *
 * Renders a clock face icon used for stage duration indicators.
 *
 * @param {any} className - className
 */
export const TimerIcon = ({ className = "w-4 h-4" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="2"
      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
);
TimerIcon.displayName = "TimerIcon";

/**
 * MinimizeIcon
 *
 * Renders a horizontal dash used for collapse / minimize panel actions.
 * Pair with AddIcon for a minimize ↔ expand toggle.
 *
 * @param {any} className - className
 */
export const MinimizeIcon = ({ className = "w-4 h-4" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
  </svg>
);
MinimizeIcon.displayName = "MinimizeIcon";

/**
 * SmartphoneIcon
 *
 * Renders a smartphone / mobile device icon.
 *
 * @param {any} className - className
 */
export const SmartphoneIcon = ({ className = "w-5 h-5" }) => (
  <svg
    className={className}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <rect
      x="5"
      y="2"
      width="14"
      height="20"
      rx="2"
      ry="2"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      strokeWidth="2"
      strokeLinecap="round"
      d="M12 18h.01"
    />
  </svg>
);

SmartphoneIcon.displayName = "SmartphoneIcon";
