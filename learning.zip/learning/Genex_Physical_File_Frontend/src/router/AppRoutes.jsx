import { useEffect } from "react";
import { useSelector } from "react-redux";
import { Navigate, Route, Routes } from "react-router-dom";
import AppLayout from "../components/layout/AppLayout";
import {
  FEATURE_REGISTRY,
  getRegistryPath,
} from "../constants/featureRegistry";
import { usePreventBackNavigation } from "../hooks/usePreventBackNavigation";
import Login from "../pages/Login";
import NotFound from "../pages/NotFound";
import { validatePermissions } from "../utils/utils";
import ProtectedRoute from "./ProtectedRoute";
import { ROUTES } from "./routes";
import EmailAction from "../pages/doc-admin/create-retrieval-request/EmailAction";
import EmailActionLogin from "../pages/doc-admin/create-retrieval-request/EmailActionLogin";

/**
 * AppRoutes
 *
 * Configures and renders the system routes, integrating authentication state, role-based base routing, and dynamic permission-driven route generation.
 */
const AppRoutes = () => {
  usePreventBackNavigation();
  const { permissions } = useSelector((state) => state.user);

  // Validate whether all backend permissions have a corresponding entry in
  // FEATURE_REGISTRY. Logs a console warning in development for any unmapped
  // permission. No-op in production (tree-shaken by Vite).
  useEffect(() => {
    if (permissions?.length > 0) {
      validatePermissions(FEATURE_REGISTRY, permissions);
    }
  }, [permissions]);

  // Build a Set of the user's permission names for O(1) lookup when generating routes.
  const userPermissionNames = new Set(
    (permissions ?? []).map((p) => p.permissionName),
  );

  // Resolve defaultRedirectPath:
  // Walk FEATURE_REGISTRY in order; the first match that the user holds
  // becomes the post-login default route.
  // This prevents users with no permissions from landing on a blank screen.
  let defaultRedirectPath = null;
  for (const permName of Object.keys(FEATURE_REGISTRY)) {
    if (userPermissionNames.has(permName)) {
      defaultRedirectPath = getRegistryPath(
        permName,
        FEATURE_REGISTRY[permName],
      ).replace(/^\//, "");
      break;
    }
  }

  // Build dynamic feature routes from the user's permissions:
  //  1. Skip permissions with no FEATURE_REGISTRY entry (already warned by validatePermissions).
  //  2. Derive the relative path by stripping the leading slash.
  //  3. Skip permissions whose component has not been wired up yet (null/undefined).
  //  4. Render each valid page as a wildcard route (`path/*`) so nested
  //     sub-routes (e.g. /users/add, /users/edit/:id) are handled by the
  //     page component's own <Routes> tree.
  const dynamicRoutes = [];

  if (permissions && permissions.length > 0) {
    permissions.forEach((p) => {
      const entry = FEATURE_REGISTRY[p.permissionName];

      // No registry entry at all — skip this permission.
      // The validator (above) already surfaced a dev warning for this case.
      if (!entry) return;

      const relativePath = getRegistryPath(p.permissionName, entry).replace(
        /^\//,
        "",
      );

      // Use the registered component, skip if no component mapped yet.
      const PageComponent = entry.component;
      if (!PageComponent) return;

      dynamicRoutes.push(
        <Route
          key={p.permissionName}
          path={`${relativePath}/*`}
          element={<PageComponent />}
        />,
      );
    });
  }

  return (
    <Routes>
      {/* Public */}
      <Route path={ROUTES.AUTH.LOGIN} element={<Login />} />
      <Route path={ROUTES.EMAIL_ACTION} element={<EmailAction />} />
      <Route
        path={ROUTES.AUTH.EMAIL_ACTION_LOGIN}
        element={<EmailActionLogin />}
      />
      {/* Protected — all roles share AppLayout; feature pages render via dynamic routes */}
      <Route element={<ProtectedRoute />}>
        <Route element={<AppLayout />}>
          {/* Default redirect when navigating to the root */}
          {defaultRedirectPath && (
            <Route
              index
              element={<Navigate to={`/${defaultRedirectPath}`} replace />}
            />
          )}
          {/* Render permission-driven feature routes */}
          {dynamicRoutes}
        </Route>
        {/* Catch-all */}
        <Route path={ROUTES.COMMON.NOT_FOUND} element={<NotFound />} />
      </Route>
    </Routes>
  );
};

AppRoutes.displayName = "AppRoutes";
export default AppRoutes;
