import { useSelector } from "react-redux";
import { Navigate, Outlet } from "react-router-dom";
import { ROUTES } from "./routes";

/**
 * ProtectedRoute
 *
 * Authentication guard: - redirects unauthenticated users to login. (Role-based access is now handled dynamically in AppRoutes)
 *
 */
const ProtectedRoute = () => {
  const { isAuthenticated } = useSelector((state) => state.user);

  if (!isAuthenticated) {
    return <Navigate to={ROUTES.AUTH.LOGIN} replace />;
  }

  return <Outlet />;
};

ProtectedRoute.displayName = "ProtectedRoute";
export default ProtectedRoute;
