/**
 * ROUTES
 *
 * Centralised path constants. Import from here whenever you need
 * a route string — avoids hard-coding paths across the codebase.
 *
 * Role-to-dashboard mapping logic lives in src/constants/roles.js
 */

export const ROUTES = {
 AUTH: {
    LOGIN: "/",
    EMAIL_ACTION_LOGIN: "/email-action/:trackId/login",
  },
  EMAIL_ACTION: "/email-action/:trackId",
  USER: {
    ADMIN: "/admin",
    BRANCH: "/branch",
    CPU: "/cpu",
    AUDIT: "/audit",
    STAMPING_USER: "/stamping-user",
    DOC_ADMIN: "/doc-admin",
  },
  FEATURES: {
    DASHBOARD: "/dashboard",
    MASTER: {
      ROLES_AND_PERMISSIONS: {
        ROOT: "/master/roles-and-permissions",
        ADD: "add",
      },
      USER_MANAGEMENT: {
        ROOT: "/master/user-management",
        ADD: "add",
        EDIT: "edit/:id",
        SEARCH: "search/*",
      },
      RACK_MASTER: {
        ROOT: "/master/rack-master",
        ADD: "add",
        EDIT: "edit/:id",
      },
      BRANCH_MASTER: {
        ROOT: "/master/branch-master",
        ADD: "add",
        EDIT: "edit/:id",
      },
      QUERY_CATEGORY: {
        ROOT: "/master/query-category",
        ADD: "add",
      },
      STAMP_MASTER: {
        ROOT: "/master/stamp-master",
        ADD: "add",
        EDIT: "edit/:id",
      },
      STAMP_STACK_MASTER: {
        ROOT: "/master/stamp-stack-master",
        ADD: "add",
      },
    },
    TRANSACTION: {
      RACK_ALLOCATION: {
        ROOT: "/transaction/rack-allocation",
        ADD: "add",
        EDIT: "edit/:id",
      },
      USER_ALLOCATION: {
        ROOT: "/transaction/user-allocation",
        ADD: "add",
        EDIT: "edit/:id",
      },
      RETURN_RACK: "/transaction/return-rack",
      HEALTH_CHECK: {
        ROOT: "/transaction/health",
        DETAILS: "details/:id",
      },
      QUERY: {
        ROOT: "/transaction/query",
        DETAILS: "details/:id",
      },
      NON_CRITICAL_QUERY: {
        ROOT: "/transaction/non-critical-query",
        DETAILS: "details/:id",
      },
      OUTWARD: "/transaction/outward",
      STAMPING: {
        ROOT: "/transaction/stamping",
        DETAILS: "details/:id",
        AMOUNT: "stamping-amount",
      },
      STORAGE: "/transaction/storage",
      ENQUIRY: "/transaction/enquiry",
      APPLICATIONS_UNLOCK: "/transaction/unlock",
       DOC_ADMIN_RETERIVAL_REQUEST: {
        ROOT: "/transaction/docAdmin",
        ADD: "add",
        EDIT: "edit/:track_id",
      },
    },
     
    REPORTS: {
      REPORT: "/reports",
    },
  },
  COMMON: {
    NOT_FOUND: "*",
  },
    };
