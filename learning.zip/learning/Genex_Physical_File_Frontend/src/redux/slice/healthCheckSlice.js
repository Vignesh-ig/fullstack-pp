import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import {
  getQueriesApi,
  getStagesApi,
} from "../../api/apiConfig";

export const fetchQueries = createAsyncThunk(
  "healthCheck/fetchQueries",
  async (params, { rejectWithValue }) => {
    try {
      return await getQueriesApi(params);
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  },
);

export const fetchStages = createAsyncThunk(
  "healthCheck/fetchStages",
  async (params, { rejectWithValue }) => {
    try {
      return await getStagesApi(params);
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  },
);


const initialState = {
  queries: [],
  stages: [],
  loading: false,
  error: null,
};

const healthCheckSlice = createSlice({
  name: "healthCheck",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      // Queries
      .addCase(fetchQueries.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchQueries.fulfilled, (state, action) => {
        state.loading = false;
        state.queries = action.payload?.data?.data || [];
      })
      .addCase(fetchQueries.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Stages
      .addCase(fetchStages.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchStages.fulfilled, (state, action) => {
        state.loading = false;
        state.stages = action.payload?.data?.data || [];
      })
      .addCase(fetchStages.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export default healthCheckSlice.reducer;
