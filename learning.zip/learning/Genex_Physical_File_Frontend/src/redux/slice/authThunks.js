import { createAsyncThunk } from "@reduxjs/toolkit";
import { getRoleApi, loginApi } from "../../api";
import { getFirstPermittedPath } from "../../constants/featureRegistry";
import { canEditRetrieval } from "../../constants/roles";
import { loginFailure, loginStart, loginSuccess } from "./userSlice";

/**
 * authThunks.js
 *
 * Async thunks for authentication.
 * These sit between the UI and the API layer — they handle the full
 * request lifecycle and dispatch the appropriate slice actions.
 */

/**
 * loginThunk
 * Maps the API response: { data: { userId, userName, userEmail, ... roleDto } }
 * On success → stores user + role info in Redux and returns redirectTo for navigation.
 * On failure → dispatches loginFailure with a user-friendly message.
 */

export const loginThunk = createAsyncThunk(
  "auth/login",
  async (credentials, { dispatch, rejectWithValue }) => {
    try {
      dispatch(loginStart());

      const response = await loginApi(credentials);
      const userData = response.data;
      const isDocAdminEdit = canEditRetrieval(userData.roleDto.roleName);

      if (!isDocAdminEdit) {
        try {
          const roleResponse = await getRoleApi(userData.userEmployeeCode);

          localStorage.setItem(
            "employeeCode",
            roleResponse?.data?.employee_status ?? "",
          );
        } catch (roleError) {
          console.error("Failed to fetch role info during login:", roleError);
        }
      }
      dispatch(loginSuccess({ data: userData }));

      const permissionNames = (userData?.roleDto?.permissionDtoList ?? []).map(
        (p) => p.permissionName,
      );

      const redirectTo = getFirstPermittedPath(permissionNames);

      return { redirectTo };
    } catch (error) {
      const message =
        error.response?.data?.message || error.message || "Login failed.";
      dispatch(loginFailure(message));
      return rejectWithValue(message);
    }
  },
);
