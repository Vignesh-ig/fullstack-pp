import { createSlice } from "@reduxjs/toolkit";

/**
 * userSlice.js
 *
 * Manages all authentication + user profile state.
 */
const SESSION_DURATION_MS = 60 * 60 * 1000;

const initialState = {
  permissions: [],

  // Auth state
  isAuthenticated: false,
  loading: false,
  error: null,
  sessionExpired: false,
};

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    loginStart: (state) => {
      state.loading = true;
      state.error = null;
      state.sessionExpired = false;
    },

    loginSuccess: (state, action) => {
      const { data } = action.payload;
      const { roleDto } = data;

      state.loading = false;
      state.isAuthenticated = true;

      // User details
      state.userId = data.userId;
      state.userName = data.userName;
      state.userEmail = data.userEmail;
      state.userEmployeeCode = data.userEmployeeCode;
      state.isActive = data.isActive;

      // Role details
      state.roleId = data.roleId;
      state.roleName = roleDto?.roleName ?? null;
      state.roleDescription = roleDto?.description ?? null;

      // Permissions list
      state.permissions =
        roleDto?.permissionDtoList?.map((p) => ({
          permissionId: p.permissionId,
          permissionName: p.permissionName,
          description: p.description,
        })) ?? [];

      state.loggedInAt = new Date().getTime();
      state.expiresAt = new Date().getTime() + SESSION_DURATION_MS;
    },

    loginFailure: (state, action) => {
      state.loading = false;
      state.error = action.payload;
    },

    logout: (state, action) => {
      return {
        ...initialState,
        sessionExpired: action.payload?.sessionExpired || false,
      };
    },
  },
});

export const { loginStart, loginSuccess, loginFailure, logout } =
  userSlice.actions;
export default userSlice.reducer;
