import { configureStore } from "@reduxjs/toolkit";
import {
  FLUSH,
  PAUSE,
  PERSIST,
  persistReducer,
  persistStore,
  PURGE,
  REGISTER,
  REHYDRATE,
} from "redux-persist";
import healthCheckReducer from "../slice/healthCheckSlice";
import rolesReducer from "../slice/rolesSlice";
import userReducer from "../slice/userSlice";

const localStorageAdapter = {
  getItem: (key) => Promise.resolve(localStorage.getItem(key)),
  setItem: (key, value) => Promise.resolve(localStorage.setItem(key, value)),
  removeItem: (key) => Promise.resolve(localStorage.removeItem(key)),
};

const sessionStorageAdapter = {
  getItem: (key) => Promise.resolve(sessionStorage.getItem(key)),
  setItem: (key, value) => Promise.resolve(sessionStorage.setItem(key, value)),
  removeItem: (key) => Promise.resolve(sessionStorage.removeItem(key)),
};

/**
 * Persist user data and permissions so navbar stays after refresh.
 */
const userPersistConfig = {
  key: "user",
  storage: sessionStorageAdapter,
  whitelist: [
    "userId",
    "roleId",
    "roleName",
    "userName",
    "userEmail",
    "userEmployeeCode",
    "isAuthenticated",
    "token",
    "permissions",
    "loggedInAt",
    "expiresAt",
    "sessionExpired",
  ],
};

const persistedUserReducer = persistReducer(userPersistConfig, userReducer);

export const store = configureStore({
  reducer: {
    user: persistedUserReducer,
    roles: rolesReducer,
    healthCheck: healthCheckReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        // Required: ignore redux-persist internal actions
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }),
});

export const persistor = persistStore(store);
