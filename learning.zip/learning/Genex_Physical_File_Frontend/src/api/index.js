/**
 * src/api/index.js
 *
 * Barrel export — import everything API-related from here.
 *
 * Usage:
 *   import { loginApi, ENDPOINTS, axiosInstance } from "../api";
 */

export * from "./apiConfig";
export { default as axiosInstance } from "./axiosInstance";
export * from "./endpoints";
