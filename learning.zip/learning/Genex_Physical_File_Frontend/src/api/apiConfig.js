import axios from "axios";
import { ENV } from "../config/envConfig";
import axiosInstance from "./axiosInstance";
import { ENDPOINTS } from "./endpoints";

// Auth
export const loginApi = ({ userEmployeeCode, password }) =>
  axiosInstance
    .post(
      ENDPOINTS.LOGIN,
      { userEmployeeCode, password },
      {
        baseURL: ENV.API_BASE_URL,
        headers: { Authorization: ENV.AUTH_TOKEN },
      },
    )
    .then((res) => res.data);

// Dashboard
export const getDashboardApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.DASHBOARD, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Users
export const getUsersApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.USERS, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => {
      return res.data;
    });

export const getGenexUsersApi = () =>
  axiosInstance
    .get(ENDPOINTS.GENEX_USERS, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const createUserApi = (payload) =>
  axiosInstance
    .post(ENDPOINTS.USERS, payload, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const updateUserApi = (payload) =>
  axiosInstance
    .put(ENDPOINTS.USERS, payload, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const deleteUsersApi = (userIds = []) =>
  axiosInstance
    .post(ENDPOINTS.DELETE_USERS, "", {
      params: {
        UserIds: userIds.join(","),
      },
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Roles
export const getRolesApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.ROLES, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const createRoleApi = (payload) =>
  axiosInstance
    .post(ENDPOINTS.ROLES, payload, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const deleteRolesApi = (id) =>
  axiosInstance
    .post(ENDPOINTS.DELETE_ROLES, "", {
      params: { roleIds: id },
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Permissions
export const getPermissionsApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.PERMISSIONS, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const createPermissionApi = (payload) =>
  axiosInstance
    .post(ENDPOINTS.PERMISSIONS, payload, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const deletePermissionApi = (id) =>
  axiosInstance
    .post(ENDPOINTS.DELETE_PERMISSIONS, "", {
      params: { permissionIds: id },
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Query Category
export const getQueryCategoriesApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.QUERY_CATEGORY, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const createQueryCategoryApi = (payload) =>
  axiosInstance
    .post(ENDPOINTS.QUERY_CATEGORY, payload, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const deleteQueryCategoryApi = (id) =>
  axiosInstance
    .post(`${ENDPOINTS.QUERY_CATEGORY}/ids`, "", {
      params: { queryCategoryIds: id },
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Branch Hierarchy
export const getBranchZonesApi = () =>
  axiosInstance
    .get(ENDPOINTS.BRANCH_ZONES, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const getBranchRegionsApi = (zoneId) =>
  axiosInstance
    .get(ENDPOINTS.BRANCH_REGIONS, {
      params: { zoneId },
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const getBranchAreasApi = (regionId) =>
  axiosInstance
    .get(ENDPOINTS.BRANCH_AREAS, {
      params: { regionId },
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const getBranchByAreaApi = (areaId) =>
  axiosInstance
    .get(ENDPOINTS.BRANCH_BRANCHES, {
      params: { areaId },
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Vault & Racks
export const getVaultsApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.VAULT, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const getRacksApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.RACKS, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const createRackApi = (payload) =>
  axiosInstance
    .post(ENDPOINTS.RACKS, payload, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const updateRackApi = (payload) =>
  axiosInstance
    .put(ENDPOINTS.RACKS, payload, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const deleteRacksApi = (rackIds = []) =>
  axiosInstance
    .post(ENDPOINTS.DELETE_RACKS, "", {
      params: {
        rackIds: rackIds.join(","),
      },
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Rack Allocation & User Allocation
export const getRackAssignedApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.RACK_ASSIGNED, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const createRackAssignedApi = (payload) =>
  axiosInstance
    .post(ENDPOINTS.RACK_ASSIGNED, payload, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const updateRackAssignedApi = (payload, params) =>
  axiosInstance
    .put(ENDPOINTS.RACK_ASSIGNED, payload, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const deleteRackAssignedApi = (ids = []) =>
  axiosInstance
    .post(ENDPOINTS.DELETE_RACK_ASSIGNED, "", {
      params: {
        rackAssignedIds: ids.join(","),
      },
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Despatch Details
export const getDespatchDetailsApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.DESPATCH_DETAILS, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// File Types
export const getFileTypesApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.FILE_TYPE, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Queries
export const getQueriesApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.QUERIES, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const getStagesApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.STAGES, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Health Check, Query, Outward, Stamping, Storage, Enquiry, Application Unlock
export const createTransactionApi = (payload) =>
  axiosInstance
    .post(ENDPOINTS.TRANSACTION, payload, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const getTransactionApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.TRANSACTION, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const updateTransactionLockApi = (params) =>
  axiosInstance
    .post(ENDPOINTS.TRANSACTION_LOCK, null, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// States Master
export const getStatesApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.STATES, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Stamp Type
export const getStampTypesApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.STAMP_TYPE, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Stamp Denominations
export const getStampDenominationsApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.STAMP_DENO, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Stamping Master
export const getStampMasterApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.STAMP_MASTER, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const createStampMasterApi = (payload) =>
  axiosInstance
    .post(ENDPOINTS.STAMP_MASTER, payload, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const updateStampMasterApi = (payload) =>
  axiosInstance
    .post(ENDPOINTS.STAMP_MASTER, payload, {
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

// Stamp Stack Master
export const getStampStackMasterApi = (params) =>
  axiosInstance
    .get(ENDPOINTS.STAMP_STACK_MASTER, {
      params,
      baseURL: ENV.API_BASE_URL,
      headers: { Authorization: ENV.AUTH_TOKEN },
    })
    .then((res) => res.data);

export const uploadStampStackMasterCsvApi = (file, createdBy) => {
  const formData = new FormData();
  formData.append("stampStackCsvFile", file);
  formData.append("createdBy", createdBy);
  return axiosInstance
    .post(ENDPOINTS.STAMP_STACK_MASTER_UPLOAD, formData, {
      baseURL: ENV.API_BASE_URL,
      headers: {
        "Content-Type": "multipart/form-data",
        Authorization: ENV.AUTH_TOKEN,
      },
    })
    .then((res) => res.data);
};

const DMS_LEAD_BASE_URL = ENV.DMS_LEAD_BASE_URL;
const DMS_PDF_VIEW_URL = ENV.DMS_PDF_VIEW_URL;
const DMS_PDF_VIEW_AUTH_KEY = ENV.DMS_PDF_VIEW_AUTH_KEY;
const DMS_PDF_UPLOAD_URL = ENV.DMS_PDF_UPLOAD_URL;
const DMS_PDF_UPLOAD_AUTH_KEY = ENV.DMS_PDF_UPLOAD_AUTH_KEY;
const GENEX_URL = ENV.GENEX_URL;
const GENEX_AUTH_KEY = ENV.GENEX_AUTH_KEY;

/**
 * Fetches the list of DMS IDs for a given application number.
 *
 * @param {string} appNo - The application number.
 * @returns {Promise<{Data: Array<{dms: string}>, status: string}>}
 */
export const getPFDmsListApi = async (appNo) => {
  const url = `${DMS_LEAD_BASE_URL}/getpfDMS?appNo=${encodeURIComponent(appNo)}`;
  const response = await fetch(url, {
    method: "GET",
    headers: {
      Authorization: DMS_PDF_VIEW_AUTH_KEY,
    },
  });

  if (response.status === 404) {
    return response.json();
  }

  if (!response.ok) {
    throw new Error(`Failed to fetch DMS list: ${response.status}`);
  }

  return response.json();
};

/**
 * Downloads a DMS document as a Blob given its DMS ID.
 *
 * @param {string} dmsId - The DMS document UUID.
 * @returns {Promise<Blob>} The PDF blob.
 */
export const downloadPFDmsDocumentApi = async (dmsId) => {
  const url = `${DMS_PDF_VIEW_URL}?dmsid=${encodeURIComponent(dmsId)}`;
  const response = await fetch(url, {
    method: "GET",
    headers: {
      Authorization: DMS_PDF_VIEW_AUTH_KEY,
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to download document: ${response.status}`);
  }

  return response.blob();
};

/**
 * Uploads a document to the DMS for a given application.
 *
 * @param {Object} metadata - The JSON metadata payload (data field).
 * @param {File} file - The file to upload (PDF or image, max 25 MB).
 * @returns {Promise<Object>} The parsed JSON response from the DMS API.
 */
export const uploadPFDmsDocumentApi = async (metadata, file) => {
  const formData = new FormData();
  formData.append("data", JSON.stringify(metadata));
  formData.append("image", file);

  const response = await fetch(DMS_PDF_UPLOAD_URL, {
    method: "POST",
    headers: {
      Authorization: DMS_PDF_UPLOAD_AUTH_KEY,
    },
    body: formData,
  });

  if (!response.ok) {
    throw new Error(`Failed to upload document: ${response.status}`);
  }

  return response.text();
};

/**
 * Fetches the PF details for a given application number.
 *
 * @param {string} appNo - The application number.
 * @returns {Promise<Object>} The parsed JSON response.
 */
export const getPFDetailsApi = async (appNo) => {
  const url = `${DMS_LEAD_BASE_URL}/getPFdetails?appNo=${encodeURIComponent(appNo)}`;
  const response = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "application/json",
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch PF details: ${response.status}`);
  }

  return response.json();
};

/**
 * Posts the DMS ID to the lead system.
 *
 * @param {Object} payload - The JSON payload containing lead_id, dms, createdBy, userName, document_name.
 * @returns {Promise<Object>} The parsed JSON response.
 */
export const postPFDmsApi = async (payload) => {
  const url = `${DMS_LEAD_BASE_URL}/postpfDMS`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error(`Failed to post DMS: ${response.status}`);
  }

  return response.json();
};

export const getGenexDashboardItemsApi = async (searchBarcode) => {
  const payload = {
    limit: 10,
    filter_date: { start: "", end: "" },
    sorted: { modifiedDate: -1 },
    search: searchBarcode,
    searchType: "All",
    offset: 0,
  };

  const response = await fetch(GENEX_URL, {
    method: "POST",
    headers: {
      Accept: "application/json, text/plain, */*",
      "Accept-Language": "en-US,en;q=0.9",
      Authorization: `${GENEX_AUTH_KEY}`,
      "Content-Type": "application/json",
      selectedRole: "GENZ_CPU_ADMIN",
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error(
      `Failed to fetch Genex dashboard items: ${response.status}`,
    );
  }

  return response.json();
};

//DOC_ADMIN_MODULE_RETRIEVAL_REQUEST
const GENEX_DOC_ADMIN_MODULE_URL = ENV.GENEX_DOC_ADMIN_MODULE_URL;
const GENEX_DOC_ADMIN_MODULE_KEY = ENV.GENEX_DOC_ADMIN_MODULE_KEY;
const GENEX_DOC_ADMIN_MODULE_BASE_URL = ENV.GENEX_DOC_ADMIN_MODULE_UAT_BASE_URL;

export const getReterievalRequestApi = async ({
  page,
  limit,
  searchKey,
  userId,
  role,
  employeeCode,
  jobStage,
}) => {
  const params = new URLSearchParams();

  params.set("page", page);
  params.set("limit", limit);

  if (searchKey) params.set("search_key", searchKey);
  if (userId) params.set("user_id", userId);
  if (role) params.set("role", role);
  if (employeeCode) params.set("employee_code", employeeCode);
  if (jobStage) params.set("job_status", jobStage);

  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}retreival/viewRetreivalReqs?${params.toString()}`;

  const response = await fetch(url, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch retrieval requests: ${response.status}`);
  }

  return response.json();
};

export const createRetrievalRequestApi = async (payload, file) => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}retreival/createRetreival`;

  const formData = new FormData();

  formData.append("data", JSON.stringify(payload));

  if (file) {
    formData.append("documents", file);
  }

  const response = await fetch(url, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    throw new Error(`Failed to create retrieval request: ${response.status}`);
  }

  return response.json();
};

export const updateRetrievalRequestApi = async (payload, trackId, userId) => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}retreival/editRetreivalReq?track_id=${encodeURIComponent(
    trackId,
  )}&user_id=${encodeURIComponent(userId)}`;

  const updatedPayload = { ...payload };

  // if (!updatedPayload.scan_file_link) {
  //   delete updatedPayload.scan_file_link;
  // }

  const response = await fetch(url, {
    method: "PUT",
    body: JSON.stringify(updatedPayload),
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to update retrieval request: ${response.status}`);
  }

  return response.json();
};

export const getRetrievalDetailApi = async (trackId) => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}retreival/viewRetreivalRequest?track_id=${encodeURIComponent(
    trackId,
  )}`;

  const response = await fetch(url, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch retrieval detail: ${response.status}`);
  }

  return response.json();
};

export const getDepartmentApi = async () => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}master/getDepartments`;

  const response = await fetch(url, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch departments: ${response.status}`);
  }

  return response.json();
};

export const getLocationsApi = async () => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}master/getLocations`;

  const response = await fetch(url, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch locations: ${response.status}`);
  }

  return response.json();
};

export const getPurposeApi = async () => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}master/getPurpose`;

  const response = await fetch(url, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch purpose: ${response.status}`);
  }

  return response.json();
};

export const getDocumentsApi = async () => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}master/getDocuments`;

  const response = await fetch(url, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch documents: ${response.status}`);
  }

  return response.json();
};

export const getRequestTypesApi = async () => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}master/getRequestTypes`;

  const response = await fetch(url, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch request types: ${response.status}`);
  }

  return response.json();
};

export const getRetreivalDocsTypeApi = async () => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}master/getRetreivalDocsType`;

  const response = await fetch(url, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error(
      `Failed to fetch retrieval document types: ${response.status}`,
    );
  }

  return response.json();
};

export const refillingRequestApi = async (payload, trackId, userId) => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}refiling/refilingRequest?track_id=${encodeURIComponent(
    trackId,
  )}&user_id=${encodeURIComponent(userId)}`;

  const formData = new FormData();

  Object.entries(payload || {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null) {
      formData.append(key, value);
    }
  });

  const response = await fetch(url, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    throw new Error(`Failed to create refiling request: ${response.status}`);
  }

  return response.json();
};

export const getRoleApi = async (role) => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}retreival/getRole?employee_code=${encodeURIComponent(
    role,
  )}`;

  const response = await fetch(url, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch role: ${response.status}`);
  }

  return response.json();
};

export const approveandRejectApi = async (
  trackId,
  userId,
  action,
  remark,
  tatValue,
) => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}retreival/retreivalRequestAction?track_id=${encodeURIComponent(
    trackId,
  )}&user_id=${encodeURIComponent(userId)}`;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },

    body: JSON.stringify({
      action,
      remarks: remark,
      tat_value: tatValue,
    }),
  });

  if (!response.ok) {
    throw new Error(`Failed to process retrieval request: ${response.status}`);
  }

  return response.json();
};

export const viewDashbardRequestApi = async (userId, role, employeeCode) => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}retreival/viewDashboard?user_id=${encodeURIComponent(
    userId,
  )}&role=${encodeURIComponent(role)}&employee_code=${encodeURIComponent(
    employeeCode,
  )}`;

  const response = await fetch(url, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch dashboard: ${response.status}`);
  }

  return response.json();
};

//downlaod DmsId csv file

export const getCsvFileapi = async (dmsId) => {
  const localUrl = `${GENEX_DOC_ADMIN_MODULE_URL}?dmsid=${dmsId}`;

  const res = await axios.get(localUrl, {
    responseType: "blob",
    headers: {
      Authorization: `Bearer ${GENEX_DOC_ADMIN_MODULE_KEY}`,
    },
  });

  return res.data;
};

export const generatedJobReportApi = async (jobIds) => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}retreival/jobReport`;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      job_nos: jobIds,
    }),
  });

  if (!response.ok) {
    throw new Error(`Failed to generate job report: ${response.status}`);
  }

  return response.blob();
};

export const allRefillingRequestApi = async (formData, userId) => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}refiling/refilingRequest?user_id=${encodeURIComponent(
    userId,
  )}`;

  const response = await fetch(url, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch refiling requests: ${response.status}`);
  }

  return response.json();
};

export const getStageFlowApi = async () => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}master/getStageFlow`;

  const response = await fetch(url, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch stage flow: ${response.status}`);
  }

  return response.json();
};

export const getScanFileRefillingApi = async (formData, userId) => {
  const url = `${GENEX_DOC_ADMIN_MODULE_BASE_URL}refiling/scanRequest?user_id=${encodeURIComponent(
    userId,
  )}`;

  // const formData = new FormData();

  // Object.entries(payload || {}).forEach(([key, value]) => {
  //   if (value !== undefined && value !== null) {
  //     formData.append(key, value);
  //   }
  // });

  const response = await fetch(url, {
    method: "POST",
    body: formData,
  });

  if (!response.ok) {
    throw new Error(
      `Failed to create scan/refiling request: ${response.status}`,
    );
  }

  return response.json();
};
