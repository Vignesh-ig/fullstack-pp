import axios from "axios";
import { ENV } from "../config/envConfig";
import { store } from "../redux/app/store";
import { logout } from "../redux/slice/userSlice";

const BASE_URL = ENV.API_BASE_URL;
const AUTH_TOKEN = ENV.AUTH_TOKEN;

const axiosInstance = axios.create({
  timeout: 120000,
  headers: {
    "Content-Type": "application/json",
  },
});

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      store.dispatch(logout());
      if (window.location.pathname !== "/") {
        window.location.href = "/";
      }
    }
    const message =
      error.response?.data?.message ||
      error.response?.data?.error ||
      error.message ||
      "Unexpected error";
    return Promise.reject(new Error(message));
  },
);

export default axiosInstance;
