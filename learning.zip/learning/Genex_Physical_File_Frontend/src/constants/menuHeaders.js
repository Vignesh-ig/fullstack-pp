import {
  AlertCircleIcon,
  BuildingIcon,
  ServerIcon,
  StampIcon,
  TransferIcon,
} from "../components/icons/icons";

// Roles & Permissions Form Tabs
export const ROLES_PERMISSIONS_FORM_TABS = [
  { id: "role", label: "Add Roles" },
  { id: "permission", label: "Add Permissions" },
];

// Roles & Permissions List Tabs
export const ROLES_PERMISSIONS_LIST_TABS = [
  { id: "roles", label: "Roles" },
  { id: "permissions", label: "Permission" },
];

// Overview Tabs
export const OVERVIEW_TAB = {
  STAMPING_OVERVIEW: "STAMPING_OVERVIEW",
  ALLOCATION_OVERVIEW: "ALLOCATION_OVERVIEW",
  BRANCH_OVERVIEW: "BRANCH_OVERVIEW",
  TRANSACTION_OVERVIEW: "TRANSACTION_OVERVIEW",
  QUERY_OVERVIEW: "QUERY_OVERVIEW",
};

// Dashboard Tabs
export const DASHBOARD_TAB = {
  ALLOCATIONS: OVERVIEW_TAB.ALLOCATION_OVERVIEW,
  STAMPING: OVERVIEW_TAB.STAMPING_OVERVIEW,
  BRANCH: OVERVIEW_TAB.BRANCH_OVERVIEW,
  TRANSACTIONS: OVERVIEW_TAB.TRANSACTION_OVERVIEW,
  QUERY: OVERVIEW_TAB.QUERY_OVERVIEW,
};

export const DASHBOARD_TABS = [
  { id: DASHBOARD_TAB.TRANSACTIONS, label: "Transactions", icon: TransferIcon },
  { id: DASHBOARD_TAB.ALLOCATIONS, label: "Allocations", icon: ServerIcon },
  { id: DASHBOARD_TAB.QUERY, label: "Query", icon: AlertCircleIcon },
  { id: DASHBOARD_TAB.STAMPING, label: "Stamping", icon: StampIcon },
  { id: DASHBOARD_TAB.BRANCH, label: "Branch", icon: BuildingIcon },
];

// Query Category List Tabs
export const QUERY_CATEGORY_LIST_TABS = [
  { id: "category", label: "Category" },
  { id: "sub-category", label: "Sub Category" },
];
