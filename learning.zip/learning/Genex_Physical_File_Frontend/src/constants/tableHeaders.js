/* User Management table */
export const USER_TABLE_COLUMNS = [
  { label: "" },
  { label: "S. No" },
  { label: "System User Name" },
  { label: "Employee Name" },
  { label: "Email" },
  { label: "Role", align: "center" },
  { label: "Status", align: "center" },
  { label: "Actions", align: "center" },
];

/* Rack Master table */
export const RACK_TABLE_COLUMNS = [
  { label: "S. No" },
  { label: "Vault Name" },
  { label: "Rack Name" },
  { label: "Self" },
  { label: "Count", align: "center" },
  { label: "Status", align: "center" },
];

/* Branch Master table */
export const BRANCH_TABLE_COLUMNS = [
  { label: "S. No" },
  { label: "Branch Name" },
  { label: "" },
  { label: "" },
  { label: "" },
];

/* Stamp Master table */
export const STAMP_MASTER_TABLE_COLUMNS = [
  { label: "S. No" },
  { label: "State" },
  { label: "Stamp Type", align: "center" },
  { label: "Denomination" },
  { label: "Status", align: "center" },
];

/* Stamp Stack Master table */
export const STAMP_STACK_MASTER_TABLE_COLUMNS = [
  { label: "S. No" },
  { label: "State" },
  { label: "Denomination Serial No" },
  { label: "Denomination Amount" },
  { label: "Used By" },
  { label: "Status", align: "center" },
];

/* Rack Allocation table */
export const RACK_ALLOCATION_TABLE_COLUMNS = [
  { label: "" },
  { label: "S. No" },
  { label: "Application Number" },
  { label: "Ageing" },
  { label: "File Type Name" },
  { label: "Vault Name" },
  { label: "Rack Name" },
  { label: "Actions", align: "center" },
];

/* User Allocation table */
export const USER_ALLOCATION_TABLE_COLUMNS = [
  { label: "" },
  { label: "S. No" },
  { label: "Application Number" },
  { label: "Assigned User" },
  { label: "File Type Name" },
  { label: "Ageing" },
  { label: "Customer Name" },
  { label: "Rack Name" },
  { label: "Self" },
  { label: "Actions", align: "center" },
];

/* Return Rack table */
export const RETURN_RACK_TABLE_COLUMNS = [
  { label: "" }, // checkbox column
  { label: "S. No" },
  { label: "Application Number" },
  { label: "Barcode" },
  { label: "Assigned User" },
  { label: "Vault Name" },
  { label: "Rack Name" },
];

/* Health Check table */
export const HEALTH_CHECK_TABLE_COLUMNS = [
  { label: "S. No" },
  { label: "Application Number" },
  { label: "Agreement Number" },
  { label: "Barcode" },
  { label: "Branch User" },
  { label: "Customer Name" },
  // { label: "Product category", align: "center" },
  { label: "Stamp Type", align: "center" },
  { label: "Stage", align: "center" },
];

/* Query table */
export const QUERY_TABLE_COLUMNS = [
  { label: "S. No" },
  { label: "Application Number" },
  { label: "Agreement Number" },
  { label: "Customer Name" },
];

/* Non Critical Query table */
export const NON_CRITICAL_QUERY_TABLE_COLUMNS = [
  { label: "S. No" },
  { label: "Application Number" },
  { label: "Agreement Number" },
  { label: "Barcode" },
  { label: "Vault Name" },
  { label: "Rack Name" },
];

/* Outward table */
export const OUTWARD_TABLE_COLUMNS = [
  { label: "" }, // checkbox column
  { label: "S. No" },
  { label: "Application Number" },
  { label: "Agreement Number" },
  { label: "Barcode" },
  { label: "Customer Name" },
  { label: "State" },
  { label: "Stamp Type", align: "center" },
];

/* Stamping table */
export const STAMPING_TABLE_COLUMNS = [
  { label: "" },
  { label: "S. No" },
  { label: "Application Number" },
  { label: "Agreement Number" },
  { label: "Barcode" },
  { label: "Customer Name" },
  { label: "State" },
  { label: "Stamp Type", align: "center" },
];

/* Stamping Amount table */
export const STAMPING_AMOUNT_TABLE_COLUMNS = [
  { label: "" },
  { label: "S. No" },
  { label: "State" },
  { label: "Total Amount" },
  { label: "Application Count", align: "center" },
];

/* Storage table */
export const STORAGE_TABLE_COLUMNS = [
  { label: "" },
  { label: "S. No" },
  { label: "Application Number" },
  { label: "Agreement Number" },
  { label: "Barcode" },
  { label: "Customer Name" },
  { label: "State" },
  { label: "Stamp Type", align: "center" },
];

/* Application Unlock table */
export const APPLICATIONS_UNLOCK_TABLE_COLUMNS = [
  { label: "" },
  { label: "S. No" },
  { label: "Application Number" },
  { label: "Agreement Number" },
  { label: "Barcode" },
  { label: "Customer Name" },
  { label: "Vault Name" },
  { label: "Rack Name" },
];

/* Roles table */
export const ROLES_TABLE_COLUMNS = [
  { label: "S. No" },
  { label: "Role Name", align: "center" },
  { label: "Role Description" },
  { label: "Actions", align: "center" },
];

/* Roles & Permissions table */
export const PERMISSIONS_TABLE_COLUMNS = [
  { label: "S. No" },
  { label: "Role Name", align: "center" },
  { label: "Permission" },
  { label: "Permission Description" },
  { label: "Actions", align: "center" },
];

/* Query Category table */
export const QUERY_CATEGORY_TABLE_COLUMNS = [
  { label: "S. No" },
  { label: "Category Name" },
  // { label: "Actions", align: "center" },
];

/* Query Sub Category table */
export const QUERY_SUB_CATEGORY_TABLE_COLUMNS = [
  { label: "S. No" },
  { label: "Category Name" },
  { label: "Sub Category Name" },
  { label: "Actions", align: "center" },
];

/* Dashboard Transaction / Query drill-down table */
export const DASHBOARD_TRANSACTION_TABLE_COLUMNS = [
  { label: "S. No" },
  { label: "Application Number" },
  { label: "Agreement No" },
  { label: "Barcode" },
  { label: "Customer Name" },
  { label: "File Type" },
  { label: "Ageing No", align: "center" },
];

export const File_RETERIAVAL_REQUEST_TABLE_COLUMNS = (isDocAdminUser) => [
  { label: "" },
  { label: "S.No" },
  { label: "Job No", align: "center" },
  { label: "Date", align: "center" },
  { label: "User Name", align: "center" },
  { label: "Department", align: "center" },

  ...(isDocAdminUser
    ? [
        { label: "Serviced / File count", align: "center" },
        { label: "Refiling", align: "center" },
      ]
    : []),

  { label: "Job Status", align: "center" },
];
