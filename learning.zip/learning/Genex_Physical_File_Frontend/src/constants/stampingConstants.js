import { mapLabelsToOptions } from "../utils/utils";

/**
 * Stamp Master Constants
 *
 * Centralized constants for stamp type, denominations, and Indian states
 * used across the stamp master form and table.
 */

// ─── Stamp Type ───────────────────────────────────────────────────────────────

export const STAMP_TYPE = {
  FIXED: "FIXED",
  VARIABLE: "VARIABLE",
  NO_STAMPING: "NO_STAMP",
  E_STAMPING: "E_STAMP",
};

/**
 * Human-readable display labels for each stamp type key.
 * Used by StampTypeBadge to render badge text.
 */
export const STAMP_TYPE_LABELS = {
  [STAMP_TYPE.FIXED]: "Fixed",
  [STAMP_TYPE.VARIABLE]: "Variable",
  [STAMP_TYPE.NO_STAMPING]: "No Stamp",
  [STAMP_TYPE.E_STAMPING]: "E-Stamp",
};

export const STAMP_TYPE_OPTIONS = mapLabelsToOptions(STAMP_TYPE_LABELS);

/**
 * CSS class map for each stamp type — mirrors ROLE_STYLES in roles.js.
 * Keys must match STAMP_TYPE values.
 */
export const STAMP_TYPE_STYLES = {
  [STAMP_TYPE.FIXED]: "badge-stamp-fixed",
  [STAMP_TYPE.VARIABLE]: "badge-stamp-variable",
  [STAMP_TYPE.NO_STAMPING]: "badge-stamp-no-stamp",
  [STAMP_TYPE.E_STAMPING]: "badge-stamp-e-stamp",
};

export const DEFAULT_STAMP_TYPE_STYLE = "badge-default";

// ─── Denomination / Stack Status ──────────────────────────────────────────────

/**
 * DENO_STATUS
 *
 * Raw backend CAPS values — used for exact comparison against API responses.
 * Follows the same pattern as stages.js (DECISION_UPDATE_STAGES).
 */
export const DENO_STATUS = {
  IN_STOCK: "IN_STOCK",
  USED: "USED",
};

/**
 * Human-readable labels for DENO_STATUS values.
 * Used by StampStackStatusBadge to render badge text.
 */
export const DENO_STATUS_LABELS = {
  [DENO_STATUS.IN_STOCK]: "In-Stock",
  [DENO_STATUS.USED]: "Used",
};

/**
 * DENO_STATUS_OPTIONS
 *
 * Dropdown options for denomination status filter.
 * value must match DENO_STATUS keys so filtering works correctly.
 */
export const DENO_STATUS_OPTIONS = mapLabelsToOptions(DENO_STATUS_LABELS);
