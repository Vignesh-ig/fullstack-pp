/**
 * DECISION_UPDATE_STAGES
 *
 * Maps backend queryName keys to their exact backend string values.
 * Used for enum-based comparisons instead of raw string literals.
 */
export const DECISION_UPDATE_STAGES = {
  COMPLETED: "COMPLETED",
  CRITICAL_QUERY: "CRITICAL_QUERY",
  NON_CRITICAL_QUERY: "NON_CRITICAL_QUERY",
  QUERY_RESOLVED: "QUERY_RESOLVED",
};

/**
 * APP_STAGES
 *
 * Centralized constant for all the stage names used across the application.
 */
export const APP_STAGES = {
  RACK_ASSIGNED: "RACK_ASSIGNED",
  USER_ASSIGNED: "USER_ASSIGNED",
  RETURN_TO_RACK: "RETURN_TO_RACK",
  HEALTH_CHECK: "HEALTH_CHECK",
  QUERY: "QUERY",
  QUERY_RESOLVED: "QUERY_RESOLVED",
  OUTWARD: "OUTWARD",
  STAMPING: "STAMPING",
  STORAGE: "STORAGE",
  ENQUIRY: "ENQUIRY",
};

/**
 * STAGE_NAMES
 *
 * Maps backend stageName keys to user-friendly display labels.
 * These are the only stages that will appear in the transaction history.
 */
export const STAGE_NAMES = {
  RACK_ASSIGNED: "Rack Assigned",
  USER_ASSIGNED: "User Assigned",
  RETURN_TO_RACK: "Return to Rack",
  HEALTH_CHECK: "Health Check",
  QUERY: "Query",
  QUERY_RESOLVED: "Query Case - Health Check",
  OUTWARD: "Outward",
  STAMPING: "Stamping",
  STORAGE: "Storage",
};

export const ALLOCATION_ENUMS = {
  UPDATE_RACK_ALLOCATION: "UPDATE_RACK_ALLOCATION",
  ASSIGN_USER: "ASSIGN_USER",
  UPDATE_ASSIGN_USER: "UPDATE_ASSIGN_USER",
  RETURN_TO_RACK: "RETURN_TO_RACK",
};
