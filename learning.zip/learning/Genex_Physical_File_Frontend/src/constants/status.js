/**
 * Status Constants
 *
 * Centralized status values used across the application for records and task progress.
 */

import { ROLES } from "./roles";

export const STATUS = {
  ACTIVE: "Active",
  INACTIVE: "Inactive",
};

export const TASK_STATUS = {
  ALL: "",
  COMPLETED: "COMPLETED",
  PENDING: "PENDING",
  IN_PROCESS: "IN_PROCESS",
  };

export const TASK_STATUS_OPTIONS = [
  { value: TASK_STATUS.ALL, label: "All Statuses" },
  { value: TASK_STATUS.PENDING, label: "Pending" },
  { value: TASK_STATUS.IN_PROCESS, label: "In Process" },
  { value: TASK_STATUS.COMPLETED, label: "Completed" },
];

/** Maximum number of applications that can be assigned to a single rack. */
export const RACK_MAX_APP_COUNT = 45;

/**
 * STAGE_NAMES
 *
 * Maps backend stageName keys to user-friendly display labels.
 * These are the only stages that will appear in the transaction history.
 */

export const STAGE_NAMES = {
  HEALTH_CHECK: "Health Check",
  QUERY: "Query",
  OUTWARD: "Outward",
  STAMPING: "Stamping",
  QUERY_OUTWARD: "Query Outward",
};

export const JOB_STATUS = {
  RetrievalRequestInitiated: "RETRIEVAL REQUEST INITIATED",
  FileReadyForUse: "FILE READY FOR PICK UP",
  FileHandedOverToUser: "FILE HANDED OVER TO USER",
  RefilingRequestedByDepartment: "REFILING REQUESTED BY DEPARTMENT",
  // UnderDepartmentReview: "UNDER DEPARTMENT REVIEW",
  RefilingInitiated: "REFILING INITIATED",
  Close: "CLOSED",
};

export const FILE_TRACKING_STATUS = {
  open: "OPEN",
  Approved: "APPROVED",
  Inprogress: "IN PROGRESS",
  PartiallyReturned: "PARTIALLY RETURNED",
  FullyReturned: "FULLY RETURNED",
  Rejected: "REJECTED",
  Canceled: "CANCELED",
  Closed: "CLOSED",

};



export const RETRIEVAL_STATUS_BY_ROLE = {
  ALL: Object.values(FILE_TRACKING_STATUS),

  [ROLES.DOC_ADMIN]: [
    FILE_TRACKING_STATUS.Approved,
    FILE_TRACKING_STATUS.Inprogress,
    FILE_TRACKING_STATUS.PartiallyReturned,
    FILE_TRACKING_STATUS.FullyReturned,
    FILE_TRACKING_STATUS.Closed,
  ],
};

export const RETRIEVAL_STATUS_OPTIONS_BY_ROLE = {
  ALL: RETRIEVAL_STATUS_BY_ROLE.ALL.map((status) => ({
    value: status,
    label: status,
  })),

  [ROLES.DOC_ADMIN]: RETRIEVAL_STATUS_BY_ROLE[ROLES.DOC_ADMIN].map((status) => ({
    value: status,
    label: status,
  })),
};

export const getRetrievalForRole = (roleName = "") => {
  const statuses =
    RETRIEVAL_STATUS_BY_ROLE[roleName] ||
    RETRIEVAL_STATUS_BY_ROLE.ALL;

  return [
     {
      value: "ALL",
      label: "ALL",
    },
    ...statuses
      .filter((status) => typeof status === "string" && status !== "")
      .map((status) => ({
        value: status,
        label: status,
      })),
  ];
};

export const getRetrievalStatusesForRole = (roleName = "") => {
  return (
    RETRIEVAL_STATUS_BY_ROLE[roleName] ||
    RETRIEVAL_STATUS_BY_ROLE.ALL
  );
};


export const canViewRetrievalStatus = (roleName, status) => {
  const allowedStatuses = getRetrievalStatusesForRole(roleName);

  return allowedStatuses.includes(status);
};



