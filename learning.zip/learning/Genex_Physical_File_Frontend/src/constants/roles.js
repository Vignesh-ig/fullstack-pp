export const ROLES = {
  SUPER_ADMIN: "SUPER_ADMIN_USER",
  ADMIN: "ADMIN_USER",
  CPU_ADMIN: "CPU_ADMIN_USER",
  CPU: "CPU_USER",
  STAMPING_ADMIN: "STAMPING_ADMIN_USER",
  STAMPING_USER: "STAMPING_USER",
  BRANCH_ADMIN: "BRANCH_ADMIN_USER",
  BRANCH: "BRANCH_USER",
  AUDIT: "AUDIT_USER",
  DOC_ADMIN: "DOC_ADMIN_USER",
};

// Common array of admin roles used throughout the application to verify if a user has admin privileges.
export const ADMIN_ROLES = [ROLES.SUPER_ADMIN, ROLES.ADMIN];

export const ROLE_STYLES = {
  SUPER_ADMIN_USER: "badge-role-super-admin",
  ADMIN_USER: "badge-role-admin",
  CPU_ADMIN_USER: "badge-role-cpu-admin",
  CPU_USER: "badge-role-cpu",
  STAMPING_ADMIN_USER: "badge-role-stamping-admin",
  STAMPING_USER: "badge-role-stamping",
  BRANCH_ADMIN_USER: "badge-role-branch-admin",
  BRANCH_USER: "badge-role-branch",
  AUDIT_USER: "badge-role-audit",
  DOC_ADMIN_USER: "badge-role-doc",
};

/**
 * Width overrides for role badges with longer display names.
 * Applied directly as Tailwind classes in RoleBadge — no CSS needed.
 */
export const ROLE_BADGE_WIDTH = {
  SUPER_ADMIN_USER: "w-34",
  CPU_ADMIN_USER: "w-34",
  STAMPING_ADMIN_USER: "w-38",
  BRANCH_ADMIN_USER: "w-34",
};

export const DEFAULT_ROLE_STYLE = "badge-default";

export const JOB_STATUS_STYLES = {
  Open: "job-status-open",
  Closed: "job-status-closed",
  approved: "job-status-approved",
  inprogress: "job-status-inprogress",
  rejected: "job-status-rejected",
  cancelled: "job-status-canceled",
  partiallyReturned: "job-status-partially-returned"
};

export const DEFAULT_JOB_STATUS_STYLE = "job-status-default";

// Side bar menu category
export const MENU_CATEGORIES = ["Master", "Transaction", "Reports"];

// -------------------------------------------------------------------------

// User ID's that have access to perform the operations.
const ALLOWED_OPERATION_USERS = new Set([
  // "sramesh",
  // "cf28962",
  // "cf28948",
]);

/**
 * Checks if an employee code is authorized to perform the operations.
 *
 * @param {string} code - The employee code to verify.
 * @returns {boolean} True if authorized, false otherwise.
 */
export const canPerformOperation = (code) =>
  !!code && ALLOWED_OPERATION_USERS.has(code.trim().toLowerCase());


const RETRIEVAL_EDIT_ROLES = new Set([
  ROLES.DOC_ADMIN,
  ROLES.ADMIN
]);

export const canEditRetrieval = (roleName) =>
  RETRIEVAL_EDIT_ROLES.has(roleName);

