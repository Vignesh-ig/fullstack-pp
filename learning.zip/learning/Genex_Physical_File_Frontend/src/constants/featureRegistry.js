import { lazy } from "react";
import FileRetrievalRequestPage from "../pages/doc-admin/file-retrieval-request/FileRetrievalRequestPage";
import { ROUTES } from "../router/routes";

const DashboardMaster = lazy(
  () => import("../pages/dashboard/DashboardMaster"),
);
const RolesAndPermissions = lazy(
  () => import("../pages/roles-and-permissions/RolesAndPermissions"),
);
const UsersManagement = lazy(() => import("../pages/users/UsersManagement"));
const RackMaster = lazy(() => import("../pages/rack-master/RackMaster"));
const BranchMaster = lazy(() => import("../pages/branch-master/BranchMaster"));
const QueryCategory = lazy(
  () => import("../pages/query-category/QueryCategory"),
);
const StampMaster = lazy(() => import("../pages/stamp-master/StampMaster"));
const StampStackMaster = lazy(
  () => import("../pages/stamp-stack-master/StampStackMaster"),
);
const RackAllocation = lazy(
  () => import("../pages/rack-allocation/RackAllocation"),
);
const UserAllocation = lazy(
  () => import("../pages/user-allocation/UserAllocation"),
);
const ReturnRack = lazy(() => import("../pages/return-rack/ReturnRack"));
const HealthCheckMaster = lazy(
  () => import("../pages/health-check/HealthCheckMaster"),
);
const QueryMaster = lazy(() => import("../pages/query/QueryMaster"));
const NonCriticalQueryMaster = lazy(
  () => import("../pages/non-critical-query/NonCriticalQueryMaster"),
);
const Outward = lazy(() => import("../pages/outward/Outward"));
const Stamping = lazy(() => import("../pages/stamping/Stamping"));
const Storage = lazy(() => import("../pages/storage/Storage"));
const Enquiry = lazy(() => import("../pages/enquiry/Enquiry"));
const ApplicationsUnlock = lazy(
  () => import("../pages/applications-unlock/ApplicationsUnlock"),
);
const Report = lazy(() => import("../pages/report/Report"));

/**
 * FEATURE_REGISTRY
 *
 * Maps backend permission names to their corresponding UI configuration.
 * Each entry drives:
 *  - Navigation bar link generation (label + path)
 *  - Dynamic route creation in AppRoutes.jsx (component)
 *
 * The order defined here dictates the display order in the sidebar menu.
 */

export const FEATURE_REGISTRY = {
  // --- MASTER ---
  DASHBOARD: {
    label: "Dashboard",
    path: ROUTES.FEATURES.DASHBOARD,
    component: DashboardMaster,
    category: "Master",
  },
  ROLES_AND_PERMISSIONS: {
    label: "Roles & Permissions",
    path: ROUTES.FEATURES.MASTER.ROLES_AND_PERMISSIONS.ROOT,
    component: RolesAndPermissions,
    category: "Master",
  },
  USER_MANAGEMENT: {
    label: "User Management",
    path: ROUTES.FEATURES.MASTER.USER_MANAGEMENT.ROOT,
    component: UsersManagement,
    category: "Master",
  },
  RACK_MASTER: {
    label: "Rack Master",
    path: ROUTES.FEATURES.MASTER.RACK_MASTER.ROOT,
    component: RackMaster,
    category: "Master",
  },
  BRANCH_MASTER: {
    label: "Branch Master",
    path: ROUTES.FEATURES.MASTER.BRANCH_MASTER.ROOT,
    component: BranchMaster,
    category: "Master",
  },
  QUERY_CATEGORY: {
    label: "Query Category",
    path: ROUTES.FEATURES.MASTER.QUERY_CATEGORY.ROOT,
    component: QueryCategory,
    category: "Master",
  },
  STAMP_MASTER: {
    label: "Stamp Master",
    path: ROUTES.FEATURES.MASTER.STAMP_MASTER.ROOT,
    component: StampMaster,
    category: "Master",
  },
  STAMP_STACK_MASTER: {
    label: "Stamp Stack Master",
    path: ROUTES.FEATURES.MASTER.STAMP_STACK_MASTER.ROOT,
    component: StampStackMaster,
    category: "Master",
  },

  // --- TRANSACTION ---
  RACK_ALLOCATION: {
    label: "Rack Allocation",
    path: ROUTES.FEATURES.TRANSACTION.RACK_ALLOCATION.ROOT,
    component: RackAllocation,
    category: "Transaction",
  },
  USER_ALLOCATION: {
    label: "User Allocation",
    path: ROUTES.FEATURES.TRANSACTION.USER_ALLOCATION.ROOT,
    component: UserAllocation,
    category: "Transaction",
  },
  RETURN_RACK: {
    label: "Return To Rack",
    path: ROUTES.FEATURES.TRANSACTION.RETURN_RACK,
    component: ReturnRack,
    category: "Transaction",
  },
  HEALTH_CHECK: {
    label: "Health Check",
    path: ROUTES.FEATURES.TRANSACTION.HEALTH_CHECK.ROOT,
    component: HealthCheckMaster,
    category: "Transaction",
  },
  QUERY: {
    label: "Query",
    path: ROUTES.FEATURES.TRANSACTION.QUERY.ROOT,
    component: QueryMaster,
    category: "Transaction",
  },
  NON_CRITICAL_QUERY: {
    label: "Non Critical Query",
    path: ROUTES.FEATURES.TRANSACTION.NON_CRITICAL_QUERY.ROOT,
    component: NonCriticalQueryMaster,
    category: "Transaction",
  },
  OUTWARD: {
    label: "Outward",
    path: ROUTES.FEATURES.TRANSACTION.OUTWARD,
    component: Outward,
    category: "Transaction",
  },
  STAMPING: {
    label: "Stamping Health Check",
    path: ROUTES.FEATURES.TRANSACTION.STAMPING.ROOT,
    component: Stamping,
    category: "Transaction",
  },
  STORAGE: {
    label: "Storage",
    path: ROUTES.FEATURES.TRANSACTION.STORAGE,
    component: Storage,
    category: "Transaction",
  },
  ENQUIRY: {
    label: "Enquiry",
    path: ROUTES.FEATURES.TRANSACTION.ENQUIRY,
    component: Enquiry,
    category: "Transaction",
  },
  APPLICATIONS_UNLOCK: {
    label: "Application Unlock",
    path: ROUTES.FEATURES.TRANSACTION.APPLICATIONS_UNLOCK,
    component: ApplicationsUnlock,
    category: "Transaction",
  },
  DOC_ADMIN_RETERIVAL_REQUEST: {
    label: "Reterival Request",
    path: ROUTES.FEATURES.TRANSACTION.DOC_ADMIN_RETERIVALREQUEST,
    component: FileRetrievalRequestPage,
    category: "Transaction",
  },
  // --- REPORTS ---
  REPORT: {
    label: "Reports",
    path: ROUTES.FEATURES.REPORTS.REPORT,
    component: Report,
    category: "Reports",
  },
};

/**
 * getRegistryPath
 *
 * Resolves a feature's route path.
 * Uses the explicitly defined `entry.path` if present;
 * otherwise auto-derives a kebab-case path from the permission key.
 *
 * @param {string} permName - The permission name key (e.g. "RACK_ALLOCATION").
 * @param {object} entry    - The registry entry object.
 * @returns {string}        - The resolved route path string.
 */
export const getRegistryPath = (permName, entry) =>
  entry.path ?? `/${permName.toLowerCase().replace(/_/g, "-")}`;

/**
 * getFirstPermittedPath
 *
 * Walks FEATURE_REGISTRY in sidebar declaration order and returns the absolute
 * path of the first permission the user holds that has a registered component.
 * Falls back to "/" when no match is found.
 *
 * @param {string[]} permissionNames - Array of permission name strings.
 * @returns {string} Absolute path (e.g. "/master/user-management").
 */

export const getFirstPermittedPath = (permissionNames) => {
  const permSet = new Set(permissionNames);
  for (const [key, entry] of Object.entries(FEATURE_REGISTRY)) {
    if (permSet.has(key) && entry.component) {
      return getRegistryPath(key, entry);
    }
  }
  return "/";
};
