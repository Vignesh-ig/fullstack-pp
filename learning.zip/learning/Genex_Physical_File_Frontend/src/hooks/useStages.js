import { useEffect, useMemo, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useLocation } from "react-router-dom";
import { APP_STAGES } from "../constants/stages";
import { fetchStages } from "../redux/slice/healthCheckSlice";
import { ROUTES } from "../router/routes";

/**
 * useStages
 *
 * Fetches and maps the stage dropdown options.
 *
 * When called with no arguments (default behaviour), the `includeStagesSearch`
 * is automatically derived from the current active page path — this is the
 * original behaviour used by Health Check, Query, Outward, and Stamping pages.
 *
 * When called with an explicit `includeStagesSearch` string, the path-based
 * logic is bypassed and the provided value is used directly. This allows any
 * page (e.g. Reports) to drive stage fetching dynamically without coupling to
 * the router location.
 *
 * @param {string} [includeStagesSearch] - Optional explicit stages to include.
 *   When provided, path detection is skipped. Pass an empty string or omit to
 *   fall back to path-based detection.
 * @returns {{ stageOptions: Array, stagesLoading: boolean }}
 *   stageOptions  — Array of { label, value, rawName } objects.
 *   stagesLoading — true while the API request is in-flight.
 */
const formatLabel = (str) => {
  if (!str) return str;
  return str
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");
};

export const useStages = (includeStagesSearch = "") => {
  const dispatch = useDispatch();
  const location = useLocation();
  const { stages, loading: stagesLoading } = useSelector(
    (state) => state.healthCheck,
  );

  const fetchedRef = useRef(false);

  useEffect(() => {
    // ── Explicit mode: caller provides includeStagesSearch ────────────────
    if (includeStagesSearch) {
      // Re-fetch whenever the caller's value changes
      dispatch(fetchStages({ page: 1, limit: 50, includeStagesSearch }));
      return;
    }

    // ── Path-based mode: derive from current route (original behaviour) ───
    const path = location.pathname;
    if (fetchedRef.current === path) return;
    fetchedRef.current = path;

    let pathInclude = "";
    let shouldFetch = false;

    if (path.includes(ROUTES.FEATURES.TRANSACTION.HEALTH_CHECK.ROOT)) {
      pathInclude = `${APP_STAGES.QUERY},${APP_STAGES.OUTWARD}`;
      shouldFetch = true;
    } else if (path.includes(ROUTES.FEATURES.TRANSACTION.QUERY.ROOT)) {
      pathInclude = APP_STAGES.QUERY_RESOLVED;
      shouldFetch = true;
    } else if (path.includes(ROUTES.FEATURES.TRANSACTION.OUTWARD)) {
      pathInclude = `${APP_STAGES.STAMPING},${APP_STAGES.STORAGE}`;
      shouldFetch = true;
    } else if (path.includes(ROUTES.FEATURES.TRANSACTION.STAMPING.ROOT)) {
      pathInclude = APP_STAGES.STORAGE;
      shouldFetch = true;
    }

    if (shouldFetch) {
      dispatch(
        fetchStages({
          page: 1,
          limit: 10,
          ...(pathInclude && { includeStagesSearch: pathInclude }),
        }),
      );
    }
  }, [dispatch, location.pathname, includeStagesSearch]);

  const stageOptions = useMemo(
    () =>
      stages.map((s) => ({
        label: formatLabel(s.stageName),
        value: s.stageId,
        rawName: s.stageName,
      })),
    [stages],
  );

  return { stageOptions, stagesLoading };
};
