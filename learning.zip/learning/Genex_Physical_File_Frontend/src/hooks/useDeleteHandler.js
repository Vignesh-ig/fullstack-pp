import { useCallback, useState } from "react";
import { useApi } from "./useApi";

/**
 * A generic hook to manage deletion state and API calls.
 * Can be used across any module that requires deleting a record with confirmation.
 *
 * @param {Function} deleteApiFn - The API function to call for deletion.
 * @param {Function} onDelSuccess - Callback function invoked on successful deletion.
 * @returns {Object} State and handler functions for deletion.
 */
export const useDeleteHandler = (deleteApiFn, onDelSuccess) => {
  const [pendingDelete, setPendingDelete] = useState(null);
  const [deletedItemInfo, setDeletedItemInfo] = useState(null);

  const {
    execute: deleteRecord,
    isLoading: isDeleting,
    error: deleteError,
    setError: setDeleteError,
  } = useApi(deleteApiFn);

  const handleDeleteRequest = useCallback((record) => {
    setPendingDelete(record);
  }, []);

  const handleConfirmDelete = useCallback(
    async (idKey) => {
      if (!pendingDelete || isDeleting) return;

      const recordId = pendingDelete[idKey] || pendingDelete.id;
      const { error } = await deleteRecord(recordId);

      if (!error) {
        // Save the deleted item info (like name) to show in success banner
        setDeletedItemInfo(pendingDelete);

        // Auto-clear success banner info after 5 seconds
        setTimeout(() => {
          setDeletedItemInfo(null);
        }, 5000);

        if (onDelSuccess) {
          await onDelSuccess();
        }
      }
      setPendingDelete(null);
    },
    [pendingDelete, isDeleting, deleteRecord, onDelSuccess],
  );

  const handleCancelDelete = useCallback(() => {
    setPendingDelete(null);
    setDeleteError(null);
  }, [setDeleteError]);

  const clearDeleteError = useCallback(() => {
    setDeleteError(null);
  }, [setDeleteError]);

  return {
    pendingDelete,
    deletedItemInfo,
    isDeleting,
    deleteError,
    handleDeleteRequest,
    handleConfirmDelete,
    handleCancelDelete,
    clearDeleteError,
  };
};
