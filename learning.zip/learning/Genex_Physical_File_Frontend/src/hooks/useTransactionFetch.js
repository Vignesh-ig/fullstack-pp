import { useCallback } from "react";
import { useSelector } from "react-redux";
import { getTransactionApi } from "../api/apiConfig";
import { ROLES } from "../constants/roles";
import { useApi } from "./useApi";

/**
 * useTransactionFetch
 *
 * Centralized hook for all GET operations against the /transaction endpoint.
 * Automatically resolves role-based query params from Redux state:
 *   - CPU  user → assignedUser: userId
 *   - BRANCH user → branchUser: userId
 *
 * Returns two modes of fetching:
 *   1. `fetchFn`  — a memoized function compatible with `usePaginatedFetch`.
 *                   Pass it directly as the first argument to `usePaginatedFetch`.
 *   2. `fetchOne` — a direct (non-paginated) async function for search-style
 *                   calls (e.g. Enquiry). Returns { data, error }.
 *
 * NOTE — POST (create transaction) is intentionally NOT included here.
 * NOTE: This hook only handles data fetching. Status updates (POST) are
 * managed by `useTransactionSubmit`. Keeping GET and POST concerns separate is the
 * cleanest way to share logic across all these different pages.
 *
 * @param {Object}  [config={}]                   - Configuration object.
 * @param {string}  [config.stage]                - Stage value to filter by (from APP_STAGES).
 * @param {string}  [config.stageParamName="stage"] - The API query-param key for stage.
 *                                                   Change this (or the default) to rename
 *                                                   the param globally without touching every caller.
 * @param {boolean} [config.applyRoleParams=true] - Whether to auto-inject role-based params.
 * @param {Object}  [config.extraParams={}]       - Additional static params (e.g. isLocked).
 * @returns {{
 *   fetchFn: Function,
 *   fetchOne: Function,
 *   isFetching: boolean,
 *   fetchError: string|null,
 *   setFetchError: Function
 * }}
 */
const useTransactionFetch = ({
  stage,
  stageParamName = "stages",
  applyRoleParams = true,
  extraParams = {},
} = {}) => {
  const { roleName, userId } = useSelector((state) => state.user);

  /**
   * Resolves the role-based query params.
   * CPU    → assignedUser (only files assigned to that user)
   * BRANCH → branchUser  (only branch-level files)
   */
  const resolveRoleParams = useCallback(() => {
    if (!applyRoleParams) return {};
    const params = {};
    if (roleName === ROLES.CPU) params.assignedUser = userId;
    if (roleName === ROLES.BRANCH) params.branchUser = userId;
    return params;
  }, [roleName, userId, applyRoleParams]);

  /**
   * fetchFn — compatible with usePaginatedFetch.
   * usePaginatedFetch injects { page, limit, [searchParamName]: value }.
   * This merges stage + role params on top before calling the API.
   *
   * @param {Object} paginatedParams - Params injected by usePaginatedFetch
   * @returns {Promise} API response
   */
  const fetchFn = useCallback(
    async (paginatedParams) => {
      return getTransactionApi({
        ...paginatedParams,
        ...(stage ? { [stageParamName]: stage } : {}),
        ...resolveRoleParams(),
        ...extraParams,
      });
    },
    // Stage, stageParamName and resolveRoleParams are stable; extraParams serialised to avoid
    // object-reference churn triggering unnecessary re-fetches.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [stage, stageParamName, resolveRoleParams, JSON.stringify(extraParams)],
  );

  // Direct (non-paginated) API wrapper for search-style pages (e.g. Enquiry).
  const {
    execute: _fetchDirect,
    isLoading: isFetching,
    error: fetchError,
    setError: setFetchError,
  } = useApi(getTransactionApi);

  /**
   * fetchOne — direct non-paginated GET call.
   * Merges stage + role params + extraParams + caller overrides.
   *
   * @param {Object} [callParams={}] - Caller-specific overrides (e.g. { appNoOrAggNo })
   * @returns {Promise<{ data, error }>}
   */
  const fetchOne = useCallback(
    async (callParams = {}) => {
      return _fetchDirect({
        ...(stage ? { [stageParamName]: stage } : {}),
        ...resolveRoleParams(),
        ...extraParams,
        ...callParams,
      });
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      _fetchDirect,
      stage,
      stageParamName,
      resolveRoleParams,
      JSON.stringify(extraParams),
    ],
  );

  return {
    fetchFn,
    fetchOne,
    isFetching,
    fetchError,
    setFetchError,
  };
};

export default useTransactionFetch;
