import { useEffect, useMemo, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useLocation } from "react-router-dom";
import { DECISION_UPDATE_STAGES } from "../constants/stages";
import { fetchQueries } from "../redux/slice/healthCheckSlice";
import { ROUTES } from "../router/routes";

/**
 * useQueries
 *
 * Fetches and maps the query dropdown options.
 * Passes `excludeStatusSearch` or `includeStatusSearch` based on the active path.
 *
 * @returns {{ queryOptions: Array }} Array of { label, value, rawName } objects.
 */
const formatLabel = (str) => {
  if (!str) return str;
  return str
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");
};

export const useQueries = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const { queries } = useSelector((state) => state.healthCheck);

  const fetchedRef = useRef(false);

  useEffect(() => {
    const path = location.pathname;
    if (fetchedRef.current === path) return;
    fetchedRef.current = path;

    let params = { page: 1, limit: 10 };
    let shouldFetch = false;

    if (path.includes(ROUTES.FEATURES.TRANSACTION.HEALTH_CHECK.ROOT)) {
      params.excludeStatusSearch = DECISION_UPDATE_STAGES.QUERY_RESOLVED;
      shouldFetch = true;
    } else if (path.includes(ROUTES.FEATURES.TRANSACTION.QUERY.ROOT)) {
      params.includeStatusSearch = DECISION_UPDATE_STAGES.QUERY_RESOLVED;
      shouldFetch = true;
    } else if (
      path.includes(ROUTES.FEATURES.TRANSACTION.NON_CRITICAL_QUERY.ROOT)
    ) {
      params.includeStatusSearch = DECISION_UPDATE_STAGES.COMPLETED;
      shouldFetch = true;
    }

    if (shouldFetch) {
      dispatch(fetchQueries(params));
    }
  }, [dispatch, location.pathname]);

  const queryOptions = useMemo(
    () =>
      queries.map((q) => ({
        label: formatLabel(q.queryName),
        value: q.queriesId,
        rawName: q.queryName,
      })),
    [queries],
  );

  return { queryOptions };
};
