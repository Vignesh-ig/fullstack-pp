import { useEffect, useRef, useState } from "react";
import { getFileTypesApi } from "../../api/apiConfig";

/**
 * useFileTypes
 *
 * Fetches all file types once (page=1, limit=100) and returns
 * formatted options for a SelectField.
 */
export const useFileTypes = () => {
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const fetched = useRef(false);

  useEffect(() => {
    if (fetched.current) return;
    fetched.current = true;

    requestAnimationFrame(() => {
      setLoading(true);
    });
    
    getFileTypesApi({ page: 1, limit: 100 })
      .then((res) => {
        const items = res?.data?.data ?? [];
        setOptions(
          items.map((ft) => ({
            value: ft.fileTypeId,
            label: ft.fileTypeName,
          })),
        );
      })
      .catch((err) => {
        setError(err?.message ?? "Failed to load file types");
      })
      .finally(() => setLoading(false));
  }, []);

  return { options, loading, error };
};
