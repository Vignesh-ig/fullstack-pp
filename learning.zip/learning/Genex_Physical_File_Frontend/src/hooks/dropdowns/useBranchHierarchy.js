import { useCallback, useEffect, useState } from "react";
import {
  getBranchAreasApi,
  getBranchByAreaApi,
  getBranchRegionsApi,
  getBranchZonesApi,
} from "../../api/apiConfig";

/**
 * useBranchHierarchy
 *
 * Manages cascading Zone → Region → Area → Branch dropdown state.
 * Each level is fetched from the API only when its parent is selected.
 * Resetting a parent clears all downstream selections and options.
 *
 * @param {boolean} [enabled=false] - Activates fetching; pass true when the
 *   BRANCH_USER role is selected so zones are loaded eagerly.
 */
export const useBranchHierarchy = (enabled = false) => {
  // ── Zone ──────────────────────────────────────────────────────────────────
  const [zoneOptions, setZoneOptions] = useState([]);
  const [zoneLoading, setZoneLoading] = useState(false);
  const [zoneError, setZoneError] = useState(null);
  const [selectedZone, setSelectedZone] = useState("");

  // ── Region ────────────────────────────────────────────────────────────────
  const [regionOptions, setRegionOptions] = useState([]);
  const [regionLoading, setRegionLoading] = useState(false);
  const [regionError, setRegionError] = useState(null);
  const [selectedRegion, setSelectedRegion] = useState("");

  // ── Area ──────────────────────────────────────────────────────────────────
  const [areaOptions, setAreaOptions] = useState([]);
  const [areaLoading, setAreaLoading] = useState(false);
  const [areaError, setAreaError] = useState(null);
  const [selectedArea, setSelectedArea] = useState("");

  // ── Branch (passed to SelectFieldWithCheckbox) ────────────────────────────
  const [branchOptions, setBranchOptions] = useState([]);
  const [branchLoading, setBranchLoading] = useState(false);
  const [branchError, setBranchError] = useState(null);

  // ── Fetch zones on mount (when enabled) ───────────────────────────────────
  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;

    const fetchZones = async () => {
      setZoneLoading(true);
      setZoneError(null);
      try {
        const res = await getBranchZonesApi();
        if (cancelled) return;
        const items = res?.data ?? [];
        setZoneOptions(items.map((z) => ({ value: z.zoneId, label: z.name })));
      } catch (err) {
        if (cancelled) return;
        setZoneError(
          err?.response?.data?.message ??
            err?.message ??
            "Failed to load zones",
        );
      } finally {
        if (!cancelled) setZoneLoading(false);
      }
    };

    fetchZones();

    return () => {
      cancelled = true;
    };
  }, [enabled]);

  // ── Fetch regions when zone changes ───────────────────────────────────────
  const handleZoneChange = useCallback((zoneId) => {
    setSelectedZone(zoneId);
    // Clear downstream
    setSelectedRegion("");
    setRegionOptions([]);
    setRegionError(null);
    setSelectedArea("");
    setAreaOptions([]);
    setAreaError(null);
    setBranchOptions([]);
    setBranchError(null);

    if (!zoneId) return;

    setRegionLoading(true);
    getBranchRegionsApi(zoneId)
      .then((res) => {
        const items = res?.data ?? [];
        setRegionOptions(
          items.map((r) => ({ value: r.regionId, label: r.name })),
        );
      })
      .catch((err) => {
        setRegionError(
          err?.response?.data?.message ??
            err?.message ??
            "Failed to load regions",
        );
      })
      .finally(() => setRegionLoading(false));
  }, []);

  // ── Fetch areas when region changes ───────────────────────────────────────
  const handleRegionChange = useCallback((regionId) => {
    setSelectedRegion(regionId);
    // Clear downstream
    setSelectedArea("");
    setAreaOptions([]);
    setAreaError(null);
    setBranchOptions([]);
    setBranchError(null);

    if (!regionId) return;

    setAreaLoading(true);
    getBranchAreasApi(regionId)
      .then((res) => {
        const items = res?.data ?? [];
        setAreaOptions(items.map((a) => ({ value: a.areaId, label: a.name })));
      })
      .catch((err) => {
        setAreaError(
          err?.response?.data?.message ??
            err?.message ??
            "Failed to load areas",
        );
      })
      .finally(() => setAreaLoading(false));
  }, []);

  // ── Fetch branches when area changes ──────────────────────────────────────
  const handleAreaChange = useCallback((areaId) => {
    setSelectedArea(areaId);
    // Clear downstream
    setBranchOptions([]);
    setBranchError(null);

    if (!areaId) return;

    setBranchLoading(true);
    getBranchByAreaApi(areaId)
      .then((res) => {
        const items = res?.data ?? [];
        setBranchOptions(
          items.map((b) => ({ value: b.branchId, label: b.branchDesc })),
        );
      })
      .catch((err) => {
        setBranchError(
          err?.response?.data?.message ??
            err?.message ??
            "Failed to load branches",
        );
      })
      .finally(() => setBranchLoading(false));
  }, []);

  // ── Reset entire hierarchy ─────────────────────────────────────────────────
  const resetHierarchy = useCallback(() => {
    setSelectedZone("");
    setSelectedRegion("");
    setSelectedArea("");
    setRegionOptions([]);
    setAreaOptions([]);
    setBranchOptions([]);
    setRegionError(null);
    setAreaError(null);
    setBranchError(null);
  }, []);

  return {
    // Zone
    zoneOptions,
    zoneLoading,
    zoneError,
    selectedZone,
    handleZoneChange,
    // Region
    regionOptions,
    regionLoading,
    regionError,
    selectedRegion,
    handleRegionChange,
    // Area
    areaOptions,
    areaLoading,
    areaError,
    selectedArea,
    handleAreaChange,
    // Branch
    branchOptions,
    branchLoading,
    branchError,
    // Helpers
    resetHierarchy,
  };
};
