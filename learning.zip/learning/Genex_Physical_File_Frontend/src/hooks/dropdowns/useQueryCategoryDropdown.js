import { useEffect, useState } from "react";
import { getQueryCategoriesApi } from "../../api/apiConfig";

/**
 * A custom hook to fetch unique query category names for dropdowns.
 * Calls /queryCategory?page=1&limit=500&queryCategoryName=UNIQUE to get distinct category names.
 *
 * @returns {Object} An object containing categoryOptions, categoriesLoading, and categoriesError.
 * @returns {Array} returns.categoryOptions - Array of { label, value } objects for SelectField.
 * @returns {boolean} returns.categoriesLoading - Whether the fetch is in progress.
 * @returns {string|null} returns.categoriesError - Error message, if any.
 */
export const useQueryCategoryDropdown = () => {
  const [categoryOptions, setCategoryOptions] = useState([]);
  const [categoriesLoading, setCategoriesLoading] = useState(false);
  const [categoriesError, setCategoriesError] = useState(null);

  useEffect(() => {
    let isMounted = true;
    setCategoriesLoading(true);
    setCategoriesError(null);

    getQueryCategoriesApi({ page: 1, limit: 500, queryCategoryName: "UNIQUE" })
      .then((res) => {
        if (!isMounted) return;
        const list = res?.data?.data || res?.data || [];
        setCategoryOptions(
          list.map((item) => ({
            label: item.queryCategoryName,
            value: item.queryCategoryName,
          })),
        );
      })
      .catch((err) => {
        if (isMounted)
          setCategoriesError(err.message || "Failed to fetch categories");
      })
      .finally(() => {
        if (isMounted) setCategoriesLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  return { categoryOptions, categoriesLoading, categoriesError };
};
