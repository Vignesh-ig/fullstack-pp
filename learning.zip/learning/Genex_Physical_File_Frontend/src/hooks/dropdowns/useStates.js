import { useEffect, useRef, useState } from "react";
import { getStatesApi } from "../../api/apiConfig";
import { toTitleCase } from "../../utils/utils";

/**
 * Custom hook to fetch states for dropdown options.
 * It formats the options to have { value: "STATE_DESC", label: "State Desc" }
 */
export const useStates = () => {
  const [stateOptions, setStateOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchedStates = useRef(false);

  useEffect(() => {
    if (fetchedStates.current) return;
    fetchedStates.current = true;

    const fetchStates = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await getStatesApi();
        if (response.data) {
          const options = response.data.map((state) => ({
            value: state.stateDesc, // Use exact capital value as returned for submission
            label: toTitleCase(state.stateDesc), // Title case for UI display
          }));
          
          setStateOptions(options);
        }
      } catch (err) {
        console.error("Error fetching states:", err);
        setError("Failed to fetch states");
        // Reset ref on error to allow retry if needed
        fetchedStates.current = false;
      } finally {
        setLoading(false);
      }
    };

    fetchStates();
  }, []);

  return { stateOptions, loading, error };
};
