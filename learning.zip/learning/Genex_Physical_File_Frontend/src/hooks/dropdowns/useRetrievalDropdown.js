import { useEffect, useState } from "react";
import { getRacksApi } from "../../api/apiConfig";

/**
 * useRetrievalDropdown
 *
 * Fetches all unique vault names from the racks list to populate a vault dropdown filter.
 *
 * @param {boolean} [enabled=false] - Whether to fetch vault options.
 * @param {boolean} [distinctVaultName=true] - Whether to fetch distinct vault names.
 */
export const useRetrievalDropdown = (enabled = false, distinctVaultName = true) => {
  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!enabled) return;

    const fetchVaults = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await getRacksApi({
          page: 1,
          limit: 10,
          ...(distinctVaultName ? { distinctVaultName: true } : {}),
        });
        const items = Array.isArray(res?.data) ? res.data : (res?.data?.data ?? []);
        const uniqueVaults = Array.from(
          new Set(
            items.map((r) => (typeof r === "string" ? r : r.vaultName)).filter(Boolean)
          ),
        ).sort();

        setOptions(
          uniqueVaults.map((vault) => ({
            value: vault,
            label: vault,
          })),
        );
      } catch (err) {
        setError(
          err?.response?.data?.message ??
            err?.message ??
            "Failed to load vaults",
        );
      } finally {
        setLoading(false);
      }
    };

    fetchVaults();
  }, [enabled, distinctVaultName]);

  return { options, loading, error };
};
