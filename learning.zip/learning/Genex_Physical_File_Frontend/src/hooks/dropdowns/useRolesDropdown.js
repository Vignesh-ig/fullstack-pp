import { useEffect, useState } from "react";
import { getRolesApi } from "../../api/apiConfig";

/**
 * A custom hook to fetch and manage roles for dropdowns.
 *
 * @param {Object} options - Options for fetching roles.
 * @param {boolean} options.formatForSelect - If true, formats the data with label/value for SelectField.
 * @returns {Object} An object containing the roles options, loading state, and error.
 */
export const useRolesDropdown = ({ formatForSelect = true } = {}) => {
  const [roleOptions, setRoleOptions] = useState([]);
  const [rolesLoading, setRolesLoading] = useState(false);
  const [rolesError, setRolesError] = useState(null);

  useEffect(() => {
    let isMounted = true;
    setRolesLoading(true);
    setRolesError(null);

    getRolesApi({ limit: 100 })
      .then((res) => {
        if (!isMounted) return;
        const list = res?.data?.data || res?.data || [];

        if (formatForSelect) {
          setRoleOptions(
            list.map((r) => ({
              label: r.roleName.replace(/_/g, " "),
              value: r.roleId,
              roleName: r.roleName,
            })),
          );
        } else {
          setRoleOptions(list);
        }
      })
      .catch((err) => {
        if (isMounted) setRolesError(err.message || "Failed to fetch roles");
      })
      .finally(() => {
        if (isMounted) setRolesLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [formatForSelect]);

  return { roleOptions, rolesLoading, rolesError };
};
