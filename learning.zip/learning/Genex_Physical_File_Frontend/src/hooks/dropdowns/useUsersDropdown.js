import { useCallback, useEffect, useRef, useState } from "react";
import { getUsersApi } from "../../api/apiConfig";
import { ROLES } from "../../constants/roles";
import { useDebounce } from "../useDebounce";

/**
 * useUsersDropdown
 *
 * Paginated, searchable user fetching.
 * Returns options ready for SearchableSelectField or FilterSelectField.
 *
 * @param {boolean} enabled - Whether to trigger the fetch.
 * @param {string} searchTerm - The search term for users.
 * @param {string} searchByRole - Comma-separated role filter.
 */

export const useUsersDropdown = (
  enabled = false,
  searchTerm = "",
  searchByRole = `${ROLES.SUPER_ADMIN},${ROLES.ADMIN},${ROLES.CPU},${ROLES.CPU_ADMIN}`,
) => {
  const [options, setOptions] = useState([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const debouncedSearch = useDebounce(searchTerm, 500);

  const fetchedKeys = useRef(new Set());
  const initialFetchDone = useRef(false);

  const fetchPage = useCallback(
    async (targetPage, search) => {
      const key = `${targetPage}::${search}::${searchByRole}`;
      if (fetchedKeys.current.has(key)) return;
      fetchedKeys.current.add(key);

      setLoading(true);
      setError(null);
      try {
        const res = await getUsersApi({
          page: targetPage,
          limit: 100,
          ...(searchByRole ? { searchByRole } : {}),
          ...(search ? { searchByName: search } : {}),
        });

        const pagination = res?.data;
        const items = pagination?.data ?? [];

        setOptions((prev) => {
          const existingIds = new Set(prev.map((o) => o.value));
          const newItems = items
            .map((u) => ({
              value: u.userId,
              label: `${u.userName ?? u.userEmployeeCode} (${u.userEmployeeCode})`,
              sublabel: u.userEmail,
            }))
            .filter((item) => !existingIds.has(item.value));
          return [...prev, ...newItems];
        });

        setHasMore(pagination?.hasNextPage ?? false);
        if (pagination?.hasNextPage) {
          setPage(targetPage + 1);
        }
      } catch (err) {
        fetchedKeys.current.delete(key);
        setError(
          err?.response?.data?.message ??
            err?.message ??
            "Failed to load users",
        );
      } finally {
        setLoading(false);
      }
    },
    [searchByRole],
  );

  useEffect(() => {
    if (!enabled || initialFetchDone.current) return;
    initialFetchDone.current = true;
    fetchPage(1, debouncedSearch);
  }, [enabled]); // eslint-disable-line react-hooks/exhaustive-deps

  const prevSearch = useRef(debouncedSearch);
  useEffect(() => {
    if (!enabled || prevSearch.current === debouncedSearch) return;
    prevSearch.current = debouncedSearch;

    setOptions([]);
    setPage(1);
    setHasMore(true);
    setError(null);
    fetchedKeys.current.clear();
    fetchPage(1, debouncedSearch);
  }, [debouncedSearch, enabled, fetchPage]);

  const prevEnabled = useRef(enabled);
  useEffect(() => {
    if (prevEnabled.current === true && enabled === false) {
      setOptions([]);
      setPage(1);
      setHasMore(true);
      setError(null);
      fetchedKeys.current.clear();
      initialFetchDone.current = false;
    }
    prevEnabled.current = enabled;
  }, [enabled]);

  return { options, page, hasMore, loading, error, fetchPage };
};
