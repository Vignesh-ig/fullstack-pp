import { useCallback, useEffect, useRef, useState } from "react";
import { getRacksApi } from "../../api/apiConfig";
import { useDebounce } from "../useDebounce";

/** Maximum number of applications that can be assigned to a single rack. */
export const RACK_MAX_APP_COUNT = 45;

/**
 * useRackDropdown
 *
 * Paginated, searchable rack fetching for the allocation form.
 *
 * @param {boolean} enabled             - Whether to activate this hook.
 * @param {string}  searchTerm          - The search term for racks.
 * @param {boolean} showPositionInLabel - Whether to show position in label.
 * @param {boolean} disableIfFull       - Whether to disable the rack if it is full.
 * @param {string}  vaultName           - Filter by vault name.
 * @param {boolean} showFullInLabel     - Whether to append "Rack is full" to option labels.
 */

export const useRackDropdown = (
  enabled = false,
  searchTerm = "",
  showPositionInLabel = false,
  disableIfFull = true,
  vaultName = "",
  showFullInLabel = true,
  showSublabel = false,
) => {
  const [options, setOptions] = useState([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [totalItems, setTotalItems] = useState(null);

  const debouncedSearch = useDebounce(searchTerm, 500);

  const fetchedKeys = useRef(new Set());

  const fetchPage = useCallback(
    async (targetPage, search) => {
      const key = `${targetPage}::${search}::${vaultName}`;
      if (fetchedKeys.current.has(key)) return;
      fetchedKeys.current.add(key);

      setLoading(true);
      setError(null);
      try {
        const res = await getRacksApi({
          page: targetPage,
          limit: 10,
          ...(search ? { searchByRackName: search } : {}),
          ...(vaultName ? { searchByVaultName: vaultName } : {}),
        });
        const pagination = res?.data;
        const items = pagination?.data ?? [];

        setOptions((prev) => {
          const existingIds = new Set(prev.map((o) => o.value));
          const newItems = items
            .map((r) => {
              const isFull = (r.rackAppCount ?? 0) >= RACK_MAX_APP_COUNT;
              const showFull = isFull && showFullInLabel;
              return {
                value: r.rackId,
                label: showFull
                  ? `Rack Name: ${r.rackName} - Self: ${r.rackPosition} - Rack is full`
                  : showPositionInLabel
                    ? `Rack Name: ${r.rackName} - Self: ${r.rackPosition}`
                    : `Rack Name: ${r.rackName}`,
                sublabel: showSublabel ? `App count: ${r.rackAppCount ?? 0}` :  `Self: ${r.rackPosition} | App count: ${r.rackAppCount ?? 0}`,
                rackAppCount: r.rackAppCount,
                rackName: r.rackName,
                rackPosition: r.rackPosition,
                disabled: disableIfFull ? isFull : false,
              };
            })
            .filter((item) => !existingIds.has(item.value));
          return [...prev, ...newItems];
        });

        setTotalItems(pagination?.totalItems ?? null);
        setHasMore(pagination?.hasNextPage ?? false);
        if (pagination?.hasNextPage) {
          setPage(targetPage + 1);
        }
      } catch (err) {
        fetchedKeys.current.delete(key);
        setError(
          err?.response?.data?.message ??
            err?.message ??
            "Failed to load racks",
        );
      } finally {
        setLoading(false);
      }
    },
    [vaultName, showPositionInLabel, disableIfFull, showFullInLabel, showSublabel],
  );

  const prevState = useRef({
    enabled: false,
    debouncedSearch: "",
    vaultName: "",
    isInitial: true,
  });

  useEffect(() => {
    const prev = prevState.current;

    // Case 1: Disabled transition (turned off)
    if (prev.enabled && !enabled) {
      setOptions([]);
      setPage(1);
      setHasMore(true);
      setTotalItems(null);
      setError(null);
      fetchedKeys.current.clear();
    }

    // Case 2: Turned on, or values changed while enabled
    if (enabled) {
      const searchChanged =
        !prev.isInitial && prev.debouncedSearch !== debouncedSearch;
      const vaultChanged = !prev.isInitial && prev.vaultName !== vaultName;
      const justEnabled = !prev.enabled;
      const shouldFetch =
        prev.isInitial || justEnabled || searchChanged || vaultChanged;

      if (shouldFetch) {
        setOptions([]);
        setPage(1);
        setHasMore(true);
        setTotalItems(null);
        setError(null);
        fetchedKeys.current.clear();
        fetchPage(1, debouncedSearch);
      }
    }

    prevState.current = {
      enabled,
      debouncedSearch,
      vaultName,
      isInitial: false,
    };
  }, [enabled, debouncedSearch, vaultName, fetchPage]);

  return { options, page, hasMore, loading, error, totalItems, fetchPage };
};
