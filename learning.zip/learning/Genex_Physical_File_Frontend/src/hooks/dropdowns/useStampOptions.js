import { useEffect, useRef, useState } from "react";
import {
  getStampDenominationsApi,
  getStampTypesApi,
} from "../../api/apiConfig";
import { STAMP_TYPE_LABELS } from "../../constants/stampingConstants";
import { toTitleCase } from "../../utils/utils";

/**
 * useStampOptions
 *
 * Fetches stamp type options and denomination options conditionally.
 * Normalises raw API field names to `stampTypeId` and `stampDenominationId`.
 *
 * @param {object} options
 * @param {boolean} [options.fetchTypes=true] - Whether to fetch stamp types.
 * @param {boolean} [options.fetchDenominations=true] - Whether to fetch stamp denominations.
 */
export const useStampOptions = ({
  fetchTypes = true,
  fetchDenominations = true,
} = {}) => {
  const [stampTypeOptions, setStampTypeOptions] = useState([]);
  const [stampDenominationOptions, setStampDenominationOptions] = useState([]);
  const [rawTypes, setRawTypes] = useState([]);
  const [rawDenos, setRawDenos] = useState([]);
  const [loadingTypes, setLoadingTypes] = useState(false);
  const [loadingDenos, setLoadingDenos] = useState(false);
  const [error, setError] = useState(null);

  const fetchedTypes = useRef(false);
  const fetchedDenos = useRef(false);

  // ── Fetch Stamp Types lazily ──────────────────────────────────────────────
  useEffect(() => {
    if (!fetchTypes || fetchedTypes.current) return;
    fetchedTypes.current = true;

    setLoadingTypes(true);
    getStampTypesApi({ page: 1, limit: 4 })
      .then((typeRes) => {
        if (typeRes?.data?.data) {
          const types = typeRes.data.data;

          setRawTypes(
            types.map((item) => ({
              stampTypeId: item.stampTypeMasterId,
              stampTypeName: item.stampTypeName,
            })),
          );

          setStampTypeOptions(
            types.map((item) => {
              // Use STAMP_TYPE_LABELS if available, else fallback to formatted string
              const label =
                STAMP_TYPE_LABELS[item.stampTypeName] ||
                toTitleCase(item.stampTypeName);
              return { value: item.stampTypeName, label };
            }),
          );
        }
      })
      .catch((err) => {
        setError(err?.message ?? "Failed to load stamp types");
        fetchedTypes.current = false;
      })
      .finally(() => setLoadingTypes(false));
  }, [fetchTypes]);

  // ── Fetch Stamp Denominations lazily ────────────────────────────────────────
  useEffect(() => {
    if (!fetchDenominations || fetchedDenos.current) return;
    fetchedDenos.current = true;

    setLoadingDenos(true);
    getStampDenominationsApi({ page: 1, limit: 10 })
      .then((denoRes) => {
        if (denoRes?.data?.data) {
          const denos = denoRes.data.data;

          setRawDenos(
            denos.map((item) => ({
              stampDenominationId: item.stampDenominationMasterId,
              stampDenominationNo: item.stampDenominationNo,
            })),
          );

          setStampDenominationOptions(
            denos.map((item) => ({
              value: item.stampDenominationNo.toString(),
              label: `₹ ${item.stampDenominationNo}`,
            })),
          );
        }
      })
      .catch((err) => {
        setError(err?.message ?? "Failed to load stamp denominations");
        fetchedDenos.current = false;
      })
      .finally(() => setLoadingDenos(false));
  }, [fetchDenominations]);

  return {
    stampTypeOptions,
    stampDenominationOptions,
    rawTypes,
    rawDenos,
    loading: loadingTypes || loadingDenos,
    error,
  };
};
