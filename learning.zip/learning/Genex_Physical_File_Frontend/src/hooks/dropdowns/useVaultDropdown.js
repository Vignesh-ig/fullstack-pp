import { useEffect, useState } from "react";

/**
 * useVaultDropdown
 *
 * Fetches all unique vault names from the racks list to populate a vault dropdown filter.
 *
 * @param {boolean} [enabled=false] - Whether to fetch vault options.
 */
export const DEFAULT_VAULT_ID = "4771e1f0-dc19-428b-b857-056b944d487b";
export const DEFAULT_VAULT_NAME = "V1";

export const useVaultDropdown = (enabled = false) => {
  const [options] = useState([{ value: DEFAULT_VAULT_NAME, label: DEFAULT_VAULT_NAME, rawName: DEFAULT_VAULT_NAME }]);
  const [loading] = useState(false);
  const [error] = useState(null);

  useEffect(() => {
    // Currently returning static Vault V1. In future we can uncomment below API code to load dynamically.
    /*
    if (!enabled) return;

    const fetchVaults = async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await getVaultsApi({
          page: 1,
          limit: 10,
        });
        const items = Array.isArray(res?.data)
          ? res.data
          : (res?.data?.data ?? []);
        const uniqueVaults = Array.from(
          new Set(
            items
              .map((r) => (typeof r === "string" ? r : r.vaultName))
              .filter(Boolean),
          ),
        ).sort();

        setOptions(
          uniqueVaults.map((vault) => ({
            value: vault,
            label: vault,
          })),
        );
      } catch (err) {
        setError(
          err?.response?.data?.message ??
            err?.message ??
            "Failed to load vaults",
        );
      } finally {
        setLoading(false);
      }
    };

    fetchVaults();
    */
  }, [enabled]);

  return { options, loading, error };
};
