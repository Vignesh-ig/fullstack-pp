import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";

/**
 * usePaginatedFetch
 *
 * Generic hook for paginated, searchable data fetching.
 * Automatically syncs 'page', 'pageSize', and 'search' with URL search params.
 *
 * @param {Function} fetchFn - API function
 * @param {number} defaultPageSize - Initial page size
 * @param {string} searchParamName - Search parameter name
 * @returns {Object} Paginated state and handler methods
 */
const MAX_PAGE_SIZE = 500;

const usePaginatedFetch = (
  fetchFn,
  defaultPageSize = 10,
  searchParamName = "searchByName",
) => {
  const [searchParams, setSearchParams] = useSearchParams();

  // Read from URL (only page and search)
  const urlPage = Math.max(1, parseInt(searchParams.get("page") || "1", 10));
  const urlSearch = searchParams.get("search") || "";
  const [data, setData] = useState([]);
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalItems: 0,
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [page, setPage] = useState(urlPage);
  const [pageSize, setPageSize] = useState(defaultPageSize);
  const [search, setSearch] = useState(urlSearch);

  // debounced copy of search
  const [debouncedSearch, setDebouncedSearch] = useState(urlSearch);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search);
      setPage(1);
    }, 500);

    return () => clearTimeout(timer);
  }, [search]);

  const lastFetchFn = useRef(fetchFn);
  const lastFetchedParams = useRef({ page: 0, search: null, limit: 0 });

  if (lastFetchFn.current !== fetchFn) {
    lastFetchFn.current = fetchFn;
    lastFetchedParams.current = { page: 0, search: null, limit: 0 };
    setPage(1);
  }

  // Sync URL → State when URL changes (back/forward, direct manipulation)
  useEffect(() => {
    setPage(urlPage);
    setSearch(urlSearch);
    setDebouncedSearch(urlSearch); // keep in sync without extra debounce delay
  }, [urlPage, urlSearch]);

  const fetchData = useCallback(
    async (targetPage, targetSearch, targetLimit) => {
      // Prevent duplicate calls
      if (
        lastFetchedParams.current.page === targetPage &&
        lastFetchedParams.current.search === targetSearch &&
        lastFetchedParams.current.limit === targetLimit
      ) {
        return;
      }

      setLoading(true);
      setError(null);

      try {
        const params = {
          page: targetPage,
          limit: targetLimit,
          ...(targetSearch ? { [searchParamName]: targetSearch } : {}),
        };

        const response = await fetchFn(params);

        const payload = response?.data ?? response;
        const totalPages = payload?.totalPages ?? 1;

        // Auto-correct if user goes to invalid high page number
        if (targetPage > totalPages && totalPages > 0) {
          setPage(1);
          return;
        }

        lastFetchedParams.current = {
          page: targetPage,
          search: targetSearch,
          limit: targetLimit,
        };

        setData(payload?.data ?? []);
        setPagination({
          currentPage: payload?.currentPage ?? targetPage,
          totalPages,
          totalItems: payload?.totalItems ?? 0,
        });
      } catch (err) {
        setError(err?.message ?? "Failed to load data");
      } finally {
        setLoading(false);
      }
    },
    [fetchFn, searchParamName],
  );

  // Fetch when page, search, or pageSize changes
  useEffect(() => {
    fetchData(page, debouncedSearch, pageSize);
  }, [page, debouncedSearch, pageSize, fetchData]);

  // Sync state → URL (only page and search)
  useEffect(() => {
    const params = new URLSearchParams();
    params.set("page", page.toString());

    if (debouncedSearch) params.set("search", debouncedSearch);

    setSearchParams(params, { replace: true });
  }, [page, debouncedSearch, setSearchParams]);

  const handleSetPageSize = (newSize) => {
    const validSize = Math.min(Math.max(5, Number(newSize)), MAX_PAGE_SIZE);
    setPageSize(validSize);
    setPage(1);
  };

  const handleSetSearch = (val) => {
    setSearch(val);
  };

  const refetch = () => {
    lastFetchedParams.current = { page: 0, search: null, limit: 0 };
    fetchData(page, debouncedSearch, pageSize);
  };

  return {
    data,
    pagination,
    loading,
    error,
    setError,
    page,
    setPage,
    pageSize,
    setPageSize: handleSetPageSize,
    search, // raw value → bound to the input so it feels instant
    setSearch: handleSetSearch,
    refetch,
  };
};

export default usePaginatedFetch;
