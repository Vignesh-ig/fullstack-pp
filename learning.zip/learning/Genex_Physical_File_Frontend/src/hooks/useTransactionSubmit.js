import { useSelector } from "react-redux";
import { createTransactionApi } from "../api/apiConfig";
import { APP_STAGES, DECISION_UPDATE_STAGES } from "../constants/stages";
import { STAMP_TYPE } from "../constants/stampingConstants";
import { useApi } from "./useApi";

// Resolves queryName/queryId/stageId/stageName based on submission mode.
const resolveQueryAndStage = (
  isHealthCheck,
  isStamping,
  isOutward,
  isNonCriticalQuery,
  data,
  queryOptions,
  stageOptions,
  currentRecord,
) => {
  if (isHealthCheck) {
    const selectedQuery = queryOptions.find(
      (q) => String(q.value) === String(data.decisionUpdate),
    );
    const selectedStage = stageOptions?.find(
      (s) => String(s.value) === String(data.stageId),
    );
    return {
      finalQueryName: selectedQuery?.rawName || "",
      finalQueryId: data.decisionUpdate || null,
      finalStageId: data.stageId || null,
      finalStageName: selectedStage?.rawName || null,
    };
  }

  if (isNonCriticalQuery) {
    const completedQuery = queryOptions?.find(
      (q) => q.rawName === DECISION_UPDATE_STAGES.COMPLETED,
    );
    return {
      finalQueryName: completedQuery
        ? DECISION_UPDATE_STAGES.COMPLETED
        : "COMPLETED",
      finalQueryId: completedQuery?.value || data.decisionUpdate || null,
      finalStageId: currentRecord?.stage?.stageId || data.stageId || null,
      finalStageName: currentRecord?.stage?.stageName || null,
    };
  }

  if (isOutward) {
    const selectedStage = stageOptions?.find(
      (s) => String(s.value) === String(data.stageId),
    );
    return {
      finalQueryName: currentRecord?.query?.queryName || null,
      finalQueryId: currentRecord?.query?.queriesId || null,
      finalStageId: selectedStage?.value || null,
      finalStageName: selectedStage?.rawName || null,
    };
  }

  if (isStamping) {
    const storageStage = stageOptions?.find(
      (s) => s.rawName === APP_STAGES.STORAGE,
    );
    return {
      finalQueryName: null,
      finalQueryId: null,
      finalStageId: storageStage?.value || null,
      finalStageName: storageStage ? APP_STAGES.STORAGE : null,
    };
  }

  const resolvedQuery = queryOptions?.find(
    (q) => q.rawName === DECISION_UPDATE_STAGES.QUERY_RESOLVED,
  );
  const queryResolvedStage = stageOptions?.find(
    (s) => s.rawName === APP_STAGES.QUERY_RESOLVED,
  );
  return {
    finalQueryName: resolvedQuery ? DECISION_UPDATE_STAGES.QUERY_RESOLVED : "",
    finalQueryId: resolvedQuery?.value || null,
    finalStageId: queryResolvedStage?.value || null,
    finalStageName: queryResolvedStage ? APP_STAGES.QUERY_RESOLVED : null,
  };
};

/**
 * Custom hook to handle submitting the health check transaction.
 *
 * @param {Object} currentRecord - Selected record
 * @param {Array} queryOptions - Query options array
 * @param {Array} stageOptions - Stage options array
 * @param {Function} setGlobalError - Error setter
 * @param {Function} handleRecordSaved - Success callback
 * @param {boolean} isHealthCheck - Whether this is Health Check
 * @param {boolean} isStamping - Whether this is Stamping
 * @param {boolean} isOutward - Whether this is Outward
 * @param {boolean} isNonCriticalQuery - Whether this is Non Critical Query
 * @returns {Object} Submit handler and loading state
 */
export const useTransactionSubmit = (
  recordsOrRecord,
  queryOptions,
  stageOptions,
  setGlobalError,
  handleRecordSaved,
  isHealthCheck = false,
  isStamping = false,
  isOutward = false,
  isNonCriticalQuery = false,
) => {
  const { execute, isLoading: isSaving } = useApi(createTransactionApi);
  const { userId: currentUserId } = useSelector((state) => state.user);

  const onSubmit = async (data) => {
    const records = Array.isArray(recordsOrRecord)
      ? recordsOrRecord
      : [recordsOrRecord].filter(Boolean);

    if (records.length === 0) return;

    if (
      !isOutward &&
      !isStamping &&
      (!queryOptions || queryOptions.length === 0)
    ) {
      setGlobalError(
        "Options are still loading. Please wait a moment and try again.",
      );
      return;
    }

    setGlobalError(null);

    const payload = records.map((currentRecord) => {
      const { finalQueryName, finalQueryId, finalStageId, finalStageName } =
        resolveQueryAndStage(
          isHealthCheck,
          isStamping,
          isOutward,
          isNonCriticalQuery,
          data,
          queryOptions,
          stageOptions,
          currentRecord,
        );

      return {
        appNo: currentRecord.appNo || null,
        aggNo: currentRecord.aggNo || null,
        leadId: currentRecord.leadId || null,
        customerName: currentRecord.customerName || null,
        amountFinance: currentRecord.amountFinance || null,
        schemaProduct: currentRecord.schemaProduct || null,
        scheme: currentRecord.scheme || null,
        zone: currentRecord.zone || null,
        state: currentRecord.state || null,
        branchName: currentRecord.branchName || null,
        modelNo: currentRecord.modelNo || null,
        make: currentRecord.make || null,
        cpuBarCode: currentRecord.cpuBarCode || null,
        vBarCode: currentRecord.vbarCode || null,
        boxCode: currentRecord.boxCode || null,
        dmsId: currentRecord.dmsId || null,
        handOffDate: currentRecord.handOffDate || null,
        // fileType is nested in query response ({ fileTypeId, fileTypeName }), flat in health-check
        fileType: isHealthCheck
          ? currentRecord.fileTypeId || null
          : currentRecord.fileType?.fileTypeId || null,
        // rackId is nested in query response ({ rackId, rackName, ... }), flat in health-check
        rackId: isHealthCheck
          ? currentRecord.rackId || null
          : currentRecord.rack?.rackId || null,
        // query response uses transactionId or rackAssignedId
        rackAssignedId: isHealthCheck
          ? currentRecord.rackAssignedId || null
          : currentRecord.transactionsHistory?.[0]?.rackAssignedId ||
            currentRecord.rackAssignedId ||
            null,
        queryName: finalQueryName,
        queryId: finalQueryId,
        stageId: finalStageId,
        stageName: finalStageName,
        vendorId: data.vendorId || null,
        assignedUser: currentRecord.assignedUser?.userId || null,
        currentRemarks:
          data.currentRemarks || currentRecord.currentRemarks || null,
        genexFromBranch: currentRecord.genexFromBranch || null,
        createdBy: currentUserId,
        ...(isHealthCheck && {
          isHealthCheck,
        }),
        ...(!isStamping &&
          !isOutward && {
            missingPodNo: data.missingPodNo || null,
          }),
        // ...(data.queryCategoryId && {
        //   queryCategoryId: data.queryCategoryId,
        // }),

        ...(data.queryCartonBarcode !== undefined && {
          queryCartonBarcode: data.queryCartonBarcode || null,
        }),

        ...(isStamping && {
          stampStackMasterIds: data.stampStackMasterList || [],
          ...(currentRecord?.stampType?.toUpperCase() === STAMP_TYPE.FIXED
            ? {
                discountStampAmount: 0,
                finalStampAmount: data.finalAmount,
              }
            : {
                discountStampAmount: data.stampAmount,
                finalStampAmount: data.finalAmount,
              }),
        }),
      };
    });

    const { error } = await execute(payload);

    if (error) {
      setGlobalError(error);
    } else {
      const selectedQuery = queryOptions?.find(
        (q) => String(q.value) === String(data.decisionUpdate),
      );

      const isQuery =
        !isHealthCheck && !isStamping && !isOutward && !isNonCriticalQuery;

      let successMessage = "Transaction updated successfully";

      if (isHealthCheck) {
        if (selectedQuery?.rawName === DECISION_UPDATE_STAGES.COMPLETED) {
          successMessage = "Health check is completed and moved to Outward";
        } else if (
          selectedQuery?.rawName === DECISION_UPDATE_STAGES.CRITICAL_QUERY
        ) {
          successMessage = "Health check is completed and moved to Query";
        } else if (
          selectedQuery?.rawName === DECISION_UPDATE_STAGES.NON_CRITICAL_QUERY
        ) {
          successMessage =
            "Health check is completed and moved to Non Critical Query and Outward";
        }
      } else if (isOutward) {
        const selectedStage = stageOptions?.find(
          (stage) => String(stage.value) === String(data.stageId),
        );

        if (selectedStage?.rawName === APP_STAGES.STAMPING) {
          successMessage = "Applications moved to Stamping successfully";
        } else if (selectedStage?.rawName === APP_STAGES.STORAGE) {
          successMessage = "Applications moved to Storage successfully";
        }
      } else if (isNonCriticalQuery) {
        successMessage = "Non Critical Query resolved successfully";
      } else if (isQuery) {
        successMessage = "Query resolved successfully and Move to Health Check";
      } else if (isStamping) {
        successMessage = "Stamping completed successfully and Move to Storage";
      }

      handleRecordSaved(successMessage);
    }
  };

  return { onSubmit, isSaving };
};
