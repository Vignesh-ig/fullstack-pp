import { useCallback, useEffect, useMemo, useState } from "react";

/**
 * A generic hook for managing multi-select state, handling individual and global toggles,
 * and robustly caching labels to prevent them from disappearing during pagination or searching.
 *
 * @param {object} params
 * @param {string[]} params.value - Selected values
 * @param {function} params.onChange - Change handler
 * @param {object[]} params.options - Visible options { label, value }
 * @param {object[]} params.selectedOptions - Initial selected options
 * @param {string} params.name - Form field name
 * @returns {Object} State and toggling functions
 */

export const useMultiSelect = ({
  value = [],
  onChange,
  options = [],
  selectedOptions = [],
  name,
  maxSelections,
}) => {
  const safeValue = useMemo(() => (Array.isArray(value) ? value : []), [value]);
  const selectedCount = safeValue.length;

  // ── Cache labels to prevent loss during pagination/search ─────────────────
  // Seed synchronously from selectedOptions so the label is correct on the
  // very first render (avoids the requestAnimationFrame delay causing a blank
  // count / missing branch names during edit-mode initial load).
  const [knownLabels, setKnownLabels] = useState(() => {
    const initial = {};
    (selectedOptions ?? []).forEach((o) => {
      if (o?.value != null) initial[o.value] = o.label;
    });
    return initial;
  });

  // Update cache when new options arrive (e.g., after a dropdown loads)
  useEffect(() => {
    requestAnimationFrame(() => {
      setKnownLabels((prev) => {
        let changed = false;
        const next = { ...prev };
        options.forEach((o) => {
          if (next[o.value] !== o.label) {
            next[o.value] = o.label;
            changed = true;
          }
        });
        return changed ? next : prev;
      });
    });
  }, [options]);

  // Update cache when selectedOptions change (e.g., parent re-computes them)
  useEffect(() => {
    if (selectedOptions) {
      requestAnimationFrame(() => {
        setKnownLabels((prev) => {
          let changed = false;
          const next = { ...prev };
          selectedOptions.forEach((o) => {
            if (next[o.value] !== o.label) {
              next[o.value] = o.label;
              changed = true;
            }
          });
          return changed ? next : prev;
        });
      });
    }
  }, [selectedOptions]);

  // ── Toggling Logic ────────────────────────────────────────────────────────
  const handleToggle = useCallback(
    (optionValue) => {
      const next = safeValue.includes(optionValue)
        ? safeValue.filter((v) => v !== optionValue)
        : [...safeValue, optionValue];
      onChange?.({ target: { name, value: next } });
    },
    [safeValue, onChange, name],
  );

  const isAllLoadedSelected = useMemo(
    () =>
      options.length > 0 &&
      options.every((opt) => safeValue.includes(opt.value)),
    [options, safeValue],
  );

  const handleGlobalToggle = useCallback(() => {
    let next;
    if (isAllLoadedSelected) {
      // Deselect all loaded
      const loadedValues = options.map((o) => o.value);
      next = safeValue.filter((v) => !loadedValues.includes(v));
    } else {
      // Select all up to maxSelections
      next = [...safeValue];
      for (const o of options) {
        if (!next.includes(o.value)) {
          if (maxSelections !== undefined && maxSelections !== null) {
            if (next.length >= maxSelections) break;
          }
          if (!o.disabled) {
            next.push(o.value);
          }
        }
      }
    }
    onChange?.({ target: { name, value: next } });
  }, [isAllLoadedSelected, options, safeValue, onChange, name, maxSelections]);

  // ── Derived Display Data ──────────────────────────────────────────────────
  const selectedLabels = useMemo(() => {
    return safeValue.map((v) => knownLabels[v]).filter(Boolean);
  }, [safeValue, knownLabels]);

  return {
    safeValue,
    selectedCount,
    isAllLoadedSelected,
    handleToggle,
    handleGlobalToggle,
    selectedLabels,
    knownLabels,
  };
};
