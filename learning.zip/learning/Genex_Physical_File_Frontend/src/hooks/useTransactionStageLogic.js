import { useEffect } from "react";
import { APP_STAGES, DECISION_UPDATE_STAGES } from "../constants/stages";

/**
 * Custom hook to encapsulate the logic for automatically selecting
 * the correct Stage based on the selected Decision Update (Query).
 *
 * @param {Function} watch - react-hook-form watch function
 * @param {Function} setValue - react-hook-form setValue function
 * @param {Array} queryOptions - Options array for query/decision dropdown
 * @param {Array} stageOptions - Options array for stage dropdown
 * @param {boolean} isHealthCheck - Whether the current page is Health Check
 * @param {boolean} isNonCriticalQuery - Whether the current page is Non Critical Query
 * @param {Object} currentRecord - The current record data
 * @returns {Object} { isStageDisabled } - whether the stage field should be disabled
 */
export const useTransactionStageLogic = (
  watch,
  setValue,
  queryOptions,
  stageOptions,
  isHealthCheck,
  isNonCriticalQuery = false,
  currentRecord = null,
) => {
  const decisionUpdate = watch("decisionUpdate");

  const selectedQuery = queryOptions.find(
    (q) => String(q.value) === String(decisionUpdate),
  );

  const rawQueryName = selectedQuery?.rawName || "";

  const isStageDisabled =
    isNonCriticalQuery ||
    !isHealthCheck ||
    rawQueryName === DECISION_UPDATE_STAGES.COMPLETED ||
    rawQueryName === DECISION_UPDATE_STAGES.CRITICAL_QUERY ||
    rawQueryName === DECISION_UPDATE_STAGES.NON_CRITICAL_QUERY ||
    (isHealthCheck && !rawQueryName);

  useEffect(() => {
    if (isNonCriticalQuery) {
      // Logic for Non Critical Query page:
      // Decision update defaults to COMPLETED.
      // Stage defaults to the current record's existing stage.
      if (queryOptions.length > 0) {
        const completedOption = queryOptions.find(
          (q) => q.rawName === DECISION_UPDATE_STAGES.COMPLETED,
        );
        if (completedOption) {
          setValue("decisionUpdate", completedOption.value, {
            shouldValidate: true,
          });
        }
      }

      if (currentRecord?.stage?.stageId) {
        setValue("stageId", currentRecord.stage.stageId, {
          shouldValidate: true,
        });
      }
      return;
    }

    if (!isHealthCheck) {
      // Logic for Query page:
      // Decision update defaults to QUERY_RESOLVED.
      // Stage defaults to HEALTH_CHECK (and is disabled).
      if (!decisionUpdate && queryOptions.length > 0) {
        const queryResolvedOption = queryOptions.find(
          (q) => q.rawName === DECISION_UPDATE_STAGES.QUERY_RESOLVED,
        );
        if (queryResolvedOption) {
          setValue("decisionUpdate", queryResolvedOption.value, {
            shouldValidate: true,
          });
        }
      }

      if (rawQueryName === DECISION_UPDATE_STAGES.QUERY_RESOLVED) {
        const healthCheckStage = stageOptions.find(
          (s) => s.rawName === APP_STAGES.QUERY_RESOLVED,
        );
        if (healthCheckStage) {
          setValue("stageId", healthCheckStage.value, { shouldValidate: true });
        }
      }
      return;
    }

    // Logic for Health Check page:
    if (!rawQueryName) {
      setValue("stageId", "", { shouldValidate: true });
      return;
    }

    if (
      rawQueryName === DECISION_UPDATE_STAGES.COMPLETED ||
      rawQueryName === DECISION_UPDATE_STAGES.NON_CRITICAL_QUERY
    ) {
      const outwardStage = stageOptions.find(
        (s) => s.rawName === APP_STAGES.OUTWARD,
      );
      if (outwardStage) {
        setValue("stageId", outwardStage.value, { shouldValidate: true });
      }
    } else if (rawQueryName === DECISION_UPDATE_STAGES.CRITICAL_QUERY) {
      const queryStage = stageOptions.find(
        (s) => s.rawName === APP_STAGES.QUERY,
      );
      if (queryStage) {
        setValue("stageId", queryStage.value, { shouldValidate: true });
      }
    }
  }, [
    rawQueryName,
    stageOptions,
    setValue,
    isHealthCheck,
    isNonCriticalQuery,
    currentRecord,
    decisionUpdate,
    queryOptions,
  ]);

  return { isStageDisabled };
};
