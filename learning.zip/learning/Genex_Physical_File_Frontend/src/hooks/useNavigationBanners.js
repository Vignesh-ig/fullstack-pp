import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";

/**
 * useNavigationBanners
 *
 * Reads navigation state set by detail pages on save or back-without-save,
 * derives banner messages (with optional App No / Agreement No), clears the
 * router state from history to prevent re-display on back/forward navigation,
 * and exposes message state + setters for use in list pages.
 *
 * Expected location.state shape (set by TransactionDetailsPage / StampMasterForm):
 *   { savedSuccess?: boolean, exitWithoutSave?: boolean, appNo?: string, aggNo?: string }
 *
 * @returns {{ successMessage: string|null, setSuccessMessage: Function, warningMessage: string|null, setWarningMessage: Function }}
 */
const useNavigationBanners = () => {
  const location = useLocation();
  const { savedSuccess, exitWithoutSave, appNo, aggNo,successMessage: navigationSuccessMessage, } = location.state || {};

  const recordLabel =
    appNo || aggNo
      ? `(App No: ${appNo || "—"}${aggNo ? ` | Agreement No: ${aggNo}` : ""})`
      : "";

 const [successMessage, setSuccessMessage] = useState(
  navigationSuccessMessage
    ? `${navigationSuccessMessage} ${recordLabel}`.trim()
    : savedSuccess
      ? `Record saved successfully. ${recordLabel}`.trim()
      : null,
);


  const [warningMessage, setWarningMessage] = useState(
    exitWithoutSave
      ? `You left without saving. No changes were recorded. ${recordLabel}`.trim()
      : null,
  );

  // Clear the router state so banners don't reappear on back/forward navigation
  useEffect(() => {
    if (savedSuccess || exitWithoutSave) {
      window.history.replaceState({}, "");
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return { successMessage, setSuccessMessage, warningMessage, setWarningMessage };
};

export default useNavigationBanners;
