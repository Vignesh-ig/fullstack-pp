import { useEffect } from "react";
import { useLocation } from "react-router-dom";

/**
 * usePreventBackNavigation
 *
 * Traps the user in the application by neutralizing the browser's back button.
 * When the user attempts to go back via the browser controls, this hook immediately
 * pushes the current URL back onto the history stack, preventing the navigation.
 */
export const usePreventBackNavigation = () => {
  const location = useLocation();

  useEffect(() => {
    // Push an initial state to establish the trap
    window.history.pushState(null, null, window.location.href);

    const handlePopState = () => {
      // When the user presses back, force the browser to go forward again
      // to the state we just trapped them in.
      window.history.go(1);
    };

    window.addEventListener("popstate", handlePopState);

    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, [location.pathname, location.search]); // Re-establish trap on route change
};
