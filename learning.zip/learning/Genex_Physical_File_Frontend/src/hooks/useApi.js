import { useCallback, useState } from "react";
import { getApiErrorMessage } from "../utils/utils";

/**
 * Global hook to handle API request states (loading, error, success, data).
 *
 * @param {Function} apiFunc - API function to execute
 * @returns {Object} State and execute method
 */

export const useApi = (apiFunc) => {
  const [data, setData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isSuccess, setIsSuccess] = useState(false);

  const execute = useCallback(
    async (...args) => {
      setIsLoading(true);
      setError(null);
      setIsSuccess(false);

      try {
        const response = await apiFunc(...args);
        setData(response);
        setIsSuccess(true);
        return { data: response, error: null };
      } catch (err) {
        const errorMessage = getApiErrorMessage(err);
        setError(errorMessage);
        return { data: null, error: errorMessage };
      } finally {
        setIsLoading(false);
      }
    },
    [apiFunc],
  );

  const reset = useCallback(() => {
    setData(null);
    setIsLoading(false);
    setError(null);
    setIsSuccess(false);
  }, []);

  return { execute, data, isLoading, error, setError, isSuccess, reset };
};
