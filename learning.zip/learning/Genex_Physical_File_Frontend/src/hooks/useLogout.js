import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { logout } from "../redux/slice/userSlice";
import { ROUTES } from "../router/routes";

/**
 * Custom hook to handle user logout logic across the app.
 * Dispatches the logout action and redirects to the login route.
 *
 * @returns {Function} handleLogout function
 */
export const useLogout = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("employeeCode");
    dispatch(logout());
    navigate(ROUTES.AUTH.LOGIN);
  };

  return handleLogout;
};
