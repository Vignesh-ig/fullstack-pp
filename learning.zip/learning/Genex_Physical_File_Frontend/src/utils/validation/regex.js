export const REGEX = {
  EMAIL: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
  PASSWORD: /^.{6,25}$/,
  NAME: /^[A-Za-z.\s]+$/,
  EMPID: /^[A-Za-z0-9]+$/,
  USERNAME: /^[A-Za-z0-9\s]+$/,
  RACK_CODE: /^[A-Za-z0-9-]+$/,
  AGEING_NO: /^[A-Za-z0-9\-_]+$/,
  ALPHANUMERIC: /^[A-Za-z0-9]*$/,
};
