import { z } from "zod";
import { STAMP_TYPE } from "../../constants/stampingConstants";
import { REGEX } from "../validation/regex";

// Login Schema
export const loginSchema = z.object({
  userEmployeeCode: z
    .string()
    .min(2, "Employee code is required")
    .regex(
      REGEX.USERNAME,
      "Employee code must contain only letters, numbers or spaces",
    ),
  password: z
    .string()
    .min(1, "Password is required")
    .regex(REGEX.PASSWORD, "Password must be 6-25 characters"),
});

// User Schema
export const userFormSchema = z
  .object({
    mode: z.enum(["add", "edit"]),
    userName: z
      .string()
      .min(2, "Name must be at least 2 characters")
      .regex(REGEX.NAME, "Name must contain only letters"),
    userEmail: z
      .string()
      .min(1, "Email is required")
      .regex(REGEX.EMAIL, "Enter a valid email address"),
    userEmployeeCode: z
      .string()
      .min(1, "Employee code is required")
      .min(2, "Employee code must be at least 2 characters")
      .regex(
        REGEX.USERNAME,
        "Employee code must contain only letters, numbers or spaces",
      ),
    roleId: z.string().min(1, "Please select a role"),
    isActive: z.boolean(),
    // Branch hierarchy fields — kept optional at object level; conditionally
    // required below via superRefine when the role is BRANCH_USER.
    isBranchUser: z.boolean().optional(),
    selectedZone: z.string().optional(),
    selectedRegion: z.string().optional(),
    selectedArea: z.string().optional(),
    branchIds: z.array(z.string()).optional(),
  })
  .superRefine((data, ctx) => {
    if (!data.isBranchUser) return;

    if (!data.selectedZone) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Zone is required for Branch User",
        path: ["selectedZone"],
      });
    }
    if (!data.selectedRegion) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Region is required for Branch User",
        path: ["selectedRegion"],
      });
    }
    if (!data.selectedArea) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Area is required for Branch User",
        path: ["selectedArea"],
      });
    }
    if (!data.branchIds || data.branchIds.length === 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "At least one branch must be selected",
        path: ["branchIds"],
      });
    }
  });

// Rack Schema
export const rackFormSchema = z.object({
  mode: z.enum(["add", "edit"]),
  vaultName: z.string().min(1, "Vault name is required"),
  rackName: z
    .string()
    .min(1, "Rack name is required")
    .regex(
      REGEX.RACK_CODE,
      "Only letters, numbers, and hyphens (-) are allowed",
    ),
  rackPosition: z
    .string()
    .min(1, "Self is required")
    .regex(
      REGEX.RACK_CODE,
      "Only letters, numbers, and hyphens (-) are allowed",
    ),
  rackStatus: z.boolean(),
});

// Rack Allocation Schema
export const rackAllocationRowSchema = z.object({
  ageingNo: z
    .string()
    .optional()
    .refine(
      (val) => !val || REGEX.AGEING_NO.test(val),
      "Ageing No contains invalid characters",
    ),
  appNo: z.string().optional().nullable(),
  aggNo: z.string().optional().nullable(),
  barcode: z.string().optional().nullable(),
  fileTypeId: z.string().optional().nullable(),
  rackId: z.string().min(1, "Rack Name is required"),
});

export const rackAllocationFormSchema = z
  .array(rackAllocationRowSchema)
  .min(1, "Please add at least one record.");

export const rackAllocationEditSchema = z.object({
  ageingNo: z
    .string()
    .optional()
    .refine(
      (val) => !val || REGEX.AGEING_NO.test(val),
      "Ageing No contains invalid characters",
    ),
  appNo: z.string().optional().nullable(),
  aggNo: z.string().optional().nullable(),
  barcode: z.string().optional().nullable(),
  fileTypeId: z.string().optional().nullable(),
  vaultName: z.string().optional().nullable(),
  rackId: z.string().min(1, "Rack Name is required"),
});

// User Allocation Schema
export const userAllocationRowSchema = z.object({
  assignedUser: z.string().min(1, "Assigned To is required"),
  rackId: z.string().min(1, "Rack Name is required"),
});

export const userAllocationFormSchema = z
  .array(userAllocationRowSchema)
  .min(1, "Please add at least one record.");

export const userAllocationEditSchema = z.object({
  assignedUser: z.string().min(1, "Assigned To is required"),
  vaultName: z.string().optional().nullable(),
  rackId: z.string().optional().nullable(),
});

// // Health Check Transaction Schema
// export const healthCheckTransactionSchema = z.object({
//   decisionUpdate: z.string().min(1, "Decision update is required"),
//   stageId: z.string().min(1, "Stage is required"),

//   currentRemarks: z.string().min(1, "Remarks is required"),
//   missingPodNo: z
//     .string()
//     .max(25, "Query POD No must be at most 25 characters")
//     .regex(REGEX.ALPHANUMERIC, "Query POD No must contain only letters and numbers")
//     .optional()
//     .or(z.literal("")),
//   queryCategoryId: z.string().optional(),
//   querySubCategoryId:z.
  
// });

// Health Check Transaction Schema
export const healthCheckTransactionSchema = z
  .object({
    decisionUpdate: z.string().min(1, "Decision update is required"),
 
    stageId: z.string().min(1, "Stage is required"),
 
    currentRemarks: z.string().optional(),
 
    missingPodNo: z
      .string()
      .max(25, "Query POD No must be at most 25 characters")
      .regex(
        REGEX.ALPHANUMERIC,
        "Query POD No must contain only letters and numbers",
      )
      .optional()
      .or(z.literal("")),
 
    queryCategoryId: z.string().optional(),
  });
 

// Query Transaction Schema
export const queryTransactionSchema = z.object({
  currentRemarks: z.string().min(1, "Remarks is required"),
  missingPodNo: z
    .string()
    .max(25, "Query POD No must be at most 25 characters")
    .regex(REGEX.ALPHANUMERIC, "Query POD No must contain only letters and numbers")
    .optional()
    .or(z.literal("")),
  queryCartonBarcode: z
    .string()
    .max(25, "Carton Barcode must be at most 25 characters")
    .regex(
      REGEX.ALPHANUMERIC,
      "Carton Barcode must contain only letters and numbers",
    )
    .optional()
    .or(z.literal("")),
});

// Non Critical Query Transaction Schema
export const nonCriticalQueryTransactionSchema = z.object({
  currentRemarks: z.string().optional(),
  missingPodNo: z
    .string()
    .max(25, "Query POD No must be at most 25 characters")
    .regex(REGEX.ALPHANUMERIC, "Query POD No must contain only letters and numbers")
    .optional()
    .or(z.literal("")),
  queryCartonBarcode: z
    .string()
    .max(25, "Carton Barcode must be at most 25 characters")
    .regex(
      REGEX.ALPHANUMERIC,
      "Carton Barcode must contain only letters and numbers",
    )
    .optional()
    .or(z.literal("")),
});
//Create Retrieval Request File Schema

export const retrievalRequestFormSchema = (othersIds) =>
  z
    .object({
      mode: z.enum(["add", "edit"]),
      department: z
        .string({
          error: (issue) =>
            issue.input === undefined
              ? "department is required"
              : "department must be a string",
        })
        .min(1, "department is required"),
      // products: z
      //   .string({
      //     error: (issue) =>
      //       issue.input === undefined
      //         ? "products is required"
      //         : "products must be a string",
      //   })
      //   .min(1, "products is required"),

      jobstage: z.string().optional(),
      otherDepartment: z.string().nullable().optional(),

      otherDocument: z.string().nullable().optional(),

      otherRequestType: z.string().nullable().optional(),

      otherDelivery: z.string().nullable().optional(),
      otherPurpose: z.string().nullable().optional(),
      agreementNumber: z.string().optional(),
      // scanLink: z.string().optional(), 
      tat: z.string().optional(),

      
      // tatDate: z
  //       .date({
  //         error: (issue) =>
  //           issue.input === undefined || issue.input === null
  //             ? "Tat date is required"
  //             : "Tat date must be a valid date",
  //       })
  //       .refine((date) => !isNaN(date.getTime()), {
  //         message: "Tat date must be a valid date",
  //       }),

      file: z.any().optional(),
      requestDocument: z
        .string({
          error: (issue) =>
            issue.input === undefined
              ? "document is required"
              : "document must be a string",
        })
        .min(1, "document is required"),

      requestType: z
        .string({
          error: (issue) =>
            issue.input === undefined
              ? "request Type is required"
              : "request Type must be a string",
        })
        .min(1, "request Type is required"),

      document: z
        .array(z.string(), {
          error: (issue) =>
            issue.input === undefined || issue.input === null
              ? "request Document is required"
              : "request Document must be an array",
        })
        .min(1, "request Document is required"),
      location: z
        .string({
          error: (issue) =>
            issue.input === undefined
              ? "location is required"
              : "location must be a string",
        })
        .min(1, "location is required"),

      purpose: z
        .string({
          error: (issue) =>
            issue.input === undefined
              ? "purpose is required"
              : "purpose must be a string",
        })
        .min(1, "purpose is required"),

      selectionType: z.enum(["single", "multiple"]),
    })
    .superRefine((data, ctx) => {
      if (
        data.selectionType === "single" &&
        (!data.agreementNumber || data.agreementNumber.trim() === "")
      ) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["agreementNumber"],
          message: "Agreement Number is required",
        });
      }

      if (data.mode != "edit") {
        if (data.selectionType === "multiple" && !data.file) {
          ctx.addIssue({
            code: z.ZodIssueCode.custom,
            path: ["file"],
            message: "Please upload a file",
          });
        }
      }

      // Department
      if (
        data.department === othersIds.department &&
        (!data.otherDepartment || data.otherDepartment.trim() === "")
      ) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["otherDepartment"],
          message: "Other Department is required",
        });
      }

      // Request Type
      if (
        data.requestType === othersIds.requestType &&
        (!data.otherRequestType || data.otherRequestType.trim() === "")
      ) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["otherRequestType"],
          message: "Other Request Type is required",
        });
      }

      // Delivery
      if (
        data.location === othersIds.location &&
        (!data.otherDelivery || data.otherDelivery.trim() === "")
      ) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["otherDelivery"],
          message: "Other Delivery Location is required",
        });
      }

      // Purpose
      if (
        data.purpose === othersIds.purpose &&
        (!data.otherPurpose || data.otherPurpose.trim() === "")
      ) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["otherPurpose"],
          message: "Other Purpose is required",
        });
      }

      // Document (multiple select)
      if (
        data.document.includes(othersIds.document) &&
        (!data.otherDocument || data.otherDocument.trim() === "")
      ) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["otherDocument"],
          message: "Other Document is required",
        });
      }

      if (
        data.mode === "edit" &&
        (!data.jobstage || data.jobstage.trim() === "")
      ) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["jobstage"],
          message: "Job Stage is required",
        });
      }
    });

// Stamp Master Schema
export const stampMasterSchema = z
  .object({
    stampMasterId: z.string().optional(),
    state: z.string().min(1, "State is required"),
    stampType: z.string().min(1, "Stamp Type is required"),
    stampDenomination: z.any().optional(),
    isActive: z.boolean().optional(),
  })
  .superRefine((data, ctx) => {
    const { stampType, stampDenomination } = data;

    // Skip validation for these types
    if (
      stampType === STAMP_TYPE.NO_STAMPING ||
      stampType === STAMP_TYPE.E_STAMPING
    ) {
      return;
    }

    const isEmpty =
      stampDenomination == null ||
      (typeof stampDenomination === "string" &&
        stampDenomination.trim() === "") ||
      (Array.isArray(stampDenomination) && stampDenomination.length === 0);

    if (stampType === STAMP_TYPE.FIXED && isEmpty) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Stamp Denomination is required for Fixed type",
        path: ["stampDenomination"],
      });
    }

    if (stampType === STAMP_TYPE.VARIABLE && isEmpty) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message:
          "At least one Stamp Denomination is required for Variable type",
        path: ["stampDenomination"],
      });
    }
  });

// Stamping Transaction Schema
export const stampingTransactionSchema = z
  .object({
    stampAmount: z.coerce.number().nullable().optional(),
    insertionAmount: z.coerce.number().nullable().optional(),
  })
  .superRefine((data, ctx) => {
    const { stampAmount, insertionAmount } = data;

    if (stampAmount == null || insertionAmount == null) return;

    if (stampAmount > insertionAmount) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Stamp Amount must be less than or equal to Insertion Amount",
        path: ["stampAmount"],
      });
      return;
    }

    const finalAmount = insertionAmount - stampAmount;

    if (finalAmount < 100) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Final Amount must be greater than or equal to 100",
        path: ["finalAmount"],
      });
      return;
    }

    if (finalAmount % 100 !== 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Final Amount must be a multiple of 100 (e.g., 100, 200)",
        path: ["finalAmount"],
      });
    }
  });

// Add Role Schema
export const addRoleSchema = z.object({
  roleName: z
    .string()
    .min(1, "Role name is required")
    .min(2, "Role name must be at least 2 characters")
    .max(50, "Role name must be at most 50 characters"),
  description: z
    .string()
    .min(1, "Description is required")
    .max(200, "Description must be at most 200 characters"),
});

// Add Permission Schema
export const addPermissionSchema = z
  .object({
    roleId: z.string().min(1, "Please select a role"),
    permissionNames: z.array(z.string()).optional().default([]),
  })
  .superRefine((data, ctx) => {
    if (data.roleId && data.permissionNames.length === 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Please select at least one permission",
        path: ["permissionNames"],
      });
    }
  });

// Add Query Sub Category Schema
export const addQuerySubCategorySchema = z.object({
  queryCategoryName: z.string().min(1, "Please select a category"),
  queryCategoryDescription: z
    .string()
    .min(1, "Sub category description is required")
    .max(120, "Maximum 120 characters allowed"),
});
