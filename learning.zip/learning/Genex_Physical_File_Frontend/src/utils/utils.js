import CryptoJS from "crypto-js";
import { getRegistryPath } from "../constants/featureRegistry";

/**
 * Helper function to validate characters as the user types in InputField.
 * Returns true if the value is allowed, false otherwise.
 *
 * @param {string} value - The input value to validate.
 * @param {RegExp} regex - The regular expression to validate against.
 * @returns {boolean} True if the input characters are valid, false otherwise.
 */
export const validateInputCharacters = (value, regex) => {
  if (!value) return true;
  if (!regex) return true;

  // If it's the email regex, check allowed character set in real-time
  if (regex.source.includes("@")) {
    return /^[a-zA-Z0-9._%+\-@]*$/.test(value);
  }

  // Otherwise, convert "+" to "*" to allow typing from empty
  const source = regex.source.replace(/\+$/, "*");
  const testRegex = new RegExp(source, regex.flags);
  return testRegex.test(value);
};

/**
 * Resolves a CSS custom property value at runtime from the document root.
 * Returns an empty string in non-browser environments (e.g. SSR).
 *
 * @param {string} name - CSS variable name, e.g. "--color-dashboard-pending".
 * @returns {string} The computed colour string.
 */
export const getCssVar = (name) => {
  if (typeof window !== "undefined") {
    return getComputedStyle(document.documentElement)
      .getPropertyValue(name)
      .trim();
  }
  return "";
};

/**
 * Extracts a user-friendly error message from an API error object.
 *
 * @param {Error} error - The error object returned from an API call (e.g., via Axios).
 * @param {string} fallbackMessage - A default message to return if the error doesn't provide one.
 * @returns {string} The error message to display to the user.
 */
export const getApiErrorMessage = (
  error,
  fallbackMessage = "Something went wrong. Please try again later.",
) => {
  if (!error) return fallbackMessage;

  if (error.code === "ERR_NETWORK") {
    return "Unable to reach server. Please check backend connection and try again.";
  }

  return error?.response?.data?.message ?? error?.message ?? fallbackMessage;
};

/**
 * Validates Redux permissions against FEATURE_REGISTRY.
 * Warns if a permission is missing from the registry or lacks a mapped component.
 * Runs only in development mode to catch routing/config errors early.
 *
 * @param {Object} registry - The feature registry
 * @param {Array} permissions - The user's permissions
 */
export const validatePermissions = (registry, permissions) => {
  if (!import.meta.env.DEV) return;
  if (!permissions?.length) return;

  permissions.forEach(({ permissionName }) => {
    const entry = registry[permissionName];

    if (!entry) {
      console.warn(
        `[PermissionValidator] Warning: Permission "${permissionName}" is not in FEATURE_REGISTRY. ` +
          "This route will be skipped. " +
          "Add an entry in src/constants/featureRegistry.js to enable it.",
      );
      return;
    }

    if (!entry.component) {
      const path = getRegistryPath(permissionName, entry);
      console.info(
        `[PermissionValidator] Info: Permission "${permissionName}" has no component registered at "${path}". ` +
          "Assign a component in FEATURE_REGISTRY to map this route.",
      );
    }
  });
};

/**
 * Computes the SHA-1 hash of a File or Blob using crypto-js.
 * Used to generate a checksum before uploading a document to the DMS API.
 *
 * @param {File|Blob} file - File to hash
 * @returns {Promise<string>} Hex SHA-1 string
 */
export const sha1FromFile = (file) => {
  return new Promise((resolve, reject) => {
    if (!(file instanceof Blob)) {
      reject(new TypeError("Expected file to be a Blob or File object"));
      return;
    }

    const reader = new FileReader();

    reader.onload = (event) => {
      const arrayBuffer = event.target.result;
      const wordArray = CryptoJS.lib.WordArray.create(arrayBuffer);
      const hash = CryptoJS.SHA1(wordArray);
      resolve(hash.toString());
    };

    reader.onerror = (error) => {
      reject(error);
    };

    reader.readAsArrayBuffer(file);
  });
};

/**
 * Formats today's date as dd-MM-yyyy (DMS API format).
 * Example output: "04-09-2026"
 *
 * @returns {string} Today's date formatted as dd-MM-yyyy.
 */
export const getTodayDmsFormatted = () => {
  const d = new Date();
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const yyyy = d.getFullYear();
  return `${dd}-${mm}-${yyyy}`;
};

/**
 * buildReportFilename
 *
 * Generates a descriptive CSV filename based on the selected module,
 * stages, and date range.
 *
 * Naming convention (all lowercase, words separated by underscores):
 *   {stage_parts}_{fromDate}_to_{toDate}.csv
 *
 * For "PRODUCTIVITY_REPORT" module the stage list is omitted and the
 * module key itself is used instead:
 *   productivity_report_{fromDate}_to_{toDate}.csv
 *
 * Examples:
 *   rack_assigned_user_assigned_01-09-2026_to_24-09-2026.csv
 *   query_resolved_01-09-2026_to_24-09-2026.csv
 *   productivity_report_01-09-2026_to_24-09-2026.csv
 *
 * @param {string}   module     - The selected module value.
 * @param {string[]} stages     - Array of selected stage values (stageName strings).
 * @param {string}   fromDate   - ISO date string "YYYY-MM-DD".
 * @param {string}   toDate     - ISO date string "YYYY-MM-DD".
 * @returns {string} The generated filename.
 */
export const buildReportFilename = (module, stages, fromDate, toDate) => {
  const formatDate = (iso) => {
    if (!iso) return "";
    const [yyyy, mm, dd] = iso.split("-");
    return `${dd}-${mm}-${yyyy}`;
  };

  const from = formatDate(fromDate);
  const to = formatDate(toDate);

  const stagePart =
    module === "PRODUCTIVITY_REPORT"
      ? "productivity_report"
      : stages?.map((s) => s.toLowerCase())?.join("_");

  return `${stagePart}_${from}_to_${to}.csv`;
};

/**
 * Formats today's date as YYYY-MM-DD for HTML input type="date".
 * Example output: "2026-09-04"
 *
 * @returns {string} Today's date formatted as YYYY-MM-DD.
 */
export const getTodayInputFormat = () => {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
};

/**
 * Formats an ISO date string to a human-readable IST (Asia/Kolkata) string.
 * - Date-only strings (e.g. "2025-11-03") are formatted without time: "03 Nov 2025"
 * - Datetime strings (e.g. "2025-11-03T00:00:00") are formatted with time in IST: "03 Nov 2025, 05:30 AM"
 *
 * @param {string|null|undefined} dateString - ISO date or datetime string from the API.
 * @param {string} [fallback="—"] - Value returned when dateString is falsy.
 * @returns {string} Formatted date (with or without time) or the fallback value.
 */
export const formatDateToIST = (dateString, fallback = "—") => {
  if (!dateString) return fallback;

  // Detect if the string is date-only (YYYY-MM-DD with no time component)
  const isDateOnly =
    typeof dateString === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(dateString.trim());

  if (isDateOnly) {
    // Parse as local date parts to avoid any timezone shift
    const [year, month, day] = dateString.trim().split("-").map(Number);
    return new Date(year, month - 1, day).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  }

  // For datetime strings: append 'Z' to treat as UTC if no timezone indicator is present
  let parsedDate = dateString;
  if (
    typeof dateString === "string" &&
    !dateString.endsWith("Z") &&
    !dateString.match(/[+-]\d{2}:\d{2}$/)
  ) {
    parsedDate += "Z";
  }

  return new Date(parsedDate).toLocaleString("en-IN", {
    timeZone: "Asia/Kolkata",
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
};

/**
 * Formats an ISO date or datetime string to a human-readable date-only string (no time).
 * Useful for fields like businessDate / sourcingDate where time must never be shown.
 * Example output: "03 Nov 2025"
 *
 * @param {string|null|undefined} dateString - ISO date or datetime string from the API.
 * @param {string} [fallback="—"] - Value returned when dateString is falsy.
 * @returns {string} Formatted date-only string or the fallback value.
 */
export const formatDateOnlyToIST = (dateString, fallback = "—") => {
  if (!dateString) return fallback;

  // Extract only the date part (YYYY-MM-DD) from both date-only and datetime strings
  const datePart =
    typeof dateString === "string"
      ? dateString.trim().slice(0, 10)
      : String(dateString);

  const [year, month, day] = datePart.split("-").map(Number);
  if (!year || !month || !day) return fallback;

  // Construct using local date parts to avoid any timezone shift
  return new Date(year, month - 1, day).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

/**
 * Returns a human-readable relative time string from a given date to now.
 * Example output: "23 hour(s) ago", "2 day(s) ago", "45 minute(s) ago"
 *
 * @param {string|Date} createdDate - The date to compare against the current time.
 * @returns {string} Relative time string (e.g., "3 hour(s) ago").
 */
export const getTimeDiff = (createdDate) => {
  const now = new Date();

  // Append 'Z' to treat datetime string as UTC if no timezone indicator is present
  let parsedDate = createdDate;
  if (
    typeof createdDate === "string" &&
    !createdDate.endsWith("Z") &&
    !createdDate.match(/[+-]\d{2}:\d{2}$/)
  ) {
    parsedDate += "Z";
  }

  const created = new Date(parsedDate);

  const diffMs = now - created; // difference in milliseconds

  // Handle cases where the createdDate is slightly in the future due to clock drift
  if (diffMs <= 0) {
    return "Just now";
  }

  const seconds = Math.floor(diffMs / 1000);
  const minutes = Math.floor(diffMs / (1000 * 60));
  const hours = Math.floor(diffMs / (1000 * 60 * 60));
  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (days > 0) return `${days} day(s) ago`;
  if (hours > 0) return `${hours} hour(s) ago`;
  if (minutes > 0) return `${minutes} minute(s) ago`;
  return `${seconds} second(s) ago`;
};

/**
 * getStageDuration
 *
 * Calculates the elapsed time between two stage transition dates and returns
 * a compact, human-readable string (e.g. "3 mins", "1 day 2 hours 5 mins").
 * Zero-value parts are omitted. Used to show how long a stage took in the
 * transaction history timeline.
 *
 * @param {string} fromDate - ISO datetime string of the earlier stage.
 * @param {string} toDate   - ISO datetime string of the later stage.
 * @returns {string|null} Formatted duration string, or null if either date is invalid.
 */
export const getStageDuration = (fromDate, toDate) => {
  const parseUTC = (dateStr) => {
    if (!dateStr) return null;
    let s = dateStr;
    if (
      typeof s === "string" &&
      !s.endsWith("Z") &&
      !s.match(/[+-]\d{2}:\d{2}$/)
    ) {
      s += "Z";
    }
    const d = new Date(s);
    return isNaN(d.getTime()) ? null : d;
  };

  const from = parseUTC(fromDate);
  const to = parseUTC(toDate);
  if (!from || !to) return null;

  const diffMs = to - from;
  if (diffMs <= 0) return null;

  const totalMinutes = Math.floor(diffMs / (1000 * 60));
  const days = Math.floor(totalMinutes / (60 * 24));
  const hours = Math.floor((totalMinutes % (60 * 24)) / 60);
  const mins = totalMinutes % 60;

  const parts = [];
  if (days > 0) parts.push(`${days} day${days > 1 ? "s" : ""}`);
  if (hours > 0) parts.push(`${hours} hour${hours > 1 ? "s" : ""}`);
  if (mins > 0) parts.push(`${mins} min${mins > 1 ? "s" : ""}`);
  if (parts.length === 0) parts.push("< 1 min");

  return parts.join(" ");
};

/**
 * Validates if the given file has a .csv extension.
 *
 * @param {File} file - The file to validate.
 * @returns {boolean} True if the file has a .csv extension.
 */
export const isValidCSV = (file) => {
  if (!file) return false;
  return file.name.toLowerCase().endsWith(".csv");
};

/**
 * Converts a string to Title Case (capitalizes the first letter of each word).
 * Also replaces underscores with spaces to seamlessly handle raw ENUM_VALUES.
 * Example: "ANDAMAN AND NICOBAR ISLANDS" -> "Andaman And Nicobar Islands"
 * Example: "NO_STAMP" -> "No Stamp"
 *
 * @param {string} str - The string to convert.
 * @returns {string} The Title Case string.
 */
export const toTitleCase = (str) => {
  if (!str) return "";
  return str
    .replace(/_/g, " ")
    .toLowerCase()
    .replace(/\b\w/g, (char) => char.toUpperCase());
};

/**
 * Converts a key-value labels object into an array of option objects
 * for dropdowns. Example: { IN_STOCK: "In Stock" } -> [{ value: "IN_STOCK", label: "In Stock" }]
 *
 * @param {Object} labelsObj - The object containing value: label pairs
 * @returns {Array<{value: string, label: string}>} Array of option objects
 */
export const mapLabelsToOptions = (labelsObj) => {
  if (!labelsObj) return [];
  return Object.entries(labelsObj).map(([value, label]) => ({
    value,
    label,
  }));
};

/**
 * Formats a number as INR currency.
 *
 * @param {number|string} amount - The amount to format.
 * @returns {string} The formatted currency string.
 */
export const formatCurrency = (amount) => {
  if (amount === null || amount === undefined || isNaN(amount)) return "—";
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
};

/**
 * Generates a deterministic badge color palette (bg, text, border) and minWidth
 * from a role name string. Uses a simple string hash to produce a consistent HSL hue
 * for any unknown role. Width is computed from character count to match existing badge sizing.
 *
 * @param {string} roleName - The role name to derive a color for.
 * @returns {{ bg: string, text: string, border: string, minWidth: string }} Inline style values.
 */
export const getRoleBadgeColor = (roleName) => {
  let hash = 0;
  for (let i = 0; i < roleName.length; i++) {
    hash = roleName.charCodeAt(i) + ((hash << 5) - hash);
  }
  // Use a wide spread of hues but avoid low-saturation/grey zones
  const hue = Math.abs(hash) % 360;
  return {
    bg: `hsl(${hue}, 65%, 92%)`,
    text: `hsl(${hue}, 55%, 30%)`,
    border: `hsl(${hue}, 50%, 75%)`,
  };
};

/**
 * Escapes a CSV cell value: wraps in double-quotes if the value contains
 * commas, double-quotes, or newlines. Internal double-quotes are escaped by doubling.
 *
 * @param {*} val - Raw cell value.
 * @returns {string} Safe CSV cell string.
 */
const escapeCsvCell = (val) => {
  if (val === null || val === undefined) return "";
  const str = String(val);
  if (str.includes(",") || str.includes('"') || str.includes("\n")) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
};

/**
 * Exports an array of objects to a CSV file using a custom column definition
 * and triggers a browser download. Preferred over exportToCSV for structured
 * data with nested fields or transformed values.
 *
 * @param {Array<Object>} data - The data array to export.
 * @param {string} filename - The desired filename (e.g. "report.csv").
 * @param {Array<{header: string, accessor: Function}>} columns
 *   Column definitions — each entry provides:
 *     - header   {string}   CSV column heading
 *     - accessor {Function} (rec) => value  extracts the cell value from a record
 */
export const exportToCSVWithColumns = (data, filename, columns) => {
  if (!data || !data.length) {
    console.warn("No data available to export.");
    return;
  }
  if (!columns || !columns.length) {
    console.warn("No column definitions provided to exportToCSVWithColumns.");
    return;
  }

  const headerRow = columns.map((col) => escapeCsvCell(col.header)).join(",");

  const dataRows = data.map((rec) =>
    columns.map((col) => escapeCsvCell(col.accessor(rec))).join(","),
  );

  const csvString = [headerRow, ...dataRows].join("\n");
  const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

/**
 * Exports an array of objects to a CSV file and triggers a download.
 *
 * @param {Array<Object>} data - The data array to export.
 * @param {string} filename - The desired filename (e.g. "report.csv").
 */
export const exportToCSV = (data, filename) => {
  if (!data || !data.length) {
    console.warn("No data available to export.");
    return;
  }

  // Extract headers
  const headers = Object.keys(data[0]);

  // Map each row into a CSV string
  const csvRows = [
    headers.join(","),
    ...data.map((row) =>
      headers
        .map((header) => {
          const val = row[header];
          // Handle null, undefined, and values containing commas
          if (val === null || val === undefined) return "";
          const str = String(val);
          if (str.includes(",") || str.includes('"') || str.includes("\n")) {
            return `"${str.replace(/"/g, '""')}"`;
          }
          return str;
        })
        .join(","),
    ),
  ];

  const csvString = csvRows.join("\n");
  const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};
