import { useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { logout } from "./redux/slice/userSlice";

const SessionManager = () => {
  const timerRef = useRef(null);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { expiresAt, isAuthenticated } = useSelector((state) => state.user);

  useEffect(() => {
    if (!isAuthenticated || !expiresAt) return;

    const checkSessionExpiration = () => {
      const currentTime = new Date().getTime();
      if (currentTime > expiresAt) {
        console.log("Session expired. Logging out.");
        if (timerRef.current) clearInterval(timerRef.current);
        dispatch(logout({ sessionExpired: true }));
        navigate("/login", { replace: true });
      }
    };

    // Check immediately and then every minute
    checkSessionExpiration();
    timerRef.current = setInterval(checkSessionExpiration, 60 * 1000);

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [dispatch, navigate, expiresAt, isAuthenticated]);

  return null;
};

export default SessionManager;
