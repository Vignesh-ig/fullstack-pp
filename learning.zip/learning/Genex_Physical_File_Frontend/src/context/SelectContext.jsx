/* eslint-disable react-refresh/only-export-components */
import { createContext, useContext } from "react";

const SelectContext = createContext(null);

/**
 * SelectProvider
 *
 * Provider component for SelectContext.
 *
 * @param {React.ReactNode} children - Child elements.
 * @param {Object} value - Context value mapping state and handlers.
 */

export const SelectProvider = ({ children, value }) => {
  return (
    <SelectContext.Provider value={value}>{children}</SelectContext.Provider>
  );
};

export const useSelectContext = () => {
  return useContext(SelectContext);
};

SelectContext.displayName = "SelectContext";
SelectProvider.displayName = "SelectProvider";
