import { Suspense } from "react";
import { BrowserRouter } from "react-router-dom";
import ErrorBoundary from "./components/error/ErrorBoundary";
import Spinner from "./components/ui/common/Spinner.jsx";
import AppRoutes from "./router/AppRoutes";
import SessionManager from "./SessionManager";

const App = () => (
  <ErrorBoundary>
    <Suspense fallback={<Spinner />}>
      <BrowserRouter>
        <SessionManager />
        <AppRoutes />
      </BrowserRouter>
    </Suspense>
  </ErrorBoundary>
);

App.displayName = "App";
export default App;
