# Project Folder Structure

This document outlines the architecture and purpose of directories in the `Genex_Physical_File_Frontend` repository.

### Folders & Files Structure
```
file_tracking_system/
├── public/
│   ├── cholamandalam-logo.png
│   └── sample-document.xlsx
├── src/
│   ├── api/                                 # Centralized API logic and Axios configuration
│   │   ├── apiConfig.js                     # All API function definitions (per endpoint)
│   │   ├── axiosInstance.js                 # Axios instance + request/response interceptors
│   │   ├── endpoints.js                     # Centralized API endpoint path constants
│   │   └── index.js                         # Barrel export for the entire API layer
│   ├── assets/                              # Static assets (images, fonts, SVGs)
│   │   └── logo.svg
│   ├── components/                          # Sub-components used only within dashboard pages
│   │   ├── error/
│   │   │   └── ErrorBoundary.jsx            # Catch-all for React rendering errors
│   │   ├── icons/
│   │   │   └── icons.jsx                    # All app icons exported as named React components
│   │   ├── layout/                          # Structural / shell components
│   │   │   ├── AppLayout.jsx                # Navbar + main content shell (for protected routes)
│   │   │   ├── LandscapeFormContainer.jsx   # Full-width form container layout
│   │   │   ├── ListContainer.jsx            # Shadowed container for tables and list headers
│   │   │   ├── ListHeader.jsx               # Unified header for list pages with search and actions
│   │   │   ├── Navbar.jsx                   # Dynamic permission-driven navigation bar
│   │   │   ├── PageHeaderInfo.jsx           # Header stats (Title, Item count, loading state)
│   │   │   ├── PortraitFormContainer.jsx    # Narrower page layout for forms
│   │   │   ├── ProfileDropdown.jsx          # User profile and logout dropdown
│   │   │   └── SidebarMenu.jsx              # Mobile side-drawer menu
│   │   └── ui/                              # Atomic, reusable UI primitives
│   │       ├── badge/                       # Centralized folder for badge implementations
│   │       │   ├── badgeIndex.js            # Barrel exports for badge components
│   │       │   ├── BaseBadge.jsx            # Shared UI-only base wrapper for all badges
│   │       │   ├── JobStatusBadge.jsx       # UI Component
│   │       │   ├── RoleBadge.jsx            # Badge for user roles
│   │       │   ├── StampStackStatusBadge.jsx # Badge for stamp stack status (IN_STOCK / USED)
│   │       │   ├── StampTypeBadge.jsx       # Badge for stamp types (Fixed / Variable / etc.)
│   │       │   ├── StatusBadge.jsx          # Badge for boolean status (Active/Inactive)
│   │       │   └── TaskStatusBadge.jsx      # Badge for task statuses (Completed/Pending)
│   │       ├── common/                      # Shared atomic UI primitives
│   │       │   ├── Button.jsx               # Full-width primary action button
│   │       │   ├── ClearSearchButton.jsx    # Reset button for search input fields
│   │       │   ├── ConfirmationDialog.jsx   # UI Component
│   │       │   ├── DashboardStatCard.jsx    # Shared stat card (clickable or read-only) for dashboards
│   │       │   ├── DashboardTablePanel.jsx  # Shared minimize/maximize collapsible panel wrapper for dashboard tables
│   │       │   ├── DashedEmptyState.jsx     # Compact dashed empty state placeholder
│   │       │   ├── DenominationsTable.jsx   # Table for displaying denomination records
│   │       │   ├── DetailCard.jsx           # Reusable metadata section card component
│   │       │   ├── DetailField.jsx          # Reusable uppercase label-value pair list item
│   │       │   ├── DocumentButton.jsx       # UI Component
│   │       │   ├── DocumentUploadModal.jsx  # UI Component
│   │       │   ├── DocumentViewerModal.jsx  # Modal for viewing DMS documents inline
│   │       │   ├── DragDropFileUpload.jsx   # Drag-and-drop file upload area
│   │       │   ├── EmptyState.jsx           # Placeholder for empty data views
│   │       │   ├── ErrorBanner.jsx          # Global/Form error display component
│   │       │   ├── FileUploadField.jsx      # Reusable file upload component
│   │       │   ├── FilterSelectField.jsx    # Custom dropdown for table filtering
│   │       │   ├── FloatingMenu.jsx         # Floating action menu for contextual operations
│   │       │   ├── FormFooter.jsx           # Form action buttons (Save/Cancel)
│   │       │   ├── FormHeader.jsx           # Back button and title for forms
│   │       │   ├── HistoryField.jsx         # Reusable label-value pair item for timeline history
│   │       │   ├── IconButton.jsx           # Reusable button for icons (back, arrows, etc.)
│   │       │   ├── IconButtonWithHover.jsx  # Icon-only button with hover tooltip
│   │       │   ├── InputField.jsx           # Labelled input with icon and error states
│   │       │   ├── Logo.jsx                 # Clickable logo linking to home
│   │       │   ├── NavigationBanners.jsx    # UI Component
│   │       │   ├── Pagination.jsx           # Shared pagination controls
│   │       │   ├── PerPageSelectField.jsx   # Custom dropdown for items-per-page selection
│   │       │   ├── RecordCard.jsx           # Card for displaying record details with badges
│   │       │   ├── RefreshButton.jsx        # Spinning circular refresh button
│   │       │   ├── SearchableSelectField.jsx # Search-as-you-type options selector
│   │       │   ├── SearchInput.jsx          # Expandable search input with debounce
│   │       │   ├── SelectField.jsx          # Custom viewport-aware dropdown select
│   │       │   ├── SelectFieldWithCheckbox.jsx # Multi-select with UI virtualization
│   │       │   ├── SlidingButton.jsx        # Hover-expanding icon+label action button
│   │       │   ├── Spinner.jsx              # Full-screen loading spinner
│   │       │   ├── StatusToggle.jsx         # Labelled Active/Inactive toggle for forms
│   │       │   ├── SuccessBanner.jsx        # Green banner for successful operations
│   │       │   ├── Table.jsx                # Reusable responsive table wrapper
│   │       │   ├── TableRecordDeleteButton.jsx # Delete action button with permission check
│   │       │   ├── TableSkeletonRow.jsx     # Dynamic skeleton row for tables
│   │       │   └── TextareaField.jsx        # Reusable labelled textarea with error state
│   │       ├── select-with-checkbox/        # Specialized multi-select modules
│   │       │   ├── DropdownHeader.jsx       # Header with selected count/bulk actions
│   │       │   ├── DropdownPanel.jsx        # Popover container with collision detection
│   │       │   ├── OptionItem.jsx           # Memoized individual selectable row
│   │       │   ├── OptionList.jsx           # Virtuoso list container (UI virtualization)
│   │       │   └── SearchBar.jsx            # Sticky search input with loading states
│   │       └── transaction/                 # Shared components for transaction features
│   │           ├── TransactionDetailsPage.jsx # Generic details-page shell
│   │           └── TransactionUpdateForm.jsx # Shared status update form
│   ├── config/                              # Configuration files
│   │   └── envConfig.js                     # Global environment variables parsing
│   ├── constants/                           # Application-wide constants
│   │   ├── featureRegistry.js               # Maps permissions to UI components and routes
│   │   ├── menuHeaders.js                   # Header configuration constants for floating menus
│   │   ├── roles.js                         # ROLES constants + dashboard route helper
│   │   ├── stages.js                        # Centralized application stage names constants
│   │   ├── stampingConstants.js             # Stamp type, denomination, and DENO_STATUS constants
│   │   ├── status.js                        # Status and Task Status constants
│   │   └── tableHeaders.js                  # Table column header arrays per module
│   ├── context/                             # Centralized React Contexts
│   │   └── SelectContext.jsx                # Shared state for custom dropdown components
│   ├── hooks/                               # Global custom React hooks
│   │   ├── dropdowns/                       # Global specialized dropdown hooks
│   │   │   ├── useBranchHierarchy.js        # Hook for zone-to-branch cascade selection
│   │   │   ├── useFileTypes.js              # File types dropdown with infinite scroll
│   │   │   ├── useQueryCategoryDropdown.js  # Custom React Hook
│   │   │   ├── useRackDropdown.js           # Rack dropdown with infinite scroll
│   │   │   ├── useRetrievalDropdown.js      # Custom React Hook
│   │   │   ├── useRolesDropdown.js          # Roles dropdown options hook
│   │   │   ├── useStampOptions.js           # Stamp type and denomination dropdown options
│   │   │   ├── useStates.js                 # Indian states dropdown hook
│   │   │   ├── useUsersDropdown.js          # Users dropdown with infinite scroll
│   │   │   └── useVaultDropdown.js          # Vault dropdown from racks
│   │   ├── useApi.js                        # Hook for generic single API interactions
│   │   ├── useDebounce.js                   # Generic hook to debounce any value
│   │   ├── useDeleteHandler.js              # Centralized delete action handler with modal & notification
│   │   ├── useLogout.js                     # Hook for clearing auth state and redirecting
│   │   ├── useMultiSelect.js                # Logic for checkbox selection state
│   │   ├── useNavigationBanners.js          # Custom React Hook
│   │   ├── usePaginatedFetch.js             # Global paginated table fetching with URL sync
│   │   ├── usePreventBackNavigation.js      # Hook to prevent browser back navigation
│   │   ├── useQueries.js                    # Hook for querying physical file tracking
│   │   ├── useStages.js                     # Hook for managing processing stages
│   │   ├── useTransactionFetch.js           # Centralized hook for transaction records
│   │   ├── useTransactionStageLogic.js      # Stage auto-selection and dropdown logic
│   │   └── useTransactionSubmit.js          # Shared transaction form submission logic
│   ├── pages/                               # Top-level page components, one folder per module
│   │   ├── applications-unlock/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── ApplicationsUnlockExpandedRow.jsx # Expanded detail panel
│   │   │   │   ├── ApplicationsUnlockTable.jsx # Data table for locked applications
│   │   │   │   └── ApplicationsUnlockTableRow.jsx # Individual record row
│   │   │   └── ApplicationsUnlock.jsx       # Main page for unlocking locked applications
│   │   ├── branch-master/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   └── BranchTable.jsx          # Data table for branch list
│   │   │   ├── BranchList.jsx               # Main container for branch list view
│   │   │   └── BranchMaster.jsx             # Layout for branch master feature
│   │   ├── dashboard/
│   │   │   ├── components/                         # Sub-components used only within dashboard pages
│   │   │   │   ├── DashBoardFileTracking.jsx/      # UI Component
│   │   │   │   │   └── DashboardFileTrackingTable.jsx # UI Component
│   │   │   │   ├── DashboardAllocationTable.jsx    # Paginated allocation table filtered by task status
│   │   │   │   ├── DashboardPieChart.jsx           # Nivo donut chart with clickable slices
│   │   │   │   ├── DashboardStampingTable.jsx      # Paginated stamp-stack table filtered by status + states
│   │   │   │   ├── DashboardTabs.jsx               # Tab bar for switching between dashboard panels
│   │   │   │   ├── DashboardTransactionPanel.jsx   # UI Component
│   │   │   │   └── DashboardTransactionRowTable.jsx # UI Component
│   │   │   ├── AllocationsDashboard.jsx            # Full-page: allocation metrics, pie chart + drill-down table
│   │   │   ├── DashboardFileTrackingPage.jsx       # Page/Layout Component
│   │   │   ├── DashboardMaster.jsx                 # Role-aware entry point; renders tabs + active dashboard
│   │   │   ├── QueryDashboard.jsx                  # Page/Layout Component
│   │   │   ├── StampingDashboard.jsx               # Full-page: stamping metrics, state filter, pie chart + drill-down table
│   │   │   └── TransactionsDashboard.jsx           # Page/Layout Component
│   │   ├── doc-admin/
│   │   │   ├── create-retrieval-request/
│   │   │   │   ├── components/              # Sub-components used only within dashboard pages
│   │   │   │   │   └── CreateRetrievalFormField.jsx # UI Component
│   │   │   │   ├── CreateRetrievalForm.jsx  # Page/Layout Component
│   │   │   │   ├── EmailAction.jsx          # Page/Layout Component
│   │   │   │   └── EmailActionLogin.jsx     # Page/Layout Component
│   │   │   └── file-retrieval-request/
│   │   │       ├── components/              # Sub-components used only within dashboard pages
│   │   │       │   ├── FileRetrievalList.jsx # UI Component
│   │   │       │   └── FileRetrievalTable.jsx # UI Component
│   │   │       └── FileRetrievalRequestPage.jsx # Page/Layout Component
│   │   ├── enquiry/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── EnquiryFileDetails.jsx   # Full read-only file details card
│   │   │   │   └── EnquiryHistory.jsx       # Collapsible transaction history timeline
│   │   │   └── Enquiry.jsx                  # Main container for Enquiry search & details
│   │   ├── health-check/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── HealthCheckFileDetails.jsx # Read-only file details card
│   │   │   │   └── HealthCheckTable.jsx     # Data table for health check list view
│   │   │   ├── HealthCheckList.jsx          # Container for health check list view
│   │   │   └── HealthCheckMaster.jsx        # Routing component for health check
│   │   ├── non-critical-query/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── NonCriticalQueryFileDetails.jsx # Read-only file details card
│   │   │   │   └── NonCriticalQueryTable.jsx # Data table for non-critical query list view
│   │   │   ├── NonCriticalQueryList.jsx     # Container for non-critical query list view
│   │   │   └── NonCriticalQueryMaster.jsx   # Routing component for non-critical query
│   │   ├── outward/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── OutwardScannedCard.jsx   # UI Component
│   │   │   │   └── OutwardScannedTable.jsx  # UI Component
│   │   │   └── Outward.jsx                  # Outward feature layout component
│   │   ├── query/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── QueryFileDetails.jsx     # Read-only file details card
│   │   │   │   └── QueryTable.jsx           # Data table for query list view
│   │   │   ├── QueryList.jsx                # Container for query list view
│   │   │   └── QueryMaster.jsx              # Routing component for query feature
│   │   ├── query-category/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── CategoryTable.jsx        # UI Component
│   │   │   │   └── SubCategoryTable.jsx     # UI Component
│   │   │   ├── AddSubCategoryForm.jsx       # Page/Layout Component
│   │   │   ├── CategoryList.jsx             # Page/Layout Component
│   │   │   ├── QueryCategory.jsx            # Page/Layout Component
│   │   │   └── SubCategoryList.jsx          # Page/Layout Component
│   │   ├── rack-allocation/
│   │   │   ├── components/                         # Sub-components used only within dashboard pages
│   │   │   │   ├── EditableAllocationTable.jsx     # Editable user allocation table
│   │   │   │   ├── EditableAllocationTableRow.jsx  # Individual editable row
│   │   │   │   ├── RackAllocationEditFormFields.jsx # Input fields for editing allocations
│   │   │   │   ├── RackAllocationExpandedRow.jsx   # Detailed expanded metadata panel
│   │   │   │   ├── RackAllocationTable.jsx         # Rack allocations list data table
│   │   │   │   └── RackAllocationTableRow.jsx      # Individual allocation record row
│   │   │   ├── contexts/
│   │   │   │   └── RackAllocationFormContext.js # Context for allocation form state
│   │   │   ├── RackAllocation.jsx           # Layout component for rack allocation
│   │   │   ├── RackAllocationEditForm.jsx   # Single-row edit form
│   │   │   ├── RackAllocationForm.jsx       # Multi-row creation form
│   │   │   └── RackAllocationList.jsx       # Table view container for rack allocation
│   │   ├── rack-master/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── RackFormFields.jsx       # Input configuration for rack forms
│   │   │   │   └── RackTable.jsx            # Data table for rack list
│   │   │   ├── RackForm.jsx                 # Add/Edit page for racks
│   │   │   ├── RackList.jsx                 # Main container for rack list view
│   │   │   └── RackMaster.jsx               # Layout for rack master feature
│   │   ├── report/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── ReportExpandedRow.jsx    # UI Component
│   │   │   │   ├── ReportTable.jsx          # UI Component
│   │   │   │   └── ReportTableRow.jsx       # UI Component
│   │   │   ├── constants/                   # Application-wide constants
│   │   │   │   └── csvHeaders.js            # Utility/Logic file
│   │   │   └── Report.jsx                   # TODO: Not Implemented module
│   │   ├── return-rack/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── ReturnRackExpandedRow.jsx # Detailed expanded metadata panel
│   │   │   │   ├── ReturnRackTable.jsx      # Data table for return rack list
│   │   │   │   └── ReturnRackTableRow.jsx   # Individual return rack record row
│   │   │   └── ReturnRack.jsx               # Layout component for return rack feature
│   │   ├── roles-and-permissions/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── AddPermissionForm.jsx    # Form component for adding permissions
│   │   │   │   ├── AddRoleForm.jsx          # Form component for adding roles
│   │   │   │   ├── PermissionsTable.jsx     # Data table for listing permissions
│   │   │   │   └── RolesTable.jsx           # Data table for listing roles
│   │   │   ├── PermissionsList.jsx          # Table container for permissions list view
│   │   │   ├── RolesAndPermissions.jsx      # Main layout & tabs for roles and permissions
│   │   │   ├── RolesList.jsx                # Table container for roles list view
│   │   │   └── RolesPermissionsForm.jsx     # Form drawer for role/permission management
│   │   ├── stamp-master/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── StampMasterFormFields.jsx # Input fields for stamp master forms
│   │   │   │   └── StampTable.jsx           # Data table for stamp master list
│   │   │   ├── StampMaster.jsx              # Layout/routing component for stamp master
│   │   │   ├── StampMasterForm.jsx          # Add/Edit form for stamp master records
│   │   │   └── StampMasterList.jsx          # Main container for stamp master list view
│   │   ├── stamp-stack-master/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   └── StampStackTable.jsx      # Data table for stamp stack records
│   │   │   ├── StampStackMaster.jsx         # Layout/routing for stamp stack master
│   │   │   ├── StampStackMasterCSVUpload.jsx # CSV bulk upload page for stamp stacks
│   │   │   └── StampStackMasterList.jsx     # Main container for stamp stack list view
│   │   ├── stamping/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── StampDenominationField.jsx # Denomination selection input
│   │   │   │   ├── StampingFileDetails.jsx  # Read-only file details for stamping
│   │   │   │   ├── StampingTable.jsx        # Data table for stamping list
│   │   │   │   └── StampingTransactionUpdateForm.jsx # Stamping-specific update form
│   │   │   ├── hooks/                       # Global custom React hooks
│   │   │   │   └── useStampDenominationLogic.js # Hook for denomination field logic
│   │   │   ├── stamping-amount/
│   │   │   │   ├── components/              # Sub-components used only within dashboard pages
│   │   │   │   │   └── StampingAmountTable.jsx # Data table for stamping amounts
│   │   │   │   └── StampingAmountList.jsx   # Main container for stamping amounts list view
│   │   │   ├── Stamping.jsx                 # Layout component for stamping
│   │   │   └── StampingList.jsx             # Main container for stamping list view
│   │   ├── storage/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── StorageExpandedRow.jsx   # Detailed expanded metadata panel
│   │   │   │   ├── StorageTable.jsx         # Data table for storage list
│   │   │   │   └── StorageTableRow.jsx      # Individual storage record row
│   │   │   ├── Storage.jsx                  # Layout component for storage
│   │   │   └── StorageList.jsx              # Main container for storage list view
│   │   ├── user-allocation/
│   │   │   ├── components/                         # Sub-components used only within dashboard pages
│   │   │   │   ├── EditableAllocationTable.jsx     # Editable user allocation table
│   │   │   │   ├── EditableAllocationTableRow.jsx  # Individual editable row
│   │   │   │   ├── UserAllocationEditFormFields.jsx # Input fields for editing
│   │   │   │   ├── UserAllocationExpandedRow.jsx   # Detailed expanded panel
│   │   │   │   ├── UserAllocationTable.jsx         # Main data table for user allocations
│   │   │   │   └── UserAllocationTableRow.jsx      # Individual list row
│   │   │   ├── contexts/
│   │   │   │   └── UserAllocationFormContext.js # Context for allocation form state
│   │   │   ├── UserAllocation.jsx           # Layout component for user allocation
│   │   │   ├── UserAllocationEditForm.jsx   # Single-row edit form
│   │   │   ├── UserAllocationForm.jsx       # Multi-row creation form
│   │   │   └── UserAllocationList.jsx       # Table view container for user allocation
│   │   ├── users/
│   │   │   ├── components/                  # Sub-components used only within dashboard pages
│   │   │   │   ├── UserExpandedRow.jsx      # Detailed expanded panel for branch users
│   │   │   │   ├── UserFormFields.jsx       # Input configuration for user forms
│   │   │   │   ├── UsersTable.jsx           # Data table for system users
│   │   │   │   └── UserTableRow.jsx         # Individual user record row
│   │   │   ├── UserForm.jsx                 # Create/Edit User (drawer content)
│   │   │   ├── UsersList.jsx                # Table view container for users list view
│   │   │   └── UsersManagement.jsx          # Layout for user management feature
│   │   ├── Login.jsx                        # Unified login page for all roles
│   │   └── NotFound.jsx                     # 404 fallback page
│   ├── redux/                               # Centralized state management (Redux Toolkit)
│   │   ├── app/
│   │   │   └── store.js                     # Store config + redux-persist setup
│   │   └── slice/
│   │       ├── authThunks.js                # Async thunks: loginThunk
│   │       ├── healthCheckSlice.js          # Health check state management
│   │       ├── rolesSlice.js                # Global roles and permissions state
│   │       └── userSlice.js                 # User auth state and profile management
│   ├── router/                              # Routing infrastructure
│   │   ├── AppRoutes.jsx                    # Dynamic permission-driven route generation
│   │   ├── ProtectedRoute.jsx               # Auth guard for secure routes
│   │   └── routes.js                        # ROUTES path constants
│   ├── utils/                               # Utility files and helpers
│   │   ├── schemas/                         # Zod schemas for form validation
│   │   │   └── configSchema.js              # Zod schemas for form validation
│   │   ├── validation/                      # Centralized regex patterns
│   │   │   └── regex.js                     # Centralized regex patterns
│   │   └── utils.js                         # Global helper function utility file
│   ├── App.jsx                              # Root component — BrowserRouter + AppRoutes
│   ├── index.css                            # Global styles, CSS variables, Tailwind base, scrollbar
│   ├── main.jsx                             # Vite entry — Redux Provider + PersistGate + scroll listener
│   └── SessionManager.jsx                   # Renderless component — polls session expiry and auto-logs out
├── .env                                     # UAT / Development environment (loaded by `npm run dev`)
├── .gitignore                               # Git exclusion rules
├── PROJECT_STRUCTURE.md                     # this file (Architectural documentation)
├── README.md                                # Project overview and setup instructions
├── eslint.config.js                         # Linting configuration
├── index.html                               # Vite HTML entry point
├── package-lock.json                        # Project dependencies lock file
├── package.json                             # Project dependencies and scripts
└── vite.config.js                           # Vite build and dev server configuration
```
