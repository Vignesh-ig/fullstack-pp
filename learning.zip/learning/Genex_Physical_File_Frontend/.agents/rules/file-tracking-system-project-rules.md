---
trigger: always_on
---

Do analyze entire project before doing any update because if you think the possibility of reusing the existing component or function or hook then reuse it.
For resuable component - use or create from [ui](directory;file:///Users/cf28962/Desktop/vignesh/projects/physical_files/Genex_Physical_File_Frontend/src/components/ui) .

Creating any new styling, try to declare common styling in index.css at component layer and use that class in tags. To declare a style use. declare only reuseable styles in [index.css](file;file:///Users/cf28962/Desktop/vignesh/projects/physical_files/Genex_Physical_File_Frontend/src/index.css)

Do use validation schema in [configSchema.js](file;file:///Users/cf28962/Desktop/vignesh/projects/physical_files/Genex_Physical_File_Frontend/src/utils/schemas/configSchema.js)

Do add the helper function, common validation in [utils.js](file;file:///Users/cf28962/Desktop/vignesh/projects/physical_files/Genex_Physical_File_Frontend/src/utils/utils.js)

While declaring a new component, do add @param comment for each prop, maintain it as per the props in a component.

Add the necessary things into its related file and its folder properly. Do update each files, folder and update the related files properly.

Do not affect existing UI, UX, functionality and styling.
