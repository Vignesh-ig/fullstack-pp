import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const ALLOWED_HOSTS = ["stgvfphysicalfile.chola.murugappa.com"];
const ALLOWED_ORIGIN = "https://stgvfphysicalfile.chola.murugappa.com";
const API_BASE_ORIGIN = "https://lstgapig.chola.murugappa.com";
const DEVGENXAPI_ORIGIN = "https://devgenxapi.chola.murugappa.com";
const DMS_PDF_UPLOAD_URL_ORIGIN = "https://ustgapig.chola.murugappa.com";
const NODE_LOCAL_HOST = "http://localhost:3000";
const DOWNLOAD_IMAGE = "https://ustgapig.chola.murugappa.com";
const API_BASE_DOC_ADMIN_MODULE = "https://stgphysicalfilenodeapi.chola.murugappa.com"
// ─────────────────────────────────────────────────────────────────────────────
//  Content Security Policy
//
//  Rules are deliberately minimal:
//    • default-src 'self'      → blocks everything not explicitly allowed
//    • script-src 'self'       → no inline scripts, no eval (XSS hardening)
//    • style-src  'unsafe-inline' → TailwindCSS v4 injects <style> tags at
//                                   runtime; unsafe-inline is required for it
//    • img-src data:           → base64 images used by charts (nivo/pie)
//    • connect-src             → API calls must go only to allowed origin
//    • frame-ancestors 'none'  → prevents clickjacking (stronger than X-Frame-Options)
//    • object-src 'none'       → blocks Flash / plugins
//    • base-uri 'self'         → prevents base-tag hijacking
//    • form-action 'self'      → form submissions stay on-origin
//    • upgrade-insecure-requests → forces HTTP→HTTPS upgrade in browser
// ─────────────────────────────────────────────────────────────────────────────
const CSP = [
  "default-src 'self'",
  `script-src 'self' 'unsafe-inline' 'unsafe-eval' ${ALLOWED_ORIGIN}`,
  `style-src 'self' 'unsafe-inline'`,
  `img-src 'self' data: blob:`,
  `font-src 'self' data:`,
  `connect-src 'self' ${ALLOWED_ORIGIN} ${API_BASE_ORIGIN} ${DEVGENXAPI_ORIGIN} ${DMS_PDF_UPLOAD_URL_ORIGIN} ${NODE_LOCAL_HOST} ${DOWNLOAD_IMAGE} ${API_BASE_DOC_ADMIN_MODULE} ws: wss:`,
  `frame-src 'self' blob:`,
  `frame-src 'none'`,
  `frame-ancestors 'self' ${ALLOWED_ORIGIN}`,
  `object-src 'none'`,
  `base-uri 'self'`,
  `form-action 'self'`,
  `manifest-src 'self'`,
  `worker-src 'self' blob:`,
  // `upgrade-insecure-requests`,
]
  .join("; ")
  .trim();

// ─────────────────────────────────────────────────────────────────────────────
//  Security Headers
//
//  Applied on every response from the Vite dev server and the preview server.
//  In production (Nginx / Apache / CDN) these same headers must also be set
//  at the reverse-proxy level.
//
//    • Content-Security-Policy          → XSS / phishing / injection protection (built above)
//    • Access-Control-Allow-Origin      → CORS — only the allowed origin may read responses
//    • Access-Control-Allow-Methods     → permitted HTTP verbs
//    • Access-Control-Allow-Headers     → permitted request headers
//    • Access-Control-Allow-Credentials → allow cookies / auth headers cross-origin
//    • Access-Control-Max-Age           → preflight cache — 10 min
//    • Strict-Transport-Security        → forces HTTPS for 1 year; subdomains included; preload eligible
//    • X-Frame-Options                  → clickjacking protection (legacy-browser fallback for frame-ancestors)
//    • X-Content-Type-Options           → blocks MIME-type sniffing
//    • X-XSS-Protection                 → XSS auditor for legacy browsers (IE / Chrome < 78)
//    • Referrer-Policy                  → sends full URL on same-origin only; strips on cross-origin
//    • Permissions-Policy               → camera, mic, geolocation, payment blocked;
//                                         usb=(self) enabled for barcode scanner (WebUSB API);
//                                         display-capture blocked; clipboard scoped to self
//    • Cross-Origin-Opener-Policy       → isolates browsing context (Spectre / side-channel hardening)
//    • Cross-Origin-Embedder-Policy     → requires CORP on sub-resources
//    • Cross-Origin-Resource-Policy     → prevents cross-origin resource reads
// ─────────────────────────────────────────────────────────────────────────────
const SECURITY_HEADERS = {
  "Content-Security-Policy": CSP,
  "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, X-Requested-With",
  "Access-Control-Allow-Credentials": "true",
  "Access-Control-Max-Age": "600",
  "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",
  "X-Frame-Options": "DENY",
  "X-Content-Type-Options": "nosniff",
  "X-XSS-Protection": "1; mode=block",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Permissions-Policy": [
    "camera=()",
    "microphone=()",
    "geolocation=()",
    "payment=()",
    "usb=(self)",
    "fullscreen=(self)",
    "display-capture=()",
    "clipboard-read=()",
    "clipboard-write=(self)",
  ].join(", "),
  "Cross-Origin-Opener-Policy": "same-origin",
  "Cross-Origin-Embedder-Policy": "require-corp",
  "Cross-Origin-Resource-Policy": "same-origin",
};

function securityHeadersPlugin() {
  return {
    name: "security-headers",
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        Object.entries(SECURITY_HEADERS).forEach(([key, value]) => {
          res.setHeader(key, value);
        });
        next();
      });
    },
    configurePreviewServer(server) {
      server.middlewares.use((req, res, next) => {
        Object.entries(SECURITY_HEADERS).forEach(([key, value]) => {
          res.setHeader(key, value);
        });
        next();
      });
    },
  };
}

const BUILD_MANUAL_CHUNKS_MAP = {
  "vendor-react": ["react", "react-dom", "react-router-dom"],
  "vendor-redux": ["@reduxjs/toolkit", "react-redux", "redux-persist"],
  "vendor-charts": ["@nivo/pie"],
  "vendor-forms": ["react-hook-form", "@hookform/resolvers", "zod"],
  "vendor-utils": ["axios", "crypto-js"],
};

/**
 * manualChunks must be a function in rolldown (Vite 8 / rolldown bundler).
 * Maps each module id to a named chunk if it belongs to one of the vendor groups.
 *
 * @param {string} id - Module path/id
 * @returns {string|undefined} Chunk name, or undefined to let rolldown decide.
 */
const manualChunksFn = (id) => {
  for (const [chunkName, packages] of Object.entries(BUILD_MANUAL_CHUNKS_MAP)) {
    if (packages.some((pkg) => id.includes(`/node_modules/${pkg}`))) {
      return chunkName;
    }
  }
};

export default defineConfig({
  plugins: [react(), tailwindcss(), securityHeadersPlugin()],
  server: {
    host: true,
    allowedHosts: ALLOWED_HOSTS,
    hmr: {
      host: "stgvfphysicalfile.chola.murugappa.com", // domain the BROWSER should connect to
      protocol: "wss", // since your domain is HTTPS, HMR socket must be wss, not ws
      clientPort: 443, // browser connects on 443 (HTTPS default), even though Vite listens on 5173 internally
    },
  },
  preview: {
    allowedHosts: ALLOWED_HOSTS,
  },
  build: {
    target: "esnext",
    minify: "oxc",
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        manualChunks: manualChunksFn,
      },
    },
  },
});
