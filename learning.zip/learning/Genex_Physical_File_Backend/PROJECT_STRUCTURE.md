# Backend Project Structure

```
Genex_Physical_File_Backend/                                                         # Root directory of the backend application
├── src/                                                                             # Source code directory
│   ├── main/                                                                        # Main application code
│   │   ├── java/                                                                    # Java source files
│   │   │   └── com/                                                                 # Top-level package
│   │   │       └── chola/                                                           # Organization package
│   │   │           └── physical_file/                                               # Root package for the Physical File application
│   │   │               ├── auditLog/                                                # Module containing auditLog related components
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   └── AuditLogController.java                          # REST endpoint handlers for AuditLog
│   │   │               │   ├── customAnnotation/                                    # Module containing customAnnotation related components
│   │   │               │   │   └── AuditLog.java                                    # File used for application logic/data
│   │   │               │   ├── entity/                                              # JPA Entities representing database tables
│   │   │               │   │   └── AuditLogEntity.java                              # JPA entity mapping for AuditLog
│   │   │               │   ├── projection/                                          # Spring Data JPA projections for custom queries
│   │   │               │   │   └── AuditLogProjection.java                          # Database projection for specific AuditLog fields
│   │   │               │   ├── repository/                                          # Data Access Object (DAO) interfaces for database operations
│   │   │               │   │   └── AuditLogRepository.java                          # Database access interface for AuditLog
│   │   │               │   └── service/                                             # Service interfaces defining business logic
│   │   │               │       ├── impl/                                            # Implementation of service interfaces
│   │   │               │       │   └── AuditLogServiceImpl.java                     # Business logic implementation for AuditLog
│   │   │               │       └── AuditLogService.java                             # Business logic interface for AuditLog
│   │   │               ├── branch/                                                  # Module containing branch related components
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   └── branchMasterController.java                      # REST endpoint handlers for branchMaster
│   │   │               │   ├── dto/                                                 # Data Transfer Objects for API requests and responses
│   │   │               │   │   └── BranchUserAssignedDto.java                       # Data transfer object for BranchUserAssigned
│   │   │               │   ├── entity/                                              # JPA Entities representing database tables
│   │   │               │   │   └── BranchUserAssignedEntity.java                    # JPA entity mapping for BranchUserAssigned
│   │   │               │   ├── mapper/                                              # Object mapping interfaces (e.g., entity to DTO)
│   │   │               │   │   ├── BranchMasterMapper.java                          # Mapper for converting BranchMaster entity/dto
│   │   │               │   │   └── BranchUserAssignedMapper.java                    # Mapper for converting BranchUserAssigned entity/dto
│   │   │               │   ├── record/                                              # Java Records for immutable data carriers
│   │   │               │   │   ├── GenexAreaResponse.java                           # File used for application logic/data
│   │   │               │   │   ├── GenexBranchResponse.java                         # File used for application logic/data
│   │   │               │   │   ├── GenexPFBranchResponse.java                       # File used for application logic/data
│   │   │               │   │   ├── GenexRegionResponse.java                         # File used for application logic/data
│   │   │               │   │   └── GenexZoneResponse.java                           # File used for application logic/data
│   │   │               │   ├── repository/                                          # Data Access Object (DAO) interfaces for database operations
│   │   │               │   │   └── BranchAssignedRepository.java                    # Database access interface for BranchAssigned
│   │   │               │   └── service/                                             # Service interfaces defining business logic
│   │   │               │       ├── impl/                                            # Implementation of service interfaces
│   │   │               │       │   ├── BranchAssignedServiceImpl.java               # Business logic implementation for BranchAssigned
│   │   │               │       │   └── BranchMasterServiceImpl.java                 # Business logic implementation for BranchMaster
│   │   │               │       ├── BranchAssignedService.java                       # Business logic interface for BranchAssigned
│   │   │               │       └── BranchMasterService.java                         # Business logic interface for BranchMaster
│   │   │               ├── common/                                                  # Common classes used across the application
│   │   │               │   ├── aspect/                                              # Module containing aspect related components
│   │   │               │   │   ├── AuditAspect.java                                 # File used for application logic/data
│   │   │               │   │   └── ControllerLoggingAspect.java                     # File used for application logic/data
│   │   │               │   ├── config/                                              # Configuration classes for Spring Boot
│   │   │               │   │   ├── MsSqlConfig.java                                 # Configuration class for MsSql
│   │   │               │   │   ├── PostgresConfig.java                              # Configuration class for Postgres
│   │   │               │   │   └── RestClientConfig.java                            # Configuration class for RestClient
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   └── LeapStateMasterController.java                   # REST endpoint handlers for LeapStateMaster
│   │   │               │   ├── dto/                                                 # Data Transfer Objects for API requests and responses
│   │   │               │   │   ├── GenexPropertiesDto.java                          # Data transfer object for GenexProperties
│   │   │               │   │   ├── LeapPropertiesDto.java                           # Data transfer object for LeapProperties
│   │   │               │   │   └── PageResponseDto.java                             # Data transfer object for PageResponse
│   │   │               │   ├── enums/                                               # Module containing enums related components
│   │   │               │   │   ├── AppResponseCode.java                             # File used for application logic/data
│   │   │               │   │   ├── RackAllocationAction.java                        # File used for application logic/data
│   │   │               │   │   ├── ResponseMessage.java                             # File used for application logic/data
│   │   │               │   │   ├── RoleType.java                                    # File used for application logic/data
│   │   │               │   │   ├── StageEnum.java                                   # File used for application logic/data
│   │   │               │   │   └── StatusEnum.java                                  # File used for application logic/data
│   │   │               │   ├── exception/                                           # Custom exceptions and global exception handlers
│   │   │               │   │   ├── ExternalServiceException.java                    # Custom exception for ExternalService
│   │   │               │   │   ├── GlobalExceptionHandler.java                      # File used for application logic/data
│   │   │               │   │   ├── ResourceAlreadyExistsException.java              # Custom exception for ResourceAlreadyExists
│   │   │               │   │   ├── ResourceNotFoundException.java                   # Custom exception for ResourceNotFound
│   │   │               │   │   ├── UserAlreadyExistsException.java                  # Custom exception for UserAlreadyExists
│   │   │               │   │   └── UserNotFoundException.java                       # Custom exception for UserNotFound
│   │   │               │   ├── record/                                              # Java Records for immutable data carriers
│   │   │               │   │   ├── GenexDisbursementApiResponse.java                # File used for application logic/data
│   │   │               │   │   ├── GenexErrorResponse.java                          # File used for application logic/data
│   │   │               │   │   ├── GenexIntegrationApiResponse.java                 # File used for application logic/data
│   │   │               │   │   ├── GenexPhysicalResponse.java                       # File used for application logic/data
│   │   │               │   │   └── LeapVFAppDetailsResponse.java                    # File used for application logic/data
│   │   │               │   ├── security/                                            # Security configuration and utility classes
│   │   │               │   │   ├── CorsConfig.java                                  # Configuration class for Cors
│   │   │               │   │   └── SecurityConfig.java                              # Configuration class for Security
│   │   │               │   ├── service/                                             # Service interfaces defining business logic
│   │   │               │   │   ├── impl/                                            # Implementation of service interfaces
│   │   │               │   │   │   └── ExternalApiCallServiceImpl.java              # Business logic implementation for ExternalApiCall
│   │   │               │   │   └── ExternalApiCallService.java                      # Business logic interface for ExternalApiCall
│   │   │               │   └── util/                                                # Utility classes and helper methods
│   │   │               │       ├── CommonResponseUtil.java                          # File used for application logic/data
│   │   │               │       ├── Create.java                                      # File used for application logic/data
│   │   │               │       ├── ResponseUtil.java                                # File used for application logic/data
│   │   │               │       ├── StampStackCsvUtil.java                           # File used for application logic/data
│   │   │               │       └── Update.java                                      # File used for application logic/data
│   │   │               ├── dashboard/                                               # Module containing dashboard related components
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   └── DashboardController.java                         # REST endpoint handlers for Dashboard
│   │   │               │   ├── dto/                                                 # Data Transfer Objects for API requests and responses
│   │   │               │   │   └── DashboardDto.java                                # Data transfer object for Dashboard
│   │   │               │   ├── projection/                                          # Spring Data JPA projections for custom queries
│   │   │               │   │   └── DashboardStatusCountProjection.java              # Database projection for specific DashboardStatusCount fields
│   │   │               │   └── service/                                             # Service interfaces defining business logic
│   │   │               │       ├── impl/                                            # Implementation of service interfaces
│   │   │               │       │   └── DashboardServiceImpl.java                    # Business logic implementation for Dashboard
│   │   │               │       └── DashboardService.java                            # Business logic interface for Dashboard
│   │   │               ├── despatchSystems/                                         # Module containing despatchSystems related components
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   └── DespatchDetailsController.java                   # REST endpoint handlers for DespatchDetails
│   │   │               │   ├── dto/                                                 # Data Transfer Objects for API requests and responses
│   │   │               │   │   ├── DespatchCourierDto.java                          # Data transfer object for DespatchCourier
│   │   │               │   │   ├── DespatchDetailsDTO.java                          # Data transfer object for DespatchDetails
│   │   │               │   │   └── DespatchWithOriginDto.java                       # Data transfer object for DespatchWithOrigin
│   │   │               │   ├── entity/                                              # JPA Entities representing database tables
│   │   │               │   │   ├── DespatchCourierEntity.java                       # JPA entity mapping for DespatchCourier
│   │   │               │   │   ├── DespatchDetailsEntity.java                       # JPA entity mapping for DespatchDetails
│   │   │               │   │   └── DespatchTransactionEntity.java                   # JPA entity mapping for DespatchTransaction
│   │   │               │   ├── mapper/                                              # Object mapping interfaces (e.g., entity to DTO)
│   │   │               │   │   └── DespatchDetailsMapper.java                       # Mapper for converting DespatchDetails entity/dto
│   │   │               │   ├── projection/                                          # Spring Data JPA projections for custom queries
│   │   │               │   │   └── DpAgreementNoBasicDetailsProjection.java         # Database projection for specific DpAgreementNoBasicDetails fields
│   │   │               │   ├── records/                                             # Module containing records related components
│   │   │               │   │   └── GenexPFDetailsResponse.java                      # File used for application logic/data
│   │   │               │   ├── Repository/                                          # Data Access Object (DAO) interfaces for database operations
│   │   │               │   │   ├── projection/                                      # Spring Data JPA projections for custom queries
│   │   │               │   │   │   └── DespatchDetailsProjection.java               # Database projection for specific DespatchDetails fields
│   │   │               │   │   └── DespatchDetailsRepository.java                   # Database access interface for DespatchDetails
│   │   │               │   └── service/                                             # Service interfaces defining business logic
│   │   │               │       ├── impl/                                            # Implementation of service interfaces
│   │   │               │       │   └── DespatchDetailsServiceImpl.java              # Business logic implementation for DespatchDetails
│   │   │               │       └── DespatchDetailsService.java                      # Business logic interface for DespatchDetails
│   │   │               ├── fileTransaction/                                         # Module containing fileTransaction related components
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   └── TransactionsController.java                      # REST endpoint handlers for Transactions
│   │   │               │   ├── dto/                                                 # Data Transfer Objects for API requests and responses
│   │   │               │   │   ├── TransactionAppResponseDto.java                   # Data transfer object for TransactionAppResponse
│   │   │               │   │   ├── TransactionsDto.java                             # Data transfer object for Transactions
│   │   │               │   │   └── TransactionsHistoryDto.java                      # Data transfer object for TransactionsHistory
│   │   │               │   ├── entity/                                              # JPA Entities representing database tables
│   │   │               │   │   ├── TransactionsEntity.java                          # JPA entity mapping for Transactions
│   │   │               │   │   └── TransactionsHistoryEntity.java                   # JPA entity mapping for TransactionsHistory
│   │   │               │   ├── mapper/                                              # Object mapping interfaces (e.g., entity to DTO)
│   │   │               │   │   ├── TransactionsHistoryMapper.java                   # Mapper for converting TransactionsHistory entity/dto
│   │   │               │   │   └── TransactionsMapper.java                          # Mapper for converting Transactions entity/dto
│   │   │               │   ├── repository/                                          # Data Access Object (DAO) interfaces for database operations
│   │   │               │   │   ├── projection/                                      # Spring Data JPA projections for custom queries
│   │   │               │   │   │   ├── TransactionAppDetailsProjection.java         # Database projection for specific TransactionAppDetails fields
│   │   │               │   │   │   └── TransactionsHistoryProjection.java           # Database projection for specific TransactionsHistory fields
│   │   │               │   │   ├── TransactionsHistoryRepository.java               # Database access interface for TransactionsHistory
│   │   │               │   │   └── TransactionsRepository.java                      # Database access interface for Transactions
│   │   │               │   └── service/                                             # Service interfaces defining business logic
│   │   │               │       ├── impl/                                            # Implementation of service interfaces
│   │   │               │       │   ├── TransactionsHistoryServiceImpl.java          # Business logic implementation for TransactionsHistory
│   │   │               │       │   └── TransactionsServiceImpl.java                 # Business logic implementation for Transactions
│   │   │               │       ├── TransactionsHistoryService.java                  # Business logic interface for TransactionsHistory
│   │   │               │       └── TransactionsService.java                         # Business logic interface for Transactions
│   │   │               ├── query/                                                   # Module containing query related components
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   └── QueryMasterController.java                       # REST endpoint handlers for QueryMaster
│   │   │               │   ├── dto/                                                 # Data Transfer Objects for API requests and responses
│   │   │               │   │   └── QueryMasterDto.java                              # Data transfer object for QueryMaster
│   │   │               │   ├── entity/                                              # JPA Entities representing database tables
│   │   │               │   │   └── QueryMasterEntity.java                           # JPA entity mapping for QueryMaster
│   │   │               │   ├── mapper/                                              # Object mapping interfaces (e.g., entity to DTO)
│   │   │               │   │   └── QueryMasterMapper.java                           # Mapper for converting QueryMaster entity/dto
│   │   │               │   ├── repository/                                          # Data Access Object (DAO) interfaces for database operations
│   │   │               │   │   └── QueryMasterRepository.java                       # Database access interface for QueryMaster
│   │   │               │   └── service/                                             # Service interfaces defining business logic
│   │   │               │       ├── impl/                                            # Implementation of service interfaces
│   │   │               │       │   └── QueryMasterServiceImpl.java                  # Business logic implementation for QueryMaster
│   │   │               │       └── QueryMasterService.java                          # Business logic interface for QueryMaster
│   │   │               ├── rackAndUserAssigned/                                     # Module containing rackAndUserAssigned related components
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   ├── RackAssignedController.java                      # REST endpoint handlers for RackAssigned
│   │   │               │   │   └── RackController.java                              # REST endpoint handlers for Rack
│   │   │               │   ├── dto/                                                 # Data Transfer Objects for API requests and responses
│   │   │               │   │   ├── RackAssignedDto.java                             # Data transfer object for RackAssigned
│   │   │               │   │   ├── RackAssignedResponseDto.java                     # Data transfer object for RackAssignedResponse
│   │   │               │   │   └── RackDto.java                                     # Data transfer object for Rack
│   │   │               │   ├── entity/                                              # JPA Entities representing database tables
│   │   │               │   │   ├── RackAssignedEntity.java                          # JPA entity mapping for RackAssigned
│   │   │               │   │   └── RackEntity.java                                  # JPA entity mapping for Rack
│   │   │               │   ├── mapper/                                              # Object mapping interfaces (e.g., entity to DTO)
│   │   │               │   │   ├── RackAssignedMapper.java                          # Mapper for converting RackAssigned entity/dto
│   │   │               │   │   └── RackMapper.java                                  # Mapper for converting Rack entity/dto
│   │   │               │   ├── repository/                                          # Data Access Object (DAO) interfaces for database operations
│   │   │               │   │   ├── projection/                                      # Spring Data JPA projections for custom queries
│   │   │               │   │   │   └── RackAssignedProjection.java                  # Database projection for specific RackAssigned fields
│   │   │               │   │   ├── RackAssignedRepository.java                      # Database access interface for RackAssigned
│   │   │               │   │   └── RackRepository.java                              # Database access interface for Rack
│   │   │               │   └── service/                                             # Service interfaces defining business logic
│   │   │               │       ├── impl/                                            # Implementation of service interfaces
│   │   │               │       │   ├── RackAssignedServiceImpl.java                 # Business logic implementation for RackAssigned
│   │   │               │       │   └── RackServiceImpl.java                         # Business logic implementation for Rack
│   │   │               │       ├── RackAssignedService.java                         # Business logic interface for RackAssigned
│   │   │               │       └── RackService.java                                 # Business logic interface for Rack
│   │   │               ├── stage/                                                   # Module containing stage related components
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   └── StageController.java                             # REST endpoint handlers for Stage
│   │   │               │   ├── dto/                                                 # Data Transfer Objects for API requests and responses
│   │   │               │   │   └── StageDto.java                                    # Data transfer object for Stage
│   │   │               │   ├── entity/                                              # JPA Entities representing database tables
│   │   │               │   │   └── StageEntity.java                                 # JPA entity mapping for Stage
│   │   │               │   ├── mapper/                                              # Object mapping interfaces (e.g., entity to DTO)
│   │   │               │   │   └── StageMapper.java                                 # Mapper for converting Stage entity/dto
│   │   │               │   ├── repository/                                          # Data Access Object (DAO) interfaces for database operations
│   │   │               │   │   └── StageRepository.java                             # Database access interface for Stage
│   │   │               │   └── service/                                             # Service interfaces defining business logic
│   │   │               │       ├── impl/                                            # Implementation of service interfaces
│   │   │               │       │   └── StageServiceImpl.java                        # Business logic implementation for Stage
│   │   │               │       └── StageService.java                                # Business logic interface for Stage
│   │   │               ├── stamp/                                                   # Module containing stamp related components
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   ├── StampDenominationMasterController.java           # REST endpoint handlers for StampDenominationMaster
│   │   │               │   │   ├── StampMasterController.java                       # REST endpoint handlers for StampMaster
│   │   │               │   │   ├── StampStackMasterController.java                  # REST endpoint handlers for StampStackMaster
│   │   │               │   │   └── StampTypeMasterController.java                   # REST endpoint handlers for StampTypeMaster
│   │   │               │   ├── dto/                                                 # Data Transfer Objects for API requests and responses
│   │   │               │   │   ├── CsvParseResult.java                              # File used for application logic/data
│   │   │               │   │   ├── StampDenominationMasterDto.java                  # Data transfer object for StampDenominationMaster
│   │   │               │   │   ├── StampMasterDto.java                              # Data transfer object for StampMaster
│   │   │               │   │   ├── StampStackCsvResponse.java                       # File used for application logic/data
│   │   │               │   │   ├── StampStackMasterDto.java                         # Data transfer object for StampStackMaster
│   │   │               │   │   ├── StampTransactionAssignedDto.java                 # Data transfer object for StampTransactionAssigned
│   │   │               │   │   └── StampTypeMasterDto.java                          # Data transfer object for StampTypeMaster
│   │   │               │   ├── entity/                                              # JPA Entities representing database tables
│   │   │               │   │   ├── StampDenominationMasterEntity.java               # JPA entity mapping for StampDenominationMaster
│   │   │               │   │   ├── StampMasterEntity.java                           # JPA entity mapping for StampMaster
│   │   │               │   │   ├── StampStackMasterEntity.java                      # JPA entity mapping for StampStackMaster
│   │   │               │   │   ├── StampTransactionAssignedEntity.java              # JPA entity mapping for StampTransactionAssigned
│   │   │               │   │   └── StampTypeMasterEntity.java                       # JPA entity mapping for StampTypeMaster
│   │   │               │   ├── mapper/                                              # Object mapping interfaces (e.g., entity to DTO)
│   │   │               │   │   ├── StampDenominationMasterMapper.java               # Mapper for converting StampDenominationMaster entity/dto
│   │   │               │   │   ├── StampMasterMapper.java                           # Mapper for converting StampMaster entity/dto
│   │   │               │   │   ├── StampStackMasterMapper.java                      # Mapper for converting StampStackMaster entity/dto
│   │   │               │   │   ├── StampTransactionAssignedMapper.java              # Mapper for converting StampTransactionAssigned entity/dto
│   │   │               │   │   └── StampTypeMasterMapper.java                       # Mapper for converting StampTypeMaster entity/dto
│   │   │               │   ├── record/                                              # Java Records for immutable data carriers
│   │   │               │   │   └── LeapStateResponse.java                           # File used for application logic/data
│   │   │               │   ├── repository/                                          # Data Access Object (DAO) interfaces for database operations
│   │   │               │   │   ├── projection/                                      # Spring Data JPA projections for custom queries
│   │   │               │   │   │   ├── StampMasterProjection.java                   # Database projection for specific StampMaster fields
│   │   │               │   │   │   ├── StampStackCountProjection.java               # Database projection for specific StampStackCount fields
│   │   │               │   │   │   └── StampStackMasterProjection.java              # Database projection for specific StampStackMaster fields
│   │   │               │   │   ├── StampDenominationMasterRepository.java           # Database access interface for StampDenominationMaster
│   │   │               │   │   ├── StampMasterRepository.java                       # Database access interface for StampMaster
│   │   │               │   │   ├── StampStackMasterRepository.java                  # Database access interface for StampStackMaster
│   │   │               │   │   ├── StampTransactionAssignedRepository.java          # Database access interface for StampTransactionAssigned
│   │   │               │   │   └── StampTypeMasterRepository.java                   # Database access interface for StampTypeMaster
│   │   │               │   └── service/                                             # Service interfaces defining business logic
│   │   │               │       ├── impl/                                            # Implementation of service interfaces
│   │   │               │       │   ├── StampDenominationMasterServiceImpl.java      # Business logic implementation for StampDenominationMaster
│   │   │               │       │   ├── StampMasterServiceImpl.java                  # Business logic implementation for StampMaster
│   │   │               │       │   ├── StampStackMasterServiceImpl.java             # Business logic implementation for StampStackMaster
│   │   │               │       │   ├── StampTransactionAssignedServiceImpl.java     # Business logic implementation for StampTransactionAssigned
│   │   │               │       │   └── StampTypeMasterServiceImpl.java              # Business logic implementation for StampTypeMaster
│   │   │               │       ├── StampDenominationMasterService.java              # Business logic interface for StampDenominationMaster
│   │   │               │       ├── StampMasterService.java                          # Business logic interface for StampMaster
│   │   │               │       ├── StampStackMasterService.java                     # Business logic interface for StampStackMaster
│   │   │               │       ├── StampTransactionAssignedService.java             # Business logic interface for StampTransactionAssigned
│   │   │               │       └── StampTypeMasterService.java                      # Business logic interface for StampTypeMaster
│   │   │               ├── userManagement/                                          # Module containing userManagement related components
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   ├── PermissionController.java                        # REST endpoint handlers for Permission
│   │   │               │   │   ├── RoleController.java                              # REST endpoint handlers for Role
│   │   │               │   │   └── UserController.java                              # REST endpoint handlers for User
│   │   │               │   ├── dto/                                                 # Data Transfer Objects for API requests and responses
│   │   │               │   │   ├── PermissionDto.java                               # Data transfer object for Permission
│   │   │               │   │   ├── RoleDto.java                                     # Data transfer object for Role
│   │   │               │   │   ├── UserBasicDetailsDto.java                         # Data transfer object for UserBasicDetails
│   │   │               │   │   ├── UserDto.java                                     # Data transfer object for User
│   │   │               │   │   └── UserLogInRequestDto.java                         # Data transfer object for UserLogInRequest
│   │   │               │   ├── entity/                                              # JPA Entities representing database tables
│   │   │               │   │   ├── LogInHistoryEntity.java                          # JPA entity mapping for LogInHistory
│   │   │               │   │   ├── PermissionEntity.java                            # JPA entity mapping for Permission
│   │   │               │   │   ├── RoleEntity.java                                  # JPA entity mapping for Role
│   │   │               │   │   └── UserEntity.java                                  # JPA entity mapping for User
│   │   │               │   ├── mapper/                                              # Object mapping interfaces (e.g., entity to DTO)
│   │   │               │   │   ├── PermissionMapper.java                            # Mapper for converting Permission entity/dto
│   │   │               │   │   ├── RoleMapper.java                                  # Mapper for converting Role entity/dto
│   │   │               │   │   └── UserMapper.java                                  # Mapper for converting User entity/dto
│   │   │               │   ├── record/                                              # Java Records for immutable data carriers
│   │   │               │   │   └── GenexUsersResponse.java                          # File used for application logic/data
│   │   │               │   ├── repository/                                          # Data Access Object (DAO) interfaces for database operations
│   │   │               │   │   ├── projection/                                      # Spring Data JPA projections for custom queries
│   │   │               │   │   │   └── PermissionProjection.java                    # Database projection for specific Permission fields
│   │   │               │   │   ├── LogInHistoryRepository.java                      # Database access interface for LogInHistory
│   │   │               │   │   ├── PermissionRepository.java                        # Database access interface for Permission
│   │   │               │   │   ├── RoleRepository.java                              # Database access interface for Role
│   │   │               │   │   └── UserRepository.java                              # Database access interface for User
│   │   │               │   └── service/                                             # Service interfaces defining business logic
│   │   │               │       ├── impl/                                            # Implementation of service interfaces
│   │   │               │       │   ├── PermissionServiceImpl.java                   # Business logic implementation for Permission
│   │   │               │       │   ├── RoleServiceImpl.java                         # Business logic implementation for Role
│   │   │               │       │   └── UserServiceImpl.java                         # Business logic implementation for User
│   │   │               │       ├── PermissionService.java                           # Business logic interface for Permission
│   │   │               │       ├── RoleService.java                                 # Business logic interface for Role
│   │   │               │       └── UserService.java                                 # Business logic interface for User
│   │   │               ├── vault/                                                   # Module containing vault related components
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   └── VaultMasterController.java                       # REST endpoint handlers for VaultMaster
│   │   │               │   ├── dto/                                                 # Data Transfer Objects for API requests and responses
│   │   │               │   │   └── VaultMasterDto.java                              # Data transfer object for VaultMaster
│   │   │               │   ├── entity/                                              # JPA Entities representing database tables
│   │   │               │   │   └── VaultMasterEntity.java                           # JPA entity mapping for VaultMaster
│   │   │               │   ├── mapper/                                              # Object mapping interfaces (e.g., entity to DTO)
│   │   │               │   │   └── VaultMasterMapper.java                           # Mapper for converting VaultMaster entity/dto
│   │   │               │   ├── repository/                                          # Data Access Object (DAO) interfaces for database operations
│   │   │               │   │   └── VaultMasterRepository.java                       # Database access interface for VaultMaster
│   │   │               │   └── service/                                             # Service interfaces defining business logic
│   │   │               │       ├── impl/                                            # Implementation of service interfaces
│   │   │               │       │   └── VaultMasterServiceImpl.java                  # Business logic implementation for VaultMaster
│   │   │               │       └── VaultMasterService.java                          # Business logic interface for VaultMaster
│   │   │               ├── vendor/                                                  # Module containing vendor related components
│   │   │               │   ├── controller/                                          # REST API controllers for handling HTTP requests
│   │   │               │   │   └── VendorController.java                            # REST endpoint handlers for Vendor
│   │   │               │   ├── dto/                                                 # Data Transfer Objects for API requests and responses
│   │   │               │   │   └── VendorDto.java                                   # Data transfer object for Vendor
│   │   │               │   ├── entity/                                              # JPA Entities representing database tables
│   │   │               │   │   └── VendorEntity.java                                # JPA entity mapping for Vendor
│   │   │               │   ├── mapper/                                              # Object mapping interfaces (e.g., entity to DTO)
│   │   │               │   │   └── VendorMapper.java                                # Mapper for converting Vendor entity/dto
│   │   │               │   ├── repository/                                          # Data Access Object (DAO) interfaces for database operations
│   │   │               │   │   └── VendorRepository.java                            # Database access interface for Vendor
│   │   │               │   └── service/                                             # Service interfaces defining business logic
│   │   │               │       ├── impl/                                            # Implementation of service interfaces
│   │   │               │       │   └── VendorServiceImpl.java                       # Business logic implementation for Vendor
│   │   │               │       └── VendorService.java                               # Business logic interface for Vendor
│   │   │               └── PhysicalFileApplication.java                             # Spring Boot main application entry point
│   │   └── resources/                                                               # Application resources and properties files
│   │       ├── application-dev.properties                                           # Configuration properties for application-dev environment
│   │       ├── application-local.properties                                         # Configuration properties for application-local environment
│   │       ├── application-prod.properties                                          # Configuration properties for application-prod environment
│   │       ├── application-uat.properties                                           # Configuration properties for application-uat environment
│   │       └── application.properties                                               # Configuration properties for application environment
│   └── test/                                                                        # Test source code directory
│       ├── java/                                                                    # Java source files
│       │   └── com/                                                                 # Top-level package
│       │       └── chola/                                                           # Organization package
│       │           └── physical_file/                                               # Root package for the Physical File application
│       │               └── PhysicalFileApplicationTests.java                        # Application context load tests
│       └── resources/                                                               # Application resources and properties files
│           └── schema.sql                                                           # SQL script file
├── mvnw                                                                             # Maven wrapper script
├── mvnw.cmd                                                                         # Maven wrapper script
├── physical.txt                                                                     # File used for application logic/data
└── pom.xml                                                                          # Maven project object model configuration
```
