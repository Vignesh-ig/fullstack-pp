package com.chola.physical_file;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
//@Disabled
@ActiveProfiles("test")
class PhysicalFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
