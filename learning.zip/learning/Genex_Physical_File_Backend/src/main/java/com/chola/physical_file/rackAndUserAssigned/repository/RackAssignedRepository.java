package com.chola.physical_file.rackAndUserAssigned.repository;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.rackAndUserAssigned.entity.RackAssignedEntity;
import com.chola.physical_file.rackAndUserAssigned.repository.projection.AllocationStatusCountProjection;
import com.chola.physical_file.rackAndUserAssigned.repository.projection.RackAssignedProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

@SuppressWarnings("all")
@Repository
public interface RackAssignedRepository extends JpaRepository<RackAssignedEntity, UUID>, JpaSpecificationExecutor<RackAssignedEntity> {

    @Query(value = """
             SELECT r.appNo
             FROM RackAssignedEntity r
             WHERE r.appNo IN :appNos
            """)
    List<String> findExistingAppNos(@Param("appNos") List<String> appNos);

    List<RackAssignedEntity> findByAppNoIn(Collection<String> appNos);

    @Query(
            value = """
                     SELECT
                         r.rackAssignedId AS rackAssignedId,
                         r.appNo AS appNo,
                         r.aggNo AS aggNo,
                         r.barcode AS barcode,
                         r.assignedStatus AS assignedStatus,
                          r.customerName As customerName, 
                          r.businessDate AS businessDate, 
                          r.fileType as fileType,
                          r.createdDate AS createdDate,
                          r.modifiedDate AS modifiedDate,
                    
                         rk.rackId AS rackId,
                         rk.vaultName as vaultName,
                         rk.rackName AS rackName,
                         rk.rackPosition AS rackPosition,
                         rk.rackStatus AS rackStatus,
                         rk.rackAppCount AS rackAppCount,
                    
                         created.userId AS empUserId,
                         created.userName AS empUserName,
                         created.userEmail AS empUserEmail,
                         created.userEmployeeCode AS empUserEmployeeCode,
                    
                         assigned.userId AS assignedUserId,
                         assigned.userName AS assignedUserName,
                         assigned.userEmail AS assignedUserEmail,
                         assigned.userEmployeeCode AS assignedUserEmployeeCode
                    
                     FROM RackAssignedEntity r
                    
                     LEFT JOIN RackEntity rk
                         ON rk.rackId = r.rack
                    
                     LEFT JOIN UserEntity created
                         ON created.userId = r.createdBy
                    
                     LEFT JOIN UserEntity assigned
                         ON assigned.userId = r.assignedUser
                    
                     WHERE
                          (:assignedUsers IS NULL OR r.assignedUser IN :assignedUsers)
                     AND
                         (:assignedRack IS NULL OR r.rack = :assignedRack)
                     AND
                         (:assignedStatus IS NULL OR r.assignedStatus = :assignedStatus)
                     AND
                         (
                           :userAssigned IS NULL
                           OR (:userAssigned = TRUE AND r.assignedUser IS NOT NULL)
                           OR (:userAssigned = FALSE AND r.assignedUser IS NULL)
                         )
                     AND
                         (
                             :appNoOrAggNo IS NULL
                             OR r.appNo = :appNoOrAggNo
                             OR r.aggNo = :appNoOrAggNo
                         )
                     AND (
                        :likeAppNoOrBarcode IS NULL
                        OR :likeAppNoOrBarcode = ''
                        OR LOWER(r.appNo) LIKE LOWER(CONCAT('%', :likeAppNoOrBarcode, '%'))
                        OR LOWER(r.barcode) LIKE LOWER(CONCAT('%', :likeAppNoOrBarcode, '%'))
                    )
                    AND (
                     :rackAssignedId IS NULL
                     OR r.rackAssignedId = :rackAssignedId
                    )
                      AND (
                         CAST(:startDate AS timestamp) IS NULL
                         OR r.createdDate >= :startDate
                       )
                       AND (
                         CAST(:endDate AS timestamp) IS NULL
                         OR r.createdDate < :endDate
                       )
                    """,

            countQuery = """
                     SELECT COUNT(r)
                     FROM RackAssignedEntity r
                     WHERE
                          (:assignedUsers IS NULL OR r.assignedUser IN :assignedUsers)
                     AND
                         (:assignedRack IS NULL OR r.rack = :assignedRack)
                     AND
                         (:assignedStatus IS NULL OR r.assignedStatus = :assignedStatus)
                     AND
                         (
                           :userAssigned IS NULL
                           OR (:userAssigned = TRUE AND r.assignedUser IS NOT NULL)
                           OR (:userAssigned = FALSE AND r.assignedUser IS NULL)
                         )
                     AND
                         (
                             :appNoOrAggNo IS NULL
                             OR r.appNo = :appNoOrAggNo
                             OR r.aggNo = :appNoOrAggNo
                         )
                     AND (
                        :likeAppNoOrBarcode IS NULL
                        OR :likeAppNoOrBarcode = ''
                        OR LOWER(r.appNo) LIKE LOWER(CONCAT('%', :likeAppNoOrBarcode, '%'))
                        OR LOWER(r.barcode) LIKE LOWER(CONCAT('%', :likeAppNoOrBarcode, '%'))
                    )
                    AND (
                     :rackAssignedId IS NULL
                     OR r.rackAssignedId = :rackAssignedId
                    )
                     AND (
                            CAST(:startDate AS timestamp) IS NULL
                            OR r.createdDate >= :startDate
                          )
                      AND (
                            CAST(:endDate AS timestamp) IS NULL
                            OR r.createdDate < :endDate
                          )
                    """
    )
    Page<RackAssignedProjection> findAllRackAssigned(@Param("assignedUsers") List<UUID> assignedUsers, @Param("assignedRack") UUID assignedRack, @Param("assignedStatus") StatusEnum assignedStatus, @Param("userAssigned") Boolean userAssigned, @Param("appNoOrAggNo") String appNoOrAggNo, @Param("likeAppNoOrBarcode") String likeAppNoOrBarcode, @Param("rackAssignedId") UUID rackAssignedId, @Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate, Pageable pageable);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("""
            UPDATE RackAssignedEntity r
            SET r.assignedStatus = :status, r.modifiedBy = :modifiedBy, r.modifiedDate = CURRENT_TIMESTAMP
            WHERE r.appNo IN :rackAppNos AND r.assignedStatus <> :status
            """)
    void bulkUpdateRackAssignedStatus(@Param("rackAppNos") List<String> rackAppNos, @Param("status") StatusEnum status, @Param("modifiedBy") UUID modifiedBy);

    @Query("""
            SELECT
                COUNT(r) AS totalApps,
            
                SUM(
                    CASE
                        WHEN r.assignedUser IS NOT NULL
                         AND r.assignedStatus = com.chola.physical_file.common.enums.StatusEnum.PENDING
                        THEN 1
                        ELSE 0
                    END
                ) AS pendingApps,
            
                SUM(
                    CASE
                        WHEN r.assignedUser IS NOT NULL
                         AND r.assignedStatus = com.chola.physical_file.common.enums.StatusEnum.IN_PROCESS
                        THEN 1
                        ELSE 0
                    END
                ) AS inProcessApps,
            
                SUM(
                    CASE
                        WHEN r.assignedUser IS NOT NULL
                         AND r.assignedStatus = com.chola.physical_file.common.enums.StatusEnum.COMPLETED
                        THEN 1
                        ELSE 0
                    END
                ) AS completedApps
            
            FROM RackAssignedEntity r
            
             WHERE r.assignedUser IS NOT NULL
             AND (:assignedUser IS NULL OR r.assignedUser = :assignedUser)
            """)
    AllocationStatusCountProjection getAllocationStatusCounts(@Param("assignedUser") UUID assignedUser);

}