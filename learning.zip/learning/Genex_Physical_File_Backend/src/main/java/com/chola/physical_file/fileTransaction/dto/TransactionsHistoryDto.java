package com.chola.physical_file.fileTransaction.dto;

import com.chola.physical_file.userManagement.dto.UserBasicDetailsDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionsHistoryDto {

    private UUID transactionsHistoryId;

    private String appNo;

    private String remarks;

    private UUID rackAssignedId;

    private Long leadId;

    private UUID stageId;
    private String stageName;

    private UUID queryId;
    private String queryName;

    private UUID transactionId;

    private UserBasicDetailsDto assignedToUserDto;

    private UserBasicDetailsDto createdByUserDto;

    private UUID assignedTo;

    private UUID createdBy;

    private LocalDateTime createdDate;
}