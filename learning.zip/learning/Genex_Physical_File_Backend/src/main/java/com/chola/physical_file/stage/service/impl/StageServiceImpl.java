package com.chola.physical_file.stage.service.impl;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.StageEnum;
import com.chola.physical_file.stage.dto.StageDto;
import com.chola.physical_file.stage.entity.StageEntity;
import com.chola.physical_file.stage.mapper.StageMapper;
import com.chola.physical_file.stage.repository.StageRepository;
import com.chola.physical_file.stage.service.StageService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class StageServiceImpl implements StageService {

    private final StageRepository stageRepository;
    private final StageMapper stageMapper;

    @Override
    @Transactional(readOnly = true)
    public PageResponseDto getAllStages(Integer pageNumber, Integer pageSize, List<StageEnum> excludeStagesSearch, List<StageEnum> includeStagesSearch) {
        PageResponseDto pageResponseDto = new PageResponseDto();
        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "createdDate")
        );
        excludeStagesSearch = (excludeStagesSearch == null || excludeStagesSearch.isEmpty()) ? null : excludeStagesSearch;
        includeStagesSearch = (includeStagesSearch == null || includeStagesSearch.isEmpty()) ? null : includeStagesSearch;
        Page<StageEntity> pageResponse = stageRepository.findStages(excludeStagesSearch, includeStagesSearch, pageable);
        List<StageDto> rackDtoList = stageMapper.toDtos(pageResponse.getContent());
        pageResponseDto.setData(rackDtoList);
        pageResponseDto.setCurrentPage(pageResponse.getNumber() + 1);
        pageResponseDto.setTotalItems((int) pageResponse.getTotalElements());
        pageResponseDto.setTotalPages(pageResponse.getTotalPages());
        pageResponseDto.setHasNextPage(pageResponse.hasNext());
        pageResponseDto.setHasPreviousPage(pageResponse.hasPrevious());
        return pageResponseDto;
    }

    @Override
    public UUID getStageId(StageEnum stageEnum) {
        return stageRepository.findByStageId(stageEnum);
    }
}