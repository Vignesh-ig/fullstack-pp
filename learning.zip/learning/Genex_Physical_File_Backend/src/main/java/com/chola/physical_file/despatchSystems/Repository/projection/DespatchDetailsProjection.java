package com.chola.physical_file.despatchSystems.Repository.projection;

import com.chola.physical_file.despatchSystems.entity.DespatchDetailsEntity;
import com.chola.physical_file.despatchSystems.projection.DpAgreementNoBasicDetailsProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface DespatchDetailsProjection extends JpaRepository<DespatchDetailsEntity, Integer> {

    @Query(value = """
        SELECT
            d.dp_AgreementNo AS dpAgreementNo,
            d.Dp_CourierNo AS dpCourierNo,
            d.dp_CreatedDate AS dpCreatedDate,
            c.Dp_Courier_Id AS dpCourierId,
            c.Dp_Courier_Name AS dpCourierName
        FROM dbo.Despatch_Detail_T d
        LEFT JOIN dbo.Depatch_CourierMaster_Tb c
               ON c.Dp_Courier_Id = d.Dp_CourierName
        WHERE d.dp_AgreementNo = :dpAgreementNo
        """,
            nativeQuery = true)
    Page<DpAgreementNoBasicDetailsProjection> findByDpAgreementNo(@Param("dpAgreementNo") String dpAgreementNo, Pageable pageable);
}
