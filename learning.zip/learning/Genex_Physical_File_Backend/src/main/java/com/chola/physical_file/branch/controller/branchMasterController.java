package com.chola.physical_file.branch.controller;

import com.chola.physical_file.branch.service.BranchMasterService;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/branch")
@Tag(name = "Branch Master Details", description = "APIs to fetch Branch master details")
public class branchMasterController {

    private final BranchMasterService branchMasterService;

    @GetMapping("/zones")
    @Operation(summary = "Get all zones", description = "Fetch all available zones.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Zones fetched successfully")
    })
    public ResponseEntity<CommonResponseUtil> getAllZones() {

        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success("Zones fetched successfully", HttpStatus.OK, branchMasterService.getAllZones()));
    }

    @GetMapping("/regions")
    @Operation(summary = "Get regions by zone", description = "Fetch regions for the given zone.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Regions fetched successfully")
    })
    public ResponseEntity<CommonResponseUtil> getRegionsByZoneId(
            @Parameter(description = "Zone Id", example = "1")
            @RequestParam("zoneId")
            @NotBlank(message = "Zone Id is required")
            String zoneId) {

        return ResponseEntity.status(HttpStatus.OK).body(ResponseUtil.success("Regions fetched successfully", HttpStatus.OK, branchMasterService.getRegionsByZoneId(zoneId)));
    }

    @GetMapping("/areas")
    @Operation(summary = "Get areas by region", description = "Fetch areas for the given region.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Areas fetched successfully")
    })
    public ResponseEntity<CommonResponseUtil> getAreasByRegionId(
            @Parameter(description = "Region Id", example = "132")
            @RequestParam("regionId")
            @NotBlank(message = "Region Id is required")
            String regionId) {

        return ResponseEntity.status(HttpStatus.OK).body(ResponseUtil.success("Areas fetched successfully", HttpStatus.OK, branchMasterService.getAreasByRegionId(regionId)));
    }

    @GetMapping("/branches")
    @Operation(summary = "Get branches by area", description = "Fetch branches for the given area.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Branches fetched successfully")
    })
    public ResponseEntity<CommonResponseUtil> getBranchesByAreaId(
            @Parameter(description = "Area Id", example = "590")
            @RequestParam("areaId")
            @NotBlank(message = "Area Id is required")
            String areaId) {

        return ResponseEntity.status(HttpStatus.OK).body(ResponseUtil.success("Branches fetched successfully", HttpStatus.OK, branchMasterService.getBranchesByAreaId(areaId)));
    }

}