package com.chola.physical_file.userManagement.service;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.userManagement.dto.PermissionDto;

import java.util.List;
import java.util.UUID;

public interface PermissionService {
    PageResponseDto getAllPermissions(Integer pageNumber, Integer pageSize, UUID role, String likePermissionName, UUID uniquePermissionsToRole);

    void createPermissionRecords(List<PermissionDto> permissionDto);

    void deletePermission(List<UUID> permissionIds);
}