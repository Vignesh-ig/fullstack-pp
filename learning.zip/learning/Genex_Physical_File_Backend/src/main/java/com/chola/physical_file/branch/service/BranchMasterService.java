package com.chola.physical_file.branch.service;

import com.chola.physical_file.branch.record.*;

import java.util.List;

public interface BranchMasterService {

    List<GenexPFBranchResponse> findAllById(List<String> branchIds);

    List<GenexZoneResponse> getAllZones();

    List<GenexRegionResponse> getRegionsByZoneId(String zoneId);

    List<GenexAreaResponse> getAreasByRegionId(String regionId);

    List<GenexBranchResponse> getBranchesByAreaId(String areaId);
}