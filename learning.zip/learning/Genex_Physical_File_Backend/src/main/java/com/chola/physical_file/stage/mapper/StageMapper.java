package com.chola.physical_file.stage.mapper;

import com.chola.physical_file.stage.dto.StageDto;
import com.chola.physical_file.stage.entity.StageEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class StageMapper {

    public StageDto entityToDto(StageEntity stageEntity) {

        if (stageEntity == null) {
            return null;
        }

        return StageDto.builder()
                .stageId(stageEntity.getStageId())
                .stageName(stageEntity.getStageName())
                .createdBy(stageEntity.getCreatedBy())
                .createdDate(stageEntity.getCreatedDate())
                .modifiedBy(stageEntity.getModifiedBy())
                .modifiedDate(stageEntity.getModifiedDate())
                .build();
    }

    public StageEntity dtoToEntity(StageDto stageDto) {

        if (stageDto == null) {
            return null;
        }

        return StageEntity.builder()
                .stageId(stageDto.getStageId())
                .stageName(stageDto.getStageName())
                .createdBy(stageDto.getCreatedBy())
                .createdDate(stageDto.getCreatedDate())
                .modifiedBy(stageDto.getModifiedBy())
                .modifiedDate(stageDto.getModifiedDate())
                .build();
    }

    public List<StageDto> toDtos(List<StageEntity> stageEntityList) {

        return stageEntityList.stream()
                .map(this::entityToDto)
                .toList();
    }
}