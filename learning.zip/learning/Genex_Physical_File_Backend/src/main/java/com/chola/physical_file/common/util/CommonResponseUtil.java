package com.chola.physical_file.common.util;

import com.chola.physical_file.common.enums.AppResponseCode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CommonResponseUtil<T> {
    private String message;
    private AppResponseCode appResponseCode;
    private HttpStatus httpStatus;
    private Integer code;
    private T data;

}
