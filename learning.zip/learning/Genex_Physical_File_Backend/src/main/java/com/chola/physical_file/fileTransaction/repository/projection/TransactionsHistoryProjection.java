package com.chola.physical_file.fileTransaction.repository.projection;

import com.chola.physical_file.common.enums.StageEnum;
import com.chola.physical_file.common.enums.StatusEnum;

import java.time.LocalDateTime;
import java.util.UUID;

public interface TransactionsHistoryProjection {
    UUID getTransactionsHistoryId();
    String getAppNo();
    String getRemarks();
    LocalDateTime getCreatedDate();
    // Assigned To User
    UUID getAssignedToUserId();
    String getAssignedToUserName();
    String getAssignedToUserEmployeeCode();
    String getAssignedToUserEmail();
    // Created By User
    UUID getCreatedByUserId();
    String getCreatedByUserName();
    String getCreatedByEmployeeCode();
    String getCreatedByUserEmail();
    // Stage
    UUID getStageId();
    StageEnum getStageName();

    // query
    UUID getQueryId();

    StatusEnum getQueryName();

    UUID getTransactionId();
}