package com.chola.physical_file.stamp.mapper;

import com.chola.physical_file.stamp.dto.StampDenominationMasterDto;
import com.chola.physical_file.stamp.entity.StampDenominationMasterEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class StampDenominationMasterMapper {


    public StampDenominationMasterDto entityToDto(StampDenominationMasterEntity stampDenominationMasterEntity) {

        if (stampDenominationMasterEntity == null) {
            return null;
        }

        return StampDenominationMasterDto.builder()
                .stampDenominationMasterId(stampDenominationMasterEntity.getStampDenominationMasterId())
                .stampDenominationNo(stampDenominationMasterEntity.getStampDenominationNo())
                .createdBy(stampDenominationMasterEntity.getCreatedBy())
                .createdDate(stampDenominationMasterEntity.getCreatedDate())
                .modifiedBy(stampDenominationMasterEntity.getModifiedBy())
                .modifiedDate(stampDenominationMasterEntity.getModifiedDate())
                .build();
    }

    public StampDenominationMasterEntity dtoToEntity(StampDenominationMasterDto stampDenominationMasterDto) {

        if (stampDenominationMasterDto == null) {
            return null;
        }

        return StampDenominationMasterEntity.builder()
                .stampDenominationMasterId(stampDenominationMasterDto.getStampDenominationMasterId())
                .stampDenominationNo(stampDenominationMasterDto.getStampDenominationNo())
                .createdBy(stampDenominationMasterDto.getCreatedBy())
                .createdDate(stampDenominationMasterDto.getCreatedDate())
                .modifiedBy(stampDenominationMasterDto.getModifiedBy())
                .modifiedDate(stampDenominationMasterDto.getModifiedDate())
                .build();
    }

    public List<StampDenominationMasterDto> toDtos(List<StampDenominationMasterEntity> stampDenoMasterEntities) {

        return stampDenoMasterEntities.stream()
                .map(this::entityToDto)
                .toList();
    }
}