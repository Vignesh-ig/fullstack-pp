package com.chola.physical_file.rackAndUserAssigned.service;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.rackAndUserAssigned.dto.RackDto;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public interface RackService {
    void createRack(RackDto rackDto);

    PageResponseDto getAllRacks(Integer pageNumber, Integer pageSize, String searchByVaultName,String searchByRackName, Boolean searchByRackStatus);

    void updateRack(RackDto rackDto);

    void deleteRacks(List<UUID> rackIds);

    void adjustRackCapacity(Map<UUID, Long> requestedRackCounts);
}