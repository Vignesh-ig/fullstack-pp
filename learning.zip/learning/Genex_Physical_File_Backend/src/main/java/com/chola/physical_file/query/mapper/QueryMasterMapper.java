package com.chola.physical_file.query.mapper;

import com.chola.physical_file.query.dto.QueryMasterDto;
import com.chola.physical_file.query.entity.QueryMasterEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class QueryMasterMapper {

    public QueryMasterDto entityToDto(QueryMasterEntity queryMasterEntity) {

        if (queryMasterEntity == null) {
            return null;
        }

        return QueryMasterDto.builder()
                .queriesId(queryMasterEntity.getQueriesId())
                .queryName(queryMasterEntity.getQueryName())
                .createdBy(queryMasterEntity.getCreatedBy())
                .createdDate(queryMasterEntity.getCreatedDate())
                .modifiedBy(queryMasterEntity.getModifiedBy())
                .modifiedDate(queryMasterEntity.getModifiedDate())
                .build();
    }

    public QueryMasterEntity dtoToEntity(QueryMasterDto queryMasterDto) {

        if (queryMasterDto == null) {
            return null;
        }

        return QueryMasterEntity.builder()
                .queryName(queryMasterDto.getQueryName())
                .createdBy(queryMasterDto.getCreatedBy())
                .createdDate(queryMasterDto.getCreatedDate())
                .modifiedBy(queryMasterDto.getModifiedBy())
                .modifiedDate(queryMasterDto.getModifiedDate())
                .build();
    }

    public List<QueryMasterDto> toDtos(List<QueryMasterEntity> queryEntities) {

        return queryEntities.stream()
                .map(this::entityToDto)
                .toList();
    }
}
