package com.chola.physical_file.common.config;

import jakarta.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = {
                "com.chola.physical_file.despatchSystems",
                "com.chola.physical_file.branchMaster"
        },
        entityManagerFactoryRef = "mssqlEntityManager",
        transactionManagerRef = "mssqlTransactionManager"
)
@Profile("!test")
public class MsSqlConfig {

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.mssql")
    public DataSource mssqlDataSource() {
        return DataSourceBuilder.create()
                .type(com.zaxxer.hikari.HikariDataSource.class)
                .build();
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean mssqlEntityManager(
            EntityManagerFactoryBuilder builder) {
        return builder
                .dataSource(mssqlDataSource())
                .packages("com.chola.physical_file.despatchSystems", "com.chola.physical_file.branchMaster")
                .persistenceUnit("mssql")
                .build();
    }

    @Bean
    public PlatformTransactionManager mssqlTransactionManager(
            @Qualifier("mssqlEntityManager") EntityManagerFactory emf) {
        return new JpaTransactionManager(emf);
    }
}
