package com.chola.physical_file.userManagement.service.impl;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.exception.ResourceAlreadyExistsException;
import com.chola.physical_file.userManagement.dto.RoleDto;
import com.chola.physical_file.userManagement.entity.RoleEntity;
import com.chola.physical_file.userManagement.mapper.RoleMapper;
import com.chola.physical_file.userManagement.repository.RoleRepository;
import com.chola.physical_file.userManagement.service.RoleService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class RoleServiceImpl implements RoleService {

    private final RoleRepository roleRepository;
    private final RoleMapper roleMapper;

    @Override
    @Transactional(readOnly = true)
    public PageResponseDto getAllRoles(Integer pageNumber, Integer pageSize) {
        PageResponseDto pageResponseDto = new PageResponseDto();
        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "createdDate")
        );
        Page<RoleEntity> roleEntities = roleRepository.findAll(pageable);
        List<RoleDto> permissionDtoList = roleMapper.toDtos(roleEntities.getContent());
        pageResponseDto.setData(permissionDtoList);
        pageResponseDto.setCurrentPage(roleEntities.getNumber() + 1);
        pageResponseDto.setTotalItems((int) roleEntities.getTotalElements());
        pageResponseDto.setTotalPages(roleEntities.getTotalPages());
        pageResponseDto.setHasNextPage(roleEntities.hasNext());
        pageResponseDto.setHasPreviousPage(roleEntities.hasPrevious());
        return pageResponseDto;
    }

    @Override
    @Transactional
    public void createRole(RoleDto roleDto) {
        if (roleRepository.existsByRoleNameIgnoreCase(roleDto.getRoleName())) {
            throw new ResourceAlreadyExistsException("Role with name " + roleDto.getRoleName() + " already exists.");
        }
        RoleEntity roleEntity = roleMapper.dtoToEntity(roleDto);
        roleRepository.save(roleEntity);
    }

    @Override
    @Transactional
    public void deleteRole(List<UUID> roleIds) {
        roleRepository.deleteAllByIdInBatch(roleIds);
    }
}
