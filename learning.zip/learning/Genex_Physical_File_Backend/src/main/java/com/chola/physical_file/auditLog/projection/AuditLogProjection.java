package com.chola.physical_file.auditLog.projection;

import java.time.LocalDateTime;
import java.util.UUID;

public interface AuditLogProjection {

    UUID getAuditId();

    UUID getUserId();

    String getUserName();

    String getUserEmail();

    String getUserEmployeeCode();

    String getUserRoleName();

    String getModuleName();

    String getActionName();

    String getEntityName();

    LocalDateTime getCreatedDate();

}