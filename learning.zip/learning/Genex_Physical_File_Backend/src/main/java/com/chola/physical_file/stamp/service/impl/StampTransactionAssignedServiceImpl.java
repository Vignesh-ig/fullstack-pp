package com.chola.physical_file.stamp.service.impl;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.stamp.dto.StampTransactionAssignedDto;
import com.chola.physical_file.stamp.entity.StampTransactionAssignedEntity;
import com.chola.physical_file.stamp.mapper.StampTransactionAssignedMapper;
import com.chola.physical_file.stamp.repository.StampStackMasterRepository;
import com.chola.physical_file.stamp.service.StampTransactionAssignedService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class StampTransactionAssignedServiceImpl implements StampTransactionAssignedService {
    private final StampTransactionAssignedMapper stampTransactionAssignedMapper;
    private final StampStackMasterRepository stampStackMasterRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Value("${records.bulk.batch-size:100}")
    private int batchSize;

    private void persistTransactionsInBatch(List<StampTransactionAssignedEntity> stampTransactionAssignedEntities) {

        int count = 0;

        for (StampTransactionAssignedEntity stampTransactionAssignedEntity : stampTransactionAssignedEntities) {

            if (stampTransactionAssignedEntity.getStampTransactionAssignedId() == null) {
                entityManager.persist(stampTransactionAssignedEntity);
            }

            if (++count % batchSize == 0) {
                entityManager.flush();
                entityManager.clear();
            }
        }

        entityManager.flush();
        entityManager.clear();
    }

    @Override
    public void createStampTransactionAssignments(List<StampTransactionAssignedDto> stampTransactionAssignedDtoList) {

        List<UUID> stampStackMasterIds = stampTransactionAssignedDtoList.stream().map(StampTransactionAssignedDto::getStampStackMasterId).toList();

        List<String> serialNumbers = stampStackMasterRepository.countByUsedRecords(stampStackMasterIds, StatusEnum.USED);

        if (!serialNumbers.isEmpty()) {
            throw new IllegalArgumentException(String.format("Some of the provided serial numbers are already used. Used serial numbers: %s", serialNumbers));
        }
        List<StampTransactionAssignedEntity> entitiesToPersist = new ArrayList<>();
        for (StampTransactionAssignedDto stampTransactionAssignedDto : stampTransactionAssignedDtoList) {

            StampTransactionAssignedEntity stampTransactionAssignedEntity = stampTransactionAssignedMapper.dtoToEntity(stampTransactionAssignedDto);

            entitiesToPersist.add(stampTransactionAssignedEntity);
        }
        persistTransactionsInBatch(entitiesToPersist);
    }
}