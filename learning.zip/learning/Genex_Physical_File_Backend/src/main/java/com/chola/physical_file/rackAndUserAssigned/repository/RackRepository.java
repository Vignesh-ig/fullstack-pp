package com.chola.physical_file.rackAndUserAssigned.repository;

import com.chola.physical_file.rackAndUserAssigned.entity.RackEntity;
import jakarta.persistence.LockModeType;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Repository
public interface RackRepository extends JpaRepository<RackEntity, UUID>, JpaSpecificationExecutor<RackEntity> {

    default Page<RackEntity> searchRacks(String searchByVaultName, String searchByRackName, Boolean searchByRackStatus, Pageable pageable) {

        Specification<RackEntity> specification =
                (root, query, criteriaBuilder) -> {

                    List<Predicate> predicates = new ArrayList<>();

                    // Search By Vault Name
                    if (searchByVaultName != null && !searchByVaultName.trim().isEmpty()) {
                        predicates.add(
                                criteriaBuilder.like(
                                        criteriaBuilder.lower(root.get("vaultName")),
                                        "%" + searchByVaultName.trim().toLowerCase() + "%"
                                )
                        );
                    }

                    // Search By Rack No
                    if (searchByRackName != null && !searchByRackName.trim().isEmpty()) {

                        predicates.add(
                                criteriaBuilder.like(
                                        criteriaBuilder.lower(root.get("rackName")),
                                        "%" + searchByRackName.trim().toLowerCase() + "%"
                                )
                        );
                    }

                    // Search By Rack Status
                    if (searchByRackStatus != null) {

                        predicates.add(criteriaBuilder.equal(root.get("rackStatus"), searchByRackStatus));
                    }

                    return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
                };

        return findAll(specification, pageable);
    }

    /*
     * PESSIMISTIC LOCK
     * Prevents concurrent updates on same rack rows
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("""
            SELECT r
            FROM RackEntity r
            WHERE r.rackId IN :rackIds
            """)
    List<RackEntity> findAllByRackIdsForUpdate(@Param("rackIds") Set<UUID> rackIds);

    boolean existsByVaultNameAndRackNameAndRackPosition(String vaultName, String rackName, String rackPosition);
}