package com.chola.physical_file.common.record;

import java.time.OffsetDateTime;
import java.util.List;

public record GenexPhysicalResponse<T>(
        OffsetDateTime currentDatetime,
        String status,
        String message,
        List<T> data
) { }