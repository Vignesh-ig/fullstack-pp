package com.chola.physical_file.stamp.dto;

import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StampDenominationMasterDto {

    private UUID stampDenominationMasterId;

    private Integer stampDenominationNo;

    private UUID createdBy;

    private LocalDateTime createdDate;

    private UUID modifiedBy;

    private LocalDateTime modifiedDate;
}