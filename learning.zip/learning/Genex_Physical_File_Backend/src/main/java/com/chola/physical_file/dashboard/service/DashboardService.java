package com.chola.physical_file.dashboard.service;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.dashboard.dto.DashboardDto;

import java.util.List;
import java.util.UUID;

public interface DashboardService {
    DashboardDto getDashboardAppCount(UUID assignedUser, StatusEnum overview, List<String> states);
}