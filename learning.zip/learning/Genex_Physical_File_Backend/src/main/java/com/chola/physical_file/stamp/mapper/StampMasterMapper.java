package com.chola.physical_file.stamp.mapper;

import com.chola.physical_file.stamp.dto.StampMasterDto;
import com.chola.physical_file.stamp.entity.StampMasterEntity;
import com.chola.physical_file.stamp.repository.projection.StampMasterProjection;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class StampMasterMapper {

    public StampMasterDto entityToDto(StampMasterProjection stampMasterProjection) {

        if (stampMasterProjection == null) {
            return null;
        }

        return StampMasterDto.builder()
                .stampMasterId(stampMasterProjection.getStampMasterId())
                .stampDenominationMasterId(stampMasterProjection.getStampDenominationMasterId())
                .stampDenominationNo(stampMasterProjection.getStampDenominationNo())
                .stampTypeMasterId(stampMasterProjection.getStampTypeMasterId())
                .stampTypeName(stampMasterProjection.getStampTypeName())
                .state(stampMasterProjection.getState())
                .status(stampMasterProjection.getStatus())
                .createdBy(stampMasterProjection.getCreatedBy())
                .createdDate(stampMasterProjection.getCreatedDate())
                .modifiedBy(stampMasterProjection.getModifiedBy())
                .modifiedDate(stampMasterProjection.getModifiedDate())
                .build();
    }

    public StampMasterEntity dtoToEntity(StampMasterDto stampMasterDto) {

        if (stampMasterDto == null) {
            return null;
        }

        return StampMasterEntity.builder()
                .stampDenominationMasterId(stampMasterDto.getStampDenominationMasterId())
                .stampTypeMasterId(stampMasterDto.getStampTypeMasterId())
                .state(stampMasterDto.getState())
                .status(true)
                .createdBy(stampMasterDto.getCreatedBy())
                .modifiedBy(stampMasterDto.getCreatedBy())
                .build();
    }

    public List<StampMasterDto> toDtos(List<StampMasterProjection> stampMasterEntities) {

        return stampMasterEntities.stream()
                .map(this::entityToDto)
                .toList();
    }

    public void updateEntityFromDto(StampMasterDto stampMasterDto, StampMasterEntity stampMasterEntity) {

        if (stampMasterDto == null || stampMasterEntity == null) {
            return;
        }

        stampMasterEntity.setStampDenominationMasterId(stampMasterDto.getStampDenominationMasterId());
        stampMasterEntity.setStampTypeMasterId(stampMasterDto.getStampTypeMasterId());
        stampMasterEntity.setState(stampMasterDto.getState());
        stampMasterEntity.setStatus(stampMasterDto.getStatus());
        stampMasterEntity.setModifiedBy(stampMasterDto.getModifiedBy());
    }
}
