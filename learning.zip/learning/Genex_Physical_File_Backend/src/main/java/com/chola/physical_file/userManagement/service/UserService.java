package com.chola.physical_file.userManagement.service;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.userManagement.dto.UserDto;
import com.chola.physical_file.userManagement.dto.UserLogInRequestDto;
import com.chola.physical_file.userManagement.record.GenexUsersResponse;

import java.util.List;
import java.util.UUID;

public interface UserService {
    void createUser(UserDto userDto);

    PageResponseDto getAllUsers(Integer pageNumber, Integer pageSize, String searchByName, List<String> filterByRoles, UUID userId);

    void updateUser(UserDto userDto);

    void deleteUser(List<UUID> userIds);

    UserDto loginUser(UserLogInRequestDto logInRequestDto);

    List<GenexUsersResponse> getAllGenexUsers();
}
