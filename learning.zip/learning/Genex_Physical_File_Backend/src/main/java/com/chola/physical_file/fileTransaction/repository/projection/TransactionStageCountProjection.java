package com.chola.physical_file.fileTransaction.repository.projection;

public interface TransactionStageCountProjection {
    Long getTotalCount();

    Long getStorageCount();

    Long getStampingCount();

    Long getOutwardCount();

    Long getQueryCount();

    Long getQueryResolvedCount();

    Long getHealthCheckCount();

    Long getRackAssignedCount();

    Long getReturnToRackCount();

    Long getUserAssignedCount();

    Long getTotalQueryCount();

    Long getCriticalQueryCount();

    Long getNonCriticalQueryCount();
}
