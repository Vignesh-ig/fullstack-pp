package com.chola.physical_file.despatchSystems.dto;

import com.chola.physical_file.common.enums.StatusEnum;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DespatchDetailsDTO {

    // Despatch Details
    private Integer dpId;

    private String dpCourierNo;

    private DespatchCourierDto despatchCourierDto;

    private String dpAppNo;

    private String dpAppName;

    private String dpAgreementNo;

    private LocalDateTime dpCreatedDate;

    private String dpBarcode;

    private String dpSchema;

    private String dpIsEsign;

    private String dpVehicleRegistrability;

    // LEAP Details
    private String genexFromBranch;

    private Integer leapAgingNo;

    private String leapFileType;

    private BigDecimal amountFinance;

    private String branchDesc;

    private String stateDesc;

    private LocalDateTime handOffDate;

    private Long leadId;

    private StatusEnum stampType;

    private BigDecimal leapStampAmount;

    private String fundedCustomerType;

    private String rePaymentMode;

    private String eStamp;

    private LocalDateTime emiEndDate;

    private String loanId;

    private LocalDate businessDate;

    private LocalDate sourcingDate;

    private Integer tenure;

    private BigDecimal birr;

    private String registrableStatus;

    private String udhayamNumberStatus;

    private BigDecimal pacAmount;

    private UUID workflowNo;

    private UUID dmsId;
}
