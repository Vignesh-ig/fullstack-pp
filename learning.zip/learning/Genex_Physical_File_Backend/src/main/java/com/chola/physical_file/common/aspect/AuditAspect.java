package com.chola.physical_file.common.aspect;

import com.chola.physical_file.auditLog.customAnnotation.AuditLog;
import com.chola.physical_file.auditLog.entity.AuditLogEntity;
import com.chola.physical_file.auditLog.repository.AuditLogRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

@Aspect
@Component
@RequiredArgsConstructor
public class AuditAspect {

    private final AuditLogRepository auditLogRepository;
    private final ObjectMapper objectMapper;

    @AfterReturning(value = "@annotation(auditLog)", returning = "result")
    public void logAudit(JoinPoint joinPoint, AuditLog auditLog, Object result) {

        UUID performedBy = extractUserId(joinPoint);

        if ("USER_LOGIN".equalsIgnoreCase(auditLog.action())) {

            UUID loginUserId = extractUserIdFromResponse(result);

            if (loginUserId != null) {
                performedBy = loginUserId;
            }
        }

        AuditLogEntity auditLogEntity = AuditLogEntity.builder()
                .moduleName(auditLog.module())
                .actionName(auditLog.action())
                .entityName(auditLog.entity())
                .createdBy(performedBy)
                .build();

        auditLogRepository.save(auditLogEntity);
    }

    private UUID extractUserId(JoinPoint joinPoint) {

        Object[] args = joinPoint.getArgs();

        for (Object arg : args) {

            if (arg == null) {
                continue;
            }

            UUID userId = findUserIdRecursively(arg);

            if (userId != null) {
                return userId;
            }
        }

        return null;
    }

    /**
     * Recursively search an object for:
     * <p>
     * createdBy
     * modifiedBy
     */
    private UUID findUserIdRecursively(Object object) {

        switch (object) {
            case null -> { return null;}

            // Direct UUID
            case UUID uuid -> { return uuid;}

            // String UUID
            case String value -> { return parseUuid(value); }


            // Map
            case Map<?, ?> map -> {

                // First check direct keys
                UUID userId = extractFromMap(map, "createdBy");

                if (userId == null) {
                    userId = extractFromMap(map, "modifiedBy");
                }

                if (userId != null) {
                    return userId;
                }

                // Then recursively inspect values
                for (Object value : map.values()) {

                    userId = findUserIdRecursively(value);

                    if (userId != null) {
                        return userId;
                    }
                }

                return null;
            }


            // Iterable / List / Set
            case Iterable<?> iterable -> {

                for (Object item : iterable) {

                    UUID userId = findUserIdRecursively(item);

                    if (userId != null) {
                        return userId;
                    }
                }

                return null;
            }
            default -> {
            }
        }


        // Array
        if (object.getClass().isArray()) {

            int length = Array.getLength(object);

            for (int i = 0; i < length; i++) {

                Object item = Array.get(object, i);

                UUID userId = findUserIdRecursively(item);

                if (userId != null) {
                    return userId;
                }
            }

            return null;
        }

        try {

            JsonNode jsonNode = objectMapper.valueToTree(object);

            return findUserIdInJson(jsonNode);

        } catch (Exception ignored) {
            return null;
        }
    }


    private UUID findUserIdInJson(JsonNode node) {

        if (node == null || node.isNull()) {
            return null;
        }

        // Object
        if (node.isObject()) {

            // Prefer createdBy
            JsonNode createdBy = node.get("createdBy");

            UUID userId = extractUuidFromJsonNode(createdBy);

            if (userId != null) {
                return userId;
            }

            // Then modifiedBy
            JsonNode modifiedBy = node.get("modifiedBy");

            userId = extractUuidFromJsonNode(modifiedBy);

            if (userId != null) {
                return userId;
            }

            // Search nested properties
            Iterator<JsonNode> fields = node.elements();

            while (fields.hasNext()) {

                userId = findUserIdInJson(fields.next());

                if (userId != null) {
                    return userId;
                }
            }
        }

        // Array
        else if (node.isArray()) {

            for (JsonNode child : node) {

                UUID userId = findUserIdInJson(child);

                if (userId != null) {
                    return userId;
                }
            }
        }

        return null;
    }

    private UUID extractUuidFromJsonNode(JsonNode node) {

        if (node == null || node.isNull()) {
            return null;
        }

        if (node.isTextual()) {
            return parseUuid(node.asText());
        }

        return null;
    }

    private UUID extractFromMap(Map<?, ?> map, String key) {

        Object value = map.get(key);

        if (value == null) {
            return null;
        }

        return findUserIdRecursively(value);
    }

    private UUID parseUuid(String value) {

        if (value == null || value.isBlank()) {
            return null;
        }

        try {
            return UUID.fromString(value);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    /**
     * Extract userId from login response.
     */
    private UUID extractUserIdFromResponse(Object result) {

        try {

            Object responseObject = result;

            if (result instanceof ResponseEntity<?> responseEntity) {
                responseObject = responseEntity.getBody();
            }

            JsonNode responseJson =
                    objectMapper.valueToTree(responseObject);

            JsonNode userIdNode =
                    responseJson.get("userId");

            return extractUuidFromJsonNode(userIdNode);

        } catch (Exception ignored) {
            return null;
        }
    }
}