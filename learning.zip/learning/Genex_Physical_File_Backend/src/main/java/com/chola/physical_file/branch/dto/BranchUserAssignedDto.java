package com.chola.physical_file.branch.dto;

import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BranchUserAssignedDto {
    private UUID branchAssignedId;
    private String despatchBranchId;
    private String genexBranchId;
    private UUID userId;
    private Boolean status;
    private UUID createdBy;
    private LocalDateTime createdDate;
    private UUID modifiedBy;
    private LocalDateTime modifiedDate;
}