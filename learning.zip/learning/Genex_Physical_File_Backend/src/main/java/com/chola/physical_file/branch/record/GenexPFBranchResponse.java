package com.chola.physical_file.branch.record;

import com.fasterxml.jackson.annotation.JsonAlias;

public record GenexPFBranchResponse(

        @JsonAlias("branchID")
        String branchId,

        String city,

        @JsonAlias("branch")
        String branchName

) {}