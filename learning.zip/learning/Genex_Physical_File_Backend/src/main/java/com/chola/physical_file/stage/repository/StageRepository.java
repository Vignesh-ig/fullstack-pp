package com.chola.physical_file.stage.repository;

import com.chola.physical_file.common.enums.StageEnum;
import com.chola.physical_file.stage.entity.StageEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface StageRepository extends JpaRepository<StageEntity, UUID> {

    @Query("""
            SELECT stage
            FROM StageEntity stage
            WHERE
                (:excludeStagesSearch IS NULL OR stage.stageName NOT IN :excludeStagesSearch)
            AND
                (:includeStagesSearch IS NULL OR stage.stageName IN :includeStagesSearch)
            """)
    Page<StageEntity> findStages(@Param("excludeStagesSearch") List<StageEnum> excludeStagesSearch, @Param("includeStagesSearch") List<StageEnum> includeStagesSearch, Pageable pageable);

    @Query("""
            SELECT stage.stageId
            FROM StageEntity stage
            WHERE stage.stageName = :stageName
            """)
    UUID findByStageId(@Param("stageName") StageEnum stageName);
}