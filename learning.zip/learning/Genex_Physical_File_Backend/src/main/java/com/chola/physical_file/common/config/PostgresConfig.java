package com.chola.physical_file.common.config;

import jakarta.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = {
                "com.chola.physical_file.userManagement",
                "com.chola.physical_file.rackAndUserAssigned",
                "com.chola.physical_file.branch",
                "com.chola.physical_file.auditLog",
                "com.chola.physical_file.vendor",
                "com.chola.physical_file.stage",
                "com.chola.physical_file.fileTransaction",
                "com.chola.physical_file.vault",
                "com.chola.physical_file.stamp",
                "com.chola.physical_file.query"
        },
        entityManagerFactoryRef = "postgresEntityManager",
        transactionManagerRef = "postgresTransactionManager"
)
@Profile("!test")
public class PostgresConfig {

    @Primary
    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.postgres")
    public DataSource postgresDataSource() {
        return DataSourceBuilder.create()
                .type(com.zaxxer.hikari.HikariDataSource.class)
                .build();
    }

    @Primary
    @Bean
    public LocalContainerEntityManagerFactoryBean postgresEntityManager(
            EntityManagerFactoryBuilder builder) {
        return builder
                .dataSource(postgresDataSource())
                .packages(
                        "com.chola.physical_file.userManagement",
                        "com.chola.physical_file.rackAndUserAssigned",
                        "com.chola.physical_file.branch",
                        "com.chola.physical_file.auditLog",
                        "com.chola.physical_file.vendor",
                        "com.chola.physical_file.stage",
                        "com.chola.physical_file.fileTransaction",
                        "com.chola.physical_file.vault",
                        "com.chola.physical_file.stamp",
                        "com.chola.physical_file.query"
                )
                .persistenceUnit("postgres")
                .build();
    }

    @Primary
    @Bean
    public PlatformTransactionManager postgresTransactionManager(
            @Qualifier("postgresEntityManager") EntityManagerFactory emf) {
        return new JpaTransactionManager(emf);
    }
}