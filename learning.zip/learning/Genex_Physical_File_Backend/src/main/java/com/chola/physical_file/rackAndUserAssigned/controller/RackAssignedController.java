package com.chola.physical_file.rackAndUserAssigned.controller;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.RackAllocationAction;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.ResponseUtil;
import com.chola.physical_file.common.util.Update;
import com.chola.physical_file.rackAndUserAssigned.dto.RackAssignedDto;
import com.chola.physical_file.rackAndUserAssigned.service.RackAssignedService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/rackAssigned")
@Validated
@Tag(name = "Rack Assigned To Users", description = "APIs to fetch Rack assigned details")
public class RackAssignedController {

    private final RackAssignedService rackAssignedService;

    @GetMapping
    @Operation(summary = "Get all rack assigned records", description = "Fetch paginated list of rack assigned records.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Rack assigned records fetched successfully",
                    content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                            schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = CommonResponseUtil.class)))
    })
    public ResponseEntity<CommonResponseUtil> getAllRackAssigned(
            @Parameter(description = "Page number (starting from 1)", example = "1") @RequestParam(name = "page", defaultValue = "1")
            @Min(value = 1, message = "The page must be a positive number.")
            Integer pageNumber,
            @Parameter(description = "Page size (max 500)", example = "10") @RequestParam(name = "limit", defaultValue = "10")
            @Min(value = 1, message = "The limit must be a positive number.") @Max(value = 500, message = "The limit must not exceed 500.")
            Integer pageSize,
            @Parameter(description = "Search by user assigned related applications") @RequestParam(name = "assignedUser", required = false) List<UUID> assignedUsers,
            @Parameter(description = "Search by rack assigned related applications") @RequestParam(name = "assignedRack", required = false) UUID assignedRack,
            @Parameter(description = "Search by user allocated  related applications") @RequestParam(name = "userAssigned", required = false) Boolean userAssigned,
            @Parameter(description = "Search by assigned status related applications") @RequestParam(name = "assignedStatus", required = false) StatusEnum assignedStatus,
            @Parameter(description = "Search by appNo or aggNo") @RequestParam(name = "appNoOrAggNo", required = false) String appNoOrAggNo,
            @Parameter(description = "Optional likeAppNoOrBarcode to search by likeAppNoOrBarcode", example = "12345") @RequestParam(name = "likeAppNoOrBarcode", required = false) String likeAppNoOrBarcode,
            @Parameter(description = "Search by rackAssignedId related application") @RequestParam(name = "rackAssignedId", required = false) UUID rackAssignedId,
            @Parameter(description = "Start date for filtering") @RequestParam(name = "startDate", required = false) LocalDate startDate,
            @Parameter(description = "End date for filtering") @RequestParam(name = "endDate", required = false) LocalDate endDate,
            @Parameter(description = "Export all records") @RequestParam(name = "exportAllRecords", required = false, defaultValue = "false") Boolean exportAllRecords

    ) {
        LocalDateTime startDateTime = startDate != null ? startDate.atStartOfDay() : null;

        LocalDateTime endDateTime = endDate != null ? endDate.plusDays(1).atStartOfDay() : null;

        if (!Boolean.TRUE.equals(exportAllRecords) && pageSize > 500) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ResponseUtil.badRequest(String.format(ResponseMessage.PAGE_SIZE_EXCEEDS_LIMIT.getMessage(), 500), HttpStatus.BAD_REQUEST));
        }

        if ((startDate == null) != (endDate == null) || (startDate != null && startDate.isAfter(endDate))) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ResponseUtil.badRequest(String.format(ResponseMessage.INVALID_DATE_RANGE.getMessage(), startDate, endDate), HttpStatus.BAD_REQUEST));
        }
        PageResponseDto pageResponseDto = rackAssignedService.getAllRackAssigned(pageNumber, pageSize, assignedUsers, assignedRack, assignedStatus, userAssigned, appNoOrAggNo, likeAppNoOrBarcode, rackAssignedId, startDateTime, endDateTime);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.RACK_ASSIGNED_RECORDS_FETCHED.getMessage(), HttpStatus.OK, pageResponseDto));
    }

    @PostMapping
    @Operation(summary = "Assign rack and applications to users", description = "Assign rack and applications to users with the provided details.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Rack and applications assigned to users successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or bad request")
    })
    public ResponseEntity<CommonResponseUtil> bulkRackAssigned(@Validated(Create.class) @RequestBody List<RackAssignedDto> rackAssignedDtos) {

        if (rackAssignedDtos.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ResponseUtil.badRequest(ResponseMessage.REQUEST_BODY_CANNOT_BE_EMPTY.getMessage(), HttpStatus.BAD_REQUEST));
        }

        rackAssignedService.bulkRackAssigned(rackAssignedDtos);

        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.RACK_AND_APPLICATIONS_ASSIGNED_SUCCESS.getMessage(), HttpStatus.OK, null));
    }

    @PutMapping
    @Operation(summary = "Update rack assigned details", description = "Update rack assigned details with the provided information.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Rack assigned details updated successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or bad request")
    })
    public ResponseEntity<CommonResponseUtil> updateBulkRackAssigned(
            @Validated(Update.class) @RequestBody List<RackAssignedDto> rackAssignedDtos,
            @Parameter(description = "rackAllocationAction to conform the action") @RequestParam(name = "rackAllocationAction") RackAllocationAction rackAllocationAction
    ) {

        if (rackAssignedDtos.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ResponseUtil.badRequest(ResponseMessage.REQUEST_BODY_CANNOT_BE_EMPTY.getMessage(), HttpStatus.BAD_REQUEST));
        }
        rackAssignedService.updateBulkRackAssigned(rackAssignedDtos, rackAllocationAction);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.RACK_ASSIGNED_UPDATED.getMessage(), HttpStatus.OK, null));
    }

}