package com.chola.physical_file.branch.service;

import com.chola.physical_file.branch.entity.BranchUserAssignedEntity;
import com.chola.physical_file.userManagement.entity.UserEntity;

import java.util.List;
import java.util.UUID;

public interface BranchAssignedService {
    void branchesAssignedToUser(UserEntity user, List<String> branchIds, UUID createdBy);

    void updateUserBranchesAssigned(UserEntity updatedUser, List<String> branchIds, UUID modifiedBy);

    void deleteUserBranchAssigned(UUID userId);

    List<BranchUserAssignedEntity> usersAssignedBranches(List<UUID> userIds);

    void deleteUsersBranchAssigned(List<UUID> userIds);

    List<String> getUserAssignedBranchIds(UUID userId);
}