package com.chola.physical_file.userManagement.repository;

import com.chola.physical_file.userManagement.entity.RoleEntity;
import com.chola.physical_file.userManagement.entity.UserEntity;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, UUID>, JpaSpecificationExecutor<UserEntity> {


    default Page<UserEntity> searchUsers(String searchByName, List<String> filterByRoles, UUID userId, Pageable pageable) {

        Specification<UserEntity> userEntitySpecification = (root, query, criteriaBuilder) -> {

            List<Predicate> predicates = new ArrayList<>();

            // Search by user name
            if (searchByName != null && !searchByName.trim().isEmpty()) {

                predicates.add(criteriaBuilder.like(
                                criteriaBuilder.lower(root.get("userName")),
                                "%" + searchByName.trim().toLowerCase() + "%"
                        )
                );
            }

            // Filter by roles
            if (filterByRoles != null && !filterByRoles.isEmpty()) {

                Join<UserEntity, RoleEntity> roleJoin = root.join("role");

                predicates.add(roleJoin.get("roleName").in(filterByRoles));
            }

            // filter by userId
            if (userId != null) {
                predicates.add(criteriaBuilder.equal(root.get("userId"), userId));
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };

        return findAll(userEntitySpecification, pageable);
    }


    @EntityGraph(attributePaths = {"role"})
    Optional<UserEntity> findByUserId(UUID userId);

    Optional<UserEntity> findByUserEmailIgnoreCase(String userEmail);

    @Modifying
    @Query(value = """
            UPDATE physical_file.users 
            SET is_active = true 
            WHERE user_id = :userId AND is_active = false
            """, nativeQuery = true)
    int reactivateUser(@Param("userId") UUID userId);

    @EntityGraph(attributePaths = {"role", "role.permissions"})
    @Query("""
                SELECT u
                FROM UserEntity u
                WHERE LOWER(u.userEmployeeCode) = LOWER(:employeeCode)
            """)
    Optional<UserEntity> findWithRoleAndPermissionsByUserEmployeeCodeIgnoreCase(@Param("employeeCode") String employeeCode);

    Optional<UserEntity> findByUserEmailIgnoreCaseOrUserEmployeeCodeIgnoreCase(String userEmail, String userEmployeeCode);

}
