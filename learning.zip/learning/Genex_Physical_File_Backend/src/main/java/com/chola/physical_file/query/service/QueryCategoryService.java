package com.chola.physical_file.query.service;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.query.dto.QueryCategoryDto;

import java.util.List;
import java.util.UUID;

public interface QueryCategoryService {
    PageResponseDto getAllQueryCategories(Integer pageNumber, Integer pageSize, String queryCategoryName);

    void createQueryCategories(QueryCategoryDto queryCategoryDto);

    void deleteQueryCategory(List<UUID> queryCategoryIds);
}