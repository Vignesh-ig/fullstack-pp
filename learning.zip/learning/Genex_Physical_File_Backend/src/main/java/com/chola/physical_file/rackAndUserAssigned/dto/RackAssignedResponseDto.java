package com.chola.physical_file.rackAndUserAssigned.dto;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.userManagement.dto.UserBasicDetailsDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RackAssignedResponseDto {

    private UUID rackAssignedId;
    private Integer ageingNo;
    private LocalDate businessDate;
    private String businessMonth;
    private String appNo;
    private String aggNo;
    private String barcode;
    private StatusEnum assignedStatus;
    private String podNo;
    private String missingPodNo;
    private String customerName;
    private String schemaProduct;
    private String scheme;
    private Boolean isESign;
    private BigDecimal amountFinance;
    private String genexFromBranch;
    private String fileType;

    // File Type
    private UUID fileTypeId;
    private String fileTypeName;

    // Rack
    private UUID rackId;
    private String vaultName;
    private String rackName;
    private String rackPosition;
    private Boolean rackStatus;
    private Integer rackAppCount;

    // Users
    private UserBasicDetailsDto createdBy;
    private UserBasicDetailsDto assignedUser;
    private UserBasicDetailsDto returnAssignedUser;

    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;
}
