package com.chola.physical_file.fileTransaction.repository;

import com.chola.physical_file.fileTransaction.entity.TransactionsHistoryEntity;
import com.chola.physical_file.fileTransaction.repository.projection.TransactionsHistoryProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface TransactionsHistoryRepository extends JpaRepository<TransactionsHistoryEntity, UUID> {


    @Query("""
            SELECT
            
            th.transactionsHistoryId            AS transactionsHistoryId,
            th.appNo                            AS appNo,
            th.leadId                           AS leadId,
            th.remarks                          AS remarks,
            th.rackAssignedId                   AS rackAssignedId,
            th.stageId                          AS stageId,
            s.stageName                         AS stageName,
            th.queryId                          AS queryId,
            q.queryName                         AS queryName,
            th.transactionId                    AS transactionId,
            th.createdBy                        AS createdBy,
            th.createdDate                      AS createdDate,
            
            assignedTo.userId                   AS assignedToUserId,
            assignedTo.userName                 AS assignedToUserName,
            assignedTo.userEmployeeCode         AS assignedToUserEmployeeCode,
            assignedTo.userEmail                AS assignedToUserEmail,
            
            createdBy.userId                    AS createdByUserId,
            createdBy.userName                  AS createdByUserName,
            createdBy.userEmployeeCode          AS createdByEmployeeCode,
            createdBy.userEmail                 AS createdByUserEmail
            
            FROM TransactionsHistoryEntity th
            
            LEFT JOIN StageEntity s
                ON s.stageId = th.stageId
            
            LEFT JOIN QueryMasterEntity q
                ON q.queriesId = th.queryId
            
            LEFT JOIN UserEntity assignedTo
                ON assignedTo.userId = th.assignedTo
            
            LEFT JOIN UserEntity createdBy
                ON createdBy.userId = th.createdBy
            
            WHERE th.transactionId IN :transactionIds
            
            ORDER BY th.createdDate DESC
            """)
    List<TransactionsHistoryProjection> findByTransactionId(@Param("transactionIds") List<UUID> transactionIds);

}