package com.chola.physical_file.despatchSystems.projection;

import java.time.LocalDateTime;

public interface DpAgreementNoBasicDetailsProjection {

    String getDpAgreementNo();

    String getDpCourierNo();

    LocalDateTime getDpCreatedDate();

    String getDpCourierId();

    String getDpCourierName();
}
