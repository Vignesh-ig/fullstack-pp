package com.chola.physical_file.auditLog.repository;

import com.chola.physical_file.auditLog.entity.AuditLogEntity;
import com.chola.physical_file.auditLog.projection.AuditLogProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLogEntity, UUID> {

    @Query(value = """            
            SELECT
                al.audit_id AS auditId,
                al.module_name AS moduleName,
               CONCAT(al.action_name, ' successfully') AS actionName,
                al.entity_name AS entityName,
                u.user_id AS userId,
                u.user_name AS userName,
                u.user_email AS userEmail,
                u.user_employee_code AS userEmployeeCode,
                r.role_name AS userRoleName,
                al.created_date AS createdDate
            
            FROM physical_file.audit_log al
            
            LEFT JOIN physical_file.users u
                ON al.created_by = u.user_id
            
            LEFT JOIN physical_file.roles r
                ON u.role_id = r.role_id            
            """,
            countQuery = """
                    
                    SELECT COUNT(*)
                    FROM physical_file.audit_log al
                    """,
            nativeQuery = true)
    Page<AuditLogProjection> getAuditLogs(Pageable pageable);
}