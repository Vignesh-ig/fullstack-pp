package com.chola.physical_file.common.aspect;

import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.jboss.logging.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.UUID;

@Slf4j
@Aspect
@Component
public class ControllerLoggingAspect {

    private static final String REQUEST_ID = "requestId";

    private static final String REQUEST_PATH = "path";

    private static final String REQUEST_METHOD = "method";

    @Around("""
            @within(org.springframework.web.bind.annotation.RestController) ||
            @within(org.springframework.stereotype.Controller)
            """)
    public Object logControllerMethods(ProceedingJoinPoint joinPoint) throws Throwable {

        long startTime = System.currentTimeMillis();

        String requestId = UUID.randomUUID().toString();

        String requestUri = "N/A";

        String httpMethod = "N/A";

        String controllerName = joinPoint.getSignature().getDeclaringType().getSimpleName();

        String methodName = joinPoint.getSignature().getName();

        // Extract Request Details
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();

        if (requestAttributes instanceof ServletRequestAttributes servletAttributes) {

            HttpServletRequest request = servletAttributes.getRequest();

            requestUri = request.getRequestURI();

            httpMethod = request.getMethod();
        }

        // MDC Context
        MDC.put(REQUEST_ID, requestId);
        MDC.put(REQUEST_PATH, requestUri);
        MDC.put(REQUEST_METHOD, httpMethod);

        try {
            // Request Log
            log.info("CONTROLLER REQUEST | RequestId: {} | Method: {} | URI: {} | Controller: {} | Function: {}", requestId, httpMethod, requestUri, controllerName, methodName);

            // Execute Method
            Object result = joinPoint.proceed();

            long duration = System.currentTimeMillis() - startTime;

            //Success Log
            log.info("CONTROLLER RESPONSE | RequestId: {} | Method: {} | URI: {} | Duration: {} ms | Status: SUCCESS", requestId, httpMethod, requestUri, duration);

            return result;

        } catch (Exception exception) {

            long duration = System.currentTimeMillis() - startTime;

            log.error("CONTROLLER ERROR | RequestId: {} | Method: {} | URI: {} | Controller: {} | Function: {} | Duration: {}ms | Error: {}", requestId, httpMethod, requestUri, controllerName, methodName, duration, exception.getMessage(), exception);

            throw exception;

        } finally {

            MDC.clear();
        }
    }
}