package com.chola.physical_file.stamp.entity;

import com.chola.physical_file.common.enums.StatusEnum;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "stamp_stack_master", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StampStackMasterEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "stamp_stack_master_id")
    private UUID stampStackMasterId;

    @Column(name = "denomination_amount")
    private Integer denominationAmount;

    @Column(name = "denomination_serial_no", length = 12)
    private String denominationSerialNo;

    @Column(name = "stamp_stack_date")
    private LocalDateTime stampStackDate;

    @Column(name = "state")
    private String state;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private StatusEnum status;

    @Column(name = "created_by")
    private UUID createdBy;

    @Column(name = "created_date")
    @CreationTimestamp
    private LocalDateTime createdDate;

    @Column(name = "used_by")
    private UUID usedBy;

    @Column(name = "used_date")
    private LocalDateTime usedDate;
}