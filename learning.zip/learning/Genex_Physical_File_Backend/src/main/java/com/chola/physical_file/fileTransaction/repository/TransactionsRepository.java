package com.chola.physical_file.fileTransaction.repository;

import com.chola.physical_file.common.enums.StageEnum;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.fileTransaction.entity.TransactionsEntity;
import com.chola.physical_file.fileTransaction.repository.projection.TransactionAppDetailsProjection;
import com.chola.physical_file.fileTransaction.repository.projection.TransactionStageCountProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Repository
public interface TransactionsRepository extends JpaRepository<TransactionsEntity, UUID> {

    @Query(
            value = """
                     SELECT
                     t.transactionId        AS transactionId,
                     t.appNo                AS appNo,
                     t.podNo                AS podNo,
                     t.missingPodNo         AS missingPodNo,
                     t.barcode              AS barcode,
                     t.isESign              AS isESign,
                     t.aggNo                AS aggNo,
                     t.leadId               AS leadId,
                     t.customerName         AS customerName,
                     t.amountFinance        AS amountFinance,
                     t.schemaProduct        AS schemaProduct,
                     t.scheme               AS scheme,
                     t.branchDesc           AS branchDesc,
                     t.modelNo              AS modelNo,
                     t.make                 AS make,
                     t.vBarCode             AS vBarCode,
                     t.boxCode              AS boxCode,
                     t.currentRemarks       AS currentRemarks,
                     t.dmsId                AS dmsId,
                     t.handOffDate          AS handOffDate,
                     t.genexFromBranch      AS genexFromBranch,
                     t.transactionStatus    AS transactionStatus,
                     t.isLocked             AS isLocked,
                     t.stateDesc            AS stateDesc,
                    t.fundedCustomerType   AS fundedCustomerType,
                    t.rePaymentMode        AS rePaymentMode,
                    t.eStamp               AS eStamp,
                    t.stampType            AS stampType,
                    t.leapStampAmount      AS leapStampAmount,
                    t.discountStampAmount  AS discountStampAmount,
                     t.finalStampAmount     AS finalStampAmount,
                     t.emiEndDate           AS emiEndDate,
                    t.fileType              AS fileType,
                    t.loanId                AS loanId,
                    t.businessDate          AS businessDate,
                    t.sourcingDate          AS sourcingDate,
                    t.tenure                AS tenure,
                    t.birr                  AS birr,
                    t.registrableStatus     AS registrableStatus,
                    t.udhayamNumberStatus   AS udhayamNumberStatus,
                    t.pacAmount             AS pacAmount,
                    t.workflowNo            AS workflowNo,
                    t.queryCartonBarcode    AS queryCartonBarcode,
                    t.createdDate           AS createdDate,
                    t.modifiedDate          AS modifiedDate,
                    
                     r.rackId                       AS rackId,
                     r.rackName                     AS rackName,
                     r.vaultName                    AS vaultName,
                     r.rackPosition                 AS rackPosition,
                     r.rackStatus                   AS rackStatus,
                     r.rackAppCount                 AS rackAppCount,
                    
                     s.stageId                      AS stageId,
                     s.stageName                    AS stageName,
                    
                     q.queriesId                    AS queryId,
                     q.queryName                    AS queryName,
                    
                     u.userId                       AS assignedUserId,
                     u.userName                     AS assignedUserName,
                     u.userEmployeeCode             AS assignedEmployeeCode,
                     u.userEmail                    AS assignedUserEmail,
                    
                     m.userId                        AS modifiedUserId,
                     m.userName                      AS modifiedUserName,
                     m.userEmployeeCode              AS modifiedEmployeeCode,
                     m.userEmail                     AS modifiedUserEmail
                    
                     FROM TransactionsEntity t
                    
                     LEFT JOIN RackEntity r
                        ON r.rackId = t.rackId
                    
                     LEFT JOIN StageEntity s
                        ON s.stageId = t.stageId
                    
                     LEFT JOIN QueryMasterEntity q
                        ON q.queriesId = t.queryId
                    
                     LEFT JOIN UserEntity u
                        ON u.userId = t.assignedUser
                    
                     LEFT JOIN UserEntity m
                        ON m.userId = t.modifiedBy
                    
                     WHERE
                        (:stages IS NULL OR s.stageName IN (:stages))
                        AND
                        (:queryState IS NULL OR q.queryName = :queryState)
                        AND (
                            :appNoOrAggNo IS NULL
                            OR t.appNo = :appNoOrAggNo
                            OR t.aggNo = :appNoOrAggNo
                        )
                        AND (
                            :likeAppNoOrBarcode IS NULL
                            OR :likeAppNoOrBarcode = ''
                            OR LOWER(t.appNo) LIKE LOWER(CONCAT('%', :likeAppNoOrBarcode, '%'))
                            OR LOWER(t.barcode) LIKE LOWER(CONCAT('%', :likeAppNoOrBarcode, '%'))
                        )
                        AND (
                            :branchUser IS NULL
                            OR EXISTS (
                                SELECT 1
                                FROM BranchUserAssignedEntity bua
                                WHERE bua.userId = :branchUser
                                  AND bua.status = true
                                  AND bua.genexBranchId = t.genexFromBranch
                            )
                        )
                        AND (
                            :assignedUsers IS NULL  OR t.assignedUser IN :assignedUsers
                        )
                        AND (
                            :stampType IS NULL OR t.stampType = :stampType
                        )
                        AND (
                            :queryCartonBarcode IS NULL
                            OR (
                                LOWER(:queryCartonBarcode) = 'null'
                                AND t.queryCartonBarcode IS NULL
                            )
                            OR (
                                LOWER(:queryCartonBarcode) <> 'null'
                                AND t.queryCartonBarcode = :queryCartonBarcode
                            )
                        )
                          AND (
                                  :appNoOrAggNo IS NOT NULL
                                  OR (
                                      (:isLocked IS NULL AND (t.isLocked = false OR t.isLocked IS NULL))
                                      OR (:isLocked IS NOT NULL AND t.isLocked = :isLocked)
                                  )
                              )
                       AND (
                                    CAST(:startDate AS timestamp) IS NULL
                                    OR t.createdDate >= :startDate
                                  )
                       AND (
                                    CAST(:endDate AS timestamp) IS NULL
                                    OR t.createdDate < :endDate
                                  )
                        order by t.createdDate DESC
                    """,

            countQuery = """
                        SELECT COUNT(t)
                    
                        FROM TransactionsEntity t
                    
                        LEFT JOIN StageEntity s
                            ON s.stageId = t.stageId
                    
                        LEFT JOIN QueryMasterEntity q
                        ON  q.queriesId = t.queryId
                    
                       WHERE
                        (:stages IS NULL OR s.stageName IN (:stages))
                        AND
                        (:queryState IS NULL OR q.queryName = :queryState)
                        AND (
                            :appNoOrAggNo IS NULL
                            OR t.appNo = :appNoOrAggNo
                            OR t.aggNo = :appNoOrAggNo
                        )
                        AND (
                            :branchUser IS NULL
                            OR EXISTS (
                                SELECT 1
                                FROM BranchUserAssignedEntity bua
                                WHERE bua.userId = :branchUser
                                 AND bua.status = true
                                  AND bua.genexBranchId = t.genexFromBranch
                            )
                        )
                       AND (
                           :likeAppNoOrBarcode IS NULL
                           OR :likeAppNoOrBarcode = ''
                           OR LOWER(t.appNo) LIKE LOWER(CONCAT('%', :likeAppNoOrBarcode, '%'))
                           OR LOWER(t.barcode) LIKE LOWER(CONCAT('%', :likeAppNoOrBarcode, '%'))
                       )
                        AND (
                            :queryCartonBarcode IS NULL
                            OR (
                                LOWER(:queryCartonBarcode) = 'null'
                                AND t.queryCartonBarcode IS NULL
                            )
                            OR (
                                LOWER(:queryCartonBarcode) <> 'null'
                                AND t.queryCartonBarcode = :queryCartonBarcode
                            )
                        )
                        AND (
                            :assignedUsers IS NULL OR t.assignedUser IN :assignedUsers
                        )
                        AND (
                            :stampType IS NULL OR t.stampType = :stampType
                        )
                             AND (
                                      :appNoOrAggNo IS NOT NULL
                                      OR (
                                          (:isLocked IS NULL AND (t.isLocked = false OR t.isLocked IS NULL))
                                          OR (:isLocked IS NOT NULL AND t.isLocked = :isLocked)
                                      )
                                  )
                     AND (
                                    CAST(:startDate AS timestamp) IS NULL
                                    OR t.createdDate >= :startDate
                                  )
                              AND (
                                    CAST(:endDate AS timestamp) IS NULL
                                    OR t.createdDate < :endDate
                                  )
                    """
    )
    Page<TransactionAppDetailsProjection> getFileTransactionApps(@Param("assignedUsers") List<UUID> assignedUsers, @Param("branchUser") UUID branchUser, @Param("stages") List<StageEnum> stages, @Param("appNoOrAggNo") String appNoOrAggNo, @Param("isLocked") Boolean isLocked, @Param("likeAppNoOrBarcode") String likeAppNoOrBarcode, @Param("stampType") StatusEnum stampType, @Param("queryState") StatusEnum queryState, @Param("queryCartonBarcode") String queryCartonBarcode, @Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate, Pageable pageable);

    List<TransactionsEntity> findByAppNoIn(List<String> appNos);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("""
            UPDATE TransactionsEntity te
            SET te.isLocked = :isLocked
            WHERE te.appNo IN :appNos AND te.isLocked <> :isLocked
            """)
    void lockFileTransactionApps(@Param("appNos") List<String> appNos, @Param("isLocked") boolean isLocked);

    @Query("""
            SELECT
                COUNT(t) AS totalCount,
                COALESCE(SUM(CASE WHEN s.stageName = 'STORAGE' THEN 1 ELSE 0 END), 0) AS storageCount,
                COALESCE(SUM(CASE WHEN s.stageName = 'STAMPING' THEN 1 ELSE 0 END), 0) AS stampingCount,
                COALESCE(SUM(CASE WHEN s.stageName = 'OUTWARD' THEN 1 ELSE 0 END), 0) AS outwardCount,
                COALESCE(SUM(CASE WHEN s.stageName = 'QUERY' THEN 1 ELSE 0 END), 0) AS queryCount,
                COALESCE(SUM(CASE WHEN s.stageName = 'QUERY_RESOLVED' THEN 1 ELSE 0 END), 0) AS queryResolvedCount,
                COALESCE(SUM(CASE WHEN s.stageName = 'HEALTH_CHECK' THEN 1 ELSE 0 END), 0) AS healthCheckCount,
                COALESCE(SUM(CASE WHEN s.stageName = 'RACK_ASSIGNED' THEN 1 ELSE 0 END), 0) AS rackAssignedCount,
                COALESCE(SUM(CASE WHEN s.stageName = 'RETURN_TO_RACK' THEN 1 ELSE 0 END), 0) AS returnToRackCount,
                COALESCE(SUM(CASE WHEN s.stageName = 'USER_ASSIGNED' THEN 1 ELSE 0 END), 0) AS userAssignedCount
            FROM TransactionsEntity t JOIN StageEntity s ON t.stageId = s.stageId
            WHERE :assignedUser IS NULL  OR t.assignedUser = :assignedUser
            """)
    TransactionStageCountProjection getTransactionDashboardCounts(UUID assignedUser);


    @Query("""
            SELECT
                COALESCE(SUM(CASE
                    WHEN q.queryName IN ('CRITICAL_QUERY', 'NON_CRITICAL_QUERY')
                    THEN 1
                    ELSE 0
                END), 0) AS totalQueryCount,
            
                COALESCE(SUM(CASE
                    WHEN q.queryName = 'CRITICAL_QUERY'
                    THEN 1
                    ELSE 0
                END), 0) AS criticalQueryCount,
            
                COALESCE(SUM(CASE
                    WHEN q.queryName = 'NON_CRITICAL_QUERY'
                    THEN 1
                    ELSE 0
                END), 0) AS nonCriticalQueryCount
            
            FROM TransactionsEntity t
            LEFT JOIN QueryMasterEntity q
                ON q.queriesId = t.queryId
            """)
    TransactionStageCountProjection getQueryAppCounts();


}