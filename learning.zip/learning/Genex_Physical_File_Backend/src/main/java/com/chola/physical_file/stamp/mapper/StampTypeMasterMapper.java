package com.chola.physical_file.stamp.mapper;

import com.chola.physical_file.stamp.dto.StampTypeMasterDto;
import com.chola.physical_file.stamp.entity.StampTypeMasterEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class StampTypeMasterMapper {

    public StampTypeMasterDto entityToDto(StampTypeMasterEntity stampTypeMasterEntity) {

        if (stampTypeMasterEntity == null) {
            return null;
        }

        return StampTypeMasterDto.builder()
                .stampTypeMasterId(stampTypeMasterEntity.getStampTypeMasterId())
                .stampTypeName(stampTypeMasterEntity.getStampTypeName())
                .createdBy(stampTypeMasterEntity.getCreatedBy())
                .createdDate(stampTypeMasterEntity.getCreatedDate())
                .modifiedBy(stampTypeMasterEntity.getModifiedBy())
                .modifiedDate(stampTypeMasterEntity.getModifiedDate())
                .build();
    }

    public StampTypeMasterEntity dtoToEntity(StampTypeMasterDto stampTypeMasterDto) {

        if (stampTypeMasterDto == null) {
            return null;
        }

        return StampTypeMasterEntity.builder()
                .stampTypeMasterId(stampTypeMasterDto.getStampTypeMasterId())
                .stampTypeName(stampTypeMasterDto.getStampTypeName())
                .createdBy(stampTypeMasterDto.getCreatedBy())
                .modifiedBy(stampTypeMasterDto.getCreatedBy())
                .build();
    }

    public List<StampTypeMasterDto> toDtos(List<StampTypeMasterEntity> stampTypeMasterEntityList) {

        return stampTypeMasterEntityList.stream()
                .map(this::entityToDto)
                .toList();
    }
}