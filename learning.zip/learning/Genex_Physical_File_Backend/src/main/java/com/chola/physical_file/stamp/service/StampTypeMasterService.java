package com.chola.physical_file.stamp.service;

import com.chola.physical_file.common.dto.PageResponseDto;

public interface StampTypeMasterService {
    PageResponseDto getStampTypeMasterRecords(Integer pageNumber, Integer pageSize);
}