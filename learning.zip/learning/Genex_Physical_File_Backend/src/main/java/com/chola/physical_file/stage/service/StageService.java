package com.chola.physical_file.stage.service;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.StageEnum;

import java.util.List;
import java.util.UUID;

public interface StageService {

    PageResponseDto getAllStages(Integer pageNumber, Integer pageSize, List<StageEnum> excludeStageSearch, List<StageEnum> includeStagesSearch);

    UUID getStageId(StageEnum stageEnum);
}