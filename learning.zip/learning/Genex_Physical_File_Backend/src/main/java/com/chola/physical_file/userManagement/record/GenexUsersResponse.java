package com.chola.physical_file.userManagement.record;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record GenexUsersResponse(
        @JsonAlias("email_id")
        String emailId,
        @JsonAlias("employee_code")
        String employeeCode,
        @JsonAlias("employee_name")
        String employeeName,
        @JsonAlias("user_name")
        String userName

) {}