package com.chola.physical_file.branch.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "branch_user_assigned", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BranchUserAssignedEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "branch_assigned_id")
    private UUID branchAssignedId;

    @Column(name = "genex_branch_id", nullable = false)
    private String genexBranchId;

    @Column(name = "user_id", nullable = false)
    private UUID userId;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "created_by")
    private UUID createdBy;

    @CreationTimestamp
    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private UUID modifiedBy;

    @UpdateTimestamp
    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;
}