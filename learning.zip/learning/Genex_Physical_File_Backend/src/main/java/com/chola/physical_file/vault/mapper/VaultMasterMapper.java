package com.chola.physical_file.vault.mapper;

import com.chola.physical_file.vault.dto.VaultMasterDto;
import com.chola.physical_file.vault.entity.VaultMasterEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class VaultMasterMapper {

    public VaultMasterDto entityToDto(VaultMasterEntity vaultMasterEntity) {

        if (vaultMasterEntity == null) {
            return null;
        }

        return VaultMasterDto.builder()
                .vaultId(vaultMasterEntity.getVaultId())
                .vaultName(vaultMasterEntity.getVaultName())
                .createdBy(vaultMasterEntity.getCreatedBy())
                .createdDate(vaultMasterEntity.getCreatedDate())
                .modifiedBy(vaultMasterEntity.getModifiedBy())
                .modifiedDate(vaultMasterEntity.getModifiedDate())
                .build();
    }

    public VaultMasterEntity dtoToEntity(VaultMasterDto vaultMasterDto) {

        if (vaultMasterDto == null) {
            return null;
        }

        return VaultMasterEntity.builder()
                .vaultId(vaultMasterDto.getVaultId())
                .vaultName(vaultMasterDto.getVaultName())
                .createdBy(vaultMasterDto.getCreatedBy())
                .createdDate(vaultMasterDto.getCreatedDate())
                .modifiedBy(vaultMasterDto.getModifiedBy())
                .modifiedDate(vaultMasterDto.getModifiedDate())
                .build();
    }

    public List<VaultMasterDto> toDtos(List<VaultMasterEntity> vaultEntities) {

        return vaultEntities.stream()
                .map(this::entityToDto)
                .toList();
    }
}