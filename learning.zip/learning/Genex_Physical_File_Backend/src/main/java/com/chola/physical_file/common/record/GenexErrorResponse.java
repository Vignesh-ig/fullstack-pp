package com.chola.physical_file.common.record;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record GenexErrorResponse(
        String code,
        String type,
        String message,
        String description
) {}