package com.chola.physical_file.query.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "query_category", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QueryCategoryEntity {

    @Id
    @Column(name = "query_category_id", nullable = false)
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID queryCategoryId;

    @Column(name = "query_category_name", length = 100)
    private String queryCategoryName;

    @Column(name = "query_sub_category_name", length = 100)
    private String querySubCategoryName;

    @Column(name = "query_category_type", length = 100)
    private String queryCategoryType;

    @Column(name = "created_by", nullable = false)
    private UUID createdBy;

    @Column(name = "created_date", nullable = false)
    @CreationTimestamp
    private LocalDateTime createdDate;
}