package com.chola.physical_file.userManagement.controller;

import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.ResponseUtil;
import com.chola.physical_file.userManagement.dto.PermissionDto;
import com.chola.physical_file.userManagement.dto.RoleDto;
import com.chola.physical_file.userManagement.service.PermissionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/v1/permissions")
@RequiredArgsConstructor
@Validated
@Tag(name = "Permissions", description = "APIs to manage permissions: list, create, update, delete")
public class PermissionController {
    private final PermissionService permissionService;

    @GetMapping
    @Operation(summary = "Get all permissions", description = "Retrieve a list of all permissions available in the system.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Permissions fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = RoleDto.class)))
    })
    public ResponseEntity<?> getAllPermissions(
            @Parameter(description = "Page number (starting from 1)", example = "1") @RequestParam(name = "page", defaultValue = "1")
            @Min(value = 1, message = "The page must be a positive number.")
            Integer pageNumber,
            @Parameter(description = "Page size (max 500)", example = "10") @RequestParam(name = "limit", defaultValue = "10")
            @Min(value = 1, message = "The limit must be a positive number.") @Max(value = 500, message = "Maximum allowed limit is 500.")
            Integer pageSize,
            @Parameter(description = "Optional role to filter permissions by", example = "admin") @RequestParam(name = "role", required = false) UUID role,
            @Parameter(description = "Optional permission name to filter permissions by", example = "READ") @RequestParam(name = "likePermissionName", required = false) String likePermissionName,
            @Parameter(description = "Optional role UUID to fetch only permissions not assigned to that role.", example = "550e8400-e29b-41d4-a716-446655440000") @RequestParam(name = "uniquePermissionsToRole", required = false) UUID uniquePermissionsToRole
    ) {
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.PERMISSIONS_FETCHED.getMessage(), HttpStatus.OK, permissionService.getAllPermissions(pageNumber, pageSize, role, likePermissionName, uniquePermissionsToRole)));
    }

    @PostMapping
    @Operation(summary = "Create permission records", description = "Create a new permission records for the given role and application")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Permission record created successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or bad request")
    })
    public ResponseEntity<CommonResponseUtil> createPermissionRecords(@Validated(Create.class) @RequestBody List<PermissionDto> permissionDto) {
        permissionService.createPermissionRecords(permissionDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ResponseUtil.success(ResponseMessage.PERMISSION_RECORD_CREATED.getMessage(), HttpStatus.CREATED, null));
    }

    @PostMapping("/ids")
    @Operation(summary = "Delete permissions", description = "Delete one or more permissions by their UUIDs. Provide permission IDs as query param 'PermissionIds'.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Permission deleted successfully"),
            @ApiResponse(responseCode = "400", description = "Bad request when PermissionIds is empty or invalid")
    })
    public ResponseEntity<CommonResponseUtil> deletePermission(@Parameter(description = "List of permission UUIDs to delete", required = true) @RequestParam(name = "permissionIds") List<UUID> permissionIds) {
        if (permissionIds == null || permissionIds.isEmpty()) {
            throw new IllegalArgumentException(ResponseMessage.PERMISSION_IDS_EMPTY.getMessage());
        }
        permissionService.deletePermission(permissionIds);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.PERMISSION_DELETED.getMessage(), HttpStatus.OK, null));
    }
}