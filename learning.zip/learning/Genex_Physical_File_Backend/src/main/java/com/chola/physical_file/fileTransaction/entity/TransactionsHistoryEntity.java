package com.chola.physical_file.fileTransaction.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "transactions_history", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionsHistoryEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "transactions_history_id")
    private UUID transactionsHistoryId;

    @Column(name = "app_no")
    private String appNo;

    @Column(name = "lead_id")
    private Long leadId;

    @Column(name = "remarks", length = 550)
    private String remarks;

    @Column(name = "rack_assigned_id")
    private UUID rackAssignedId;

    @Column(name = "stage_id")
    private UUID stageId;

    @Column(name = "query_id")
    private UUID queryId;

    @Column(name = "transaction_id")
    private UUID transactionId;

    @Column(name = "assigned_to")
    private UUID assignedTo;

    @Column(name = "created_by")
    private UUID createdBy;

    @Column(name = "created_date")
    @CreationTimestamp
    private LocalDateTime createdDate;
}
