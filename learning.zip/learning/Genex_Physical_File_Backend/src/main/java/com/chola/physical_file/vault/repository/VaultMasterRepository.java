package com.chola.physical_file.vault.repository;

import com.chola.physical_file.vault.entity.VaultMasterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface VaultMasterRepository extends JpaRepository<VaultMasterEntity, UUID> {
}