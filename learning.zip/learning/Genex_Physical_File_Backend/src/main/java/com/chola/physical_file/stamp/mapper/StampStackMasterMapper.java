package com.chola.physical_file.stamp.mapper;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.stamp.dto.StampStackMasterDto;
import com.chola.physical_file.stamp.entity.StampStackMasterEntity;
import com.chola.physical_file.stamp.repository.projection.StampStackMasterProjection;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class StampStackMasterMapper {

    public StampStackMasterDto entityToDto(StampStackMasterEntity stampStackMasterEntity) {

        if (stampStackMasterEntity == null) {
            return null;
        }

        return StampStackMasterDto.builder()
                .stampStackMasterId(stampStackMasterEntity.getStampStackMasterId())
                .denominationAmount(stampStackMasterEntity.getDenominationAmount())
                .denominationSerialNo(stampStackMasterEntity.getDenominationSerialNo())
                .stampStackDate(stampStackMasterEntity.getStampStackDate())
                .state(stampStackMasterEntity.getState())
                .status(stampStackMasterEntity.getStatus())
                .createdBy(stampStackMasterEntity.getCreatedBy())
                .createdDate(stampStackMasterEntity.getCreatedDate())
                .usedBy(stampStackMasterEntity.getUsedBy())
                .usedDate(stampStackMasterEntity.getUsedDate())
                .build();
    }

    public StampStackMasterDto projectionToDto(StampStackMasterProjection stampStackMasterProjection) {

        if (stampStackMasterProjection == null) {
            return null;
        }

        return StampStackMasterDto.builder()
                .stampStackMasterId(stampStackMasterProjection.getStampStackMasterId())
                .denominationAmount(stampStackMasterProjection.getDenominationAmount())
                .denominationSerialNo(stampStackMasterProjection.getDenominationSerialNo())
                .state(stampStackMasterProjection.getState())
                .status(stampStackMasterProjection.getStatus())
                .usedBy(stampStackMasterProjection.getUsedBy())
                .usedUserName(stampStackMasterProjection.getUsedUserName())
                .build();
    }

    public StampStackMasterEntity dtoToEntity(StampStackMasterDto stampStackMasterDto, UUID createdBy) {

        if (stampStackMasterDto == null) {
            return null;
        }

        return StampStackMasterEntity.builder()
                .stampStackMasterId(stampStackMasterDto.getStampStackMasterId())
                .denominationAmount(stampStackMasterDto.getDenominationAmount())
                .denominationSerialNo(stampStackMasterDto.getDenominationSerialNo())
                .stampStackDate(stampStackMasterDto.getStampStackDate())
                .state(stampStackMasterDto.getState())
                .status(StatusEnum.IN_STOCK)
                .createdBy(createdBy)
                .usedBy(stampStackMasterDto.getUsedBy())
                .usedDate(stampStackMasterDto.getUsedDate())
                .build();
    }

    public List<StampStackMasterDto> toDtos(List<StampStackMasterEntity> entities) {

        return entities.stream()
                .map(this::entityToDto)
                .toList();
    }

    public List<StampStackMasterDto> stampStackMasterProjectionToDtos(List<StampStackMasterProjection> stampStackMasterProjections) {

        return stampStackMasterProjections.stream()
                .map(this::projectionToDto)
                .toList();
    }
}