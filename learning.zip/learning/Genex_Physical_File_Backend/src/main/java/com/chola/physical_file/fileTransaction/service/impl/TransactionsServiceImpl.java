package com.chola.physical_file.fileTransaction.service.impl;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.StageEnum;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.dashboard.dto.DashboardDto;
import com.chola.physical_file.fileTransaction.dto.TransactionAppResponseDto;
import com.chola.physical_file.fileTransaction.dto.TransactionsDto;
import com.chola.physical_file.fileTransaction.dto.TransactionsHistoryDto;
import com.chola.physical_file.fileTransaction.entity.TransactionsEntity;
import com.chola.physical_file.fileTransaction.mapper.TransactionsMapper;
import com.chola.physical_file.fileTransaction.repository.TransactionsRepository;
import com.chola.physical_file.fileTransaction.repository.projection.TransactionAppDetailsProjection;
import com.chola.physical_file.fileTransaction.repository.projection.TransactionStageCountProjection;
import com.chola.physical_file.fileTransaction.service.TransactionsHistoryService;
import com.chola.physical_file.fileTransaction.service.TransactionsService;
import com.chola.physical_file.rackAndUserAssigned.repository.RackAssignedRepository;
import com.chola.physical_file.stamp.dto.StampStackMasterDto;
import com.chola.physical_file.stamp.dto.StampTransactionAssignedDto;
import com.chola.physical_file.stamp.service.StampStackMasterService;
import com.chola.physical_file.stamp.service.StampTransactionAssignedService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TransactionsServiceImpl implements TransactionsService {

    private final TransactionsRepository transactionsRepository;
    private final TransactionsHistoryService transactionsHistoryService;
    private final TransactionsMapper transactionsMapper;
    private final RackAssignedRepository rackAssignedRepository;
    private final StampTransactionAssignedService stampTransactionAssignedService;
    private final StampStackMasterService stampStackMasterService;

    @PersistenceContext
    private EntityManager entityManager;

    @Value("${records.bulk.batch-size:100}")
    private int batchSize;

    private void persistTransactionsInBatch(List<TransactionsEntity> transactionsEntities) {

        int count = 0;

        for (TransactionsEntity transactionsEntity : transactionsEntities) {

            if (transactionsEntity.getTransactionId() == null) {
                entityManager.persist(transactionsEntity);
            } else {
                entityManager.merge(transactionsEntity);
            }

            if (++count % batchSize == 0) {
                entityManager.flush();
                entityManager.clear();
            }
        }

        entityManager.flush();
        entityManager.clear();
    }

    @Override
    @Transactional
    public void createFileTransaction(List<TransactionsDto> transactionsDtos) {

        if (CollectionUtils.isEmpty(transactionsDtos)) {
            return;
        }

        // Bulk Update Rack Assigned Status
        List<String> completedRackAppNos = new ArrayList<>();
        List<String> queryRackAppNos = new ArrayList<>();
        List<String> healthCheckRackAppNos = new ArrayList<>();

        for (TransactionsDto transactionsDto : transactionsDtos) {

            if (StageEnum.OUTWARD.name().equals(transactionsDto.getStageName())) {
                completedRackAppNos.add(transactionsDto.getAppNo());
            } else if (StageEnum.QUERY.name().equals(transactionsDto.getStageName())) {
                queryRackAppNos.add(transactionsDto.getAppNo());
            } else if (StageEnum.HEALTH_CHECK.name().equals(transactionsDto.getStageName())) {
                healthCheckRackAppNos.add(transactionsDto.getAppNo());
            }
        }

        if (!completedRackAppNos.isEmpty()) {
            rackAssignedRepository.bulkUpdateRackAssignedStatus(completedRackAppNos, StatusEnum.COMPLETED, transactionsDtos.getFirst().getCreatedBy());
        }

        if (!queryRackAppNos.isEmpty()) {
            rackAssignedRepository.bulkUpdateRackAssignedStatus(queryRackAppNos, StatusEnum.IN_PROCESS, transactionsDtos.getFirst().getCreatedBy());
        }
        if (!healthCheckRackAppNos.isEmpty()) {
            rackAssignedRepository.bulkUpdateRackAssignedStatus(healthCheckRackAppNos, StatusEnum.PENDING, transactionsDtos.getFirst().getCreatedBy());
        }

        // Load Existing Transactions
        List<String> appNos = transactionsDtos.stream()
                .map(TransactionsDto::getAppNo)
                .toList();

        Map<String, TransactionsEntity> existingTransactionMap = transactionsRepository.findByAppNoIn(appNos).stream()
                .collect(Collectors.toMap(TransactionsEntity::getAppNo, Function.identity()));

        // Prepare Insert & Update Lists
        List<TransactionsEntity> entitiesToPersist = new ArrayList<>();

        List<StampTransactionAssignedDto> stampTransactionAssignedDtoList = new ArrayList<>();
        List<UUID> stampStackMasterIdList = new ArrayList<>();
        UUID createdBy = transactionsDtos.getFirst().getCreatedBy() == null ? transactionsDtos.getFirst().getModifiedBy() : transactionsDtos.getFirst().getCreatedBy();
        for (TransactionsDto transactionsDto : transactionsDtos) {

            TransactionsEntity transactionsEntity = existingTransactionMap.get(transactionsDto.getAppNo());

            if (transactionsEntity != null) {

                if (transactionsDto.getStampStackMasterIds() != null && !transactionsDto.getStampStackMasterIds().isEmpty()) {
                    for (UUID stampStackMasterId : transactionsDto.getStampStackMasterIds()) {
                        StampTransactionAssignedDto stampTransactionAssignedDto = new StampTransactionAssignedDto();
                        stampTransactionAssignedDto.setTransactionId(transactionsEntity.getTransactionId());
                        stampTransactionAssignedDto.setStampStackMasterId(stampStackMasterId);
                        stampTransactionAssignedDto.setCreatedBy(createdBy);
                        stampTransactionAssignedDtoList.add(stampTransactionAssignedDto);
                        stampStackMasterIdList.add(stampStackMasterId);
                    }
                }

                transactionsMapper.updateEntityFromDto(transactionsDto, transactionsEntity, StageEnum.valueOf(transactionsDtos.getFirst().getStageName()));

            } else {

                transactionsEntity = transactionsMapper.dtoToEntity(transactionsDto);
            }

            entitiesToPersist.add(transactionsEntity);
        }

        // map stampTransactionAssigned and update the status of stampStackMaster to USED
        if (!stampTransactionAssignedDtoList.isEmpty() && !stampStackMasterIdList.isEmpty()) {
            stampTransactionAssignedService.createStampTransactionAssignments(stampTransactionAssignedDtoList);
            stampStackMasterService.updateStampStackMasterStatus(stampStackMasterIdList, createdBy, StatusEnum.USED);

        }

        // Batch Insert / Update
        persistTransactionsInBatch(entitiesToPersist);

        // Batch Transaction History
        transactionsHistoryService.createTransactionsHistory(entitiesToPersist, transactionsDtos);

    }

    @Override
    @Transactional(readOnly = true)
    public PageResponseDto getFileTransactionApps(Integer pageNumber, Integer pageSize, String appNoOrAggNo, String likeAppNoOrBarcode, List<StageEnum> stages, List<UUID> assignedUsers, UUID branchUser, Boolean isLocked, StatusEnum stampType, StatusEnum queryState, String queryCartonBarcode, LocalDateTime startDate, LocalDateTime endDate, Boolean exportAllRecords) {

        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "createdDate")
        );

        List<StageEnum> stagesFilters = (stages == null || stages.isEmpty() || stages.contains(StageEnum.ENQUIRY)) ? null : stages;

        if (assignedUsers != null && assignedUsers.isEmpty()) {
            assignedUsers = null;
        }
        if (stages != null && stages.isEmpty()) {
            stages = null;
        }

        Page<TransactionAppDetailsProjection> transactionAppsProjections = transactionsRepository.getFileTransactionApps(assignedUsers, branchUser, stagesFilters, appNoOrAggNo, isLocked, likeAppNoOrBarcode, stampType, queryState, queryCartonBarcode, startDate, endDate, pageable);

        List<TransactionAppResponseDto> transactionAppResponseDtoList;

        StageEnum enquiryStageName = stages != null && stages.contains(StageEnum.ENQUIRY) ? StageEnum.ENQUIRY : null;

        // ENQUIRY returns application transactions with transactionId-wise history.
        if (StageEnum.ENQUIRY == enquiryStageName) {

            if (transactionAppsProjections.isEmpty()) {
                transactionAppResponseDtoList = Collections.emptyList();
            } else {

                List<TransactionAppDetailsProjection> transactionDetails = transactionAppsProjections.getContent();

                TransactionAppDetailsProjection firstTransaction = transactionDetails.getFirst();

                if (appNoOrAggNo != null && Boolean.TRUE.equals(firstTransaction.getIsLocked())) {
                    throw new IllegalArgumentException("The application is locked and cannot be viewed.");
                }

                // Get all transaction IDs.
                List<UUID> transactionIds = transactionDetails.stream()
                        .map(TransactionAppDetailsProjection::getTransactionId)
                        .filter(Objects::nonNull)
                        .toList();

                // Get complete history for all transactions.
                List<TransactionsHistoryDto> transactionsHistory = transactionIds.isEmpty()
                        ? Collections.emptyList()
                        : transactionsHistoryService.findByTransactionId(transactionIds);

                // Group history by transactionId.
                Map<UUID, List<TransactionsHistoryDto>> transactionsHistoryMap = transactionsHistory.stream()
                        .filter(history -> history.getTransactionId() != null)
                        .collect(Collectors.groupingBy(
                                TransactionsHistoryDto::getTransactionId
                        ));

                transactionAppResponseDtoList = transactionDetails.stream().map(transaction -> {

                    UUID transactionId = transaction.getTransactionId();

                    List<TransactionsHistoryDto> transactionHistory = transactionsHistoryMap.getOrDefault(transactionId, Collections.emptyList());

                    // Stamp stack is transaction-specific.
                    List<StampStackMasterDto> stampStackMasterDtoList = Collections.emptyList();

                    if (appNoOrAggNo != null && transactionId != null && (transaction.getStageName() == StageEnum.STAMPING || transaction.getStageName() == StageEnum.STORAGE)) {
                        stampStackMasterDtoList = stampStackMasterService.getUsedStampStackByTransactionId(transactionId);
                    }

                    return transactionsMapper.toDto(transaction, transactionHistory, stampStackMasterDtoList
                    );
                }).toList();
            }
        }

        // No history lookup required.
        else {
            transactionAppResponseDtoList = transactionAppsProjections.stream()
                    .map(projection ->
                            transactionsMapper.toDto(
                                    projection,
                                    Collections.emptyList(), Collections.emptyList()
                            )
                    )
                    .toList();
        }

        PageResponseDto pageResponseDto = new PageResponseDto();

        pageResponseDto.setData(transactionAppResponseDtoList);
        pageResponseDto.setCurrentPage(transactionAppsProjections.getNumber() + 1);
        pageResponseDto.setTotalItems((int) transactionAppsProjections.getTotalElements());
        pageResponseDto.setTotalPages(transactionAppsProjections.getTotalPages());
        pageResponseDto.setHasNextPage(transactionAppsProjections.hasNext());
        pageResponseDto.setHasPreviousPage(transactionAppsProjections.hasPrevious());

        return pageResponseDto;
    }

    @Override
    @Transactional
    public void lockFileTransactionApps(List<String> appNos, Boolean isLocked) {
        transactionsRepository.lockFileTransactionApps(appNos, isLocked);
    }

    @Override
    public DashboardDto getTransactionsCount(UUID assignedUser) {
        TransactionStageCountProjection transactionStageCountProjection = transactionsRepository.getTransactionDashboardCounts(assignedUser);
        return transactionsMapper.toDashboardDto(transactionStageCountProjection);
    }

    @Override
    public DashboardDto getQueryAppCount() {
        TransactionStageCountProjection transactionStageCountProjection = transactionsRepository.getQueryAppCounts();
        return transactionsMapper.toDashboardDto(transactionStageCountProjection);
    }

}