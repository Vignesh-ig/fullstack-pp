package com.chola.physical_file.branch.mapper;

import com.chola.physical_file.branch.dto.BranchUserAssignedDto;
import com.chola.physical_file.branch.entity.BranchUserAssignedEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BranchUserAssignedMapper {

    public BranchUserAssignedDto entityToDto(BranchUserAssignedEntity branchUserAssignedEntity) {

        if (branchUserAssignedEntity == null) {
            return null;
        }

        return BranchUserAssignedDto.builder()
                .branchAssignedId(branchUserAssignedEntity.getBranchAssignedId())
                .status(branchUserAssignedEntity.getStatus())
                .createdBy(branchUserAssignedEntity.getCreatedBy())
                .createdDate(branchUserAssignedEntity.getCreatedDate())
                .modifiedBy(branchUserAssignedEntity.getModifiedBy())
                .modifiedDate(branchUserAssignedEntity.getModifiedDate())
                .build();
    }

    public BranchUserAssignedEntity dtoToEntity(BranchUserAssignedDto branchUserAssignedDto) {

        if (branchUserAssignedDto == null) {
            return null;
        }

        return BranchUserAssignedEntity.builder()
                .branchAssignedId(branchUserAssignedDto.getBranchAssignedId())
                .status(branchUserAssignedDto.getStatus())
                .createdBy(branchUserAssignedDto.getCreatedBy())
                .createdDate(branchUserAssignedDto.getCreatedDate())
                .modifiedBy(branchUserAssignedDto.getModifiedBy())
                .modifiedDate(branchUserAssignedDto.getModifiedDate())
                .build();
    }

    public List<BranchUserAssignedDto> toDtos(List<BranchUserAssignedEntity> branchUserAssignedEntities) {

        return branchUserAssignedEntities.stream()
                .map(this::entityToDto)
                .toList();
    }
}