package com.chola.physical_file.branch.repository;

import com.chola.physical_file.branch.entity.BranchUserAssignedEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface BranchAssignedRepository extends JpaRepository<BranchUserAssignedEntity, UUID> {

    List<BranchUserAssignedEntity> findByUserIdIn(List<UUID> userIds);

    @Query("""
            SELECT bua.genexBranchId
            FROM BranchUserAssignedEntity bua
            WHERE bua.userId = :userId
            """)
    List<String> findBranchIdsByUserId(@Param("userId") UUID userId);

    @Modifying
    @Query("""
            DELETE FROM BranchUserAssignedEntity b
            WHERE b.userId IN :userIds
            """)
    void deleteByUserIds(List<UUID> userIds);

}