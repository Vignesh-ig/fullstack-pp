package com.chola.physical_file.common.enums;

public enum StatusEnum {
    PENDING,
    IN_PROCESS,
    COMPLETED,
    RACK_ALLOCATED,
    ACTIVE,
    IN_STOCK,
    USED,
    VARIABLE,
    FIXED,
    NO_STAMP,
    E_STAMP,
    STAMPING_OVERVIEW,
    ALLOCATION_OVERVIEW,
    TRANSACTION_OVERVIEW,
    QUERY_OVERVIEW,
    CRITICAL_QUERY,
    NON_CRITICAL_QUERY,
    QUERY,
    UNIQUE,
    QUERY_RESOLVED
}