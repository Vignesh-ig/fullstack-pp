package com.chola.physical_file.stamp.service.impl;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.stamp.dto.StampMasterDto;
import com.chola.physical_file.stamp.entity.StampMasterEntity;
import com.chola.physical_file.stamp.mapper.StampMasterMapper;
import com.chola.physical_file.stamp.repository.StampMasterRepository;
import com.chola.physical_file.stamp.repository.projection.StampMasterProjection;
import com.chola.physical_file.stamp.service.StampMasterService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class StampMasterServiceImpl implements StampMasterService {

    private final StampMasterRepository stampMasterRepository;
    private final StampMasterMapper stampMasterMapper;
    @PersistenceContext
    private EntityManager entityManager;

    @Value("${records.bulk.batch-size:100}")
    private int batchSize;

    private void persistTransactionsInBatch(List<StampMasterEntity> stampMasterEntityList) {

        int count = 0;

        for (StampMasterEntity stampMasterEntity : stampMasterEntityList) {

            if (stampMasterEntity.getStampMasterId() == null) {
                entityManager.persist(stampMasterEntity);
            }

            if (++count % batchSize == 0) {
                entityManager.flush();
                entityManager.clear();
            }
        }

        entityManager.flush();
        entityManager.clear();
    }


    @Override
    @Transactional
    public void createStampMasterRecords(List<StampMasterDto> stampMasterDtoList) {

        for (StampMasterDto dto : stampMasterDtoList) {

            String state = dto.getState();
            UUID stampTypeMasterId = dto.getStampTypeMasterId();
            UUID denominationMasterId = dto.getStampDenominationMasterId();

            boolean differentStampTypeExists = stampMasterRepository.existsByStateAndStampTypeMasterIdNot(state, stampTypeMasterId);

            if (differentStampTypeExists) {
                throw new IllegalArgumentException(state + " stamp type already exists");
            }

            if ("VARIABLE".equalsIgnoreCase(dto.getStampTypeName())) {

                boolean duplicateVariableDenomination = stampMasterRepository.existsByStateAndStampTypeMasterIdAndStampDenominationMasterId(state, stampTypeMasterId, denominationMasterId);

                if (duplicateVariableDenomination) {
                    throw new IllegalArgumentException("Stamp Master record already exists for state: " + state + ", stamp type: " + dto.getStampTypeName() + ", denomination: " + dto.getStampDenominationNo());
                }
            }
        }

        List<StampMasterEntity> entitiesToPersist = stampMasterDtoList.stream()
                .map(stampMasterMapper::dtoToEntity)
                .toList();

        persistTransactionsInBatch(entitiesToPersist);
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponseDto getStampMasterRecords(Integer pageNumber, Integer pageSize, String state, UUID stampType, UUID stampMasterId) {
        PageResponseDto pageResponseDto = new PageResponseDto();
        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize)
        );
        Page<StampMasterProjection> pageResponse = stampMasterRepository.findStampMasters(state, stampType, stampMasterId, pageable);
        List<StampMasterDto> stampMasterDtoList = stampMasterMapper.toDtos(pageResponse.getContent());
        pageResponseDto.setData(stampMasterDtoList);
        pageResponseDto.setCurrentPage(pageResponse.getNumber() + 1);
        pageResponseDto.setTotalItems((int) pageResponse.getTotalElements());
        pageResponseDto.setTotalPages(pageResponse.getTotalPages());
        pageResponseDto.setHasNextPage(pageResponse.hasNext());
        pageResponseDto.setHasPreviousPage(pageResponse.hasPrevious());
        return pageResponseDto;
    }
}