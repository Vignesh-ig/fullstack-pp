package com.chola.physical_file.query.repository;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.query.entity.QueryMasterEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface QueryMasterRepository extends JpaRepository<QueryMasterEntity, UUID> {

    @Query("""
            SELECT query
            FROM QueryMasterEntity query
            WHERE
                (:excludeStatusSearch IS NULL OR query.queryName NOT IN :excludeStatusSearch)
            AND
                (:includeStatusSearch IS NULL OR query.queryName IN :includeStatusSearch)
            """)
    Page<QueryMasterEntity> findQueries(@Param("excludeStatusSearch") List<StatusEnum> excludeStatusSearch, @Param("includeStatusSearch") List<StatusEnum> includeStatusSearch, Pageable pageable);
}