package com.chola.physical_file.userManagement.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PermissionDto {

    private UUID permissionId;
    private String permissionName;
    private String description;
    private UUID roleId;
    private String roleName;
    private LocalDateTime createdDate;
    private UUID createdBy;
    private LocalDateTime modifiedDate;
    private UUID modifiedBy;
}
