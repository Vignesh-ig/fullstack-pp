package com.chola.physical_file.rackAndUserAssigned.mapper;

import com.chola.physical_file.rackAndUserAssigned.dto.RackAssignedDto;
import com.chola.physical_file.rackAndUserAssigned.dto.RackAssignedResponseDto;
import com.chola.physical_file.rackAndUserAssigned.entity.RackAssignedEntity;
import com.chola.physical_file.rackAndUserAssigned.repository.projection.RackAssignedProjection;
import com.chola.physical_file.userManagement.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.List;

@Component
@RequiredArgsConstructor
public class RackAssignedMapper {
    private final UserMapper userMapper;

    public RackAssignedDto entityToDto(RackAssignedEntity rackAssignedEntity) {

        if (rackAssignedEntity == null) {
            return null;
        }

        return RackAssignedDto.builder()
                .rackAssignedId(rackAssignedEntity.getRackAssignedId())
                .leapAgingNo((int) ChronoUnit.DAYS.between(rackAssignedEntity.getBusinessDate() != null ? rackAssignedEntity.getBusinessDate() : LocalDate.now(), LocalDate.now()))
                .assignedUser(rackAssignedEntity.getAssignedUser())
                .appNo(rackAssignedEntity.getAppNo())
                .aggNo(rackAssignedEntity.getAggNo())
                .barcode(rackAssignedEntity.getBarcode())
                .assignedStatus(rackAssignedEntity.getAssignedStatus())
                .customerName(rackAssignedEntity.getCustomerName())
                .rackId(
                        rackAssignedEntity.getRack() != null
                                ? rackAssignedEntity.getRack()
                                : null
                )
                .createdBy(rackAssignedEntity.getCreatedBy())
                .createdDate(rackAssignedEntity.getCreatedDate())
                .modifiedBy(rackAssignedEntity.getModifiedBy())
                .modifiedDate(rackAssignedEntity.getModifiedDate())
                .build();
    }

    public RackAssignedEntity dtoToEntity(RackAssignedDto rackAssignedDto) {

        if (rackAssignedDto == null) {
            return null;
        }

        return RackAssignedEntity.builder()
                .rackAssignedId(rackAssignedDto.getRackAssignedId())
                .assignedUser(rackAssignedDto.getAssignedUser())
                .appNo(rackAssignedDto.getAppNo())
                .aggNo(rackAssignedDto.getAggNo())
                .barcode(rackAssignedDto.getBarcode())
                .customerName(rackAssignedDto.getCustomerName())
                .fileType(rackAssignedDto.getLeapFileType())
                .businessDate(rackAssignedDto.getBusinessDate())
                .rack(
                        rackAssignedDto.getRackId() != null
                                ? rackAssignedDto.getRackId()
                                : null
                )
                .createdBy(rackAssignedDto.getCreatedBy())
                .modifiedBy(rackAssignedDto.getCreatedBy())
                .build();
    }

    public List<RackAssignedDto> toDtos(List<RackAssignedEntity> rackAssignedEntities) {

        if (rackAssignedEntities == null || rackAssignedEntities.isEmpty()) {
            return Collections.emptyList();
        }

        return rackAssignedEntities.stream()
                .map(this::entityToDto)
                .toList();
    }

    public List<RackAssignedEntity> toEntities(List<RackAssignedDto> rackAssignedDtos) {

        if (rackAssignedDtos == null || rackAssignedDtos.isEmpty()) {
            return Collections.emptyList();
        }

        return rackAssignedDtos.stream()
                .map(this::dtoToEntity)
                .toList();
    }

    public void updateEntityFromDto(RackAssignedDto rackAssignedDto, RackAssignedEntity rackAssignedEntity) {

        rackAssignedEntity.setAssignedUser(rackAssignedDto.getAssignedUser());
        if (rackAssignedDto.getRackId() != null) {
            rackAssignedEntity.setRack(rackAssignedDto.getRackId());
        }
        rackAssignedEntity.setModifiedBy(rackAssignedDto.getModifiedBy() == null ? rackAssignedEntity.getCreatedBy() : rackAssignedDto.getModifiedBy());

    }

    public RackAssignedResponseDto mapToRackAssignedDto(RackAssignedProjection rackAssignedProjection) {

        return RackAssignedResponseDto.builder()

                .rackAssignedId(rackAssignedProjection.getRackAssignedId())
                .appNo(rackAssignedProjection.getAppNo())
                .aggNo(rackAssignedProjection.getAggNo())
                .barcode(rackAssignedProjection.getBarcode())
                .assignedStatus(rackAssignedProjection.getAssignedStatus())
                .customerName(rackAssignedProjection.getCustomerName())
                .businessDate(rackAssignedProjection.getBusinessDate())
                .businessMonth(rackAssignedProjection.getBusinessDate() != null ? rackAssignedProjection.getBusinessDate().getMonth().toString() : null)
                .ageingNo(
                        (int) ChronoUnit.DAYS.between(
                                rackAssignedProjection.getBusinessDate() == null ? LocalDate.now() : rackAssignedProjection.getBusinessDate(),
                                LocalDate.now()
                        )
                )
                .fileType(rackAssignedProjection.getFileType())
                // Rack
                .rackId(rackAssignedProjection.getRackId())
                .vaultName(rackAssignedProjection.getVaultName())
                .rackName(rackAssignedProjection.getRackName())
                .rackPosition(rackAssignedProjection.getRackPosition())
                .rackStatus(rackAssignedProjection.getRackStatus())
                .rackAppCount(rackAssignedProjection.getRackAppCount())
                .createdDate(rackAssignedProjection.getCreatedDate())
                .modifiedDate(rackAssignedProjection.getModifiedDate())
                // Created By
                .createdBy(
                        userMapper.buildUserBasicDetailsMapper(
                                rackAssignedProjection.getEmpUserId(),
                                rackAssignedProjection.getEmpUserName(),
                                rackAssignedProjection.getEmpUserEmail(),
                                rackAssignedProjection.getEmpUserEmployeeCode()
                        )
                )

                // Assigned User
                .assignedUser(
                        userMapper.buildUserBasicDetailsMapper(
                                rackAssignedProjection.getAssignedUserId(),
                                rackAssignedProjection.getAssignedUserName(),
                                rackAssignedProjection.getAssignedUserEmail(),
                                rackAssignedProjection.getAssignedUserEmployeeCode()
                        )
                )

                // Return Assigned User
                .returnAssignedUser(
                        userMapper.buildUserBasicDetailsMapper(
                                rackAssignedProjection.getReturnUserId(),
                                rackAssignedProjection.getReturnUserName(),
                                rackAssignedProjection.getReturnUserEmail(),
                                rackAssignedProjection.getReturnUserEmployeeCode()
                        )
                )

                .build();
    }
}