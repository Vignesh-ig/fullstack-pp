package com.chola.physical_file.rackAndUserAssigned.repository.projection;

public interface AllocationStatusCountProjection {

    Long getTotalApps();

    Long getPendingApps();

    Long getInProcessApps();

    Long getCompletedApps();

}

