package com.chola.physical_file.userManagement.mapper;

import com.chola.physical_file.branch.record.GenexPFBranchResponse;
import com.chola.physical_file.userManagement.dto.UserBasicDetailsDto;
import com.chola.physical_file.userManagement.dto.UserDto;
import com.chola.physical_file.userManagement.entity.UserEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class UserMapper {

    private final RoleMapper roleMapper;

    public UserDto entityToDto(UserEntity entity, List<GenexPFBranchResponse> branchMasterDtos) {

        if (entity == null) return null;

        return UserDto.builder()
                .userId(entity.getUserId())
                .userName(entity.getUserName())
                .userEmail(entity.getUserEmail())
                .userEmployeeCode(entity.getUserEmployeeCode())
                .isActive(entity.getIsActive())
                .createdDate(entity.getCreatedDate())
                .createdBy(entity.getCreatedBy())
                .modifiedDate(entity.getModifiedDate())
                .modifiedBy(entity.getModifiedBy())
                .roleId(entity.getRole() != null
                        ? entity.getRole().getRoleId()
                        : null)
                .roleDto(entity.getRole() != null
                        ? roleMapper.entityToDto(entity.getRole())
                        : null)
                .branchDtos(branchMasterDtos)
                .build();
    }

    public UserDto entityToDtoWithoutPermissions(UserEntity entity, List<GenexPFBranchResponse> branchMasterDtos) {
        if (entity == null) return null;

        return UserDto.builder()
                .userId(entity.getUserId())
                .userName(entity.getUserName())
                .userEmail(entity.getUserEmail())
                .userEmployeeCode(entity.getUserEmployeeCode())
                .isActive(entity.getIsActive())
                .createdDate(entity.getCreatedDate())
                .createdBy(entity.getCreatedBy())
                .modifiedDate(entity.getModifiedDate())
                .modifiedBy(entity.getModifiedBy())
                .roleId(entity.getRole() != null ? entity.getRole().getRoleId() : null)
                .roleDto(entity.getRole() != null
                        ? roleMapper.toDtoWithoutPermissions(entity.getRole())
                        : null)
                .branchDtos(branchMasterDtos)
                .build();
    }

    public UserEntity dtoToEntity(UserDto dto) {
        if (dto == null) return null;

        return UserEntity.builder()
                .userName(dto.getUserName())
                .userEmail(dto.getUserEmail())
                .userEmployeeCode(dto.getUserEmployeeCode())
                .isActive(dto.getIsActive())
                .createdBy(dto.getCreatedBy())
                .modifiedBy(dto.getCreatedBy())
                .build();
    }

    public UserBasicDetailsDto buildUserBasicDetailsMapper(
            UUID userId,
            String userName,
            String userEmail,
            String userEmployeeCode
    ) {

        if (userId == null) {
            return null;
        }

        return UserBasicDetailsDto.builder()
                .userId(userId)
                .userName(userName)
                .userEmail(userEmail)
                .userEmployeeCode(userEmployeeCode)
                .build();
    }

//    public List<UserDto> toDtos(List<UserEntity> list) {
//        return list == null ? List.of() :
//                list.stream()
//                        .map(this::entityToDtoWithoutPermissions)
//                        .toList();
//    }
}
