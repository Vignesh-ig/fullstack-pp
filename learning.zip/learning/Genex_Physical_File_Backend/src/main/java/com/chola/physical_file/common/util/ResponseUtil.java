package com.chola.physical_file.common.util;

import com.chola.physical_file.common.enums.AppResponseCode;
import org.springframework.http.HttpStatus;

//S3740
public class ResponseUtil {

    // 🔹 success response with custom status + message
    public static CommonResponseUtil success(String message, HttpStatus status, Object data) {
        return CommonResponseUtil.builder()
                .message(message)
                .appResponseCode(AppResponseCode.SUCCESS)
                .httpStatus(status)
                .data(data)
                .code(status.value())
                .build();
    }

    // 🔹 Error response with custom status + message
    public static CommonResponseUtil error(String message, HttpStatus status, AppResponseCode code) {
        return CommonResponseUtil.builder()
                .message(message)
                .appResponseCode(code)
                .httpStatus(status)
                .code(status.value())
                .build();
    }

    // 🔹 Shortcut — INTERNAL SERVER ERROR
    public static CommonResponseUtil internalError(String message) {
        return error(message, HttpStatus.INTERNAL_SERVER_ERROR, AppResponseCode.ERROR);
    }

    // 🔹 Shortcut — NOT FOUND
    public static CommonResponseUtil notFound(String message) {
        return error(message, HttpStatus.NOT_FOUND, AppResponseCode.NOT_FOUND);
    }

    // 🔹 Shortcut — BAD REQUEST
    public static CommonResponseUtil badRequest(String message, HttpStatus status) {
        return error(message, status, AppResponseCode.BAD_REQUEST);
    }

    // 🔹 Shortcut — UNAUTHORIZED
    public static CommonResponseUtil unauthorized(String message) {
        return error(message, HttpStatus.UNAUTHORIZED, AppResponseCode.AUTH_FAILED);
    }

    public static CommonResponseUtil conflict(String message) {
        return error(message, HttpStatus.CONFLICT, AppResponseCode.CONFLICT);
    }
}
