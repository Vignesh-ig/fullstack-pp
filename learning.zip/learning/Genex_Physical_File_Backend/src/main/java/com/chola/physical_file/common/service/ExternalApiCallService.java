package com.chola.physical_file.common.service;

import com.chola.physical_file.branch.record.*;
import com.chola.physical_file.common.record.LeapVFAppDetailsResponse;
import com.chola.physical_file.despatchSystems.records.GenexPFDetailsResponse;
import com.chola.physical_file.stamp.record.LeapStateResponse;
import com.chola.physical_file.userManagement.record.GenexUsersResponse;

import java.util.List;

public interface ExternalApiCallService {
    List<GenexUsersResponse> getAllGenexUsers();

    List<GenexZoneResponse> getAllZones();

    List<GenexRegionResponse> getRegionsByZoneId(String zoneId);

    List<GenexAreaResponse> getAreasByRegionId(String regionId);

    List<GenexBranchResponse> getBranchesByAreaId(String areaId);

    List<GenexPFDetailsResponse> getGenexAppNoDetailsByAppNo(String applicationNumber);

    List<GenexPFBranchResponse> getGenexBranchesByIds(String branchId);

    List<LeapStateResponse> getAllStates();

    List<LeapVFAppDetailsResponse> getLeapVFAppNoDetailsByAppNos(String applicationNumbers);
}