package com.chola.physical_file.auditLog.service;

import com.chola.physical_file.common.dto.PageResponseDto;

public interface AuditLogService {
    PageResponseDto getAuditLogs(Integer pageNumber, Integer pageSize);
}