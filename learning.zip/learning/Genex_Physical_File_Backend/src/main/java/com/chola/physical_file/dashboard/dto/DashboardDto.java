package com.chola.physical_file.dashboard.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DashboardDto {
    Long totalApps;
    Long pendingApps;
    Long completedApps;
    Long inProcessApps;
    Long totalStampStacks;
    Long availableStampStacks;
    Long usedStampStacks;
    Long totalTransactions;
    Long outwardTransactions;
    Long stampingTransactions;
    Long queryTransactions;
    Long queryResolvedTransactions;
    Long healthCheckTransactions;
    Long rackAssignedTransactions;
    Long returnToRackTransactions;
    Long userAssignedTransactions;
    Long storageTransactions;
    Long totalQueries;
    Long totalQueryCount;
    Long criticalQueryCount;
    Long nonCriticalQueryCount;
}