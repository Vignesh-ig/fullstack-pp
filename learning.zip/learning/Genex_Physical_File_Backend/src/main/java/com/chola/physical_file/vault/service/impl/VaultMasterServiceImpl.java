package com.chola.physical_file.vault.service.impl;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.vault.dto.VaultMasterDto;
import com.chola.physical_file.vault.entity.VaultMasterEntity;
import com.chola.physical_file.vault.mapper.VaultMasterMapper;
import com.chola.physical_file.vault.repository.VaultMasterRepository;
import com.chola.physical_file.vault.service.VaultMasterService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class VaultMasterServiceImpl implements VaultMasterService {

    private final VaultMasterRepository vaultMasterRepository;
    private final VaultMasterMapper vaultMasterMapper;

    @Override
    @Transactional(readOnly = true)
    public PageResponseDto getAllVaultRecords(Integer pageNumber, Integer pageSize) {
        PageResponseDto pageResponseDto = new PageResponseDto();
        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "createdDate")
        );

        Page<VaultMasterEntity> pageResponse = vaultMasterRepository.findAll(pageable);
        List<VaultMasterDto> rackDtoList = vaultMasterMapper.toDtos(pageResponse.getContent());
        pageResponseDto.setData(rackDtoList);
        pageResponseDto.setCurrentPage(pageResponse.getNumber() + 1);
        pageResponseDto.setTotalItems((int) pageResponse.getTotalElements());
        pageResponseDto.setTotalPages(pageResponse.getTotalPages());
        pageResponseDto.setHasNextPage(pageResponse.hasNext());
        pageResponseDto.setHasPreviousPage(pageResponse.hasPrevious());
        return pageResponseDto;
    }
}