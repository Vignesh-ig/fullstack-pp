package com.chola.physical_file.fileTransaction.controller;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.enums.StageEnum;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.ResponseUtil;
import com.chola.physical_file.fileTransaction.dto.TransactionsDto;
import com.chola.physical_file.fileTransaction.service.TransactionsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/transaction")
@Validated
@Tag(name = "File Transactions", description = "APIs to manage file transactions such as issue, return, transfer, etc.")
public class TransactionsController {

    private final TransactionsService fileTransactionService;

    @PostMapping
    @Operation(summary = "Create file transactions", description = "Create a new file transaction records for actions like issue, return, transfer, etc.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "File transaction record created successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or bad request")
    })
    public ResponseEntity<CommonResponseUtil> createFileTransaction(@Validated(Create.class) @RequestBody List<TransactionsDto> transactionsDto) {
        fileTransactionService.createFileTransaction(transactionsDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ResponseUtil.success(ResponseMessage.TRANSACTION_CREATED.getMessage(), HttpStatus.CREATED, null));
    }

    @GetMapping
    @Operation(summary = "Get Applications", description = "Fetch Applications details based on the filter.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Get Application full details fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = PageResponseDto.class)))
    })
    public ResponseEntity<CommonResponseUtil> getFileTransactionApps(
            @Parameter(description = "Page number (starting from 1)", example = "1") @RequestParam(name = "page", defaultValue = "1")
            @Min(value = 1, message = "The page must be a positive number.")
            Integer pageNumber,
            @Parameter(description = "Page size (max 500)", example = "10") @RequestParam(name = "limit", defaultValue = "10")
            @Min(value = 1, message = "The limit must be a positive number.")
            @Max(value = 500, message = "The limit must not exceed 500.")
            Integer pageSize,
            @Parameter(description = "Optional AppNoOrAggNo to search by AppNoOrAggNo", example = "12345") @RequestParam(name = "appNoOrAggNo", required = false) String appNoOrAggNo,
            @Parameter(description = "Optional likeAppNoOrBarcode to search by likeAppNoOrBarcode", example = "12345") @RequestParam(name = "likeAppNoOrBarcode", required = false) String likeAppNoOrBarcode,
            @Parameter(description = "Optional stage to search by stage", example = "Query") @RequestParam(name = "stages", required = false) List<StageEnum> stages,
            @Parameter(description = "Search by queryState Query name") @RequestParam(name = "queryState", required = false) StatusEnum queryState,
            @Parameter(description = "Search by user assigned related applications") @RequestParam(name = "assignedUser", required = false) List<UUID> assignedUsers,
            @Parameter(description = "Search by related branch users applications") @RequestParam(name = "branchUser", required = false) UUID branchUser,
            @Parameter(description = "Search by related isLocked applications") @RequestParam(name = "isLocked", required = false) Boolean isLocked,
            @Parameter(description = "Optional stampType to search by stampType", example = "VARIABLE") @RequestParam(name = "stampType", required = false) StatusEnum stampType,
            @Parameter(description = "Optional queryCartonBarcode to search by queryCartonBarcode", example = "12345") @RequestParam(name = "queryCartonBarcode", required = false) String queryCartonBarcode,
            @Parameter(description = "Optional state to search by state", example = "California") @RequestParam(name = "state", required = false) String stateName,
            @Parameter(description = "Start date for filtering") @RequestParam(name = "startDate", required = false) LocalDate startDate,
            @Parameter(description = "End date for filtering") @RequestParam(name = "endDate", required = false) LocalDate endDate,
            @Parameter(description = "Export all records") @RequestParam(name = "exportAllRecords", required = false, defaultValue = "false") Boolean exportAllRecords

    ) {
        LocalDateTime startDateTime = startDate != null ? startDate.atStartOfDay() : null;

        LocalDateTime endDateTime = endDate != null ? endDate.plusDays(1).atStartOfDay() : null;

        if (!Boolean.TRUE.equals(exportAllRecords) && pageSize > 500) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ResponseUtil.badRequest(String.format(ResponseMessage.PAGE_SIZE_EXCEEDS_LIMIT.getMessage(), 500), HttpStatus.BAD_REQUEST));
        }

        if ((startDate == null) != (endDate == null) || (startDate != null && startDate.isAfter(endDate))) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ResponseUtil.badRequest(String.format(ResponseMessage.INVALID_DATE_RANGE.getMessage(), startDate, endDate), HttpStatus.BAD_REQUEST));
        }
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.APPLICATION_DETAILS_FETCHED.getMessage(), HttpStatus.OK, fileTransactionService.getFileTransactionApps(pageNumber, pageSize, appNoOrAggNo, likeAppNoOrBarcode, stages, assignedUsers, branchUser, isLocked, stampType, queryState, queryCartonBarcode, startDateTime, endDateTime, exportAllRecords)));
    }

    @PostMapping("/lock")
    @Operation(summary = "Lock Applications", description = "Lock or Unlock Applications based on the transactionIds.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Applications locked or unlocked successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or bad request")
    })
    public ResponseEntity<CommonResponseUtil> lockFileTransactionApps(
            @Parameter(description = "Optional appNos to search by appNos", example = "12345") @RequestParam(name = "appNos") List<String> appNos,
            @Parameter(description = "Search by related isLocked applications") @RequestParam(name = "isLocked") Boolean isLocked
    ) {
        fileTransactionService.lockFileTransactionApps(appNos, isLocked);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.APPLICATIONS_LOCKED.getMessage(), HttpStatus.OK, null));
    }

}