package com.chola.physical_file.fileTransaction.dto;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.Update;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionsDto {

    //    @NotNull(groups = Update.class, message = "Transaction id is required for update")
    private UUID transactionId;
    @NotNull(groups = {Create.class, Update.class}, message = "App no is required")
    private String appNo;
    private String aggNo;
    private String podNo;
    private String barcode;
    private Integer ageingNo;
    private Boolean isESign;
    private Long leadId;
    private String customerName;
    private BigDecimal amountFinance;
    private String schemaProduct;
    private String scheme;
    private String queryCartonBarcode;
//    private String stateId;

    private String stateDesc;
    private String branchId;

    private String fundedCustomerType;
    private String rePaymentMode;
    private UUID workflowNo;
    private String eStamp;

    private StatusEnum stampType;
    private BigDecimal leapStampAmount;
    private BigDecimal discountStampAmount;
    private BigDecimal finalStampAmount;
    private LocalDateTime emiEndDate;

    private String branchDesc;
    private String modelNo;
    private String make;
    private String fileType;
    private String vBarCode;
    private String boxCode;
    @Max(value = 550, message = "Current remarks cannot exceed 550 characters")
    @NotNull(groups = {Create.class, Update.class}, message = "Stage id is required")
    private String currentRemarks;
    private UUID dmsId;
    private LocalDateTime handOffDate;
    private UUID rackId;
    private UUID rackAssignedId;
    private String stageName;
    @NotNull(groups = {Create.class, Update.class}, message = "Stage id is required")
    private UUID stageId;
    @NotNull(groups = {Create.class, Update.class}, message = "Query id is required")
    private UUID queryId;
    private UUID docAdminId;
    private UUID vendorId;
    private String queryName;
    private StatusEnum transactionStatus;
    @NotNull(groups = {Create.class, Update.class}, message = "Assigned user is required")
    private UUID assignedUser;
    private String genexFromBranch;
    private Boolean isHealthCheck;
    private List<UUID> stampStackMasterIds;
    private String missingPodNo;
    private String loanId;
    private LocalDate businessDate;
    private LocalDate sourcingDate;
    private Integer tenure;
    private BigDecimal birr;
    private String registrableStatus;
    private String udhayamNumberStatus;
    private BigDecimal pacAmount;

    private UUID createdBy;
    private LocalDateTime createdDate;
    private UUID modifiedBy;
    private LocalDateTime modifiedDate;
}
