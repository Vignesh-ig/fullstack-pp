package com.chola.physical_file.stamp.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StampTransactionAssignedDto {

    private UUID stampTransactionAssignedId;

    private UUID transactionId;

    private UUID stampStackMasterId;

    private UUID createdBy;

    private LocalDateTime createdDate;
}