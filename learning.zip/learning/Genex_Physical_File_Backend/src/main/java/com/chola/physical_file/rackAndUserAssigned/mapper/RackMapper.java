package com.chola.physical_file.rackAndUserAssigned.mapper;

import com.chola.physical_file.rackAndUserAssigned.dto.RackDto;
import com.chola.physical_file.rackAndUserAssigned.entity.RackEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class RackMapper {

    public RackDto entityToDto(RackEntity rackEntity) {

        if (rackEntity == null) {
            return null;
        }

        return RackDto.builder()
                .rackId(rackEntity.getRackId())
                .rackName(rackEntity.getRackName())
                .vaultName(rackEntity.getVaultName())
                .rackPosition(rackEntity.getRackPosition())
                .rackStatus(rackEntity.getRackStatus())
                .rackAppCount(rackEntity.getRackAppCount())
                .createdBy(rackEntity.getCreatedBy())
                .createdDate(rackEntity.getCreatedDate())
                .modifiedBy(rackEntity.getModifiedBy())
                .modifiedDate(rackEntity.getModifiedDate())
                .build();
    }

    public RackEntity dtoToEntity(RackDto rackDto) {

        if (rackDto == null) {
            return null;
        }

        return RackEntity.builder()
                .rackId(rackDto.getRackId())
                .rackName(rackDto.getRackName())
                .vaultName(rackDto.getVaultName())
                .rackPosition(rackDto.getRackPosition())
                .rackStatus(rackDto.getRackStatus())
                .createdBy(rackDto.getCreatedBy())
                .modifiedBy(rackDto.getCreatedBy())
                .build();
    }

    public List<RackDto> toDtos(List<RackEntity> rackEntityList) {
        return rackEntityList.stream()
                .map(this::entityToDto)
                .toList();
    }
}