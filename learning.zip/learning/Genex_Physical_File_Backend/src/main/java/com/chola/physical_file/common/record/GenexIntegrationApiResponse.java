package com.chola.physical_file.common.record;

import java.util.List;

public record GenexIntegrationApiResponse<T>(
        String message,
        List<T> result,
        String code,
        Integer statusCode,
        String status
) { }