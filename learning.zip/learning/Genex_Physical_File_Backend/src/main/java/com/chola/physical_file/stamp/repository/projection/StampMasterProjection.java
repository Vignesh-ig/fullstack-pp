package com.chola.physical_file.stamp.repository.projection;

import com.chola.physical_file.common.enums.StatusEnum;

import java.time.LocalDateTime;
import java.util.UUID;

public interface StampMasterProjection {

    UUID getStampMasterId();

    UUID getStampDenominationMasterId();

    Integer getStampDenominationNo();

    UUID getStampTypeMasterId();

    String getStampTypeName();

    String getState();

    Boolean getStatus();

    UUID getCreatedBy();

    LocalDateTime getCreatedDate();

    UUID getModifiedBy();

    LocalDateTime getModifiedDate();
}