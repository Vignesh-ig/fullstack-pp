package com.chola.physical_file.query.entity;

import com.chola.physical_file.common.enums.StatusEnum;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "queries", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QueryMasterEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "queries_id")
    private UUID queriesId;

    @Enumerated(EnumType.STRING)
    @Column(name = "query_name")
    private StatusEnum queryName;

    @Column(name = "created_by")
    private UUID createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private UUID modifiedBy;

    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;
}