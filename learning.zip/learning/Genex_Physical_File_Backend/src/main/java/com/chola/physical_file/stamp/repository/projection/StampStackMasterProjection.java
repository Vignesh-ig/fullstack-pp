package com.chola.physical_file.stamp.repository.projection;

import com.chola.physical_file.common.enums.StatusEnum;

import java.util.UUID;

public interface StampStackMasterProjection {

    UUID getStampStackMasterId();

    Integer getDenominationAmount();

    String getDenominationSerialNo();

    String getState();

    StatusEnum getStatus();

    UUID getUsedBy();

    String getUsedUserName();
}