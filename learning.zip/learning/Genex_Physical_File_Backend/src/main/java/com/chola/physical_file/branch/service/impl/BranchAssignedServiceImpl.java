package com.chola.physical_file.branch.service.impl;

import com.chola.physical_file.auditLog.customAnnotation.AuditLog;
import com.chola.physical_file.branch.entity.BranchUserAssignedEntity;
import com.chola.physical_file.branch.repository.BranchAssignedRepository;
import com.chola.physical_file.branch.service.BranchAssignedService;
import com.chola.physical_file.branch.service.BranchMasterService;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.userManagement.entity.UserEntity;
import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BranchAssignedServiceImpl implements BranchAssignedService {

    private final BranchAssignedRepository branchAssignedRepository;
    private final EntityManager entityManager;
    private final BranchMasterService branchMasterService;

    private static final int BATCH_SIZE = 1000;

    @AuditLog(
            action = "ASSIGN_BRANCH_TO_USER",
            module = "BRANCH_ASSIGNMENT",
            entity = "USER_BRANCH_ASSIGNMENT"
    )
    @Override
    public void branchesAssignedToUser(UserEntity user, List<String> branchIds, UUID createdBy) {

        validateBranches(branchIds);

        int count = 0;

        for (String branchId : branchIds) {

            BranchUserAssignedEntity entity =
                    BranchUserAssignedEntity.builder()
                            .userId(user.getUserId())
                            .genexBranchId(branchId)
                            .status(Boolean.TRUE)
                            .createdBy(createdBy)
                            .modifiedBy(createdBy)
                            .build();

            entityManager.persist(entity);

            if (++count % BATCH_SIZE == 0) {
                entityManager.flush();
                entityManager.clear();
            }
        }

        entityManager.flush();
        entityManager.clear();
    }

    @AuditLog(
            action = "UPDATE_USER_BRANCH_ASSIGNMENT",
            module = "BRANCH_ASSIGNMENT",
            entity = "USER_BRANCH_ASSIGNMENT"
    )
    @Override
    public void updateUserBranchesAssigned(UserEntity user, List<String> branchIds, UUID modifiedBy) {

        List<String> requestedBranchIds = branchIds == null ? Collections.emptyList() : branchIds;

        validateBranches(requestedBranchIds);

        List<String> branchIdsByUserId = branchAssignedRepository.findBranchIdsByUserId(user.getUserId());

        if (branchIdsByUserId.equals(requestedBranchIds)) {
            return;
        }

        branchAssignedRepository.deleteByUserIds(Collections.singletonList(user.getUserId()));

        if (!requestedBranchIds.isEmpty()) {
            branchesAssignedToUser(user, requestedBranchIds, modifiedBy);
        }
    }

    @AuditLog(
            action = "DELETE_USER_BRANCH_ASSIGNMENT",
            module = "BRANCH_ASSIGNMENT",
            entity = "USER_BRANCH_ASSIGNMENT"
    )
    @Override
    public void deleteUserBranchAssigned(UUID userId) {
        branchAssignedRepository.deleteByUserIds(Collections.singletonList(userId));
    }

    @AuditLog(
            action = "DELETE_USERS_BRANCH_ASSIGNMENT",
            module = "BRANCH_ASSIGNMENT",
            entity = "USER_BRANCH_ASSIGNMENT"
    )
    @Override
    public void deleteUsersBranchAssigned(List<UUID> userIds) {
        branchAssignedRepository.deleteByUserIds(userIds);
    }

    @Override
    public List<String> getUserAssignedBranchIds(UUID userId) {
        return branchAssignedRepository.findBranchIdsByUserId(userId);
    }

    @Override
    public List<BranchUserAssignedEntity> usersAssignedBranches(List<UUID> userIds) {
        return branchAssignedRepository.findByUserIdIn(userIds);
    }

    public void validateBranches(List<String> branchIds) {

        if (branchIds == null || branchIds.isEmpty()) {
            throw new IllegalArgumentException(ResponseMessage.BRANCH_IDS_EMPTY.getMessage());
        }
        if (branchIds.stream().distinct().count() != branchIds.size()) {
            throw new IllegalArgumentException(
                    ResponseMessage.DUPLICATE_BRANCH_IDS.getMessage()
            );
        }
//        long count = branchMasterService.countByBranchIdIn(branchIds);
//        if (count != branchIds.size()) {
//            throw new ResourceNotFoundException(ResponseMessage.ONE_OR_MORE_BRANCHES_NOT_FOUND.getMessage());
//        }
    }
}