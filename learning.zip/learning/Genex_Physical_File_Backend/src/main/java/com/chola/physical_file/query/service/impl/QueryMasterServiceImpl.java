package com.chola.physical_file.query.service.impl;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.query.dto.QueryMasterDto;
import com.chola.physical_file.query.entity.QueryMasterEntity;
import com.chola.physical_file.query.mapper.QueryMasterMapper;
import com.chola.physical_file.query.repository.QueryMasterRepository;
import com.chola.physical_file.query.service.QueryMasterService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class QueryMasterServiceImpl implements QueryMasterService {

    private final QueryMasterRepository queryMasterRepository;
    private final QueryMasterMapper queryMasterMapper;

    @Override
    @Transactional(readOnly = true)
    public PageResponseDto getAllQueries(Integer pageNumber, Integer pageSize, List<StatusEnum> excludeStatusSearch, List<StatusEnum> includeStatusSearch) {
        PageResponseDto pageResponseDto = new PageResponseDto();
        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "createdDate")
        );
        excludeStatusSearch = (excludeStatusSearch == null || excludeStatusSearch.isEmpty()) ? null : excludeStatusSearch;
        includeStatusSearch = (includeStatusSearch == null || includeStatusSearch.isEmpty()) ? null : includeStatusSearch;
        Page<QueryMasterEntity> pageResponse = queryMasterRepository.findQueries(excludeStatusSearch, includeStatusSearch, pageable);
        List<QueryMasterDto> rackDtoList = queryMasterMapper.toDtos(pageResponse.getContent());
        pageResponseDto.setData(rackDtoList);
        pageResponseDto.setCurrentPage(pageResponse.getNumber() + 1);
        pageResponseDto.setTotalItems((int) pageResponse.getTotalElements());
        pageResponseDto.setTotalPages(pageResponse.getTotalPages());
        pageResponseDto.setHasNextPage(pageResponse.hasNext());
        pageResponseDto.setHasPreviousPage(pageResponse.hasPrevious());
        return pageResponseDto;
    }
}