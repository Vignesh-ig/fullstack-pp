package com.chola.physical_file.vault.dto;

import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VaultMasterDto {
    private UUID vaultId;
    private String vaultName;
    private UUID createdBy;
    private LocalDateTime createdDate;
    private UUID modifiedBy;
    private LocalDateTime modifiedDate;
}