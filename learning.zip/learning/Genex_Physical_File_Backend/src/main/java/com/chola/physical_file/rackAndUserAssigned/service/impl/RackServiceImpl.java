package com.chola.physical_file.rackAndUserAssigned.service.impl;

import com.chola.physical_file.auditLog.customAnnotation.AuditLog;
import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.exception.ResourceNotFoundException;
import com.chola.physical_file.rackAndUserAssigned.dto.RackDto;
import com.chola.physical_file.rackAndUserAssigned.entity.RackEntity;
import com.chola.physical_file.rackAndUserAssigned.mapper.RackMapper;
import com.chola.physical_file.rackAndUserAssigned.repository.RackRepository;
import com.chola.physical_file.rackAndUserAssigned.service.RackService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RackServiceImpl implements RackService {

    private final RackMapper rackMapper;
    private final RackRepository rackRepository;

    @Value("${rack.master.max-rack-app-count}")
    private int maxRackAppCount;

    @AuditLog(
            action = "CREATE_RACK_MASTER",
            module = "RACK",
            entity = "RACK_MASTER"
    )
    @Override
    @Transactional
    public void createRack(RackDto rackDto) {
        if (rackRepository.existsByVaultNameAndRackNameAndRackPosition(rackDto.getVaultName(),rackDto.getRackName(), rackDto.getRackPosition())) {
            throw new IllegalArgumentException(String.format(ResponseMessage.VAULT_AND_RACK_WITH_NAME_POSITION_EXISTS.getMessage(), rackDto.getVaultName(), rackDto.getRackName(), rackDto.getRackPosition()));
        }
        rackRepository.save(rackMapper.dtoToEntity(rackDto));
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponseDto getAllRacks(Integer pageNumber, Integer pageSize, String searchByVaultName, String searchByRackName, Boolean searchByRackStatus) {
        PageResponseDto pageResponseDto = new PageResponseDto();
        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "createdDate")
        );

        Page<RackEntity> pageResponse = rackRepository.searchRacks(searchByVaultName,searchByRackName, searchByRackStatus, pageable);
        List<RackDto> rackDtoList = rackMapper.toDtos(pageResponse.getContent());
        pageResponseDto.setData(rackDtoList);
        pageResponseDto.setCurrentPage(pageResponse.getNumber() + 1);
        pageResponseDto.setTotalItems((int) pageResponse.getTotalElements());
        pageResponseDto.setTotalPages(pageResponse.getTotalPages());
        pageResponseDto.setHasNextPage(pageResponse.hasNext());
        pageResponseDto.setHasPreviousPage(pageResponse.hasPrevious());
        return pageResponseDto;
    }

    @AuditLog(
            action = "UPDATE_RACK_MASTER",
            module = "RACK",
            entity = "RACK_MASTER"
    )
    @Override
    @Transactional
    public void updateRack(RackDto rackDto) {
        RackEntity existingEntity = rackRepository.findById(rackDto.getRackId())
                .orElseThrow(() -> new ResourceNotFoundException(String.format(ResponseMessage.RACK_NOT_FOUND_WITH_ID.getMessage(), rackDto.getRackId())));

        validateUpdateRackNameAndRackPosition(existingEntity, rackDto);
        existingEntity.setModifiedBy(rackDto.getModifiedBy());
        rackRepository.save(existingEntity);
    }

    @AuditLog(
            action = "DELETE_RACK_MASTER",
            module = "RACK",
            entity = "RACK_MASTER"
    )
    @Override
    @Transactional
    public void deleteRacks(List<UUID> rackIds) {
        rackRepository.deleteAllByIdInBatch(rackIds);
    }

    @Override
    public void adjustRackCapacity(Map<UUID, Long> rackCountChanges) {

        Set<UUID> rackIds = rackCountChanges.keySet();

        List<RackEntity> racks = rackRepository.findAllByRackIdsForUpdate(rackIds);

        Map<UUID, RackEntity> rackMap = racks.stream()
                .collect(Collectors.toMap(
                        RackEntity::getRackId,
                        Function.identity()
                ));

        for (Map.Entry<UUID, Long> entry : rackCountChanges.entrySet()) {

            UUID rackId = entry.getKey();
            long entryValue = entry.getValue();

            RackEntity rack = rackMap.get(rackId);

            validateRackExists(rack, rackId);

            int currentCount = Optional.ofNullable(rack.getRackAppCount())
                    .orElse(0);

            long finalCount = currentCount + entryValue;

            validateRackCapacity(rack, currentCount, entryValue, finalCount);

            rack.setRackAppCount((int) finalCount);
            rack.setRackStatus(finalCount != maxRackAppCount);
        }
    }

    // VALIDATE RACK EXISTS
    public void validateRackExists(RackEntity rack, UUID rackId) {

        if (rack == null) {
            throw new ResourceNotFoundException(String.format(ResponseMessage.RACK_NOT_FOUND_WITH_ID.getMessage(), rackId));
        }
    }

    public void validateRackCapacity(RackEntity rack, int currentCount, long delta, long finalCount) {

        // NEGATIVE VALIDATION
        if (finalCount < 0) {
            throw new IllegalArgumentException(String.format(ResponseMessage.INVALID_RACK_COUNT_NEGATIVE.getMessage(), rack.getRackName()));
        }

        // MAX CAPACITY VALIDATION
        if (finalCount > maxRackAppCount) {
            throw new IllegalArgumentException(String.format(ResponseMessage.RACK_FULL_MESSAGE.getMessage(), rack.getRackName(), rack.getRackStatus(), currentCount, delta, maxRackAppCount));
        }
    }

    public void validateUpdateRackNameAndRackPosition(RackEntity existingEntity, RackDto rackDto) {
        if (!Objects.equals(existingEntity.getVaultName(), rackDto.getVaultName()) || !Objects.equals(existingEntity.getRackName(), rackDto.getRackName()) ||
                !Objects.equals(existingEntity.getRackPosition(), rackDto.getRackPosition())) {
            if (rackRepository.existsByVaultNameAndRackNameAndRackPosition(rackDto.getVaultName(),rackDto.getRackName(), rackDto.getRackPosition())) {
                throw new IllegalArgumentException(String.format(ResponseMessage.VAULT_AND_RACK_WITH_NAME_POSITION_EXISTS.getMessage(), rackDto.getVaultName(), rackDto.getRackName(), rackDto.getRackPosition()));
            }
            existingEntity.setVaultName(rackDto.getVaultName());
            existingEntity.setRackName(rackDto.getRackName());
            existingEntity.setRackPosition(rackDto.getRackPosition());
        }
    }

}