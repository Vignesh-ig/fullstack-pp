package com.chola.physical_file.userManagement.service;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.userManagement.dto.RoleDto;

import java.util.List;
import java.util.UUID;

public interface RoleService {
    PageResponseDto getAllRoles(Integer pageNumber, Integer pageSize);

    void createRole(RoleDto roleDto);

    void deleteRole(List<UUID> roleIds);
}
