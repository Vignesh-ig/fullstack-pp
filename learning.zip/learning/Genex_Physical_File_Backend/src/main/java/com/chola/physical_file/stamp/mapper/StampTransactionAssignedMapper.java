package com.chola.physical_file.stamp.mapper;

import com.chola.physical_file.stamp.dto.StampTransactionAssignedDto;
import com.chola.physical_file.stamp.entity.StampTransactionAssignedEntity;
import java.util.Collections;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class StampTransactionAssignedMapper {

    public StampTransactionAssignedDto entityToDto(StampTransactionAssignedEntity stampTransactionAssignedEntity) {
        if (stampTransactionAssignedEntity == null) {
            return null;
        }

        return StampTransactionAssignedDto.builder()
                .stampTransactionAssignedId(stampTransactionAssignedEntity.getStampTransactionAssignedId())
                .transactionId(stampTransactionAssignedEntity.getTransactionId())
                .stampStackMasterId(stampTransactionAssignedEntity.getStampStackMasterId())
                .createdBy(stampTransactionAssignedEntity.getCreatedBy())
                .createdDate(stampTransactionAssignedEntity.getCreatedDate())
                .build();
    }

    public StampTransactionAssignedEntity dtoToEntity(StampTransactionAssignedDto stampTransactionAssignedDto) {
        if (stampTransactionAssignedDto == null) {
            return null;
        }

        return StampTransactionAssignedEntity.builder()
                .transactionId(stampTransactionAssignedDto.getTransactionId())
                .stampStackMasterId(stampTransactionAssignedDto.getStampStackMasterId())
                .createdBy(stampTransactionAssignedDto.getCreatedBy())
                .build();
    }

    public List<StampTransactionAssignedEntity> dtoToEntity(List<StampTransactionAssignedDto> stampTransactionAssignedDtos) {
        if (stampTransactionAssignedDtos == null || stampTransactionAssignedDtos.isEmpty()) {
            return Collections.emptyList();
        }
        return stampTransactionAssignedDtos.stream()
                .map(this::dtoToEntity)
                .toList();
    }
}