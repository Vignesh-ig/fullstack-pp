package com.chola.physical_file.userManagement.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserBasicDetailsDto {
    private UUID userId;
    private String userName;
    private String userEmail;
    private String userEmployeeCode;
    private String userRoleName;
}
