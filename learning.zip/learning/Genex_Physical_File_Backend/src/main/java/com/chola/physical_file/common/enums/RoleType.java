package com.chola.physical_file.common.enums;

public enum RoleType {
    DOC_ADMIN_USER,
    AUDIT_USER,
    BRANCH_USER,
    STAMPING_USER,
    CPU_USER,
    ADMIN_USER,
    BRANCH_ADMIN_USER,
    STAMPING_ADMIN_USER,
    CPU_ADMIN_USER,
    SUPER_ADMIN_USER
}