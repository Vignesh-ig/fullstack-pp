package com.chola.physical_file.query.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class QueryCategoryDto {

    private UUID queryCategoryId;

    private String queryCategoryName;

    private String queryCategoryDescription;

    private String queryCategoryType;

    private UUID createdBy;

    private LocalDateTime createdDate;
}