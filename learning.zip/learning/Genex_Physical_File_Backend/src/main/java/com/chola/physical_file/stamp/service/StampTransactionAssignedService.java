package com.chola.physical_file.stamp.service;

import com.chola.physical_file.stamp.dto.StampTransactionAssignedDto;

import java.util.List;

public interface StampTransactionAssignedService {
    void createStampTransactionAssignments(List<StampTransactionAssignedDto> stampTransactionAssignedDtoList);
}