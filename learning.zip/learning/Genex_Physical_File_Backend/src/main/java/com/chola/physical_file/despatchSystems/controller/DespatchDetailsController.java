package com.chola.physical_file.despatchSystems.controller;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.util.ResponseUtil;
import com.chola.physical_file.despatchSystems.service.DespatchDetailsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/despatchDetails")
@RequiredArgsConstructor
@Tag(name = "Despatch Details", description = "APIs to fetch and search despatch details")
public class DespatchDetailsController {

    private final DespatchDetailsService despatchDetailsService;

    /*
     * API to fetch despatch details with pagination
     */
    @GetMapping
    @Operation(summary = "Get despatch details", description = "Fetch paginated despatch details. Use page and limit to paginate results.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Despatch details are fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = PageResponseDto.class)))
    })
    public ResponseEntity<?> getDespatchDetails(@Parameter(description = "App number or Barcode number to filter results", example = "99999") @RequestParam(name = "appNoOrBarcode", required = false) String appNoOrBarcode) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.DESPATCH_DETAILS_FETCHED.getMessage(), HttpStatus.OK, despatchDetailsService.getDespatchDetails(appNoOrBarcode)));
    }

    @GetMapping("/appNo")
    @Operation(summary = "Search despatch by application number", description = "Fetch despatch details filtered by agreement number with pagination.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Application details are fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = PageResponseDto.class))),
            @ApiResponse(responseCode = "400", description = "Bad request when Agreement Number is empty")
    })
    public ResponseEntity<?> getDespatchDetailsBasicDetails(@Parameter(description = "Page number (starting from 1)", example = "1") @RequestParam(name = "page", defaultValue = "1") Integer pageNumber,
                                                @Parameter(description = "Page size (max 100)", example = "10") @RequestParam(name = "limit", defaultValue = "10") Integer pageSize,
                                                @Parameter(description = "Agreement Number to filter results", example = "99999") @RequestParam(name = "agreementNo", required = false) String agreementNo) {
        if (agreementNo == null || agreementNo.trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(ResponseUtil.badRequest(ResponseMessage.AGREEMENT_NUMBER_EMPTY.getMessage(), HttpStatus.BAD_REQUEST));
        }
        PageResponseDto pageResponseDespatchDetails = despatchDetailsService.getDespatchDetailsByAgreementNo(pageNumber, pageSize, agreementNo);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.APPLICATION_DETAILS_FETCHED.getMessage(), HttpStatus.OK, pageResponseDespatchDetails));

    }

}