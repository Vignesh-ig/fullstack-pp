package com.chola.physical_file.fileTransaction.repository.projection;

import com.chola.physical_file.common.enums.StageEnum;
import com.chola.physical_file.common.enums.StatusEnum;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

public interface TransactionAppDetailsProjection {

    // Transaction
    UUID getTransactionId();
    String getAppNo();
    String getBarcode();
    String getPodNo();

    String getMissingPodNo();
    Boolean getIsESign();
    String getAggNo();
    Long getLeadId();
    String getCustomerName();
    BigDecimal getAmountFinance();
    String getSchemaProduct();
    String getScheme();
    String getState();
    String getBranchDesc();
    String getModelNo();
    String getMake();
    String getVBarCode();
    String getBoxCode();
    String getCurrentRemarks();
    UUID getDmsId();
    LocalDateTime getHandOffDate();
    String getGenexFromBranch();
    StatusEnum getTransactionStatus();
    Boolean getIsLocked();

    LocalDateTime getOutwardDate();

    String getStateDesc();

    String getLoanId();

    LocalDate getBusinessDate();

    LocalDate getSourcingDate();

    Integer getTenure();

    BigDecimal getBirr();

    String getRegistrableStatus();

    String getUdhayamNumberStatus();

    BigDecimal getPacAmount();

    String getWorkflowNo();

    String getFundedCustomerType();
    String getRePaymentMode();
    String getEStamp();

    String getStampType();
    BigDecimal getLeapStampAmount();
    BigDecimal getDiscountStampAmount();
    BigDecimal getFinalStampAmount();
    LocalDateTime getEmiEndDate();

    String getQueryCartonBarcode();
    String getFileType();

    // Rack
    UUID getRackId();
    String getRackName();
    String getVaultName();
    String getRackPosition();
    Boolean getRackStatus();
    Integer getRackAppCount();

    // Stage
    UUID getStageId();
    StageEnum getStageName();

    // Query
    UUID getQueryId();
    StatusEnum getQueryName();

    // Document Admin
    UUID getDocAdminId();
    String getDocAdminName();

    // Vendor
    UUID getVendorId();
    String getVendorName();

    // Assigned User
    UUID getAssignedUserId();
    String getAssignedUserName();
    String getAssignedEmployeeCode();
    String getAssignedUserEmail();

    // Modified User
    UUID getModifiedUserId();

    String getModifiedUserName();

    String getModifiedEmployeeCode();

    String getModifiedUserEmail();

    LocalDateTime getCreatedDate();

    LocalDateTime getModifiedDate();
}
