package com.chola.physical_file.userManagement.service.impl;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.exception.ResourceAlreadyExistsException;
import com.chola.physical_file.userManagement.dto.PermissionDto;
import com.chola.physical_file.userManagement.entity.PermissionEntity;
import com.chola.physical_file.userManagement.mapper.PermissionMapper;
import com.chola.physical_file.userManagement.repository.PermissionRepository;
import com.chola.physical_file.userManagement.repository.projection.PermissionProjection;
import com.chola.physical_file.userManagement.service.PermissionService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PermissionServiceImpl implements PermissionService {
    private final PermissionRepository permissionRepository;
    private final PermissionMapper permissionMapper;

    @PersistenceContext
    private EntityManager entityManager;

    @Value("${records.bulk.batch-size:100}")
    private int batchSize;

    private void persistTransactionsInBatch(List<PermissionEntity> permissionEntityList) {

        int count = 0;

        for (PermissionEntity permissionEntity : permissionEntityList) {

            if (permissionEntity.getPermissionId() == null) {
                entityManager.persist(permissionEntity);
            }

            if (++count % batchSize == 0) {
                entityManager.flush();
                entityManager.clear();
            }
        }

        entityManager.flush();
        entityManager.clear();
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponseDto getAllPermissions(Integer pageNumber, Integer pageSize, UUID role, String likePermissionName, UUID uniquePermissionsToRole) {
        PageResponseDto pageResponseDto = new PageResponseDto();
        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "createdDate")
        );
        Page<PermissionProjection> pageResponse = permissionRepository.findAllPermissions(role, likePermissionName, uniquePermissionsToRole, pageable);
        List<PermissionDto> permissionDtoList = permissionMapper.projectionsToDtos(pageResponse.getContent());
        pageResponseDto.setData(permissionDtoList);
        pageResponseDto.setCurrentPage(pageResponse.getNumber() + 1);
        pageResponseDto.setTotalItems((int) pageResponse.getTotalElements());
        pageResponseDto.setTotalPages(pageResponse.getTotalPages());
        pageResponseDto.setHasNextPage(pageResponse.hasNext());
        pageResponseDto.setHasPreviousPage(pageResponse.hasPrevious());
        return pageResponseDto;
    }

    @Override
    @Transactional
    public void createPermissionRecords(List<PermissionDto> permissionDtoList) {

        // Validate duplicates within request
        Set<String> requestKeys = new HashSet<>();

        for (PermissionDto permissionDto : permissionDtoList) {

            String key = permissionDto.getRoleId() + ":" +
                    permissionDto.getPermissionName().trim().toLowerCase();

            if (!requestKeys.add(key)) {
                throw new ResourceAlreadyExistsException(
                        "Duplicate permission in request for the given role and permission name: "
                                + permissionDto.getPermissionName()
                );
            }
            if (permissionRepository.existsByPermissionNameIgnoreCaseAndRole_RoleId(permissionDto.getPermissionName(), permissionDto.getRoleId())) {
                throw new ResourceAlreadyExistsException("Permission record already exists in DB for the given role and permission name");
            }
        }

        // Persist
        List<PermissionEntity> entitiesToPersist = permissionDtoList.stream()
                .map(permissionMapper::dtoToEntity)
                .toList();

        persistTransactionsInBatch(entitiesToPersist);
    }

    @Override
    @Transactional
    public void deletePermission(List<UUID> permissionIds) {
        permissionRepository.deleteAllByIdInBatch(permissionIds);
    }
}
