package com.chola.physical_file.common.record;

import java.util.List;

public record GenexDisbursementApiResponse<T>(
        String message,
        List<T> result
) {}