package com.chola.physical_file.auditLog.controller;

import com.chola.physical_file.auditLog.service.AuditLogService;
import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/auditLogs")
@Tag(name = "Audit Logs", description = "APIs to manage audit logs for tracking user actions and system events")
public class AuditLogController {

    private final AuditLogService auditLogService;

    @GetMapping
    @Operation  (summary = "Get audit logs", description = "Fetch paginated list of audit logs with optional filters for user actions and system events.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Audit logs fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = PageResponseDto.class)))
    })
    public ResponseEntity<CommonResponseUtil> getAuditLogs(
            @Parameter(description = "Page number (starting from 1)", example = "1") @RequestParam(name = "page", defaultValue = "1")
            @Min(value = 1, message = "The page must be a positive number.")
            Integer pageNumber,
            @Parameter(description = "Page size (max 100)", example = "10") @RequestParam(name = "limit", defaultValue = "10")
            @Min(value = 1, message = "The limit must be a positive number.")
            @Max(value = 100, message = "Maximum allowed limit is 100.")
            Integer pageSize
    ) {
        PageResponseDto pageResponseDto = auditLogService.getAuditLogs(pageNumber, pageSize);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.AUDIT_LOGS_FETCHED.getMessage(), HttpStatus.OK, pageResponseDto));
    }
}