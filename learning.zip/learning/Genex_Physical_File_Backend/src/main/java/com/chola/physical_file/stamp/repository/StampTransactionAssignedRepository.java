package com.chola.physical_file.stamp.repository;

import com.chola.physical_file.stamp.entity.StampTransactionAssignedEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface StampTransactionAssignedRepository extends JpaRepository<StampTransactionAssignedEntity, UUID> {
}