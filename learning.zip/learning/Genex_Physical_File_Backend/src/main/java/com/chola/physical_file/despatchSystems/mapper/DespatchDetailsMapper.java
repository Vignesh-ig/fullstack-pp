package com.chola.physical_file.despatchSystems.mapper;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.common.record.LeapVFAppDetailsResponse;
import com.chola.physical_file.despatchSystems.dto.DespatchCourierDto;
import com.chola.physical_file.despatchSystems.dto.DespatchDetailsDTO;
import com.chola.physical_file.despatchSystems.entity.DespatchDetailsEntity;
import com.chola.physical_file.despatchSystems.projection.DpAgreementNoBasicDetailsProjection;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Component
public class DespatchDetailsMapper {
    // handOffDate == disbursedDate
    public DespatchDetailsDTO convertEntityToDto(DespatchDetailsEntity despatchDetailsEntity, LeapVFAppDetailsResponse leapVFAppDetails) {
        if (despatchDetailsEntity == null) {
            return null;
        }
        return DespatchDetailsDTO.builder()
                // Despatch Details
                .dpId(despatchDetailsEntity.getDpId())
                .dpCourierNo(despatchDetailsEntity.getDpCourierNo())
                .dpAppNo(despatchDetailsEntity.getDpAppNo())
                .dpAppName(despatchDetailsEntity.getDpAppName())
                .dpAgreementNo(despatchDetailsEntity.getDpAgreementNo())
                .dpCreatedDate(despatchDetailsEntity.getDpCreatedDate())
                .dpBarcode(despatchDetailsEntity.getDpBarcode())
                .dpSchema(despatchDetailsEntity.getDpSchema())
                .dpIsEsign(despatchDetailsEntity.getDpIsEsign())
                .dpVehicleRegistrability(despatchDetailsEntity.getDpVehicleRegistrability())
                .leapAgingNo((int) ChronoUnit.DAYS.between(leapVFAppDetails != null ? leapVFAppDetails.businessDate() : LocalDate.now(), LocalDate.now()))
                // LEAP Details
                .amountFinance(leapVFAppDetails != null ? leapVFAppDetails.financeAmount() : null)
                .branchDesc(leapVFAppDetails != null ? leapVFAppDetails.branchDesc() : null)
                .stateDesc(leapVFAppDetails != null ? leapVFAppDetails.stateDesc() : null)
                .handOffDate(leapVFAppDetails != null && leapVFAppDetails.disbursedDate() != null ? leapVFAppDetails.disbursedDate().atStartOfDay() : null)
                .leapFileType(leapVFAppDetails != null ? leapVFAppDetails.fileType() : null)
                .leadId(leapVFAppDetails != null ? leapVFAppDetails.leadId() : null)
                .genexFromBranch(leapVFAppDetails != null ? leapVFAppDetails.branchId() : null)
                .stampType(mapStampType(leapVFAppDetails != null ? leapVFAppDetails.stampType() : null))
                .leapStampAmount(leapVFAppDetails != null && leapVFAppDetails.stampAmount() != null && !leapVFAppDetails.stampAmount().isBlank() ? new BigDecimal(leapVFAppDetails.stampAmount().trim()) : null)
                .fundedCustomerType(leapVFAppDetails != null ? leapVFAppDetails.fundedCustomerType() : null)
                .rePaymentMode(leapVFAppDetails != null ? leapVFAppDetails.rePaymentMode() : null)
                .eStamp(leapVFAppDetails != null ? leapVFAppDetails.eStamp() : null)
                .emiEndDate(leapVFAppDetails != null ? leapVFAppDetails.emiEndDate().atStartOfDay() : null)
                .loanId(leapVFAppDetails != null ? leapVFAppDetails.loanId() : null)
                .businessDate(leapVFAppDetails != null ? leapVFAppDetails.businessDate() : null)
                .sourcingDate(leapVFAppDetails != null ? leapVFAppDetails.sourcingDate() : null)
                .tenure(leapVFAppDetails != null ? leapVFAppDetails.tenure() : null)
                .birr(leapVFAppDetails != null ? leapVFAppDetails.birr() : null)
                .registrableStatus(leapVFAppDetails != null ? leapVFAppDetails.registrableStatus() : null)
                .udhayamNumberStatus(leapVFAppDetails != null ? leapVFAppDetails.udhayamNumberStatus() : null)
                .pacAmount(leapVFAppDetails != null ? leapVFAppDetails.pacAmount() : null)
                .workflowNo(leapVFAppDetails != null ? leapVFAppDetails.workflowNo() : null)
                .dmsId(leapVFAppDetails != null ? leapVFAppDetails.dmsId() : null)
                .build();
    }

    public List<DespatchDetailsDTO> convertProjectionsToDtos(List<DpAgreementNoBasicDetailsProjection> appNoBasicDetailsProjections) {

        if (appNoBasicDetailsProjections == null || appNoBasicDetailsProjections.isEmpty()) return List.of();

        return appNoBasicDetailsProjections.stream()
                .map(appNoBasicDetailsProjection -> {
                    DespatchCourierDto courierDto = null;

                    if (appNoBasicDetailsProjection.getDpCourierId() != null) {
                        courierDto = DespatchCourierDto.builder()
                                .DpCourierId(appNoBasicDetailsProjection.getDpCourierId())
                                .DpCourierName(appNoBasicDetailsProjection.getDpCourierName())
                                .build();
                    }

                    return DespatchDetailsDTO.builder()
                            .dpAppNo(appNoBasicDetailsProjection.getDpAgreementNo())
                            .dpCourierNo(appNoBasicDetailsProjection.getDpCourierNo())
                            .dpCreatedDate(appNoBasicDetailsProjection.getDpCreatedDate())
                            .despatchCourierDto(courierDto)
                            .build();
                })
                .toList();
    }


    public StatusEnum mapStampType(String stampType) {
        if (stampType != null && !stampType.trim().isEmpty()) {
            switch (stampType.trim().toLowerCase()) {
                case "variable" -> {
                    return StatusEnum.VARIABLE;
                }
                case "e-stamp" -> {
                    return StatusEnum.E_STAMP;
                }
                case "fixed" -> {
                    return StatusEnum.FIXED;
                }
                case "no-stamp" -> {
                    return StatusEnum.NO_STAMP;
                }
                default -> {
                    return null;
                }
            }
        } else {
            return null;
        }

    }
}