package com.chola.physical_file.stamp.service;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.dashboard.dto.DashboardDto;
import com.chola.physical_file.stamp.dto.CsvParseResult;
import com.chola.physical_file.stamp.dto.StampStackMasterDto;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;

public interface StampStackMasterService {

    PageResponseDto getStampStackMasterRecords(List<String> states, Integer denominationAmount, StatusEnum status, String denominationSerialNo, Integer pageNumber, Integer pageSize);

    CsvParseResult uploadStampStack(MultipartFile stampStackCsvFile, UUID createdBy);

    void updateStampStackMasterStatus(List<UUID> stampStackMasterIdList, UUID stampStackMasterUsedBy, StatusEnum statusEnum);

    List<StampStackMasterDto> getUsedStampStackByTransactionId(UUID transactionId);

    DashboardDto getStampStackMasterCount(List<String> states);
}