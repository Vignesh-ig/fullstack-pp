package com.chola.physical_file.stamp.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "stamp_denomination_master", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StampDenominationMasterEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "stamp_denomination_master_id")
    private UUID stampDenominationMasterId;

    @Column(name = "stamp_denomination_no")
    private Integer stampDenominationNo;

    @Column(name = "created_by")
    private UUID createdBy;

    @Column(name = "created_date")
    @CreationTimestamp
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private UUID modifiedBy;

    @Column(name = "modified_date")
    @UpdateTimestamp
    private LocalDateTime modifiedDate;
}