package com.chola.physical_file.userManagement.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RoleDto {

    private UUID roleId;
    private String roleName;
    private String description;
    private Boolean isActive;
    private LocalDateTime createdDate;
    private UUID createdBy;
    private LocalDateTime modifiedDate;
    private UUID modifiedBy;
    private List<PermissionDto> permissionDtoList;
}
