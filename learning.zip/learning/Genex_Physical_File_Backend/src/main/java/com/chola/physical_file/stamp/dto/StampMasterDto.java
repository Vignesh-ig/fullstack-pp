package com.chola.physical_file.stamp.dto;

import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.Update;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StampMasterDto {

    @NotNull(groups = Update.class, message = "Stamp id is required for update")
    private UUID stampMasterId;

    private UUID stampDenominationMasterId;

    private Integer stampDenominationNo;

    @NotNull(groups = {Create.class, Update.class}, message = "Stamp Type is required")
    private UUID stampTypeMasterId;

    private String stampTypeName;

    private String state;

    private Boolean status;

    @NotNull(groups = Create.class, message = "Created By is required for create")
    private UUID createdBy;

    private LocalDateTime createdDate;

    @NotNull(groups = Update.class, message = "Modified By is required for update")
    private UUID modifiedBy;

    private LocalDateTime modifiedDate;
}