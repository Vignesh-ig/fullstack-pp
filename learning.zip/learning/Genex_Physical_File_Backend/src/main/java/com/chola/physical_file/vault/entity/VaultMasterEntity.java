package com.chola.physical_file.vault.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "vault", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VaultMasterEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "vault_id")
    private UUID vaultId;
    @Column(name = "vault_name")
    private String vaultName;
    @Column(name = "created_by")
    private UUID createdBy;
    @Column(name = "created_date")
    private LocalDateTime createdDate;
    @Column(name = "modified_by")
    private UUID modifiedBy;
    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;
}