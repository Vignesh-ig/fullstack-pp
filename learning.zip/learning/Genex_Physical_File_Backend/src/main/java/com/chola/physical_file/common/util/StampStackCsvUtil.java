package com.chola.physical_file.common.util;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.stamp.dto.CsvParseResult;
import com.chola.physical_file.stamp.dto.StampStackCsvResponse;
import com.chola.physical_file.stamp.dto.StampStackMasterDto;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class StampStackCsvUtil {

    private static final Pattern DENOMINATION_PATTERN = Pattern.compile("^deno_(\\d+)$");

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yy");

    public CsvParseResult parseStampStackCsv(MultipartFile stampStackCsvFile) {

        validateFile(stampStackCsvFile);

        List<StampStackMasterDto> validRecords = new ArrayList<>();
        List<StampStackCsvResponse> validationErrors = new ArrayList<>();

        try (
                BufferedReader reader = new BufferedReader(new InputStreamReader(stampStackCsvFile.getInputStream(), StandardCharsets.UTF_8));

                CSVParser parser = CSVFormat.DEFAULT.builder()
                        .setHeader()
                        .setSkipHeaderRecord(true)
                        .setIgnoreEmptyLines(true)
                        .setTrim(true)
                        .build()
                        .parse(reader)
        ) {

            Map<String, Integer> headers = parser.getHeaderMap();

            String denominationHeader = validateHeaders(headers);

            Integer denominationAmount = extractDenominationAmount(denominationHeader);

            for (CSVRecord csvRecord : parser) {

                processRecord(csvRecord, denominationHeader, denominationAmount, validRecords, validationErrors);
            }

        } catch (IOException ex) {
            throw new RuntimeException("Unable to parse CSV.", ex);
        }

        int totalRecords = validRecords.size() + validationErrors.size();

        return CsvParseResult.builder()
                .validRecords(validRecords)
                .validationMessages(validationErrors)
                .totalRecords(totalRecords)
                .successfulRecords(0)
                .failedRecords(0)
                .build();
    }

    private void validateFile(MultipartFile file) {

        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("CSV file is empty.");
        }

        String fileName = file.getOriginalFilename();

        if (fileName == null || !fileName.toLowerCase().endsWith(".csv")) {
            throw new IllegalArgumentException("Only CSV files are allowed.");
        }
    }

    private String validateHeaders(Map<String, Integer> headers) {

        String denominationHeader = headers.keySet()
                .stream()
                .filter(header -> DENOMINATION_PATTERN.matcher(header).matches())
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Invalid first column. Expected format : deno_2000"));

        validateMandatoryHeader(headers, "Month");
        validateMandatoryHeader(headers, "State");
        validateMandatoryHeader(headers, "Usage_status");

        return denominationHeader;
    }

    private void validateMandatoryHeader(Map<String, Integer> headers,
                                         String column) {

        if (!headers.containsKey(column)) {
            throw new IllegalArgumentException("Missing mandatory column : " + column);
        }
    }

    private Integer extractDenominationAmount(String denominationHeader) {

        Matcher matcher = DENOMINATION_PATTERN.matcher(denominationHeader);

        if (!matcher.matches()) {
            throw new IllegalArgumentException("Invalid denomination header.");
        }

        return Integer.parseInt(matcher.group(1));
    }

    private void processRecord(CSVRecord csvRecord, String denominationHeader, Integer denominationAmount, List<StampStackMasterDto> validRecords, List<StampStackCsvResponse> validationErrors) {

        int csvRowNo = (int) csvRecord.getRecordNumber() + 1;

        String serialNo = csvRecord.get(denominationHeader).trim();
        String date = csvRecord.get("Month").trim();
        String state = csvRecord.get("State").trim();
        String usageStatus = csvRecord.get("Usage_status").trim();

        List<String> errors = new ArrayList<>();

        validateSerialNumber(serialNo, errors);

        LocalDateTime stampDate = parseStampDate(date, errors);

        validateState(state, errors);

        validateUsageStatus(usageStatus, errors);

        if (!errors.isEmpty()) {
            validationErrors.add(buildValidationResponse(csvRowNo, serialNo, errors));
            return;
        }

        validRecords.add(buildDto(csvRowNo, denominationAmount, serialNo, stampDate, state));
    }

    private void validateSerialNumber(String serialNo, List<String> errors) {

        if (serialNo == null || serialNo.isBlank()) {
            errors.add("Serial Number is mandatory.");
        }
    }

    private LocalDateTime parseStampDate(String value, List<String> errors) {

        try {

            LocalDate localDate = LocalDate.parse(value.trim(), DATE_FORMATTER);

            return localDate.atStartOfDay();

        } catch (DateTimeParseException ex) {

            errors.add("Invalid date format. Expected dd-MM-yy");

            return null;
        }
    }

    private void validateState(String state, List<String> errors) {

        if (state == null || state.isBlank()) {
            errors.add("State is mandatory.");
        }
    }

    private void validateUsageStatus(String usageStatus, List<String> errors) {

        if (!"IN-Stock".equalsIgnoreCase(usageStatus)) {
            errors.add("Usage_status should be IN-Stock.");
        }
    }

    private StampStackCsvResponse buildValidationResponse(Integer csvRowNo, String serialNo, List<String> errors) {

        return StampStackCsvResponse.builder()
                .csvRowNo(csvRowNo)
                .denominationSerialNo(serialNo)
                .csvRowMessage(String.join(" ", errors))
                .build();
    }

    private StampStackMasterDto buildDto(Integer csvRowNo, Integer denominationAmount, String serialNo, LocalDateTime stampDate, String state) {

        return StampStackMasterDto.builder()
                .csvRowNo(csvRowNo)
                .denominationAmount(denominationAmount)
                .denominationSerialNo(serialNo)
                .stampStackDate(stampDate)
                .state(state)
                .status(StatusEnum.IN_STOCK)
                .build();
    }
}