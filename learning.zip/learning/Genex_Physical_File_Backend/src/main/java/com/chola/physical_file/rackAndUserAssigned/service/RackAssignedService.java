package com.chola.physical_file.rackAndUserAssigned.service;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.RackAllocationAction;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.dashboard.dto.DashboardDto;
import com.chola.physical_file.rackAndUserAssigned.dto.RackAssignedDto;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@SuppressWarnings("all")
public interface RackAssignedService {
    void bulkRackAssigned(List<RackAssignedDto> rackAssignedDtos);

    PageResponseDto getAllRackAssigned(Integer pageNumber, Integer pageSize, List<UUID> assignedUsers, UUID assignedRack, StatusEnum assignedStatus, Boolean userAssigned, String appNoOrAggNo, String likeAppNoOrBarcode, UUID rackAssignedId, LocalDateTime startDate, LocalDateTime endDate);

    void updateBulkRackAssigned(List<RackAssignedDto> rackAssignedDto, RackAllocationAction rackAllocationAction);

    DashboardDto getAllocationAppCount(UUID assignedUser);
}
