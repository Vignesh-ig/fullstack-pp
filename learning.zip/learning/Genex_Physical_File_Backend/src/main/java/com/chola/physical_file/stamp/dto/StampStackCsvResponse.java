package com.chola.physical_file.stamp.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StampStackCsvResponse {
    private Integer csvRowNo;
    private String denominationSerialNo;
    private String csvRowMessage;
}