package com.chola.physical_file.common.util;

public interface Create {
}
