package com.chola.physical_file.common.dto;

import lombok.Data;
import java.util.List;

@Data
public class PageResponseDto {
    private List<?> data;
    private int currentPage;
    private int totalItems;
    private int totalPages;
    private boolean hasNextPage;
    private boolean hasPreviousPage;
}
