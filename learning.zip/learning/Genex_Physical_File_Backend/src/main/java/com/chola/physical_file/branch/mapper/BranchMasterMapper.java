package com.chola.physical_file.branch.mapper;

import org.springframework.stereotype.Component;

@Component
public class BranchMasterMapper {

}

