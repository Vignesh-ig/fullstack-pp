package com.chola.physical_file.userManagement.mapper;

import com.chola.physical_file.userManagement.dto.PermissionDto;
import com.chola.physical_file.userManagement.entity.PermissionEntity;
import com.chola.physical_file.userManagement.entity.RoleEntity;
import com.chola.physical_file.userManagement.repository.projection.PermissionProjection;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PermissionMapper {

    public PermissionDto entityToDto(PermissionEntity permissionEntity) {
        if (permissionEntity == null) return null;

        return PermissionDto.builder()
                .permissionId(permissionEntity.getPermissionId())
                .permissionName(permissionEntity.getPermissionName())
                .description(permissionEntity.getDescription())
                .roleId(permissionEntity.getRole() != null ? permissionEntity.getRole().getRoleId() : null)
                .createdBy(permissionEntity.getCreatedBy())
                .modifiedBy(permissionEntity.getModifiedBy())
                .build();
    }

    public PermissionEntity dtoToEntity(PermissionDto permissionDto) {
        if (permissionDto == null) return null;

        return PermissionEntity.builder()
                .permissionName(permissionDto.getPermissionName())
                .description(permissionDto.getDescription())
                .createdBy(permissionDto.getCreatedBy())
                .modifiedBy(permissionDto.getModifiedBy() != null ? permissionDto.getModifiedBy() : permissionDto.getCreatedBy())
                .role(RoleEntity.builder().roleId(permissionDto.getRoleId()).build())
                .build();
    }

    public List<PermissionDto> toDtos(List<PermissionEntity> entities) {
        return entities == null ? List.of() :
                entities.stream()
                        .map(this::entityToDto)
                        .toList();
    }

    public List<PermissionDto> projectionsToDtos(List<PermissionProjection> entities) {
        return entities == null ? List.of() :
                entities.stream()
                        .map(this::projectionToDto)
                        .toList();
    }

    public PermissionDto projectionToDto(PermissionProjection permissionProjection) {

        if (permissionProjection == null) {
            return null;
        }

        return PermissionDto.builder()
                .permissionId(permissionProjection.getPermissionId())
                .permissionName(permissionProjection.getPermissionName())
                .description(permissionProjection.getDescription())
                .roleId(permissionProjection.getRoleId())
                .roleName(permissionProjection.getRoleName())
                .createdBy(permissionProjection.getCreatedBy())
                .createdDate(permissionProjection.getCreatedDate())
                .modifiedBy(permissionProjection.getModifiedBy())
                .modifiedDate(permissionProjection.getModifiedDate())
                .build();
    }
}
