package com.chola.physical_file.rackAndUserAssigned.controller;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.ResponseUtil;
import com.chola.physical_file.common.util.Update;
import com.chola.physical_file.rackAndUserAssigned.dto.RackDto;
import com.chola.physical_file.rackAndUserAssigned.service.RackService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/rack")
@Validated
@Tag(name = "Rack Master Details", description = "APIs to fetch Rack master details")
public class RackController {

    private final RackService rackService;

    @GetMapping
    @Operation(summary = "Get all active rack records", description = "Fetch paginated list of active rack records.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Active rack records fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = PageResponseDto.class)))
    })
    public ResponseEntity<CommonResponseUtil> getAllRacks(
            @Parameter(description = "Page number (starting from 1)", example = "1") @RequestParam(name = "page", defaultValue = "1")
            @Min(value = 1, message = "The page must be a positive number.")
            Integer pageNumber,
            @Parameter(description = "Page size (max 500)", example = "10") @RequestParam(name = "limit", defaultValue = "10")
            @Min(value = 1, message = "The limit must be a positive number.") @Max(value = 500, message = "Maximum allowed limit is 500.")
            Integer pageSize,
            @Parameter(description = "Optional name to search vault by", example = "Vault A")
            @RequestParam(name = "searchByVaultName", required = false) String searchByVaultName,
            @Parameter(description = "Optional name to search rack by", example = "Chennai")
            @RequestParam(name = "searchByRackName", required = false) String searchByRackName,
            @Parameter(description = "Optional status to search rack by")
            @RequestParam(name = "searchByRackStatus", required = false) Boolean searchByRackStatus
    ) {
        PageResponseDto pageResponseDto = rackService.getAllRacks(pageNumber, pageSize, searchByVaultName,searchByRackName, searchByRackStatus);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.ACTIVE_RACK_RECORDS_FETCHED.getMessage(), HttpStatus.OK, pageResponseDto));
    }

    @PostMapping
    @Operation(summary = "Create rack record", description = "Create a new rack record with the provided details.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Rack record created successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or bad request")
    })
    public ResponseEntity<CommonResponseUtil> createRackRecord(@Validated(Create.class) @RequestBody RackDto rackDto) {
        rackService.createRack(rackDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ResponseUtil.success(ResponseMessage.RACK_CREATED.getMessage(), HttpStatus.CREATED, null));
    }

    @PutMapping
    @Operation(summary = "Update rack record", description = "Update an existing rack record with the provided details. Ensure to include the rackId in the request body.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Rack record updated successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error, bad request, or rack record not found")
    })
    public ResponseEntity<CommonResponseUtil> updateRackRecord(@Validated(Update.class) @RequestBody RackDto rackDto) {
        rackService.updateRack(rackDto);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.RACK_UPDATED.getMessage(), HttpStatus.OK, null));
    }

    @PostMapping("/ids")
    @Operation(summary = "Delete rack records", description = "Delete one or more rack records by their UUIDs. Provide rack IDs as query param 'rackIds'.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Rack record deleted successfully"),
            @ApiResponse(responseCode = "400", description = "Bad request when rackIds is empty or invalid")
    })
    public ResponseEntity<CommonResponseUtil> deleteRackRecords(@Parameter(description = "List of rack UUIDs to delete", required = true) @RequestParam(name = "rackIds") List<UUID> rackIds) {
        if (rackIds == null || rackIds.isEmpty()) {
            throw new IllegalArgumentException(ResponseMessage.RACK_IDS_EMPTY.getMessage());
        }
        rackService.deleteRacks(rackIds);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.RACK_DELETED.getMessage(), HttpStatus.OK, null));
    }

}