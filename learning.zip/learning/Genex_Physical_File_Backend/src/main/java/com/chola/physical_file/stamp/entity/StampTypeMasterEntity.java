package com.chola.physical_file.stamp.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "stamp_type_master", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StampTypeMasterEntity {

    @Id
    @Column(name = "stamp_type_master_id")
    private UUID stampTypeMasterId;

    @Column(name = "stamp_type_name")
    private String stampTypeName;

    @Column(name = "created_by")
    private UUID createdBy;

    @Column(name = "created_date")
    @CreationTimestamp
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private UUID modifiedBy;

    @Column(name = "modified_date")
    @UpdateTimestamp
    private LocalDateTime modifiedDate;
}