package com.chola.physical_file.stamp.controller;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.ResponseUtil;
import com.chola.physical_file.stamp.dto.StampMasterDto;
import com.chola.physical_file.stamp.service.StampMasterService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/stampMaster")
@Validated
@Tag(name = "Stamp Master", description = "APIs to manage stamp master records.")
public class StampMasterController {

    private final StampMasterService stampMasterService;

    @PostMapping
    @Operation(summary = "Create stamp master records", description = "Create a new stamp master records")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Stamp master record created successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or bad request")
    })
    public ResponseEntity<CommonResponseUtil> createStampMasterRecords(@Validated(Create.class) @RequestBody List<StampMasterDto> stampMasterDtoList) {
        stampMasterService.createStampMasterRecords(stampMasterDtoList);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ResponseUtil.success(ResponseMessage.STAMP_MASTER_RECORD_CREATED.getMessage(), HttpStatus.CREATED, null));
    }

    @GetMapping
    @Operation(summary = "Get Stamp Master Records", description = "Fetch Stamp Master records based on the filter.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Stamp Master records fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = PageResponseDto.class)))
    })
    public ResponseEntity<CommonResponseUtil> getStampMasterRecords(
            @Parameter(description = "Page number (starting from 1)", example = "1") @RequestParam(name = "page", defaultValue = "1")
            @Min(value = 1, message = "The page must be a positive number.")
            Integer pageNumber,
            @Parameter(description = "Page size (max 500)", example = "10") @RequestParam(name = "limit", defaultValue = "10")
            @Min(value = 1, message = "The limit must be a positive number.") @Max(value = 500, message = "Maximum allowed limit is 500.")
            Integer pageSize,
            @Parameter(description = "State filter for stamp master records", example = "California") @RequestParam(name = "state", required = false) String state,
            @Parameter(description = "Stamp Type filter for stamp master records", example = "Type A") @RequestParam(name = "stampType", required = false) UUID stampType,
            @Parameter(description = "Stamp Master ID filter for stamp master records", example = "1") @RequestParam(name = "stampMasterId", required = false) UUID stampMasterId
    ) {
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.STAMP_MASTER_RECORDS_FETCHED.getMessage(), HttpStatus.OK, stampMasterService.getStampMasterRecords(pageNumber, pageSize, state, stampType,stampMasterId)));
    }

}