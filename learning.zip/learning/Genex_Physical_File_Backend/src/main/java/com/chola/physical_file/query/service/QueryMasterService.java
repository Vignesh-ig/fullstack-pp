package com.chola.physical_file.query.service;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.StatusEnum;

import java.util.List;

public interface QueryMasterService {

    PageResponseDto getAllQueries(Integer pageNumber, Integer pageSize, List<StatusEnum> excludeStatusSearch, List<StatusEnum> includeStatusSearch);
}