package com.chola.physical_file.userManagement.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UserLogInRequestDto {

    @NotBlank(message = "User employee code is required")
    @Size(max = 15, message = "User employee code cannot exceed 15 characters")
    private String userEmployeeCode;

    @NotBlank(message = "Password is required")
    @Size(min = 6, max = 25, message = "Password must be between 6 and 25 characters")
    private String password;

}