package com.chola.physical_file.fileTransaction.mapper;

import com.chola.physical_file.fileTransaction.dto.TransactionsDto;
import com.chola.physical_file.fileTransaction.dto.TransactionsHistoryDto;
import com.chola.physical_file.fileTransaction.entity.TransactionsEntity;
import com.chola.physical_file.fileTransaction.entity.TransactionsHistoryEntity;
import com.chola.physical_file.fileTransaction.repository.projection.TransactionsHistoryProjection;
import com.chola.physical_file.userManagement.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class TransactionsHistoryMapper {
    private final UserMapper userMapper;

    public TransactionsHistoryDto entityToDto(TransactionsHistoryEntity transactionsHistoryEntity) {

        if (transactionsHistoryEntity == null) {
            return null;
        }

        return TransactionsHistoryDto.builder()
                .transactionsHistoryId(transactionsHistoryEntity.getTransactionsHistoryId())
                .appNo(transactionsHistoryEntity.getAppNo())
                .remarks(transactionsHistoryEntity.getRemarks())
                .stageId(transactionsHistoryEntity.getStageId())
                .queryId(transactionsHistoryEntity.getQueryId())
                .rackAssignedId(transactionsHistoryEntity.getRackAssignedId())
                .leadId(transactionsHistoryEntity.getLeadId())
                .transactionId(transactionsHistoryEntity.getTransactionId())
                .assignedTo(transactionsHistoryEntity.getAssignedTo())
                .createdBy(transactionsHistoryEntity.getCreatedBy())
                .createdDate(transactionsHistoryEntity.getCreatedDate())
                .build();
    }

    public TransactionsHistoryEntity dtoToEntity(TransactionsHistoryDto transactionsHistoryDto) {

        if (transactionsHistoryDto == null) {
            return null;
        }

        return TransactionsHistoryEntity.builder()
                .transactionsHistoryId(transactionsHistoryDto.getTransactionsHistoryId())
                .appNo(transactionsHistoryDto.getAppNo())
                .remarks(transactionsHistoryDto.getRemarks())
                .stageId(transactionsHistoryDto.getStageId())
                .queryId(transactionsHistoryDto.getQueryId())
                .rackAssignedId(transactionsHistoryDto.getRackAssignedId())
                .leadId(transactionsHistoryDto.getLeadId())
                .assignedTo(transactionsHistoryDto.getAssignedTo())
                .createdBy(transactionsHistoryDto.getCreatedBy())
                .createdDate(transactionsHistoryDto.getCreatedDate())
                .build();
    }

    public List<TransactionsHistoryDto> toDtos(List<TransactionsHistoryEntity> transactionsHistoryEntityList) {

        return transactionsHistoryEntityList.stream()
                .map(this::entityToDto)
                .toList();
    }

    public TransactionsHistoryEntity transactionsDtoToEntity(TransactionsEntity transactionsEntity, TransactionsDto transactionsDto) {
        if (transactionsEntity == null) {
            return null;
        }

        return TransactionsHistoryEntity.builder()
                .appNo(transactionsEntity.getAppNo())
                .remarks(transactionsEntity.getCurrentRemarks())
                .stageId(transactionsEntity.getStageId())
                .queryId(transactionsDto.getQueryId())
                .leadId(transactionsEntity.getLeadId())
                .rackAssignedId(transactionsDto.getRackAssignedId())
                .remarks(transactionsEntity.getCurrentRemarks())
                .transactionId(transactionsEntity.getTransactionId())
                .assignedTo(transactionsDto.getAssignedUser())
                .createdBy(transactionsDto.getCreatedBy() == null ? transactionsDto.getModifiedBy() : transactionsDto.getCreatedBy())
                .build();
    }

    public TransactionsHistoryDto toProjectionToDto(TransactionsHistoryProjection transactionsHistoryProjection) {

        return TransactionsHistoryDto.builder()
                .transactionsHistoryId(transactionsHistoryProjection.getTransactionsHistoryId())
                .appNo(transactionsHistoryProjection.getAppNo())
                .remarks(transactionsHistoryProjection.getRemarks())
                .stageId(transactionsHistoryProjection.getStageId())
                .transactionId(transactionsHistoryProjection.getTransactionId())
                .stageName(
                        transactionsHistoryProjection.getStageName() != null
                                ? transactionsHistoryProjection.getStageName().name()
                                : null
                )
                .queryId(transactionsHistoryProjection.getQueryId())
                .queryName(
                        transactionsHistoryProjection.getQueryName() != null
                                ? transactionsHistoryProjection.getQueryName().name()
                                : null
                )
                .createdDate(transactionsHistoryProjection.getCreatedDate())

                .assignedToUserDto(
                        userMapper.buildUserBasicDetailsMapper(
                                transactionsHistoryProjection.getAssignedToUserId(),
                                transactionsHistoryProjection.getAssignedToUserName(),
                                transactionsHistoryProjection.getAssignedToUserEmail(),
                                transactionsHistoryProjection.getAssignedToUserEmployeeCode()
                        )
                )
                .createdByUserDto(
                        userMapper.buildUserBasicDetailsMapper(
                                transactionsHistoryProjection.getCreatedByUserId(),
                                transactionsHistoryProjection.getCreatedByUserName(),
                                transactionsHistoryProjection.getCreatedByUserEmail(),
                                transactionsHistoryProjection.getCreatedByEmployeeCode()
                        )
                )
                .build();
    }

    public List<TransactionsHistoryDto> toProjectionsToDtos(List<TransactionsHistoryProjection> transactionsHistoryProjections) {

        return transactionsHistoryProjections.stream()
                .map(this::toProjectionToDto)
                .toList();
    }

}