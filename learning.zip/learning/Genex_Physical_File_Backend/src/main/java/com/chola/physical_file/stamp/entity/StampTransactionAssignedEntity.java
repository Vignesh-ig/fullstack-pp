package com.chola.physical_file.stamp.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "stamp_transaction_assigned", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StampTransactionAssignedEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "stamp_transaction_assigned_id")
    private UUID stampTransactionAssignedId;

    @Column(name = "transaction_id")
    private UUID transactionId;

    @Column(name = "stamp_stack_master_id")
    private UUID stampStackMasterId;

    @Column(name = "created_by")
    private UUID createdBy;

    @Column(name = "created_date")
    @CreationTimestamp
    private LocalDateTime createdDate;
}