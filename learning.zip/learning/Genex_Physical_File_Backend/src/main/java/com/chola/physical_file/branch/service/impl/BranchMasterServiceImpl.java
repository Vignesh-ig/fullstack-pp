package com.chola.physical_file.branch.service.impl;

import com.chola.physical_file.branch.record.*;
import com.chola.physical_file.branch.service.BranchMasterService;
import com.chola.physical_file.common.service.ExternalApiCallService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BranchMasterServiceImpl implements BranchMasterService {

    private final ExternalApiCallService externalApiCallService;


    @Override
    public List<GenexPFBranchResponse> findAllById(List<String> branchIds) {

        if (branchIds == null || branchIds.isEmpty()) {
            return Collections.emptyList();
        }

        return externalApiCallService.getGenexBranchesByIds(String.join(",", branchIds));
    }

    @Override
    public List<GenexZoneResponse> getAllZones() {
        return externalApiCallService.getAllZones();
    }

    @Override
    public List<GenexRegionResponse> getRegionsByZoneId(String zoneId) {
        return externalApiCallService.getRegionsByZoneId(zoneId);
    }

    @Override
    public List<GenexAreaResponse> getAreasByRegionId(String regionId) {
        return externalApiCallService.getAreasByRegionId(regionId);
    }

    @Override
    public List<GenexBranchResponse> getBranchesByAreaId(String areaId) {
        return externalApiCallService.getBranchesByAreaId(areaId);
    }
}