package com.chola.physical_file.userManagement.repository;

import com.chola.physical_file.userManagement.entity.PermissionEntity;
import com.chola.physical_file.userManagement.repository.projection.PermissionProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface PermissionRepository extends JpaRepository<PermissionEntity, UUID> {
    @Query("""
            SELECT
                p.permissionId AS permissionId,
                p.permissionName AS permissionName,
                p.description AS description,
                r.roleId AS roleId,
                r.roleName AS roleName,
                p.createdBy AS createdBy,
                p.createdDate AS createdDate,
                p.modifiedBy AS modifiedBy,
                p.modifiedDate AS modifiedDate
            FROM PermissionEntity p JOIN p.role r
            WHERE
                (
                    (
                        :uniquePermissionsToRole IS NULL
                        AND (:role IS NULL OR r.roleId = :role)
                    )
                    OR
                    (
                        :uniquePermissionsToRole IS NOT NULL
                        AND r.roleName = 'ADMIN_USER'
                        AND NOT EXISTS (
                            SELECT 1
                            FROM PermissionEntity p2
                            JOIN p2.role r2
                            WHERE r2.roleId = :uniquePermissionsToRole
                              AND p2.permissionName = p.permissionName
                        )
                    )
                )
                AND (
                    :likePermissionName IS NULL
                    OR LOWER(p.permissionName) LIKE CONCAT(
                        '%',
                        LOWER(CAST(:likePermissionName AS string)),
                        '%'
                    )
                )
            """)
    Page<PermissionProjection> findAllPermissions(@Param("role") UUID role, @Param("likePermissionName") String likePermissionName, @Param("uniquePermissionsToRole") UUID uniquePermissionsToRole, Pageable pageable);

    boolean existsByPermissionNameIgnoreCaseAndRole_RoleId(String permissionName, UUID roleId);
}
