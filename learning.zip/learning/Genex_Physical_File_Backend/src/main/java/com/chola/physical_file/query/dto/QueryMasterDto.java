package com.chola.physical_file.query.dto;

import com.chola.physical_file.common.enums.StatusEnum;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class QueryMasterDto {

    private UUID queriesId;

    private StatusEnum queryName;

    private UUID createdBy;

    private LocalDateTime createdDate;

    private UUID modifiedBy;

    private LocalDateTime modifiedDate;
}