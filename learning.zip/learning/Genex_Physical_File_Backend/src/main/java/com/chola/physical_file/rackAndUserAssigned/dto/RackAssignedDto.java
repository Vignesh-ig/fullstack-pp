package com.chola.physical_file.rackAndUserAssigned.dto;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.Update;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RackAssignedDto {
    @NotNull(groups = Update.class, message = "Rack assigned id is required for update")
    private UUID rackAssignedId;
    private Integer ageingNo;
    @NotBlank(groups = {Create.class, Update.class}, message = "App no is required")
    private String appNo;
    @NotBlank(groups = {Create.class, Update.class}, message = "Agg no is required")
    private String aggNo;
    @NotBlank(groups = {Create.class, Update.class}, message = "Barcode is required")
    private String barcode;
    @NotBlank(groups = {Create.class, Update.class}, message = "Assigned to is required")
    private UUID assignedUser;
    private StatusEnum assignedStatus;
    private String customerName;
    private String schemaProduct;
    private String scheme;
    private Boolean isESign;
    private String podNo;
    private String missingPodNo;
    private String genexFromBranch;
    @NotNull(groups = Create.class, message = "createdBy is required")
    private UUID createdBy;
    private LocalDateTime createdDate;
    @NotNull(groups = Update.class, message = "modifiedBy is required")
    private UUID modifiedBy;
    private LocalDateTime modifiedDate;
    @NotBlank(groups = {Create.class, Update.class}, message = "Rack id is required")
    private UUID rackId;
    private RackDto rackDto;
    private StatusEnum updateRackAllocation;

    // LEAP Details

    private Integer leapAgingNo;

    private String leapFileType;

    private BigDecimal amountFinance;

    private String branchDesc;

    private String stateDesc;

    private LocalDateTime handOffDate;

    private Long leadId;

    private StatusEnum stampType;

    private BigDecimal leapStampAmount;

    private String fundedCustomerType;

    private String rePaymentMode;

    private String eStamp;

    private LocalDateTime emiEndDate;

    private String loanId;

    private LocalDate businessDate;

    private LocalDate sourcingDate;

    private Integer tenure;

    private BigDecimal birr;

    private String registrableStatus;

    private String udhayamNumberStatus;

    private BigDecimal pacAmount;

    private UUID workflowNo;

    private UUID dmsId;

}