package com.chola.physical_file.stamp.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "stamp_master", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StampMasterEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "stamp_master_id")
    private UUID stampMasterId;

    @Column(name = "stamp_denomination_master_id")
    private UUID stampDenominationMasterId;

    @Column(name = "stamp_type_master_id")
    private UUID stampTypeMasterId;

    @Column(name = "state")
    private String state;

    @Column(name = "status")
    private Boolean status = true;

    @Column(name = "created_by")
    private UUID createdBy;

    @Column(name = "created_date")
    @CreationTimestamp
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private UUID modifiedBy;

    @Column(name = "modified_date")
    @UpdateTimestamp
    private LocalDateTime modifiedDate;
}
