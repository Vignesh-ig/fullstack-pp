package com.chola.physical_file.stamp.repository.projection;

public interface StampStackCountProjection {

    Long getTotalStampStacks();

    Long getUsedStampStacks();

    Long getAvailableStampStacks();
}