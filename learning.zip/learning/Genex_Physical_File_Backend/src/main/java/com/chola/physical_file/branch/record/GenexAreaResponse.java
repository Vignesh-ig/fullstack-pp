package com.chola.physical_file.branch.record;

import com.fasterxml.jackson.annotation.JsonAlias;

public record GenexAreaResponse(
        String name,

        @JsonAlias("regionID")
        String regionId,

        @JsonAlias("areaID")
        String areaId
) { }