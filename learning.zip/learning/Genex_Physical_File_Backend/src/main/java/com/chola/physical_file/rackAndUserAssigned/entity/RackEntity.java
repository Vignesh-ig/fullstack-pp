package com.chola.physical_file.rackAndUserAssigned.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "rack", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RackEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "rack_id")
    private UUID rackId;

    @Column(name = "rack_name")
    private String rackName;

    @Column(name = "vault_name")
    private String vaultName;

    @Column(name = "rack_position")
    private String rackPosition;

    @Column(name = "rack_status")
    private Boolean rackStatus;

    @Builder.Default
    @Column(name = "rack_app_count", nullable = false)
    private Integer rackAppCount = 0;

    @Column(name = "created_by")
    private UUID createdBy;

    @CreationTimestamp
    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private UUID modifiedBy;

    @UpdateTimestamp
    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;
}