package com.chola.physical_file.rackAndUserAssigned.dto;

import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.Update;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RackDto {

    @NotNull(groups = Update.class, message = "Id is required for update")
    private UUID rackId;

    @NotBlank(groups = {Create.class, Update.class}, message = "rackName is required")
    private String rackName;

    @NotBlank(groups = {Create.class, Update.class}, message = "vaultName is required")
    private String vaultName;

    private String rackPosition;

    private Boolean rackStatus;

    private Integer rackAppCount;

    @NotNull(groups = Create.class, message = "createdBy is required")
    private UUID createdBy;

    private LocalDateTime createdDate;

    @NotNull(groups = Update.class, message = "modifiedBy is required")
    private UUID modifiedBy;

    private LocalDateTime modifiedDate;
}