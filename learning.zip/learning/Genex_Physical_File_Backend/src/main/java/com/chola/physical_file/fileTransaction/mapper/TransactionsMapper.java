package com.chola.physical_file.fileTransaction.mapper;

import com.chola.physical_file.common.enums.StageEnum;
import com.chola.physical_file.dashboard.dto.DashboardDto;
import com.chola.physical_file.fileTransaction.dto.TransactionAppResponseDto;
import com.chola.physical_file.fileTransaction.dto.TransactionsDto;
import com.chola.physical_file.fileTransaction.dto.TransactionsHistoryDto;
import com.chola.physical_file.fileTransaction.entity.TransactionsEntity;
import com.chola.physical_file.fileTransaction.repository.projection.TransactionAppDetailsProjection;
import com.chola.physical_file.fileTransaction.repository.projection.TransactionStageCountProjection;
import com.chola.physical_file.query.dto.QueryCategoryDto;
import com.chola.physical_file.query.dto.QueryMasterDto;
import com.chola.physical_file.rackAndUserAssigned.dto.RackAssignedDto;
import com.chola.physical_file.rackAndUserAssigned.dto.RackDto;
import com.chola.physical_file.stage.dto.StageDto;
import com.chola.physical_file.stamp.dto.StampStackMasterDto;
import com.chola.physical_file.userManagement.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class TransactionsMapper {
    private final UserMapper userMapper;

    public TransactionsEntity dtoToEntity(TransactionsDto transactionsDto) {

        if (transactionsDto == null) {
            return null;
        }

        return TransactionsEntity.builder()
                .appNo(transactionsDto.getAppNo())
                .barcode(transactionsDto.getBarcode())
                .isESign(transactionsDto.getIsESign())
                .podNo(transactionsDto.getPodNo())
                .missingPodNo(transactionsDto.getMissingPodNo())
                .aggNo(transactionsDto.getAggNo())
                .leadId(transactionsDto.getLeadId())
                .customerName(transactionsDto.getCustomerName())
                .amountFinance(transactionsDto.getAmountFinance())
                .schemaProduct(transactionsDto.getSchemaProduct())
                .scheme(transactionsDto.getScheme())
                .branchDesc(transactionsDto.getBranchDesc())
                .modelNo(transactionsDto.getModelNo())
                .make(transactionsDto.getMake())
                .fileType(transactionsDto.getFileType())
                .vBarCode(transactionsDto.getVBarCode())
                .boxCode(transactionsDto.getBoxCode())
                .currentRemarks(transactionsDto.getCurrentRemarks())
                .dmsId(transactionsDto.getDmsId())
                .handOffDate(transactionsDto.getHandOffDate())
                .rackId(transactionsDto.getRackId())
                .stageId(transactionsDto.getStageId())
                .queryId(transactionsDto.getQueryId())
                .docAdminId(transactionsDto.getDocAdminId())
                .vendorId(transactionsDto.getVendorId())
                .transactionStatus(transactionsDto.getTransactionStatus())
                .assignedUser(transactionsDto.getAssignedUser())
                .genexFromBranch(transactionsDto.getGenexFromBranch())
                .stateDesc(transactionsDto.getStateDesc())
                .stampType(transactionsDto.getStampType())
                .leapStampAmount(transactionsDto.getLeapStampAmount())
                .fundedCustomerType(transactionsDto.getFundedCustomerType())
                .rePaymentMode(transactionsDto.getRePaymentMode())
                .eStamp(transactionsDto.getEStamp())
                .emiEndDate(transactionsDto.getEmiEndDate())
                .loanId(transactionsDto.getLoanId())
                .businessDate(transactionsDto.getBusinessDate())
                .sourcingDate(transactionsDto.getSourcingDate())
                .tenure(transactionsDto.getTenure())
                .birr(transactionsDto.getBirr())
                .registrableStatus(transactionsDto.getRegistrableStatus())
                .udhayamNumberStatus(transactionsDto.getUdhayamNumberStatus())
                .pacAmount(transactionsDto.getPacAmount())
                .workflowNo(transactionsDto.getWorkflowNo())
                .createdBy(transactionsDto.getCreatedBy())
                .modifiedBy(transactionsDto.getCreatedBy())
                .build();
    }

    public void updateEntityFromDto(TransactionsDto transactionsDto, TransactionsEntity existingTransaction, StageEnum stageName) {
        if (transactionsDto.getCurrentRemarks() != null) {
            existingTransaction.setCurrentRemarks(transactionsDto.getCurrentRemarks());
        }
        if (transactionsDto.getQueryId() != null) {
            existingTransaction.setQueryId(transactionsDto.getQueryId());
        }
        if (transactionsDto.getStageId() != null) {
            existingTransaction.setStageId(transactionsDto.getStageId());
        }
        if (transactionsDto.getAssignedUser() != null) {
            existingTransaction.setAssignedUser(transactionsDto.getAssignedUser());
        }
        if (StageEnum.QUERY_RESOLVED == stageName || StageEnum.QUERY == stageName || StageEnum.OUTWARD == stageName || StageEnum.STAMPING == stageName || StageEnum.STORAGE == stageName) {
            existingTransaction.setIsLocked(false);
        }
        if ((existingTransaction.getOutwardDate() == null) && (StageEnum.STAMPING == stageName || stageName == StageEnum.STORAGE)) {
            existingTransaction.setOutwardDate(LocalDateTime.now());
        }
        if (transactionsDto.getStageId() != null) {
            existingTransaction.setStageId(existingTransaction.getStageId());
        }
        if (transactionsDto.getDiscountStampAmount() != null) {
            existingTransaction.setDiscountStampAmount(transactionsDto.getDiscountStampAmount());
        }
        if (transactionsDto.getFinalStampAmount() != null) {
            existingTransaction.setFinalStampAmount(transactionsDto.getFinalStampAmount());
        }
        if (transactionsDto.getMissingPodNo() != null) {
            existingTransaction.setMissingPodNo(transactionsDto.getMissingPodNo());
        }
        if (transactionsDto.getQueryCartonBarcode() != null) {
            existingTransaction.setQueryCartonBarcode(transactionsDto.getQueryCartonBarcode());
        }
        existingTransaction.setModifiedBy(transactionsDto.getCreatedBy() == null ? transactionsDto.getModifiedBy() : transactionsDto.getCreatedBy());

    }

    public TransactionAppResponseDto toDto(TransactionAppDetailsProjection transactionAppDetailsProjection, List<TransactionsHistoryDto> history, List<StampStackMasterDto> stampStackMasterDtoList) {

        return TransactionAppResponseDto.builder()

                // Transaction Details
                .transactionId(transactionAppDetailsProjection.getTransactionId())
                .appNo(transactionAppDetailsProjection.getAppNo())
                .aggNo(transactionAppDetailsProjection.getAggNo())
                .barcode(transactionAppDetailsProjection.getBarcode())
                .podNo(transactionAppDetailsProjection.getPodNo())
                .missingPodNo(transactionAppDetailsProjection.getMissingPodNo())
                .ageingNo((int) ChronoUnit.DAYS.between(transactionAppDetailsProjection.getBusinessDate() != null ? transactionAppDetailsProjection.getBusinessDate() : LocalDate.now(), LocalDate.now()))
                .isESign(transactionAppDetailsProjection.getIsESign())
                .leadId(transactionAppDetailsProjection.getLeadId())
                .customerName(transactionAppDetailsProjection.getCustomerName())
                .amountFinance(transactionAppDetailsProjection.getAmountFinance())
                .schemaProduct(transactionAppDetailsProjection.getSchemaProduct())
                .scheme(transactionAppDetailsProjection.getScheme())
                .state(transactionAppDetailsProjection.getState())
                .branchDesc(transactionAppDetailsProjection.getBranchDesc())
                .stateDesc(transactionAppDetailsProjection.getStateDesc())
                .fundedCustomerType(transactionAppDetailsProjection.getFundedCustomerType())
                .rePaymentMode(transactionAppDetailsProjection.getRePaymentMode())
                .eStamp(transactionAppDetailsProjection.getEStamp())
                .stampType(transactionAppDetailsProjection.getStampType())
                .leapStampAmount(transactionAppDetailsProjection.getLeapStampAmount())
                .discountStampAmount(transactionAppDetailsProjection.getDiscountStampAmount())
                .finalStampAmount(transactionAppDetailsProjection.getFinalStampAmount())
                .emiEndDate(transactionAppDetailsProjection.getEmiEndDate())
                .modelNo(transactionAppDetailsProjection.getModelNo())
                .make(transactionAppDetailsProjection.getMake())
                .vBarCode(transactionAppDetailsProjection.getVBarCode())
                .boxCode(transactionAppDetailsProjection.getBoxCode())
                .currentRemarks(transactionAppDetailsProjection.getCurrentRemarks())
                .dmsId(transactionAppDetailsProjection.getDmsId())
                .handOffDate(transactionAppDetailsProjection.getHandOffDate())
                .genexFromBranch(transactionAppDetailsProjection.getGenexFromBranch())
                .transactionStatus(transactionAppDetailsProjection.getTransactionStatus())
                .isLocked(transactionAppDetailsProjection.getIsLocked())
                .fileType(transactionAppDetailsProjection.getFileType())
                .loanId(transactionAppDetailsProjection.getLoanId())
                .businessMonth(transactionAppDetailsProjection.getBusinessDate() != null ? transactionAppDetailsProjection.getBusinessDate().getMonth().toString() : null)
                .businessDate(transactionAppDetailsProjection.getBusinessDate())
                .sourcingDate(transactionAppDetailsProjection.getSourcingDate())
                .tenure(transactionAppDetailsProjection.getTenure())
                .birr(transactionAppDetailsProjection.getBirr())
                .registrableStatus(transactionAppDetailsProjection.getRegistrableStatus())
                .udhayamNumberStatus(transactionAppDetailsProjection.getUdhayamNumberStatus())
                .pacAmount(transactionAppDetailsProjection.getPacAmount())
                .workflowNo(transactionAppDetailsProjection.getWorkflowNo())
                .queryCartonBarcode(transactionAppDetailsProjection.getQueryCartonBarcode())
                .outwardDate(transactionAppDetailsProjection.getOutwardDate())
                .createdDate(transactionAppDetailsProjection.getCreatedDate())
                .modifiedDate(transactionAppDetailsProjection.getModifiedDate())

                // Rack
                .rack(
                        RackDto.builder()
                                .rackId(transactionAppDetailsProjection.getRackId())
                                .rackName(transactionAppDetailsProjection.getRackName())
                                .vaultName(transactionAppDetailsProjection.getVaultName())
                                .rackPosition(transactionAppDetailsProjection.getRackPosition())
                                .rackStatus(transactionAppDetailsProjection.getRackStatus())
                                .rackAppCount(transactionAppDetailsProjection.getRackAppCount())
                                .createdBy(null).modifiedBy(null).build()
                )

                // Stage
                .stage(
                        StageDto.builder()
                                .stageId(transactionAppDetailsProjection.getStageId())
                                .stageName(transactionAppDetailsProjection.getStageName())
                                .build()
                )

                // Query
                .query(
                        QueryMasterDto.builder()
                                .queriesId(transactionAppDetailsProjection.getQueryId())
                                .queryName(transactionAppDetailsProjection.getQueryName())
                                .build()
                )
                // Assigned User
                .assignedUser(
                        userMapper.buildUserBasicDetailsMapper(
                                transactionAppDetailsProjection.getAssignedUserId(),
                                transactionAppDetailsProjection.getAssignedUserName(),
                                transactionAppDetailsProjection.getAssignedUserEmail(),
                                transactionAppDetailsProjection.getAssignedEmployeeCode()
                        )
                )
                // Modified User
                .modifiedUser(
                        userMapper.buildUserBasicDetailsMapper(
                                transactionAppDetailsProjection.getModifiedUserId(),
                                transactionAppDetailsProjection.getModifiedUserName(),
                                transactionAppDetailsProjection.getModifiedUserEmail(),
                                transactionAppDetailsProjection.getModifiedEmployeeCode()
                        )
                )
                // History
                .transactionsHistory(history)

                .stampStackMasterList(stampStackMasterDtoList)

                .build();
    }

    public TransactionsDto mapRackAssignedDtoToTransactionDto(RackAssignedDto rackAssignedDto, UUID stageId, StageEnum stageName) {

        if (rackAssignedDto == null) {
            return null;
        }

        return TransactionsDto.builder()
                .appNo(rackAssignedDto.getAppNo())
                .barcode(rackAssignedDto.getBarcode())
                .ageingNo(rackAssignedDto.getAgeingNo())
                .isESign(rackAssignedDto.getIsESign())
                .podNo(rackAssignedDto.getPodNo())
                .missingPodNo(rackAssignedDto.getMissingPodNo())
                .aggNo(rackAssignedDto.getAggNo())
                .customerName(rackAssignedDto.getCustomerName())
                .schemaProduct(rackAssignedDto.getSchemaProduct())
                .scheme(rackAssignedDto.getScheme())
                .currentRemarks(null)
                .rackId(rackAssignedDto.getRackId())
                .stageId(stageId)
                .stageName(String.valueOf(stageName))
                .queryId(null)
                .assignedUser(rackAssignedDto.getAssignedUser())
                // handOffDate == disbursedDate
                .amountFinance(rackAssignedDto.getAmountFinance())
                .branchDesc(rackAssignedDto.getBranchDesc())
                .stateDesc(rackAssignedDto.getStateDesc())
                .handOffDate(rackAssignedDto.getHandOffDate())
                .fileType(rackAssignedDto.getLeapFileType())
                .leadId(rackAssignedDto.getLeadId())
                .genexFromBranch(rackAssignedDto.getGenexFromBranch())
                .stampType(rackAssignedDto.getStampType())
                .leapStampAmount(rackAssignedDto.getLeapStampAmount())
                .fundedCustomerType(rackAssignedDto.getFundedCustomerType())
                .rePaymentMode(rackAssignedDto.getRePaymentMode())
                .eStamp(rackAssignedDto.getEStamp())
                .emiEndDate(rackAssignedDto.getEmiEndDate())
                .loanId(rackAssignedDto.getLoanId())
                .businessDate(rackAssignedDto.getBusinessDate())
                .sourcingDate(rackAssignedDto.getSourcingDate())
                .tenure(rackAssignedDto.getTenure())
                .birr(rackAssignedDto.getBirr())
                .registrableStatus(rackAssignedDto.getRegistrableStatus())
                .udhayamNumberStatus(rackAssignedDto.getUdhayamNumberStatus())
                .pacAmount(rackAssignedDto.getPacAmount())
                .workflowNo(rackAssignedDto.getWorkflowNo())
                .dmsId(rackAssignedDto.getDmsId())

                .createdBy(rackAssignedDto.getCreatedBy() != null ? rackAssignedDto.getCreatedBy() : rackAssignedDto.getModifiedBy())
                .modifiedBy(rackAssignedDto.getCreatedBy() != null ? rackAssignedDto.getCreatedBy() : rackAssignedDto.getModifiedBy())
                .build();
    }

    public List<TransactionsDto> mapBulkRackAssignedDtosToTransactionDtos(List<RackAssignedDto> rackAssignedDtos, UUID stageId, StageEnum stageName) {
        return rackAssignedDtos.stream()
                .map(rackAssignedDto -> mapRackAssignedDtoToTransactionDto(rackAssignedDto, stageId, stageName))
                .toList();
    }

    public DashboardDto toDashboardDto(TransactionStageCountProjection transactionStageCountProjection) {

        if (transactionStageCountProjection == null) {
            return null;
        }

        return DashboardDto.builder()
                .totalTransactions(transactionStageCountProjection.getTotalCount())
                .storageTransactions(transactionStageCountProjection.getStorageCount())
                .stampingTransactions(transactionStageCountProjection.getStampingCount())
                .outwardTransactions(transactionStageCountProjection.getOutwardCount())
                .queryTransactions(transactionStageCountProjection.getQueryCount())
                .queryResolvedTransactions(transactionStageCountProjection.getQueryResolvedCount())
                .healthCheckTransactions(transactionStageCountProjection.getHealthCheckCount())
                .rackAssignedTransactions(transactionStageCountProjection.getRackAssignedCount())
                .returnToRackTransactions(transactionStageCountProjection.getReturnToRackCount())
                .userAssignedTransactions(transactionStageCountProjection.getUserAssignedCount())
                .totalQueries(transactionStageCountProjection.getTotalQueryCount())
                .criticalQueryCount(transactionStageCountProjection.getCriticalQueryCount())
                .nonCriticalQueryCount(transactionStageCountProjection.getNonCriticalQueryCount())
                .build();
    }

}
