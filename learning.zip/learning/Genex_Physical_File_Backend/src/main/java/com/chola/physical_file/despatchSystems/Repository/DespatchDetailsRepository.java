package com.chola.physical_file.despatchSystems.Repository;

import com.chola.physical_file.despatchSystems.entity.DespatchDetailsEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface DespatchDetailsRepository extends JpaRepository<DespatchDetailsEntity, Integer> {

    @Modifying
    @Transactional
    @Query("""
            UPDATE DespatchDetailsEntity d
            SET d.isPhysicalFileProcess = :isPhysicalFileProcess
            WHERE d.dpAppNo IN :appNos
            """)
    int updateIsPhysicalFileProcess(@Param("appNos") List<String> appNos, @Param("isPhysicalFileProcess") boolean isPhysicalFileProcess);

    @Query("""
            SELECT d
            FROM DespatchDetailsEntity d
            WHERE
                d.dpBarcode IS NOT NULL
            AND d.dpAppNo IS NOT NULL
            AND (
                    :appNoOrBarcode IS NULL
                    OR d.dpAppNo = :appNoOrBarcode
                    OR d.dpBarcode = :appNoOrBarcode
                )
            """)
    Optional<DespatchDetailsEntity> findPendingDespatchDetails(@Param("appNoOrBarcode") String appNoOrBarcode);
}