package com.chola.physical_file.query.repository;

import com.chola.physical_file.query.entity.QueryCategoryEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface QueryCategoryRepository extends JpaRepository<QueryCategoryEntity, UUID> {

    @Query("""
            SELECT q
            FROM QueryCategoryEntity q
            WHERE (
                :queryCategoryName IS NULL OR :queryCategoryName = ''
                OR q.queryCategoryName = :queryCategoryName
            )
            """)
    Page<QueryCategoryEntity> findQueryCategories(@Param("queryCategoryName") String queryCategoryName, Pageable pageable);

    @Query("""
            SELECT q
            FROM QueryCategoryEntity q
            WHERE q.id IN (
                SELECT MIN(q2.id)
                FROM QueryCategoryEntity q2
                GROUP BY q2.queryCategoryName
            )
            """)
    Page<QueryCategoryEntity> findDistinctQueryCategories(Pageable pageable);

    boolean existsByQueryCategoryNameAndQuerySubCategoryName(String queryCategoryName, String queryCategoryDescription);
}