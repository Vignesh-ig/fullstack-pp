package com.chola.physical_file.common.exception;

import com.chola.physical_file.common.enums.AppResponseCode;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.util.ResponseUtil;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.convert.ConversionFailedException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.server.ResponseStatusException;

@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
@Slf4j
//S1452
public class GlobalExceptionHandler {

    // 🔹 400 — Validation errors (invalid request body)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<?> handleValidation(MethodArgumentNotValidException ex) {
        var fieldError = ex.getBindingResult().getFieldError();
        String msg = fieldError != null && fieldError.getDefaultMessage() != null
                ? fieldError.getDefaultMessage()
                : ResponseMessage.INVALID_REQUEST_PAYLOAD.getMessage();
        log.debug("GlobalExceptionHandler.handleValidation -> {}", msg);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ResponseUtil.badRequest(msg, HttpStatus.BAD_REQUEST));
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<?> handleDataIntegrity(DataIntegrityViolationException ex) {

        String message = ResponseMessage.DUPLICATE_OR_INVALID_DATA.getMessage();

        Throwable rootCause = ex.getRootCause();

        if (rootCause != null && rootCause.getMessage() != null) {
            String dbMessage = rootCause.getMessage();
            if (dbMessage.contains("users_user_email_key")) {
                message = ResponseMessage.EMAIL_ALREADY_EXISTS.getMessage();

            } else if (dbMessage.contains("fk_permissions_role")) {

                message = ResponseMessage.ROLE_CONTAINS_PERMISSIONS.getMessage();

            } else if (dbMessage.contains("fk_users_role")) {

                message = ResponseMessage.ROLE_ASSIGNED_TO_USERS.getMessage();

            } else {
                message = ResponseMessage.DUPLICATE_OR_INVALID_DATA.getMessage();
                // Do not expose raw database error to API consumers
            }
        }

        log.error("DataIntegrityViolationException -> {}", message, ex);

        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ResponseUtil.badRequest(message, HttpStatus.BAD_REQUEST));
    }


    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<?> handleConstraintViolation(ConstraintViolationException ex) {

        String message = ex.getConstraintViolations()
                .stream()
                .map(ConstraintViolation::getMessage)
                .findFirst()
                .orElse(ResponseMessage.INVALID_REQUEST_PARAMETERS.getMessage());

        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ResponseUtil.badRequest(message, HttpStatus.BAD_REQUEST));
    }

    //    ResourceNotFoundException validation
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<?> handleResourceNotFound(ResourceNotFoundException ex) {
        log.debug("GlobalExceptionHandler.handleResourceNotFound -> {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ResponseUtil.notFound(ex.getMessage()));
    }

    // 🔹 400 — request validation
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<?> handleRequest(IllegalArgumentException ex) {
        log.debug("GlobalExceptionHandler.handleConstraint -> {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ResponseUtil.badRequest(ex.getMessage(), HttpStatus.BAD_REQUEST));

    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<?> handleMethodArgumentTypeMismatch(MethodArgumentTypeMismatchException ex) {

        String parameterName = ex.getName();
        String parameterValue = String.valueOf(ex.getValue());

        String message = String.format("Invalid value '%s' for parameter '%s'", parameterValue, parameterName);

        log.debug("GlobalExceptionHandler.handleMethodArgumentTypeMismatch -> {}", message);

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ResponseUtil.badRequest(message, HttpStatus.BAD_REQUEST));
    }

    @ExceptionHandler(ConversionFailedException.class)
    public ResponseEntity<?> handleConversionFailed(ConversionFailedException ex) {
        log.debug("GlobalExceptionHandler.handleConversionFailed -> {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ResponseUtil.badRequest(ResponseMessage.INVALID_REQUEST_PARAMETERS.getMessage(), HttpStatus.BAD_REQUEST));
    }

    // 🔹 Handle flexible ResponseStatusException (Spring Built-in)
    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<?> handleResponseStatus(ResponseStatusException ex) {
        HttpStatus status = (HttpStatus) ex.getStatusCode();
        String msg = ex.getReason() != null ? ex.getReason() : ResponseMessage.INVALID_REQUEST.getMessage();
        log.debug("GlobalExceptionHandler.handleResponseStatus -> {} {}", status, msg);

        return ResponseEntity.status(status)
                .body(ResponseUtil.error(
                        msg,
                        status,
                        AppResponseCode.ERROR
                ));
    }

    // 🔹 401 — Incorrect login credentials
    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<?> handleBadCredentials(BadCredentialsException ex) {
        log.debug("GlobalExceptionHandler.handleBadCredentials -> {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(ResponseUtil.unauthorized(ResponseMessage.INVALID_USERNAME_OR_PASSWORD.getMessage()));
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<?> handleUserNotFound(UserNotFoundException ex) {
        log.debug("GlobalExceptionHandler.handleUserNotFound -> {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(ResponseUtil.notFound(ex.getMessage()));
    }

    @ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<?> handleUserAlreadyExists(UserAlreadyExistsException ex) {
        log.debug("GlobalExceptionHandler.handleUserAlreadyExists -> {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(ResponseUtil.conflict(ex.getMessage()));
    }

    @ExceptionHandler(ExternalServiceException.class)
    public ResponseEntity<?> handleExternalServiceError(ExternalServiceException ex) {
        log.debug("GlobalExceptionHandler.handleExternalServiceError -> {}", ex.getMessage(), ex);
        return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                .body(ResponseUtil.error(ex.getMessage(), HttpStatus.BAD_GATEWAY, AppResponseCode.EXTERNAL_SERVICE_ERROR));
    }

    @ExceptionHandler(ResourceAlreadyExistsException.class)
    public ResponseEntity<?> handleResourceAlreadyExists(ResourceAlreadyExistsException ex) {
        log.debug("GlobalExceptionHandler.handleResourceAlreadyExists -> {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.CONFLICT)
                .body(ResponseUtil.conflict(ex.getMessage()));
    }

    // 🔹 500 — Internal server exception (fallback)
    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> handleInternalError(Exception ex) {
        log.error("GlobalExceptionHandler.handleInternalError -> {}", ex.getMessage(), ex);

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(ResponseUtil.internalError(
                        ResponseMessage.INTERNAL_SERVER_ERROR.getMessage()
                ));
    }
}
