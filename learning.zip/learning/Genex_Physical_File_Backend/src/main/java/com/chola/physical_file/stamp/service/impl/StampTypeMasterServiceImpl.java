package com.chola.physical_file.stamp.service.impl;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.stamp.dto.StampTypeMasterDto;
import com.chola.physical_file.stamp.entity.StampTypeMasterEntity;
import com.chola.physical_file.stamp.mapper.StampTypeMasterMapper;
import com.chola.physical_file.stamp.repository.StampTypeMasterRepository;
import com.chola.physical_file.stamp.service.StampTypeMasterService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StampTypeMasterServiceImpl implements StampTypeMasterService {

    private final StampTypeMasterRepository stampTypeMasterRepository;
    private final StampTypeMasterMapper stampTypeMasterMapper;


    @Override
    public PageResponseDto getStampTypeMasterRecords(Integer pageNumber, Integer pageSize) {
        PageResponseDto pageResponseDto = new PageResponseDto();
        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "createdDate")

        );
        Page<StampTypeMasterEntity> pageResponse = stampTypeMasterRepository.findAll(pageable);
        List<StampTypeMasterDto> stampTypeMasterDtoList = stampTypeMasterMapper.toDtos(pageResponse.getContent());
        pageResponseDto.setData(stampTypeMasterDtoList);
        pageResponseDto.setCurrentPage(pageResponse.getNumber() + 1);
        pageResponseDto.setTotalItems((int) pageResponse.getTotalElements());
        pageResponseDto.setTotalPages(pageResponse.getTotalPages());
        pageResponseDto.setHasNextPage(pageResponse.hasNext());
        pageResponseDto.setHasPreviousPage(pageResponse.hasPrevious());
        return pageResponseDto;
    }
}