package com.chola.physical_file.fileTransaction.service;

import com.chola.physical_file.fileTransaction.dto.TransactionsDto;
import com.chola.physical_file.fileTransaction.dto.TransactionsHistoryDto;
import com.chola.physical_file.fileTransaction.entity.TransactionsEntity;

import java.util.List;
import java.util.UUID;

public interface TransactionsHistoryService {

    void createTransactionsHistory(List<TransactionsEntity> transactionEntities, List<TransactionsDto> transactionDtos);

    List<TransactionsHistoryDto> findByTransactionId(List<UUID> transactionId);
}