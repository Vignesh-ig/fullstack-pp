package com.chola.physical_file.stamp.service.impl;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.common.util.StampStackCsvUtil;
import com.chola.physical_file.dashboard.dto.DashboardDto;
import com.chola.physical_file.stamp.dto.CsvParseResult;
import com.chola.physical_file.stamp.dto.StampStackCsvResponse;
import com.chola.physical_file.stamp.dto.StampStackMasterDto;
import com.chola.physical_file.stamp.entity.StampStackMasterEntity;
import com.chola.physical_file.stamp.mapper.StampStackMasterMapper;
import com.chola.physical_file.stamp.repository.StampStackMasterRepository;
import com.chola.physical_file.stamp.repository.projection.StampStackCountProjection;
import com.chola.physical_file.stamp.repository.projection.StampStackMasterProjection;
import com.chola.physical_file.stamp.service.StampStackMasterService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StampStackMasterServiceImpl implements StampStackMasterService {

    private final StampStackMasterRepository stampStackMasterRepository;
    private final StampStackMasterMapper stampStackMasterMapper;
    private final StampStackCsvUtil stampStackCsvUtil;
    @PersistenceContext
    private EntityManager entityManager;

    @Value("${records.bulk.batch-size:100}")
    private int batchSize;

    @Override
    @Transactional
    public CsvParseResult uploadStampStack(MultipartFile stampStackCsvFile, UUID createdBy) {

        // Parse CSV and validate syntax
        CsvParseResult csvParseResult = stampStackCsvUtil.parseStampStackCsv(stampStackCsvFile);

        List<StampStackCsvResponse> stampStackCsvResponseList = new ArrayList<>(csvParseResult.getValidationMessages());

        List<StampStackMasterDto> validStampStackMasterDtoList = csvParseResult.getValidRecords();

        if (CollectionUtils.isEmpty(validStampStackMasterDtoList)) {

            csvParseResult.setValidationMessages(stampStackCsvResponseList);
            csvParseResult.setSuccessfulRecords(0);
            csvParseResult.setFailedRecords(stampStackCsvResponseList.size());

            return csvParseResult;
        }

        // Duplicate Validation inside CSV
        Set<String> processedSerialNos = new HashSet<>();
        List<StampStackMasterDto> uniqueStampStackMasterDtoList = new ArrayList<>();

        for (StampStackMasterDto stampStackMasterDto : validStampStackMasterDtoList) {

            if (!processedSerialNos.add(stampStackMasterDto.getDenominationSerialNo())) {

                stampStackCsvResponseList.add(
                        StampStackCsvResponse.builder()
                                .csvRowNo(stampStackMasterDto.getCsvRowNo())
                                .denominationSerialNo(stampStackMasterDto.getDenominationSerialNo())
                                .csvRowMessage("Duplicate denomination serial number found in CSV.")
                                .build()
                );
                continue;
            }

            uniqueStampStackMasterDtoList.add(stampStackMasterDto);
        }

        if (CollectionUtils.isEmpty(uniqueStampStackMasterDtoList)) {

            csvParseResult.setValidationMessages(stampStackCsvResponseList);
            csvParseResult.setSuccessfulRecords(0);
            csvParseResult.setFailedRecords(stampStackCsvResponseList.size());

            return csvParseResult;
        }

        //Fetch Existing Record
        List<String> serialNos = uniqueStampStackMasterDtoList.stream()
                .map(StampStackMasterDto::getDenominationSerialNo)
                .toList();

        Map<String, StampStackMasterEntity> existingMap = stampStackMasterRepository.findAllByDenominationSerialNoIn(serialNos).stream()
                .collect(Collectors.toMap(StampStackMasterEntity::getDenominationSerialNo, Function.identity()));

        // Prepare Entity List
        List<StampStackMasterEntity> stampStackMasterEntityList = new ArrayList<>();

        int successfulRecords = 0;

        for (StampStackMasterDto stampStackMasterDto : uniqueStampStackMasterDtoList) {

            if (existingMap.containsKey(stampStackMasterDto.getDenominationSerialNo())) {

                stampStackCsvResponseList.add(
                        StampStackCsvResponse.builder()
                                .csvRowNo(stampStackMasterDto.getCsvRowNo())
                                .denominationSerialNo(stampStackMasterDto.getDenominationSerialNo())
                                .csvRowMessage("Duplicate record already exists in database.")
                                .build()
                );

                continue;
            }

            StampStackMasterEntity stampStackMasterEntity = stampStackMasterMapper.dtoToEntity(stampStackMasterDto, createdBy);


            stampStackMasterEntityList.add(stampStackMasterEntity);

            successfulRecords++;
        }

        // Batch Insert
        if (!stampStackMasterEntityList.isEmpty()) {
            persistTransactionsInBatch(stampStackMasterEntityList);
        }

        csvParseResult.setValidRecords(null);
        csvParseResult.setValidationMessages(stampStackCsvResponseList);
        csvParseResult.setSuccessfulRecords(successfulRecords);
        csvParseResult.setFailedRecords(stampStackCsvResponseList.size());

        return csvParseResult;
    }

    @Override
    public void updateStampStackMasterStatus(List<UUID> stampStackMasterIdList, UUID stampStackMasterUsedBy, StatusEnum statusEnum) {
         if(!stampStackMasterIdList.isEmpty()) {
             stampStackMasterRepository.updateStatusByIds(stampStackMasterIdList, stampStackMasterUsedBy, statusEnum);
         }
    }

    @Override
    public List<StampStackMasterDto> getUsedStampStackByTransactionId(UUID transactionId) {
        return stampStackMasterMapper.toDtos(stampStackMasterRepository.getUsedStampStackByTransactionId(transactionId));
    }

    @Override
    @Transactional(readOnly = true)
    public DashboardDto getStampStackMasterCount(List<String> states) {

        StampStackCountProjection stampStackCountProjection = stampStackMasterRepository.getStampStackCounts(states);

        return DashboardDto.builder()
                .totalStampStacks(stampStackCountProjection.getTotalStampStacks())
                .usedStampStacks(stampStackCountProjection.getUsedStampStacks())
                .availableStampStacks(stampStackCountProjection.getAvailableStampStacks())
                .build();
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponseDto getStampStackMasterRecords(List<String> states, Integer denominationAmount, StatusEnum status, String denominationSerialNo, Integer pageNumber, Integer pageSize) {
        PageResponseDto pageResponseDto = new PageResponseDto();
        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "createdDate")
        );
        Page<StampStackMasterProjection> pageResponse = stampStackMasterRepository.findStampStackMasterRecords(states, denominationAmount, status, denominationSerialNo, pageable);
        List<StampStackMasterDto> stampMasterDtoList = stampStackMasterMapper.stampStackMasterProjectionToDtos(pageResponse.getContent());
        pageResponseDto.setData(stampMasterDtoList);
        pageResponseDto.setCurrentPage(pageResponse.getNumber() + 1);
        pageResponseDto.setTotalItems((int) pageResponse.getTotalElements());
        pageResponseDto.setTotalPages(pageResponse.getTotalPages());
        pageResponseDto.setHasNextPage(pageResponse.hasNext());
        pageResponseDto.setHasPreviousPage(pageResponse.hasPrevious());
        return pageResponseDto;
    }

    private void persistTransactionsInBatch(List<StampStackMasterEntity> stampStackMasterEntityList) {

        int count = 0;

        for (StampStackMasterEntity stampStackMasterEntity : stampStackMasterEntityList) {

            if (stampStackMasterEntity.getStampStackMasterId() == null) {
                entityManager.persist(stampStackMasterEntity);
            }

            if (++count % batchSize == 0) {
                entityManager.flush();
                entityManager.clear();
            }
        }

        entityManager.flush();
        entityManager.clear();
    }
}