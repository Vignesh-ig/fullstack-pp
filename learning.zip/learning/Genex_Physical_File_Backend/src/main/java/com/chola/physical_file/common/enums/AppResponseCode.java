package com.chola.physical_file.common.enums;

public enum AppResponseCode {
    SUCCESS,
    BAD_REQUEST,
    ERROR,
    UNAUTHORIZED,
    CONFLICT,
    AUTH_FAILED,
    NOT_FOUND,
    EXTERNAL_SERVICE_ERROR
}