package com.chola.physical_file.stamp.service.impl;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.stamp.dto.StampDenominationMasterDto;
import com.chola.physical_file.stamp.entity.StampDenominationMasterEntity;
import com.chola.physical_file.stamp.mapper.StampDenominationMasterMapper;
import com.chola.physical_file.stamp.repository.StampDenominationMasterRepository;
import com.chola.physical_file.stamp.service.StampDenominationMasterService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StampDenominationMasterServiceImpl implements StampDenominationMasterService {

    private final StampDenominationMasterRepository stampDenominationMasterRepository;
    private final StampDenominationMasterMapper stampDenominationMasterMapper;

    @Override
    public PageResponseDto getStampDenoMasterRecords(Integer pageNumber, Integer pageSize) {
        PageResponseDto pageResponseDto = new PageResponseDto();
        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "createdDate")

        );
        Page<StampDenominationMasterEntity> pageResponse = stampDenominationMasterRepository.findAll(pageable);
        List<StampDenominationMasterDto> stampTypeMasterDtoList = stampDenominationMasterMapper.toDtos(pageResponse.getContent());
        pageResponseDto.setData(stampTypeMasterDtoList);
        pageResponseDto.setCurrentPage(pageResponse.getNumber() + 1);
        pageResponseDto.setTotalItems((int) pageResponse.getTotalElements());
        pageResponseDto.setTotalPages(pageResponse.getTotalPages());
        pageResponseDto.setHasNextPage(pageResponse.hasNext());
        pageResponseDto.setHasPreviousPage(pageResponse.hasPrevious());
        return pageResponseDto;
    }
}