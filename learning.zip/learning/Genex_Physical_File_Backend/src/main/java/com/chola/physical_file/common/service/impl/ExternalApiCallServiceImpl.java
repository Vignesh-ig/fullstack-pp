package com.chola.physical_file.common.service.impl;

import com.chola.physical_file.branch.record.*;
import com.chola.physical_file.common.dto.GenexPropertiesDto;
import com.chola.physical_file.common.dto.LeapPropertiesDto;
import com.chola.physical_file.common.exception.ExternalServiceException;
import com.chola.physical_file.common.record.GenexDisbursementApiResponse;
import com.chola.physical_file.common.record.GenexIntegrationApiResponse;
import com.chola.physical_file.common.record.GenexPhysicalResponse;
import com.chola.physical_file.common.record.LeapVFAppDetailsResponse;
import com.chola.physical_file.common.service.ExternalApiCallService;
import com.chola.physical_file.despatchSystems.records.GenexPFDetailsResponse;
import com.chola.physical_file.stamp.record.LeapStateResponse;
import com.chola.physical_file.userManagement.record.GenexUsersResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.*;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExternalApiCallServiceImpl implements ExternalApiCallService {

    private final RestClient restClient;
    private final ObjectMapper objectMapper;

    private final GenexPropertiesDto genexPropertiesDto;
    private final LeapPropertiesDto leapPropertiesDto;

    private static final String HEADER_CUSTOM = "Custom";
    private static final String HEADER_AUTH_ID = "authId";

    @Override
    public List<GenexUsersResponse> getAllGenexUsers() {

        GenexPhysicalResponse<GenexUsersResponse> response = executeApi(HttpMethod.GET, genexPropertiesDto.getPhysicalApiUrl() + "user/viewAll", null, new ParameterizedTypeReference<GenexPhysicalResponse<GenexUsersResponse>>() {}, genexPropertiesDto.getAuthorizationToken());

        return response.data();
    }

    @Override
    public List<GenexPFDetailsResponse> getGenexAppNoDetailsByAppNo(String applicationNumber) {

        return executeApi(HttpMethod.GET, genexPropertiesDto.getIntegrationApiUrl() + "lead/getPFdetails?appNo=" + applicationNumber, null, new ParameterizedTypeReference<GenexIntegrationApiResponse<GenexPFDetailsResponse>>() {}, genexPropertiesDto.getIntegrationToken()).result();
    }

    @Override
    public List<LeapStateResponse> getAllStates() {

        return executeApi(HttpMethod.GET, leapPropertiesDto.getMasterCacheApiUrl() + "1.0.0/mastersapi/masters/State", null, new ParameterizedTypeReference<List<LeapStateResponse>>() {}, leapPropertiesDto.getMasterCacheAuthorizationToken());
    }

    @Override
    public List<LeapVFAppDetailsResponse> getLeapVFAppNoDetailsByAppNos(String applicationNumbers) {

        return executeApi(HttpMethod.GET, leapPropertiesDto.getSalesApiUrl() + "v1.0/vf/getDataForGenexPhysicalFile?ApplicationNo=" + applicationNumbers, null, new ParameterizedTypeReference<GenexDisbursementApiResponse<LeapVFAppDetailsResponse>>() {}, leapPropertiesDto.getSalesAuthorizationToken()).result();
    }

    @Override
    public List<GenexPFBranchResponse> getGenexBranchesByIds(String branchId) {

        return executeApi(HttpMethod.GET, genexPropertiesDto.getIntegrationApiUrl() + "lead/getPFbranches?branchid=" + branchId, null, new ParameterizedTypeReference<GenexIntegrationApiResponse<GenexPFBranchResponse>>() {}, genexPropertiesDto.getIntegrationToken()).result();
    }

    @Override
    public List<GenexZoneResponse> getAllZones() {

        return executeApi(HttpMethod.GET, genexPropertiesDto.getDisbursementApiUrl() + "master/zone", null, new ParameterizedTypeReference<GenexDisbursementApiResponse<GenexZoneResponse>>() {}, genexPropertiesDto.getAuthorizationToken()).result();
    }

    @Override
    public List<GenexRegionResponse> getRegionsByZoneId(String zoneId) {

        return executeApi(HttpMethod.GET, genexPropertiesDto.getDisbursementApiUrl() + "master/region?ZoneID=" + zoneId, null, new ParameterizedTypeReference<GenexDisbursementApiResponse<GenexRegionResponse>>() {}, genexPropertiesDto.getAuthorizationToken()).result();
    }

    @Override
    public List<GenexAreaResponse> getAreasByRegionId(String regionId) {

        return executeApi(HttpMethod.GET, genexPropertiesDto.getDisbursementApiUrl() + "master/area?Region=" + regionId, null, new ParameterizedTypeReference<GenexDisbursementApiResponse<GenexAreaResponse>>() {}, genexPropertiesDto.getAuthorizationToken()).result();
    }

    @Override
    public List<GenexBranchResponse> getBranchesByAreaId(String areaId) {

        return executeApi(HttpMethod.GET, genexPropertiesDto.getDisbursementApiUrl() + "master/branchs?Area=" + areaId, null, new ParameterizedTypeReference<GenexDisbursementApiResponse<GenexBranchResponse>>() {}, genexPropertiesDto.getAuthorizationToken()).result();
    }


    @Retry(name = "genexRetry")
    @CircuitBreaker(name = "genexCircuit", fallbackMethod = "genexFallback")
    private <T> T executeApi(HttpMethod httpMethod, String uri, Object requestBody, ParameterizedTypeReference<T> parameterizedTypeReference, String authorizationToken) {
        try {
            RestClient.RequestBodySpec requestSpec = restClient
                    .method(httpMethod)
                    .uri(uri)
                    .header(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + authorizationToken)
                    .header(HEADER_CUSTOM, "Bearer " + genexPropertiesDto.getCustomToken())
                    .header(HEADER_AUTH_ID, genexPropertiesDto.getAuthId());

            if (requestBody != null) {
                requestSpec.contentType(MediaType.APPLICATION_JSON).body(requestBody);
            }

            return requestSpec.retrieve().body(parameterizedTypeReference);

        } catch (RestClientException ex) {
            throw mapResponseException(ex);
        }
    }

    private ExternalServiceException mapResponseException(Exception ex) {

        // Handle 404 specifically
        if (ex instanceof HttpClientErrorException.NotFound) {
            return new ExternalServiceException("External server is unavailable");
        }

        // Handle all other 4xx responses
        if (ex instanceof HttpClientErrorException clientException) {
            try {
                JsonNode root = objectMapper.readTree(clientException.getResponseBodyAsString());

                String message = root.path("message").asText(null);

                if (message == null || message.isBlank()) {
                    message = root.path("description").asText(null);
                }

                if (message == null || message.isBlank()) {
                    message = clientException.getStatusText();
                }

                return new ExternalServiceException("External server message " + message);

            } catch (Exception ignored) {
                return new ExternalServiceException(clientException.getStatusText());
            }
        }

        // Handle 5xx responses
        if (ex instanceof HttpServerErrorException) {
            return new ExternalServiceException("External server is unavailable. Or Connection issue");
        }

        // Handle connection/timeout/etc.
        if (ex instanceof ResourceAccessException) {
            return new ExternalServiceException("External server is unavailable. Or Connection issue");
        }

        return new ExternalServiceException("Error communicating with External service.");
    }

    private <T> T genexFallback(HttpMethod httpMethod, String uri, Object requestBody, ParameterizedTypeReference<T> parameterizedTypeReference, String authorizationToken, Exception exception) {

        throw new ExternalServiceException(
                "External service is currently unavailable. Please try again later.");
    }
}