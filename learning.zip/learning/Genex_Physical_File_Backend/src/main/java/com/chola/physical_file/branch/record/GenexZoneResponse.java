package com.chola.physical_file.branch.record;

import com.fasterxml.jackson.annotation.JsonAlias;

public record GenexZoneResponse(

        @JsonAlias("ZoneID")
        String zoneId,

        String name
) { }