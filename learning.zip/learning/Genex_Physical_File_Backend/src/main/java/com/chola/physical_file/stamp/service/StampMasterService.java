package com.chola.physical_file.stamp.service;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.stamp.dto.StampMasterDto;

import java.util.List;
import java.util.UUID;

public interface StampMasterService {

    void createStampMasterRecords(List<StampMasterDto> stampMasterDtoList);

    PageResponseDto getStampMasterRecords(Integer pageNumber, Integer pageSize, String state,UUID stampType, UUID stampMasterId);
}