package com.chola.physical_file.common.controller;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.service.ExternalApiCallService;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1")
@Validated
@Tag(name = "Leap Master Controller", description = "Controller for managing Leap Master data")
public class LeapStateMasterController {
    private final ExternalApiCallService externalApiCallService;

    @GetMapping("/state")
    @Operation(summary = "Get Leap State Master Records", description = "Fetch Leap State Master records based on the filter.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Leap State Master records fetched successfully    ",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = PageResponseDto.class)))
    })
    public ResponseEntity<CommonResponseUtil> getLeapStateMasterRecords() {
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.LEAP_STATE_MASTER_RECORDS_FETCHED.getMessage(), HttpStatus.OK, externalApiCallService.getAllStates()));
    }
}