package com.chola.physical_file.stamp.controller;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.ResponseUtil;
import com.chola.physical_file.stamp.dto.CsvParseResult;
import com.chola.physical_file.stamp.dto.StampStackCsvResponse;
import com.chola.physical_file.stamp.service.StampStackMasterService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/stampStackMaster")
@Validated
@Tag(name = "Stamp Stack Master", description = "APIs to manage stamp stack master records.")
public class StampStackMasterController {

    private final StampStackMasterService stampStackMasterService;

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Upload Stamp Stack CSV")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Stamp Stack Master records created successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = StampStackCsvResponse.class))),
            @ApiResponse(responseCode = "400", description = "Invalid CSV file or validation errors",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = CommonResponseUtil.class))),
            @ApiResponse(responseCode = "500", description = "Internal server error",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = CommonResponseUtil.class)))
    })
    public ResponseEntity<CommonResponseUtil> uploadStampStackCsv(
            @Parameter(description = "CSV file containing stamp stack records", required = true) @RequestParam("stampStackCsvFile") MultipartFile stampStackCsvFile,
            @Parameter(description = "UUID of the user who is uploading the CSV file", required = true) @RequestParam("createdBy") UUID createdBy) {

        CsvParseResult stampStackCsvResponses = stampStackMasterService.uploadStampStack(stampStackCsvFile, createdBy);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ResponseUtil.success(ResponseMessage.STAMP_STACK_MASTER_RECORD_CREATED.getMessage(), HttpStatus.CREATED, stampStackCsvResponses));
    }

    @GetMapping
    @Operation(summary = "Get Stamp Stack Master Records", description = "Fetch Stamp Stack Master records based on the filter.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Stamp Stack Master records fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = PageResponseDto.class)))
    })
    public ResponseEntity<CommonResponseUtil> getStampStackMasterRecords(
            @Parameter(description = "Page number (starting from 1)", example = "1") @RequestParam(name = "page", defaultValue = "1")
            @Min(value = 1, message = "The page must be a positive number.")
            Integer pageNumber,
            @Parameter(description = "Page size (max 500)", example = "10") @RequestParam(name = "limit", defaultValue = "10")
            @Min(value = 1, message = "The limit must be a positive number.") @Max(value = 500, message = "Maximum allowed limit is 500.") Integer pageSize,
            @Parameter(description = "State filter for stamp master records", example = "California") @RequestParam(name = "state", required = false) List<String> states,
            @Parameter(description = "Denomination amount filter for stamp master records", example = "100") @RequestParam(name = "denominationAmount", required = false) Integer denominationAmount,
            @Parameter(description = "Status filter for stamp master records", example = "IN_STOCK") @RequestParam(name = "status", required = false) StatusEnum status,
            @Parameter (description = "Denomination serial number filter for stamp master records", example = "ABC123") @RequestParam(name = "denominationSerialNo", required = false) String denominationSerialNo

    ) {
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.STAMP_STACK_MASTER_RECORDS_FETCHED.getMessage(), HttpStatus.OK, stampStackMasterService.getStampStackMasterRecords(states, denominationAmount, status, denominationSerialNo, pageNumber, pageSize)));
    }
}