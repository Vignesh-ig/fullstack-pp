package com.chola.physical_file.stage.controller;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.enums.StageEnum;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.ResponseUtil;
import com.chola.physical_file.stage.service.StageService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/stage")
@Validated
@Tag(name = "Stage Master Details", description = "APIs to fetch Stage master details")
public class StageController {

    private final StageService stageService;

    @GetMapping
    @Operation(summary = "Get all stage records", description = "Fetch paginated list of stage records.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Stage records fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = PageResponseDto.class)))
    })
    public ResponseEntity<CommonResponseUtil> getAllStages(
            @Parameter(description = "Page number (starting from 1)", example = "1") @RequestParam(name = "page", defaultValue = "1")
            @Min(value = 1, message = "The page must be a positive number.")
            Integer pageNumber,
            @Parameter(description = "Page size (max 500)", example = "10") @RequestParam(name = "limit", defaultValue = "10")
            @Min(value = 1, message = "The limit must be a positive number.") @Max(value = 500, message = "Maximum allowed limit is 500.")
            Integer pageSize,
            @Parameter(description = "Search by stage not in related records") @RequestParam(name = "excludeStageSearch", required = false) List<StageEnum> excludeStagesSearch,
            @Parameter(description = "Search by stage not in related records") @RequestParam(name = "includeStagesSearch", required = false) List<StageEnum> includeStagesSearch
    ) {
        PageResponseDto pageResponseDto = stageService.getAllStages(pageNumber, pageSize, excludeStagesSearch, includeStagesSearch);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.STAGE_RECORDS_FETCHED.getMessage(), HttpStatus.OK, pageResponseDto));
    }
}