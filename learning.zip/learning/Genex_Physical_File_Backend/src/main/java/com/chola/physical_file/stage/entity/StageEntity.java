package com.chola.physical_file.stage.entity;

import com.chola.physical_file.common.enums.StageEnum;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "stage", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class StageEntity {

    @Id
    @Column(name = "stage_id")
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID stageId;

    @Enumerated(EnumType.STRING)
    @Column(name = "stage_name")
    private StageEnum stageName;

    @Column(name = "created_by")
    private UUID createdBy;

    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private UUID modifiedBy;

    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;
}