package com.chola.physical_file.stamp.repository;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.stamp.entity.StampStackMasterEntity;
import com.chola.physical_file.stamp.repository.projection.StampStackCountProjection;
import com.chola.physical_file.stamp.repository.projection.StampStackMasterProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface StampStackMasterRepository extends JpaRepository<StampStackMasterEntity, UUID> {
    List<StampStackMasterEntity> findAllByDenominationSerialNoIn(List<String> denominationSerialNos);


    @Query("""
        SELECT
            s.stampStackMasterId AS stampStackMasterId,
            s.denominationAmount AS denominationAmount,
            s.denominationSerialNo AS denominationSerialNo,
            s.state AS state,
            s.status AS status,
            s.usedBy AS usedBy,
            u.userName AS usedUserName

        FROM StampStackMasterEntity s

        LEFT JOIN UserEntity u
            ON s.status = com.chola.physical_file.common.enums.StatusEnum.USED
            AND u.userId = s.usedBy

        WHERE (:states IS NULL OR s.state IN :states)
          AND (:denominationAmount IS NULL OR s.denominationAmount = :denominationAmount)
          AND (:status IS NULL OR s.status = :status)
          AND (:denominationSerialNo IS NULL OR s.denominationSerialNo = :denominationSerialNo)
        """)
    Page<StampStackMasterProjection> findStampStackMasterRecords(@Param("states") List<String> states, @Param("denominationAmount") Integer denominationAmount, @Param("status") StatusEnum status, @Param("denominationSerialNo") String denominationSerialNo, Pageable pageable);

    @Query("""
            SELECT s.denominationSerialNo
            FROM StampStackMasterEntity s
            WHERE s.stampStackMasterId IN :stampStackMasterIds AND s.status = :status
            """)
    List<String> countByUsedRecords(@Param("stampStackMasterIds") List<UUID> stampStackMasterIds, @Param("status") StatusEnum status);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("""
        UPDATE StampStackMasterEntity s
        SET s.status = :status, s.usedBy = :stampStackMasterUsedBy, s.usedDate = CURRENT_TIMESTAMP
        WHERE s.stampStackMasterId IN :stampStackMasterIds
        """)
    void updateStatusByIds(@Param("stampStackMasterIds") List<UUID> stampStackMasterIds, @Param("stampStackMasterUsedBy") UUID stampStackMasterUsedBy, @Param("status") StatusEnum statusEnum);

    @Query("""
            SELECT ssm
            FROM StampStackMasterEntity ssm
            JOIN StampTransactionAssignedEntity sta
                ON sta.stampStackMasterId = ssm.stampStackMasterId
            WHERE sta.transactionId = :transactionId
            """)
    List<StampStackMasterEntity> getUsedStampStackByTransactionId(@Param("transactionId") UUID transactionId);

    @Query("""
    SELECT
        COUNT(s) AS totalStampStacks,
        SUM(CASE WHEN s.status = com.chola.physical_file.common.enums.StatusEnum.USED
                 THEN 1 ELSE 0 END) AS usedStampStacks,
        SUM(CASE WHEN s.status = com.chola.physical_file.common.enums.StatusEnum.IN_STOCK
                 THEN 1 ELSE 0 END) AS availableStampStacks
    FROM StampStackMasterEntity s
    WHERE (:states IS NULL OR s.state IN :states)
    """)
    StampStackCountProjection getStampStackCounts(@Param("states") List<String> states);
}