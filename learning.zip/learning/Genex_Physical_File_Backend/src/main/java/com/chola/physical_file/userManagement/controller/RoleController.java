package com.chola.physical_file.userManagement.controller;

import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.ResponseUtil;
import com.chola.physical_file.userManagement.dto.RoleDto;
import com.chola.physical_file.userManagement.service.RoleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/v1/roles")
@RequiredArgsConstructor
@Tag(name = "Roles", description = "APIs to manage and fetch application roles")
public class RoleController {

    private final RoleService roleService;

    @GetMapping
    @Operation(summary = "Get all roles", description = "Retrieve a list of all roles available in the system.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Roles fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = RoleDto.class)))
    })
    public ResponseEntity<?> getAllRoles(
            @Parameter(description = "Page number (starting from 1)", example = "1") @RequestParam(name = "page", defaultValue = "1")
            @Min(value = 1, message = "The page must be a positive number.")
            Integer pageNumber,
            @Parameter(description = "Page size (max 500)", example = "10") @RequestParam(name = "limit", defaultValue = "10")
            @Min(value = 1, message = "The limit must be a positive number.") @Max(value = 500, message = "Maximum allowed limit is 500.")
            Integer pageSize
    ) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.ROLES_FETCHED.getMessage(), HttpStatus.OK, roleService.getAllRoles(pageNumber, pageSize)));
    }

    @PostMapping
    @Operation(summary = "Create a new role", description = "Create a new role in the system.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Role created successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or bad request")
    })
    public ResponseEntity<CommonResponseUtil> createRole(@Validated(Create.class) @RequestBody RoleDto roleDto) {
        roleService.createRole(roleDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ResponseUtil.success(ResponseMessage.ROLE_CREATED.getMessage(), HttpStatus.CREATED, null));
    }

    @PostMapping("/ids")
    @Operation(summary = "Delete roles", description = "Delete one or more roles by their UUIDs. Provide role IDs as query param 'RoleIds'.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Role deleted successfully"),
            @ApiResponse(responseCode = "400", description = "Bad request when RoleIds is empty or invalid")
    })
    public ResponseEntity<CommonResponseUtil> deleteRole(@Parameter(description = "List of role UUIDs to delete", required = true) @RequestParam(name = "roleIds") List<UUID> roleIds) {
        if (roleIds == null || roleIds.isEmpty()) {
            throw new IllegalArgumentException(ResponseMessage.ROLE_IDS_EMPTY.getMessage());
        }
        roleService.deleteRole(roleIds);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.ROLE_DELETED.getMessage(), HttpStatus.OK, null));
    }
}
