package com.chola.physical_file.userManagement.repository;

import com.chola.physical_file.userManagement.entity.RoleEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface RoleRepository extends JpaRepository<RoleEntity, UUID> {

    Optional<RoleEntity> findByRoleId(UUID roleId);

    boolean existsByRoleNameIgnoreCase(String roleName);
}
