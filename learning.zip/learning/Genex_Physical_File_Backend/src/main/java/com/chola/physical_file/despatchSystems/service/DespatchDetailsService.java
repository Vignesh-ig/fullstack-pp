package com.chola.physical_file.despatchSystems.service;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.despatchSystems.dto.DespatchDetailsDTO;

import java.util.List;

public interface DespatchDetailsService {

    DespatchDetailsDTO getDespatchDetails(String appNoOrBarcode);

    PageResponseDto getDespatchDetailsByAgreementNo(Integer pageNumber, Integer pageSize, String agreementNo);

    int updateIsPhysicalFileProcess(List<String> requestAppNos, boolean isPhysicalFileProcess);
}
