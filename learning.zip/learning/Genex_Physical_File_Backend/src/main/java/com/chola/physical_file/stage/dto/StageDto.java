package com.chola.physical_file.stage.dto;

import com.chola.physical_file.common.enums.StageEnum;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StageDto {

    private UUID stageId;

    private StageEnum stageName;

    private UUID createdBy;

    private LocalDateTime createdDate;

    private UUID modifiedBy;

    private LocalDateTime modifiedDate;
}