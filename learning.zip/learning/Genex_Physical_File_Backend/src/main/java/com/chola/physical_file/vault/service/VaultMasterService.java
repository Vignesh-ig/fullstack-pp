package com.chola.physical_file.vault.service;

import com.chola.physical_file.common.dto.PageResponseDto;

public interface VaultMasterService {
    PageResponseDto getAllVaultRecords(Integer pageNumber, Integer pageSize);
}