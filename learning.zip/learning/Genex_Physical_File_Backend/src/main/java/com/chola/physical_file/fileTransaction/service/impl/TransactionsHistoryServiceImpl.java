package com.chola.physical_file.fileTransaction.service.impl;

import com.chola.physical_file.fileTransaction.dto.TransactionsDto;
import com.chola.physical_file.fileTransaction.dto.TransactionsHistoryDto;
import com.chola.physical_file.fileTransaction.entity.TransactionsEntity;
import com.chola.physical_file.fileTransaction.entity.TransactionsHistoryEntity;
import com.chola.physical_file.fileTransaction.mapper.TransactionsHistoryMapper;
import com.chola.physical_file.fileTransaction.repository.TransactionsHistoryRepository;
import com.chola.physical_file.fileTransaction.repository.projection.TransactionsHistoryProjection;
import com.chola.physical_file.fileTransaction.service.TransactionsHistoryService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class TransactionsHistoryServiceImpl implements TransactionsHistoryService {
    private final TransactionsHistoryRepository transactionsHistoryRepository;
    private final TransactionsHistoryMapper transactionsHistoryMapper;


    @PersistenceContext
    private EntityManager entityManager;

    @Value("${records.bulk.batch-size:100}")
    private int batchSize;

    @Override
    public void createTransactionsHistory(List<TransactionsEntity> transactionEntities, List<TransactionsDto> transactionDtos) {

        int count = 0;

        for (int i = 0; i < transactionEntities.size(); i++) {

            TransactionsHistoryEntity transactionsHistoryEntity = transactionsHistoryMapper.transactionsDtoToEntity(transactionEntities.get(i), transactionDtos.get(i));

            entityManager.persist(transactionsHistoryEntity);

            if (++count % batchSize == 0) {
                entityManager.flush();
                entityManager.clear();
            }
        }

        entityManager.flush();
        entityManager.clear();

    }

    @Override
    public List<TransactionsHistoryDto> findByTransactionId(List<UUID> transactionIds) {

        List<TransactionsHistoryProjection> transactionsHistoryProjections = transactionsHistoryRepository.findByTransactionId(transactionIds);

        return transactionsHistoryMapper.toProjectionsToDtos(transactionsHistoryProjections);
    }
}
