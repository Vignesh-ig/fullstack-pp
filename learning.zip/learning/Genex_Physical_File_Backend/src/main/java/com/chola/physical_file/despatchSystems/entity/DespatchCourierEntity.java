package com.chola.physical_file.despatchSystems.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Depatch_CourierMaster_Tb", schema = "dbo")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DespatchCourierEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Dp_Courier_Id", nullable = false)
    private Integer DpCourierId;

    @Column(name = "Dp_Courier_Name", length = 50, nullable = false)
    private String DpCourierName;
}
