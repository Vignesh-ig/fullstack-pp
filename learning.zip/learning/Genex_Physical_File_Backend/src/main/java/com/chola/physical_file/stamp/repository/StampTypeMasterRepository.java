package com.chola.physical_file.stamp.repository;

import com.chola.physical_file.stamp.entity.StampTypeMasterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface StampTypeMasterRepository extends JpaRepository<StampTypeMasterEntity, UUID> {
}