package com.chola.physical_file.branch.record;

import com.fasterxml.jackson.annotation.JsonAlias;

public record GenexRegionResponse(
        String name,

        @JsonAlias("ZoneID")
        String zoneId,

        @JsonAlias("regionID")
        String regionId
) { }