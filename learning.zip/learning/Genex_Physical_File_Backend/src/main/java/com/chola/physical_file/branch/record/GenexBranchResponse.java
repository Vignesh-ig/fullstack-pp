package com.chola.physical_file.branch.record;

import com.fasterxml.jackson.annotation.JsonAlias;

public record GenexBranchResponse(

        String branchDesc,

        @JsonAlias("branch_id")
        String branchId
) { }