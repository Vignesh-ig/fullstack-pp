package com.chola.physical_file.despatchSystems.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "Despatch_Detail_T", schema = "dbo")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DespatchDetailsEntity {

    @Id
    @Column(name = "dp_ID")
    private Integer dpId;

    @Column(name = "Dp_CourierNo", length = 50)
    private String dpCourierNo;

    @Column(name = "is_physical_file_process", nullable = false)
    private Boolean isPhysicalFileProcess;

    @Column(name = "dp_AppNo", length = 50)
    private String dpAppNo;

    @Column(name = "dp_AppName", length = 50)
    private String dpAppName;

    @Column(name = "dp_AgreementNo", length = 20)
    private String dpAgreementNo;

    @Column(name = "Dp_Createddate")
    private LocalDateTime dpCreatedDate;

    @Column(name = "dp_barcode", length = 25)
    private String dpBarcode;

    @Column(name = "dp_schema", length = 50)
    private String dpSchema;

    @Column(name = "dp_isEsign", length = 10)
    private String dpIsEsign;

    @Column(name = "dp_VehicleRegistrability", length = 50)
    private String dpVehicleRegistrability;

}
