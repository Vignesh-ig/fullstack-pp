package com.chola.physical_file.common.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.core5.util.Timeout;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import java.nio.charset.StandardCharsets;

@Configuration
@Slf4j
public class RestClientConfig {

    @Bean
    public RestClient restClient() {

        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(Timeout.ofSeconds(10))
                .setConnectionRequestTimeout(Timeout.ofSeconds(10))
                .setResponseTimeout(Timeout.ofSeconds(100))
                .build();

        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();

        connectionManager.setMaxTotal(100);
        connectionManager.setDefaultMaxPerRoute(20);

        CloseableHttpClient httpClient = HttpClients.custom()
                .setConnectionManager(connectionManager)
                .setDefaultRequestConfig(requestConfig)
                .disableAutomaticRetries()
                .build();

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);

        return RestClient.builder().requestFactory(requestFactory)
                .requestInterceptor((request, body, execution) -> {

                    StringBuilder curl = new StringBuilder();

                    curl.append("curl -X ")
                            .append(request.getMethod())
                            .append(" '")
                            .append(request.getURI())
                            .append("'");

                    request.getHeaders().forEach((header, values) -> {
                        for (String value : values) {
                            curl.append(" -H '")
                                    .append(header)
                                    .append(": ")
                                    .append(value)
                                    .append("'");
                        }
                    });

                    if (body != null && body.length > 0) {
                        String requestBody = new String(
                                body,
                                StandardCharsets.UTF_8
                        );

                        curl.append(" --data-raw '")
                                .append(requestBody.replace("'", "'\\''"))
                                .append("'");
                    }

//                    log.info("OUTGOING CURL: {}", curl);

                    return execution.execute(request, body);
                })
                .build();
    }
}

