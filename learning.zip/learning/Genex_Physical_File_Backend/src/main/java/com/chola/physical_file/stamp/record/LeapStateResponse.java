package com.chola.physical_file.stamp.record;

import com.fasterxml.jackson.annotation.JsonProperty;

public record LeapStateResponse(
        @JsonProperty("stateID") String stateId,
        @JsonProperty("stateDesc") String stateDesc,
        @JsonProperty("stateCode") String stateCode
) { }