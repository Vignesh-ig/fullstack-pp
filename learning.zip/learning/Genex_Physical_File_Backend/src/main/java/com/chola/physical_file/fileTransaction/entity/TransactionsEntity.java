package com.chola.physical_file.fileTransaction.entity;

import com.chola.physical_file.common.enums.StatusEnum;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "transactions", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionsEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "transactions_id")
    private UUID transactionId;

    @Column(name = "app_no", unique = true)
    private String appNo;

    @Column(name = "agg_no")
    private String aggNo;

    @Column(name = "barcode")
    private String barcode;

    @Column(name = "pod_no")
    private String podNo;

    @Column(name = "missing_pod_no")
    private String missingPodNo;

    @Column(name = "is_e_sign")
    private Boolean isESign;

    @Column(name = "lead_id")
    private Long leadId;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "amount_finance")
    private BigDecimal amountFinance;

    @Column(name = "schema_product")
    private String schemaProduct;

    @Column(name = "scheme")
    private String scheme;

    @Column(name = "branch_desc")
    private String branchDesc;

    @Column(name = "model_no")
    private String modelNo;

    @Column(name = "make")
    private String make;

    @Column(name = "file_type")
    private String fileType;

    @Column(name = "v_bar_code")
    private String vBarCode;

    @Column(name = "box_code")
    private String boxCode;

    @Column(name = "current_remarks", length = 550)
    private String currentRemarks;

    @Column(name = "dms_id")
    private UUID dmsId;

    @Column(name = "hand_off_date")
    private LocalDateTime handOffDate;

    @Column(name = "rack_id")
    private UUID rackId;

    @Column(name = "stage_id")
    private UUID stageId;

    @Column(name = "query_id")
    private UUID queryId;

    @Column(name = "doc_admin_id")
    private UUID docAdminId;

    @Column(name = "vendor_id")
    private UUID vendorId;

    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_status", nullable = false)
    @Builder.Default
    private StatusEnum transactionStatus = StatusEnum.ACTIVE;

    @Column(name = "assigned_user")
    private UUID assignedUser;

    @Column(name = "genex_from_branch")
    private String genexFromBranch;

    @Column(name = "is_locked")
    @Builder.Default
    private Boolean isLocked = false;

    @Column(name = "state_desc")
    private String stateDesc;

    @Column(name = "funded_customer_type")
    private String fundedCustomerType;
    @Column(name = "re_payment_mode")
    private String rePaymentMode;
    @Column(name = "e_stamp")
    private String eStamp;
    @Enumerated(EnumType.STRING)
    @Column(name = "stamp_type")
    private StatusEnum stampType;
    @Column(name = "leap_stamp_amount")
    private BigDecimal leapStampAmount;
    @Column(name = "discount_stamp_amount")
    private BigDecimal discountStampAmount;
    @Column(name = "final_stamp_amount")
    private BigDecimal finalStampAmount;
    @Column(name = "emi_end_date")
    private LocalDateTime emiEndDate;
    @Column(name = "loan_id")
    private String loanId;
    @Column(name = "workflow_no")
    private UUID workflowNo;
    @Column(name = "business_date")
    private LocalDate businessDate;
    @Column(name = "sourcing_date")
    private LocalDate sourcingDate;
    @Column(name = "tenure")
    private Integer tenure;
    @Column(name = "birr")
    private BigDecimal birr;
    @Column(name = "registrable_status")
    private String registrableStatus;
    @Column(name = "udhayam_number_status")
    private String udhayamNumberStatus;
    @Column(name = "pac_amount")
    private BigDecimal pacAmount;
    @Column(name = "query_carton_barcode")
    private String queryCartonBarcode;
    @Column(name = "outward_date")
    private LocalDateTime outwardDate;

    @Column(name = "created_by")
    private UUID createdBy;
    @CreationTimestamp
    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private UUID modifiedBy;

    @UpdateTimestamp
    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;


}
