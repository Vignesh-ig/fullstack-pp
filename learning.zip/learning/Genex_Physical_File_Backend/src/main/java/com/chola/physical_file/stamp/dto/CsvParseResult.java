package com.chola.physical_file.stamp.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CsvParseResult {

    private Integer totalRecords;

    private Integer successfulRecords;

    private Integer failedRecords;

    private List<StampStackMasterDto> validRecords;

    private List<StampStackCsvResponse> validationMessages;

}