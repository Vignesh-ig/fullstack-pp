package com.chola.physical_file.common.dto;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "leap")
public class LeapPropertiesDto {

    private String masterCacheApiUrl;
    private String salesApiUrl;
    private String masterCacheAuthorizationToken;
    private String salesAuthorizationToken;
}