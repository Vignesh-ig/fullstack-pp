package com.chola.physical_file.common.record;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

public record LeapVFAppDetailsResponse(

        @JsonProperty("agreementNo")
        String agreementNo,

        @JsonProperty("applicationFormNo")
        String applicationFormNo,

        @JsonProperty("loanID")
        String loanId,

        @JsonProperty("businessDate")
        LocalDate businessDate,

        @JsonProperty("sourcingDate")
        LocalDate sourcingDate,

        @JsonProperty("tenure")
        Integer tenure,

        @JsonProperty("BIRR")
        BigDecimal birr,

        @JsonProperty("registrableStatus")
        String registrableStatus,

        @JsonProperty("UdhayamNumberStatus")
        String udhayamNumberStatus,

        @JsonProperty("pacAmount")
        BigDecimal pacAmount,

        @JsonProperty("branchDesc")
        String branchDesc,

        @JsonProperty("branchId")
        String branchId,

        @JsonProperty("stateID")
        String stateId,

        @JsonProperty("financeAmount")
        BigDecimal financeAmount,

        @JsonProperty("fundedCustomerType")
        String fundedCustomerType,

        @JsonProperty("rePaymentMode")
        String rePaymentMode,

        @JsonProperty("workflow_no")
        UUID workflowNo,

        @JsonProperty("lead_id")
        Long leadId,

        @JsonProperty("e-stamp")
        String eStamp,

        @JsonProperty("stateDesc")
        String stateDesc,

        @JsonProperty("stamp_type")
        String stampType,

        @JsonProperty("stampamt")
        String stampAmount,

        @JsonProperty("customername")
        String customerName,

        @JsonProperty("dms_id")
        UUID dmsId,

        @JsonProperty("file_type")
        String fileType,

        @JsonProperty("emiEndDate")
        LocalDate emiEndDate,

        @JsonProperty("disbursedDate")
        LocalDate disbursedDate

) { }