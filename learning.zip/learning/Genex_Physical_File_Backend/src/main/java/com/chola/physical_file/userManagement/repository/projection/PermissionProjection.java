package com.chola.physical_file.userManagement.repository.projection;

import java.time.LocalDateTime;
import java.util.UUID;

public interface PermissionProjection {

    UUID getPermissionId();

    String getPermissionName();

    String getDescription();

    UUID getRoleId();

    String getRoleName();

    UUID getCreatedBy();

    LocalDateTime getCreatedDate();

    UUID getModifiedBy();

    LocalDateTime getModifiedDate();
}

