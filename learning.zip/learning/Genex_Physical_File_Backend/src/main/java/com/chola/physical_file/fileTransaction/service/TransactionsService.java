package com.chola.physical_file.fileTransaction.service;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.StageEnum;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.dashboard.dto.DashboardDto;
import com.chola.physical_file.fileTransaction.dto.TransactionsDto;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@SuppressWarnings("all")
public interface TransactionsService {

    void createFileTransaction(List<TransactionsDto> transactionsDtos);

    PageResponseDto getFileTransactionApps(Integer pageNumber, Integer pageSize, String appNoOrAggNo, String likeAppNoOrBarcode, List<StageEnum> stages, List<UUID> assignedUsers, UUID branchUser, Boolean isLocked, StatusEnum stampType, StatusEnum queryState, String queryCartonBarcode, LocalDateTime startDate, LocalDateTime endDate, Boolean exportAllRecords);

    void lockFileTransactionApps(List<String> appNos, Boolean isLocked);

    DashboardDto getTransactionsCount(UUID assignedUser);

    DashboardDto getQueryAppCount();
}
