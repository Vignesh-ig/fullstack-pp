package com.chola.physical_file.stamp.repository;

import com.chola.physical_file.stamp.entity.StampMasterEntity;
import com.chola.physical_file.stamp.repository.projection.StampMasterProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface StampMasterRepository extends JpaRepository<StampMasterEntity, UUID> {

    @Query("""
            SELECT
                sm.stampMasterId AS stampMasterId,
                sm.stampDenominationMasterId AS stampDenominationMasterId,
                sdm.stampDenominationNo AS stampDenominationNo,
                sm.stampTypeMasterId AS stampTypeMasterId,
                stm.stampTypeName AS stampTypeName,
                sm.state AS state,
                sm.status AS status,
                sm.createdBy AS createdBy,
                sm.createdDate AS createdDate,
                sm.modifiedBy AS modifiedBy,
                sm.modifiedDate AS modifiedDate
            FROM StampMasterEntity sm
            LEFT JOIN StampDenominationMasterEntity sdm
                ON sm.stampDenominationMasterId = sdm.stampDenominationMasterId
            LEFT JOIN StampTypeMasterEntity stm
                ON sm.stampTypeMasterId = stm.stampTypeMasterId
            WHERE (:state IS NULL OR sm.state = :state)
            AND (:stampType IS NULL OR sm.stampTypeMasterId = :stampType)
              AND (:stampMasterId IS NULL OR sm.stampMasterId = :stampMasterId)
            ORDER BY sm.state ASC, sdm.stampDenominationNo ASC
            """)
    Page<StampMasterProjection> findStampMasters(@Param("state") String state, @Param("stampType") UUID stampType, @Param("stampMasterId") UUID stampMasterId, Pageable pageable);

    boolean existsByStateAndStampTypeMasterIdAndStampDenominationMasterId(String state, UUID stampTypeMasterId, UUID stampDenominationMasterId);

    boolean existsByStateAndStampTypeMasterIdNot(String state, UUID stampTypeMasterId);
}