package com.chola.physical_file.despatchSystems.dto;

import com.chola.physical_file.despatchSystems.entity.DespatchDetailsEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class DespatchWithOriginDto {
    private DespatchDetailsEntity despatchDetails;
    private String origin;
}