package com.chola.physical_file.rackAndUserAssigned.service.impl;

import com.chola.physical_file.auditLog.customAnnotation.AuditLog;
import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.RackAllocationAction;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.enums.StageEnum;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.common.exception.ResourceAlreadyExistsException;
import com.chola.physical_file.common.exception.ResourceNotFoundException;
import com.chola.physical_file.common.record.LeapVFAppDetailsResponse;
import com.chola.physical_file.common.service.ExternalApiCallService;
import com.chola.physical_file.dashboard.dto.DashboardDto;
import com.chola.physical_file.despatchSystems.service.DespatchDetailsService;
import com.chola.physical_file.fileTransaction.dto.TransactionsDto;
import com.chola.physical_file.fileTransaction.mapper.TransactionsMapper;
import com.chola.physical_file.fileTransaction.service.TransactionsService;
import com.chola.physical_file.rackAndUserAssigned.dto.RackAssignedDto;
import com.chola.physical_file.rackAndUserAssigned.dto.RackAssignedResponseDto;
import com.chola.physical_file.rackAndUserAssigned.entity.RackAssignedEntity;
import com.chola.physical_file.rackAndUserAssigned.mapper.RackAssignedMapper;
import com.chola.physical_file.rackAndUserAssigned.repository.RackAssignedRepository;
import com.chola.physical_file.rackAndUserAssigned.repository.projection.AllocationStatusCountProjection;
import com.chola.physical_file.rackAndUserAssigned.repository.projection.RackAssignedProjection;
import com.chola.physical_file.rackAndUserAssigned.service.RackAssignedService;
import com.chola.physical_file.rackAndUserAssigned.service.RackService;
import com.chola.physical_file.stage.service.StageService;
import com.chola.physical_file.userManagement.mapper.UserMapper;
import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class RackAssignedServiceImpl implements RackAssignedService {

    private final RackAssignedRepository rackAssignedRepository;
    private final RackAssignedMapper rackAssignedMapper;
    private final EntityManager entityManager;
    private final RackService rackService;
    private final DespatchDetailsService despatchDetailsService;
    private final ExternalApiCallService externalApiCallService;
    private final UserMapper userMapper;
    private final TransactionsService transactionsService;
    private final TransactionsMapper transactionsMapper;
    private final StageService stageService;

    @Value("${records.bulk.batch-size}")
    private Integer batchSize;

    @AuditLog(
            action = "BULK_RACK_ASSIGNMENT",
            module = "RACK_ASSIGNMENT",
            entity = "RACK_ASSIGNED"
    )
    @Override
    @Transactional
    public void bulkRackAssigned(List<RackAssignedDto> rackAssignedDtos) {
        // Validation / preparation
        List<String> requestAppNos = validateDuplicateAppNos(rackAssignedDtos);

        Map<UUID, Long> requestedRackCounts = getRequestedRackCounts(rackAssignedDtos);

        rackService.adjustRackCapacity(requestedRackCounts);

        // Update MSSQL
        updatePhysicalFileProcessStatus(requestAppNos);

        // Execute PostgreSQL transaction
        try {

            processPostgresRackAssignment(rackAssignedDtos);

        } catch (Exception ex) {

            // Compensating transaction in MSSQL
            compensatePhysicalFileProcessStatus(requestAppNos, ex);

            // Let GlobalExceptionHandler handle the exception
            throw ex;
        }
    }

    @Transactional
    protected void processPostgresRackAssignment(List<RackAssignedDto> rackAssignedDtos) {

        List<RackAssignedEntity> rackAssignedEntities = rackAssignedMapper.toEntities(rackAssignedDtos);

        persistEntitiesInBatch(rackAssignedEntities);

        List<RackAssignedDto> rackAssignedDtosToTransactions =
                rackAssignedDtos.stream()
                        .filter(dto -> dto.getAssignedUser() == null)
                        .toList();

        if (!rackAssignedDtosToTransactions.isEmpty()) {

            UUID stageId = stageService.getStageId(StageEnum.RACK_ASSIGNED);

            List<TransactionsDto> transactionsDtos = transactionsMapper.mapBulkRackAssignedDtosToTransactionDtos(rackAssignedDtosToTransactions, stageId, StageEnum.USER_ASSIGNED);

            transactionsService.createFileTransaction(transactionsDtos);
        }
    }

    private Map<String, LeapVFAppDetailsResponse> validateLeapApplicationNumbers(List<String> requestAppNos) {

        String appNo = String.join(",", requestAppNos);

        List<LeapVFAppDetailsResponse> leapDetails = externalApiCallService.getLeapVFAppNoDetailsByAppNos(appNo);

        Set<String> leapAppNos = leapDetails.stream()
                .map(LeapVFAppDetailsResponse::applicationFormNo)
                .collect(Collectors.toSet());

        List<String> missingAppNos = requestAppNos.stream()
                .filter(appNoValue -> !leapAppNos.contains(appNoValue))
                .toList();

        if (!missingAppNos.isEmpty()) {
            throw new ResourceNotFoundException("Application numbers not found in Leap: " + String.join(", ", missingAppNos));
        }

        return leapDetails.stream()
                .collect(Collectors.toMap(LeapVFAppDetailsResponse::applicationFormNo, Function.identity()));
    }

    private Map<UUID, Long> getRequestedRackCounts(List<RackAssignedDto> rackAssignedDtos) {

        return rackAssignedDtos.stream()
                .collect(Collectors.groupingBy(RackAssignedDto::getRackId, Collectors.counting()));
    }

    private void updatePhysicalFileProcessStatus(List<String> requestAppNos) {

        int updateCount = despatchDetailsService.updateIsPhysicalFileProcess(requestAppNos, true);

        if (updateCount != requestAppNos.size()) {

            throw new IllegalStateException("Mismatch in updating isPhysicalFileProcess for appNos");
        }
    }

    private void compensatePhysicalFileProcessStatus(List<String> requestAppNos, Exception originalException) {

        try {

            int updateCount = despatchDetailsService.updateIsPhysicalFileProcess(requestAppNos, false);

            if (updateCount != requestAppNos.size()) {

                log.error("MSSQL compensation partially failed. " + "Expected: {}, Updated: {}, AppNos: {}", requestAppNos.size(), updateCount, requestAppNos);
            }

        } catch (Exception compensationException) {

            log.error("CRITICAL: MSSQL compensation failed. " + "AppNos: {}, Original error: {}", requestAppNos, originalException.getMessage(), compensationException);
        }
    }

    @AuditLog(
            action = "BULK_RACK_ASSIGNMENT_UPDATE",
            module = "RACK_ASSIGNMENT",
            entity = "RACK_ASSIGNED"
    )
    @Override
    @Transactional
    public void updateBulkRackAssigned(List<RackAssignedDto> rackAssignedDtos, RackAllocationAction rackAllocationAction) {

        if (CollectionUtils.isEmpty(rackAssignedDtos)) {
            return;
        }

        List<String> requestAppNos = extractRequestAppNos(rackAssignedDtos);

        List<RackAssignedEntity> existingEntities = rackAssignedRepository.findByAppNoIn(requestAppNos);

        if (existingEntities.isEmpty()) {
            throw new ResourceNotFoundException(
                    ResponseMessage.NO_EXISTING_RECORDS_FOR_APP_NUMBERS.getMessage());
        }

        Map<String, RackAssignedDto> rackAssignedDtoMap = buildDtoMap(rackAssignedDtos);

        switch (rackAllocationAction) {

            case UPDATE_RACK_ALLOCATION -> updateRackAllocation(existingEntities, rackAssignedDtoMap);

            case ASSIGN_USER -> assignUser(existingEntities, rackAssignedDtoMap);

            case RETURN_TO_RACK -> returnToRack(existingEntities, rackAssignedDtoMap);

            case UPDATE_ASSIGN_USER -> updateAssignUser(existingEntities, rackAssignedDtoMap);

            default -> throw new IllegalArgumentException("Unsupported action : " + rackAllocationAction);
        }
    }

    public void updateAssignUser(List<RackAssignedEntity> existingEntities, Map<String, RackAssignedDto> rackAssignedDtoMap) {
        updateEntitiesInBatch(existingEntities, rackAssignedDtoMap);
    }

    public void updateRackAllocation(List<RackAssignedEntity> existingEntities, Map<String, RackAssignedDto> rackAssignedDtoMap) {

        Map<UUID, Long> delta = buildRackMoveDelta(existingEntities, rackAssignedDtoMap);

        updateEntitiesInBatch(existingEntities, rackAssignedDtoMap);

        rackService.adjustRackCapacity(delta);
    }

    public void assignUser(List<RackAssignedEntity> existingEntities, Map<String, RackAssignedDto> rackAssignedDtoMap) {

        Map<UUID, Long> delta = buildAssignUserDelta(existingEntities);

        updateEntitiesInBatch(existingEntities, rackAssignedDtoMap);

        UUID stageId = stageService.getStageId(StageEnum.HEALTH_CHECK);

        List<TransactionsDto> transactions = transactionsMapper.mapBulkRackAssignedDtosToTransactionDtos(new ArrayList<>(rackAssignedDtoMap.values()), stageId, StageEnum.HEALTH_CHECK);

        transactionsService.createFileTransaction(transactions);

        rackService.adjustRackCapacity(delta);
    }

    public void returnToRack(List<RackAssignedEntity> existingEntities, Map<String, RackAssignedDto> rackAssignedDtoMap) {

        Map<UUID, Long> delta = buildReturnRackDelta(existingEntities, rackAssignedDtoMap);

        updateEntitiesInBatch(existingEntities, rackAssignedDtoMap);

        UUID stageId = stageService.getStageId(StageEnum.RETURN_TO_RACK);


        List<TransactionsDto> transactions = transactionsMapper.mapBulkRackAssignedDtosToTransactionDtos(new ArrayList<>(rackAssignedDtoMap.values()), stageId, StageEnum.RETURN_TO_RACK);

        transactionsService.createFileTransaction(transactions);

        rackService.adjustRackCapacity(delta);
    }

    public Map<UUID, Long> buildRackMoveDelta(List<RackAssignedEntity> existingEntities, Map<String, RackAssignedDto> rackAssignedDtoMap) {

        Map<UUID, Long> delta = new HashMap<>();

        for (RackAssignedEntity rackAssignedEntity : existingEntities) {

            RackAssignedDto rackAssignedDto = rackAssignedDtoMap.get(rackAssignedEntity.getAppNo());

            if (rackAssignedDto == null) {
                continue;
            }

            UUID oldRack = rackAssignedEntity.getRack();
            UUID newRack = rackAssignedDto.getRackId();

            if (Objects.equals(oldRack, newRack)) {
                continue;
            }

            delta.merge(oldRack, -1L, Long::sum);

            delta.merge(newRack, 1L, Long::sum);
        }

        return delta;
    }

    public Map<UUID, Long> buildAssignUserDelta(List<RackAssignedEntity> existingEntities) {

        Map<UUID, Long> delta = new HashMap<>();

        for (RackAssignedEntity entity : existingEntities) {

            delta.merge(entity.getRack(), -1L, Long::sum);
        }

        return delta;
    }

    public Map<UUID, Long> buildReturnRackDelta(List<RackAssignedEntity> existingEntities, Map<String, RackAssignedDto> rackAssignedDtoMap) {

        Map<UUID, Long> delta = new HashMap<>();

        for (RackAssignedEntity rackAssignedEntity : existingEntities) {

            RackAssignedDto rackAssignedDto = rackAssignedDtoMap.get(rackAssignedEntity.getAppNo());

            if (rackAssignedDto == null) {
                continue;
            }

            UUID destinationRack = Objects.equals(rackAssignedEntity.getRack(), rackAssignedDto.getRackId()) ? rackAssignedEntity.getRack() : rackAssignedDto.getRackId();

            delta.merge(destinationRack, 1L, Long::sum);
        }

        return delta;
    }

    @Override
    @Transactional(readOnly = true)
    public DashboardDto getAllocationAppCount(UUID assignedUser) {

        AllocationStatusCountProjection allocationStatusCounts = rackAssignedRepository.getAllocationStatusCounts(assignedUser);

        return DashboardDto.builder()
                .totalApps(allocationStatusCounts.getTotalApps())
                .pendingApps(allocationStatusCounts.getPendingApps())
                .inProcessApps(allocationStatusCounts.getInProcessApps())
                .completedApps(allocationStatusCounts.getCompletedApps())
                .build();
    }


    // VALIDATE DUPLICATES
    public List<String> validateDuplicateAppNos(List<RackAssignedDto> rackAssignedDtos) {

        List<String> requestAppNos = extractRequestAppNos(rackAssignedDtos);

        if (requestAppNos.isEmpty()) {
            throw new IllegalArgumentException(ResponseMessage.AT_LEAST_ONE_VALID_APP_NUMBER_REQUIRED.getMessage());
        }

        // CHECK DUPLICATES INSIDE REQUEST
        Set<String> uniqueAppNos = new HashSet<>();
        Set<String> duplicateRequestAppNos = requestAppNos.stream()
                .filter(appNo -> !uniqueAppNos.add(appNo))
                .collect(Collectors.toCollection(LinkedHashSet::new));

        if (!duplicateRequestAppNos.isEmpty()) {
            throw new IllegalArgumentException(
                    String.format(ResponseMessage.DUPLICATE_APP_NUMBERS_IN_REQUEST.getMessage(), String.join(", ", duplicateRequestAppNos))
            );
        }

        // CHECK DUPLICATES IN DATABASE
        List<String> existingAppNos = rackAssignedRepository.findExistingAppNos(requestAppNos);

        if (!existingAppNos.isEmpty()) {
            throw new ResourceAlreadyExistsException(String.format(ResponseMessage.APP_NUMBERS_ALREADY_EXIST.getMessage(), String.join(", ", existingAppNos)));
        }

        return requestAppNos;
    }

    // EXTRACT APP NOS
    public List<String> extractRequestAppNos(List<RackAssignedDto> rackAssignedDtos) {

        return rackAssignedDtos.stream()
                .map(RackAssignedDto::getAppNo)
                .filter(StringUtils::hasText)
                .toList();
    }

    // DTO MAP
    public Map<String, RackAssignedDto> buildDtoMap(List<RackAssignedDto> rackAssignedDtos) {

        return rackAssignedDtos.stream()
                .filter(dto -> StringUtils.hasText(dto.getAppNo()))
                .collect(Collectors.toMap(
                        RackAssignedDto::getAppNo,
                        Function.identity(),
                        (oldValue, newValue) -> newValue
                ));
    }

    // BUILD RACK DELTA
    public Map<UUID, Long> buildRackCountChanges(List<RackAssignedEntity> existingEntities, Map<String, RackAssignedDto> rackAssignedDtoMap) {

        Map<UUID, Long> rackCountChanges = new HashMap<>();

        for (RackAssignedEntity rackAssignedEntity : existingEntities) {

            RackAssignedDto rackAssignedDto = rackAssignedDtoMap.get(rackAssignedEntity.getAppNo());

            if (rackAssignedDto == null) {
                continue;
            }

            UUID oldRackId = rackAssignedEntity.getRack();

            UUID newRackId = rackAssignedDto.getRackId();

            // SAME RACK
            if (Objects.equals(oldRackId, newRackId)) {
                continue;
            }

            // OLD RACK --
            rackCountChanges.merge(oldRackId, -1L, Long::sum);

            // NEW RACK ++
            rackCountChanges.merge(newRackId, 1L, Long::sum);
        }

        return rackCountChanges;
    }

    // BATCH INSERT
    public void persistEntitiesInBatch(List<RackAssignedEntity> rackAssignedEntities) {

        int count = 0;

        for (RackAssignedEntity rackAssignedEntity : rackAssignedEntities) {

            entityManager.persist(rackAssignedEntity);

            count++;

            batchFlush(count);
        }

        flushAndClear();
    }

    // BATCH UPDATE
    public void updateEntitiesInBatch(List<RackAssignedEntity> existingEntities, Map<String, RackAssignedDto> rackAssignedDtoMap) {

        int count = 0;

        for (RackAssignedEntity rackAssignedEntity : existingEntities) {

            if (rackAssignedEntity.getAssignedStatus() != StatusEnum.PENDING) {
                throw new IllegalArgumentException(String.format(ResponseMessage.CANNOT_UPDATE_NON_PENDING_RECORDS.getMessage(), rackAssignedEntity.getAppNo()));
            }

            RackAssignedDto rackAssignedDto = rackAssignedDtoMap.get(rackAssignedEntity.getAppNo());

            if (rackAssignedDto == null) {
                continue;
            }

            rackAssignedMapper.updateEntityFromDto(rackAssignedDto, rackAssignedEntity);

            count++;

            batchFlush(count);
        }

        flushAndClear();
    }

    // BATCH FLUSH
    public void batchFlush(int count) {
        if (count % batchSize == 0) {
            entityManager.flush();
            entityManager.clear();
        }
    }

    // FINAL FLUSH
    public void flushAndClear() {
        entityManager.flush();
        entityManager.clear();
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponseDto getAllRackAssigned(Integer pageNumber, Integer pageSize, List<UUID> assignedUsers, UUID assignedRack, StatusEnum assignedStatus, Boolean userAssigned, String appNoOrAggNo, String likeAppNoOrBarcode, UUID rackAssignedId, LocalDateTime startDate, LocalDateTime endDate) {

        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "createdDate")
        );
        if (assignedUsers == null || assignedUsers.isEmpty()) {
            assignedUsers = null;
        }

        Page<RackAssignedProjection> pageResponse = rackAssignedRepository.findAllRackAssigned(assignedUsers, assignedRack, assignedStatus, userAssigned, appNoOrAggNo, likeAppNoOrBarcode, rackAssignedId, startDate, endDate, pageable);

        List<RackAssignedResponseDto> rackAssignedResponseDtoList = pageResponse.stream()
                .map(rackAssignedMapper::mapToRackAssignedDto)
                .toList();

        PageResponseDto pageResponseDto = new PageResponseDto();
        pageResponseDto.setData(rackAssignedResponseDtoList);
        pageResponseDto.setCurrentPage(pageResponse.getNumber() + 1);
        pageResponseDto.setTotalItems((int) pageResponse.getTotalElements());
        pageResponseDto.setTotalPages(pageResponse.getTotalPages());
        pageResponseDto.setHasNextPage(pageResponse.hasNext());
        pageResponseDto.setHasPreviousPage(pageResponse.hasPrevious());
        return pageResponseDto;
    }
}