package com.chola.physical_file.dashboard.service.impl;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.dashboard.dto.DashboardDto;
import com.chola.physical_file.dashboard.service.DashboardService;
import com.chola.physical_file.fileTransaction.service.TransactionsService;
import com.chola.physical_file.rackAndUserAssigned.service.RackAssignedService;
import com.chola.physical_file.stamp.service.StampStackMasterService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class DashboardServiceImpl implements DashboardService {
    private final RackAssignedService  rackAssignedService;
    private final StampStackMasterService stampStackMasterService;
    private final TransactionsService transactionsService;

    @Override
    @Transactional(readOnly = true)
    public DashboardDto getDashboardAppCount(UUID assignedUser, StatusEnum overview, List<String> states) {

        return switch (overview) {

            case ALLOCATION_OVERVIEW -> rackAssignedService.getAllocationAppCount(assignedUser);

            case STAMPING_OVERVIEW -> stampStackMasterService.getStampStackMasterCount(states);

            case TRANSACTION_OVERVIEW -> transactionsService.getTransactionsCount(assignedUser);

            case QUERY_OVERVIEW -> transactionsService.getQueryAppCount();

            default -> throw new IllegalArgumentException("Unsupported dashboard overview: " + overview);
        };
    }
}