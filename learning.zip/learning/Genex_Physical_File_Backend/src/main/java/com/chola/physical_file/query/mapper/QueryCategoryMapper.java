package com.chola.physical_file.query.mapper;

import com.chola.physical_file.query.dto.QueryCategoryDto;
import com.chola.physical_file.query.entity.QueryCategoryEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class QueryCategoryMapper {

    public QueryCategoryDto entityToDto(QueryCategoryEntity queryCategoryEntity) {

        if (queryCategoryEntity == null) {
            return null;
        }

        return QueryCategoryDto.builder()
                .queryCategoryId(queryCategoryEntity.getQueryCategoryId())
                .queryCategoryName(queryCategoryEntity.getQueryCategoryName())
                .queryCategoryDescription(queryCategoryEntity.getQuerySubCategoryName())
                .queryCategoryType(queryCategoryEntity.getQueryCategoryType())
                .createdBy(queryCategoryEntity.getCreatedBy())
                .createdDate(queryCategoryEntity.getCreatedDate())
                .build();
    }

    public QueryCategoryEntity dtoToEntity(QueryCategoryDto queryCategoryDto) {

        if (queryCategoryDto == null) {
            return null;
        }

        return QueryCategoryEntity.builder()
                .queryCategoryName(queryCategoryDto.getQueryCategoryName())
                .querySubCategoryName(queryCategoryDto.getQueryCategoryDescription())
                .queryCategoryType(queryCategoryDto.getQueryCategoryType())
                .createdBy(queryCategoryDto.getCreatedBy())
                .build();
    }

    public List<QueryCategoryDto> toDtos(List<QueryCategoryEntity> entities) {

        return entities.stream()
                .map(this::entityToDto)
                .toList();
    }
}