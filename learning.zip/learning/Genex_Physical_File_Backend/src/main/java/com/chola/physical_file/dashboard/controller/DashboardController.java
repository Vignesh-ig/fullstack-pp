package com.chola.physical_file.dashboard.controller;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.ResponseUtil;
import com.chola.physical_file.dashboard.service.DashboardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/dashboard")
@Tag(name = "Dashboard", description = "APIs to fetch Dashboard details")
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping
    @Operation(summary = "Get Dashboard details", description = "Fetch Dashboard details Based on the user and rack assigned applications.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Dashboard details fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = PageResponseDto.class)))
    })
    public ResponseEntity<CommonResponseUtil> getDashboardAppCount(
            @Parameter(description = "Search by user assigned related applications") @RequestParam(name = "assignedUser", required = false) UUID assignedUser,
            @Parameter(description = "overview filter based on the type of user") @RequestParam(name = "overview") StatusEnum overview,
            @Parameter(description = "List of states to filter the stamp stack master records") @RequestParam(name = "states", required = false) List<String> states
    ) {
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.DASHBOARD_APPS_COUNT.getMessage(), HttpStatus.OK, dashboardService.getDashboardAppCount(assignedUser, overview, states)));
    }

}