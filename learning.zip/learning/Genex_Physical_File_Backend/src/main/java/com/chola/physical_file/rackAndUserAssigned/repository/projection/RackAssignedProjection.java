package com.chola.physical_file.rackAndUserAssigned.repository.projection;

import com.chola.physical_file.common.enums.StatusEnum;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

public interface RackAssignedProjection {

    UUID getRackAssignedId();
    String getAgeingNo();

    LocalDate getBusinessDate();
    String getAppNo();
    String getAggNo();
    String getBarcode();
    StatusEnum getAssignedStatus();
    String getCustomerName();

    String getFileType();
    LocalDateTime getCreatedDate();

    LocalDateTime getModifiedDate();

    // rack
    UUID getRackId();
    String getRackName();
    String getVaultName();
    String getRackPosition();
    Boolean getRackStatus();
    Integer getRackAppCount();

    // Emp User
    UUID getEmpUserId();
    String getEmpUserName();
    String getEmpUserEmail();
    String getEmpUserEmployeeCode();

    // Assigned User
    UUID getAssignedUserId();
    String getAssignedUserName();
    String getAssignedUserEmail();
    String getAssignedUserEmployeeCode();

    // Return User
    UUID getReturnUserId();
    String getReturnUserName();
    String getReturnUserEmail();
    String getReturnUserEmployeeCode();
}