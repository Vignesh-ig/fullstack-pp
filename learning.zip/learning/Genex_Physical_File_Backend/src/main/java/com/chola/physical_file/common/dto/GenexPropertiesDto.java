package com.chola.physical_file.common.dto;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "genex")
public class GenexPropertiesDto {

    private String physicalApiUrl;
    private String disbursementApiUrl;
    private String integrationApiUrl;
    private String authorizationToken;
    private String customToken;
    private String integrationToken;
    private String authId;
}
