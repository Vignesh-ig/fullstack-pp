package com.chola.physical_file.userManagement.dto;

import com.chola.physical_file.branch.record.GenexPFBranchResponse;
import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.Update;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserDto {

    @NotNull(groups = Update.class, message = "Id is required for update")
    private UUID userId;

    @NotBlank(groups = {Create.class, Update.class}, message = "User name is required")
    @Size(max = 150, message = "User name cannot exceed 150 characters")
    private String userName;

    @NotBlank(groups = {Create.class, Update.class}, message = "Email is required")
    @Email(message = "Invalid email format")
    @Size(max = 150, message = "Email cannot exceed 150 characters")
    private String userEmail;

    @NotBlank(groups = {Create.class, Update.class}, message = "User employee code is required")
    @Size(max = 50, message = "User employee code cannot exceed 50 characters")
    private String userEmployeeCode;

    private Boolean isActive = true;

    private LocalDateTime createdDate;

    @NotNull(groups = Create.class, message = "Created By is required for create")
    private UUID createdBy;

    private LocalDateTime modifiedDate;

    @NotNull(groups = Update.class, message = "Modified By is required for update")
    private UUID modifiedBy;

    @NotNull(groups = {Create.class, Update.class}, message = "Role is required")
    private UUID roleId;

    private RoleDto roleDto;

    private List<String> branchIds;

    private List<GenexPFBranchResponse> branchDtos;
}