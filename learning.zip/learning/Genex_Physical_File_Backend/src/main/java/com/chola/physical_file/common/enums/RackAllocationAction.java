package com.chola.physical_file.common.enums;

public enum RackAllocationAction {

    UPDATE_RACK_ALLOCATION,

    ASSIGN_USER,

    RETURN_TO_RACK,

    UPDATE_ASSIGN_USER,
}