package com.chola.physical_file.userManagement.repository;

import com.chola.physical_file.userManagement.entity.LogInHistoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface LogInHistoryRepository extends JpaRepository<LogInHistoryEntity, UUID> {
}
