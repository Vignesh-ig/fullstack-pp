package com.chola.physical_file.common.enums;

public enum StageEnum {
    OUTWARD,
    STAMPING,
    QUERY,
    QUERY_RESOLVED,
    HEALTH_CHECK,
    RACK_ASSIGNED,
    RETURN_TO_RACK,
    USER_ASSIGNED,
    ENQUIRY,
    STORAGE,
}