package com.chola.physical_file.rackAndUserAssigned.entity;

import com.chola.physical_file.common.enums.StatusEnum;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "rack_user_assigned", schema = "physical_file")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RackAssignedEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "rack_assigned_id")
    private UUID rackAssignedId;

    @Column(name = "business_date")
    private LocalDate businessDate;

    @Column(name = "assigned_user")
    private UUID assignedUser;

    @Column(name = "app_no")
    private String appNo;

    @Column(name = "agg_no")
    private String aggNo;

    @Column(name = "barcode")
    private String barcode;

    @Enumerated(EnumType.STRING)
    @Column(name = "assigned_status", nullable = false)
    @Builder.Default
    private StatusEnum assignedStatus = StatusEnum.PENDING;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "file_type")
    private String fileType;

    @Column(name = "rack_id")
    private UUID rack;

    @Column(name = "created_by")
    private UUID createdBy;

    @CreationTimestamp
    @Column(name = "created_date")
    private LocalDateTime createdDate;

    @Column(name = "modified_by")
    private UUID modifiedBy;

    @UpdateTimestamp
    @Column(name = "modified_date")
    private LocalDateTime modifiedDate;

}

