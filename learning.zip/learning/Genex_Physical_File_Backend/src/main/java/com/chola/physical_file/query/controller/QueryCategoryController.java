package com.chola.physical_file.query.controller;

import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.ResponseUtil;
import com.chola.physical_file.query.dto.QueryCategoryDto;
import com.chola.physical_file.query.service.QueryCategoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/queryCategory")
@Validated
@Tag(name = "Query Category", description = "APIs for managing query categories")
public class QueryCategoryController {
    private final QueryCategoryService queryCategoryService;

    @GetMapping
    @Operation(summary = "Get all query categories", description = "Fetch list of all query categories.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Query categories fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = List.class)))
    })
    public ResponseEntity<CommonResponseUtil> getAllQueryCategories(
            @Parameter(description = "Page number (starting from 1)", example = "1") @RequestParam(name = "page", defaultValue = "1") @Min(value = 1, message = "The page must be a positive number.")
            Integer pageNumber,
            @Parameter(description = "Page size (max 500)", example = "10") @RequestParam(name = "limit", defaultValue = "10") @Min(value = 1, message = "The limit must be a positive number.") @Max(value = 500, message = "Maximum allowed limit is 500.")
            Integer pageSize,
            @Parameter(description = "Optional search by query category name") @RequestParam(name = "queryCategoryName", required = false) String queryCategoryName

    ) {
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.QUERY_CATEGORIES_FETCHED.getMessage(), HttpStatus.OK, queryCategoryService.getAllQueryCategories(pageNumber, pageSize, queryCategoryName)));
    }

    @PostMapping
    @Operation(summary = "Create query categories", description = "Create a new query category.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Query category created successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or bad request")
    })
    public ResponseEntity<CommonResponseUtil> createQueryCategory(@Validated(Create.class) @RequestBody QueryCategoryDto queryCategoryDtoList) {
        queryCategoryService.createQueryCategories(queryCategoryDtoList);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ResponseUtil.success(ResponseMessage.QUERY_CATEGORY_CREATED.getMessage(), HttpStatus.CREATED, null));
    }

    @PostMapping("/ids")
    @Operation(summary = "Delete query categories", description = "Delete one or more query categories by their UUIDs. Provide query category IDs as query param 'queryCategoryIds'.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Query category deleted successfully"),
            @ApiResponse(responseCode = "400", description = "Bad request when queryCategoryIds is empty or invalid")
    })
    public ResponseEntity<CommonResponseUtil> deleteQueryCategory(@Parameter(description = "List of query category UUIDs to delete", required = true) @RequestParam(name = "queryCategoryIds") List<UUID> queryCategoryIds) {
        if (queryCategoryIds == null || queryCategoryIds.isEmpty()) {
            throw new IllegalArgumentException(ResponseMessage.QUERY_CATEGORY_IDS_EMPTY.getMessage());
        }
        queryCategoryService.deleteQueryCategory(queryCategoryIds);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.QUERY_CATEGORY_DELETED.getMessage(), HttpStatus.OK, null));
    }
}