package com.chola.physical_file.common.enums;

import lombok.Getter;

@Getter
public enum ResponseMessage {

    // Branch messages
    ACTIVE_BRANCH_RECORDS_FETCHED("Active branch records fetched successfully"),
    BRANCH_CREATED("Branch record created successfully"),
    BRANCH_UPDATED("Branch record updated successfully"),
    BRANCH_DELETED("Branch record(s) deleted successfully"),
    BRANCH_IDS_EMPTY("Branch IDs cannot be empty"),
    DUPLICATE_BRANCH_IDS("Duplicate branch Ids found in the request"),

    // Despatch messages
    DESPATCH_DETAILS_FETCHED("Despatch details are fetched successfully"),
    AGREEMENT_NUMBER_EMPTY("Agreement Number must not be empty"),
    APPLICATION_DETAILS_FETCHED("Application details are fetched successfully"),

    // Rack messages
    ACTIVE_RACK_RECORDS_FETCHED("Active rack records fetched successfully"),
    RACK_CREATED("Rack record created successfully"),
    RACK_UPDATED("Rack record updated successfully"),
    RACK_DELETED("Rack record(s) deleted successfully"),
    RACK_IDS_EMPTY("Rack IDs cannot be empty"),

    // File type
    FILE_TYPE_RECORDS_FETCHED("File type records fetched successfully"),

    // Rack assigned
    RACK_ASSIGNED_RECORDS_FETCHED("Rack assigned records fetched successfully"),
    REQUEST_BODY_CANNOT_BE_EMPTY("Request body cannot be empty"),
    RACK_AND_APPLICATIONS_ASSIGNED_SUCCESS("Rack and applications assigned to users successfully"),
    RACK_ASSIGNED_UPDATED("Rack assigned details updated successfully"),

    // Role
    ROLES_FETCHED("Roles fetched successfully"),

    //vault
    VAULT_RECORDS_FETCHED("Vault records fetched successfully"),

    // User
    USERS_FETCHED("Users fetched successfully"),
    GENEX_USERS_FETCHED("Genex users fetched successfully"),
    USER_LOGGED_IN_SUCCESS("User logged in successfully"),
    USER_CREATED("User created successfully"),
    USER_UPDATED("User updated successfully"),
    USER_IDS_EMPTY("User IDs cannot be empty"),
    USER_DELETED("User deleted successfully"),

    // Generic
    INVALID_REQUEST("Invalid request"),
    INVALID_REQUEST_PAYLOAD("Invalid request payload"),
    DUPLICATE_OR_INVALID_DATA("Duplicate or invalid data"),
    EMAIL_ALREADY_EXISTS("Email already exists"),
    ROLE_CONTAINS_PERMISSIONS("This role has associated permissions. Please delete the permissions, then delete the role."),
    ROLE_ASSIGNED_TO_USERS("This role is assigned to one or more users. Please reassign the users to another role, then delete this role."),
    INVALID_REQUEST_PARAMETERS("Invalid request parameters"),
    INVALID_USERNAME_OR_PASSWORD("Invalid username or password"),
    INTERNAL_SERVER_ERROR("Something went wrong, please try again later"),

    // Additional service / validation messages
    BRANCH_EMAIL_ALREADY_EXISTS("Branch email already exists"),
    BRANCH_NOT_FOUND_WITH_ID("Branch record not found with id: %s"),
    ONE_OR_MORE_BRANCHES_NOT_FOUND("One or more branches not found"),

    VAULT_AND_RACK_WITH_NAME_POSITION_EXISTS("Vault with name %s and rack with name %s already exists in position %s"),
    RACK_NOT_FOUND_WITH_ID("Rack record not found with id: %s"),
    INVALID_RACK_COUNT_NEGATIVE("Invalid rack count for Rack No [%s]. Final count cannot be negative."),
    RACK_FULL_MESSAGE("Rack No [%s] Row [%s] is full. Current Count: %d, Requested Change: %d, Max Allowed: %d. Please select another rack."),

    AT_LEAST_ONE_VALID_APP_NUMBER_REQUIRED("At least one valid app number is required."),
    APP_NUMBERS_ALREADY_EXIST("App numbers already exist : %s"),
    NO_EXISTING_RECORDS_FOR_APP_NUMBERS("No existing records found for provided app numbers."),

    USER_NOT_FOUND("User not found."),
    USER_ACCOUNT_INACTIVE("User account is inactive"),
    INVALID_ROLE_ID("Invalid role ID: %s"),
    USER_NOT_FOUND_WITH_ID("User not found with ID: %s"),
    EMAIL_ALREADY_IN_USE("Email already in use: %s"),
    AUTH_SERVER_ERROR("Auth server error"),
    USER_ALREADY_EXISTS_REACTIVATED("User already exists with %s. Reactivated."),
    USER_ALREADY_EXISTS_ACTIVE("User already exists with %s and is active."),
    DUPLICATE_APP_NUMBERS_IN_REQUEST("Duplicate app numbers in request: %s"),
    QUERY_RECORDS_FETCHED("Query records fetched successfully"),
    VENDOR_RECORDS_FETCHED("Vendor records fetched successfully"),
    STAGE_RECORDS_FETCHED("Stage records fetched successfully"),
    TRANSACTION_CREATED("File transaction completed successfully"),
    DASHBOARD_APPS_COUNT("Dashboard Apps count fetched successfully"),
    APPLICATIONS_LOCKED("Applications locked successfully"),
    STAMP_MASTER_RECORD_CREATED("Stamping record created successfully"),
    STAMP_MASTER_RECORDS_FETCHED("Stamping records fetched successfully"),
    CANNOT_UPDATE_NON_PENDING_RECORDS("Cannot update non-pending Applications records"),
    STAMP_STACK_MASTER_RECORD_CREATED("Stamping stack record created successfully"),
    STAMP_STACK_MASTER_RECORDS_FETCHED("Stamping stack records fetched successfully"),
    STAMP_TYPE_MASTER_RECORDS_FETCHED("Stamp type master records fetched successfully"),
    STAMP_DENOMINATION_MASTER_RECORDS_FETCHED("Stamp denomination master records fetched successfully"),
    PERMISSIONS_FETCHED("Permissions fetched successfully"),
    PERMISSION_RECORD_CREATED("Permission record created successfully"),
    ROLE_CREATED("Role record created successfully"),
    LEAP_STATE_MASTER_RECORDS_FETCHED("Leap state master records fetched successfully"),
    ROLE_DELETED("Role record(s) deleted successfully"),
    QUERY_CATEGORY_CREATED("Query category record(s) created successfully"),
    ROLE_IDS_EMPTY("Role IDs cannot be empty"),
    PERMISSION_IDS_EMPTY("Permission IDs cannot be empty"),
    PERMISSION_DELETED("Permission record(s) deleted successfully"),
    PAGE_SIZE_EXCEEDS_LIMIT("Page size exceeds the maximum limit of %d"),
    INVALID_DATE_RANGE("Invalid date range. Start date must be before or equal to end date. Start date: %s, End date: %s"),
    QUERY_CATEGORIES_FETCHED("Query categories fetched successfully"),
    QUERY_CATEGORY_DELETED("Query category record(s) deleted successfully"),
    QUERY_CATEGORY_IDS_EMPTY("Query category IDs cannot be empty"),
    AUDIT_LOGS_FETCHED("Audit logs fetched successfully");

    private final String message;

    ResponseMessage(String message) {
        this.message = message;
    }

}