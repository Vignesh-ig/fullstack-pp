package com.chola.physical_file.userManagement.service.impl;

import com.chola.physical_file.auditLog.customAnnotation.AuditLog;
import com.chola.physical_file.branch.entity.BranchUserAssignedEntity;
import com.chola.physical_file.branch.service.BranchAssignedService;
import com.chola.physical_file.branch.mapper.BranchMasterMapper;
import com.chola.physical_file.branch.record.GenexPFBranchResponse;
import com.chola.physical_file.branch.service.BranchMasterService;
import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.enums.RoleType;
import com.chola.physical_file.common.exception.ResourceAlreadyExistsException;
import com.chola.physical_file.common.exception.UserAlreadyExistsException;
import com.chola.physical_file.common.exception.UserNotFoundException;
import com.chola.physical_file.common.service.ExternalApiCallService;
import com.chola.physical_file.userManagement.dto.UserDto;
import com.chola.physical_file.userManagement.dto.UserLogInRequestDto;
import com.chola.physical_file.userManagement.entity.LogInHistoryEntity;
import com.chola.physical_file.userManagement.entity.RoleEntity;
import com.chola.physical_file.userManagement.entity.UserEntity;
import com.chola.physical_file.userManagement.mapper.UserMapper;
import com.chola.physical_file.userManagement.record.GenexUsersResponse;
import com.chola.physical_file.userManagement.repository.LogInHistoryRepository;
import com.chola.physical_file.userManagement.repository.RoleRepository;
import com.chola.physical_file.userManagement.repository.UserRepository;
import com.chola.physical_file.userManagement.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClient;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final UserMapper userMapper;
    private final RoleRepository roleRepository;
    private final LogInHistoryRepository logInHistoryRepository;
    private final RestClient restClient;
    private final BranchAssignedService branchAssignedService;
    private final BranchMasterMapper branchMasterMapper;
    private final BranchMasterService branchMasterService;
    private final ExternalApiCallService externalApiCallService;


    @Value("${auth.token-url}")
    private String tokenUrl;

    @Value("${auth.client-id}")
    private String clientId;

    @Value("${auth.client-secret}")
    private String clientSecret;

    private static final String GRANT_TYPE = "password";

    private static final String USERNAME = "username";

    @Override
    @Transactional
    @AuditLog(
            action = "CREATE_USER",
            module = "USER_MANAGEMENT",
            entity = "USER"
    )
    // need to add at least one active admin user exit
    public void createUser(UserDto userDto) {

        validateNewUser(userDto);

        RoleEntity roleEntity = roleRepository.findById(userDto.getRoleId())
                .orElseThrow(() -> new IllegalArgumentException(String.format(ResponseMessage.INVALID_ROLE_ID.getMessage(), userDto.getRoleId())));

        UserEntity userEntity = userMapper.dtoToEntity(userDto);
        userEntity.setRole(roleEntity);

        UserEntity savedUser = userRepository.save(userEntity);

        if (RoleType.BRANCH_USER.name().equals(roleEntity.getRoleName())) {
            branchAssignedService.branchesAssignedToUser(savedUser, userDto.getBranchIds(), userDto.getCreatedBy());
        }
    }

    @AuditLog(
            action = "USER_LOGIN",
            module = "USER_MANAGEMENT",
            entity = "USER"
    )
    @Override
    @Transactional
    public UserDto loginUser(UserLogInRequestDto logInRequestDto) {

        getTokenFromAuthServer(logInRequestDto);

        UserEntity userEntity = userRepository.findWithRoleAndPermissionsByUserEmployeeCodeIgnoreCase(logInRequestDto.getUserEmployeeCode())
                .orElseThrow(() -> new UserNotFoundException(ResponseMessage.USER_NOT_FOUND.getMessage()));

        if (Boolean.FALSE.equals(userEntity.getIsActive())) {
            throw new BadCredentialsException(ResponseMessage.USER_ACCOUNT_INACTIVE.getMessage());
        }

        saveLoginHistory(userEntity);

        List<GenexPFBranchResponse> branchResponses = Collections.emptyList();

        if (RoleType.BRANCH_USER.name().equals(userEntity.getRole().getRoleName())) {

            List<String> branchIds = branchAssignedService.getUserAssignedBranchIds(userEntity.getUserId());

            if (!branchIds.isEmpty()) {
                branchResponses = branchMasterService.findAllById(branchIds);
            }
        }

        return userMapper.entityToDto(userEntity, branchResponses);
    }

    @Override
    public List<GenexUsersResponse> getAllGenexUsers() {
        return externalApiCallService.getAllGenexUsers();
    }

    @Override
    @Transactional(readOnly = true)
    public PageResponseDto getAllUsers(Integer pageNumber, Integer pageSize, String searchByName, List<String> filterByRoles, UUID userId) {

        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "createdDate")
        );

        List<String> roleNames = Optional.ofNullable(filterByRoles)
                .filter(roles -> !roles.isEmpty())
                .map(roles -> roles.stream()
                        .map(String::toUpperCase)
                        .toList())
                .orElse(null);

        Page<UserEntity> userPage = userRepository.searchUsers(searchByName, roleNames, userId, pageable);

        List<UserEntity> users = userPage.getContent();

        if (users.isEmpty()) {
            return buildPageResponse(userPage, Collections.emptyList());
        }

        /*
         * Get all BRANCH_USER ids
         */
        List<UUID> branchUserIds = users.stream()
                .filter(user ->
                        RoleType.BRANCH_USER.name()
                                .equals(user.getRole().getRoleName()))
                .map(UserEntity::getUserId)
                .toList();

        Map<UUID, List<GenexPFBranchResponse>> branchesByUserId;

        if (!branchUserIds.isEmpty()) {

            /*
             * Fetch all assignments in single query
             */
            List<BranchUserAssignedEntity> assignments = branchAssignedService.usersAssignedBranches(branchUserIds);

            if (!assignments.isEmpty()) {

                /*
                 * Collect unique branch ids
                 */
                Set<String> branchIds = assignments.stream()
                        .map(BranchUserAssignedEntity::getGenexBranchId)
                        .collect(Collectors.toSet());

                Map<String, GenexPFBranchResponse> branchMap =
                        branchMasterService.findAllById(new ArrayList<>(branchIds))
                                .stream()
                                .collect(Collectors.toMap(
                                        GenexPFBranchResponse::branchId,
                                        Function.identity()
                                ));

                branchesByUserId = assignments.stream()
                        .collect(Collectors.groupingBy(
                                BranchUserAssignedEntity::getUserId,
                                Collectors.mapping(
                                        assignment -> branchMap.get(assignment.getGenexBranchId()),
                                                Collectors.toList()
                                        )
                        ));
            } else {
                branchesByUserId = Collections.emptyMap();
            }
        } else {
            branchesByUserId = Collections.emptyMap();
        }

        // Convert users to DTOs
        List<UserDto> userDtos = users.stream()
                .map(user -> {

                    List<GenexPFBranchResponse> branches =
                            RoleType.BRANCH_USER.name().equals(user.getRole().getRoleName())
                                    ? branchesByUserId.getOrDefault(
                                    user.getUserId(),
                                    Collections.emptyList())
                                    : Collections.emptyList();

                    return userMapper.entityToDtoWithoutPermissions(user, branches);
                })
                .toList();

        return buildPageResponse(userPage, userDtos);
    }
    private PageResponseDto buildPageResponse(Page<UserEntity> page, List<UserDto> data) {

        PageResponseDto pageResponseDto = new PageResponseDto();

        pageResponseDto.setData(data);
        pageResponseDto.setCurrentPage(page.getNumber() + 1);
        pageResponseDto.setTotalItems((int) page.getTotalElements());
        pageResponseDto.setTotalPages(page.getTotalPages());
        pageResponseDto.setHasNextPage(page.hasNext());
        pageResponseDto.setHasPreviousPage(page.hasPrevious());

        return pageResponseDto;
    }

    @AuditLog(
            action = "UPDATE_USER",
            module = "USER_MANAGEMENT",
            entity = "USER"
    )
    @Override
    @Transactional
    public void updateUser(UserDto userDto) {

        UserEntity userEntity = userRepository.findByUserId(userDto.getUserId())
                .orElseThrow(() -> new IllegalArgumentException(String.format(ResponseMessage.USER_NOT_FOUND_WITH_ID.getMessage(), userDto.getUserId())));

        String oldRoleName = userEntity.getRole().getRoleName();

        // Update Role
        updateRole(userEntity, userDto.getRoleId());

        String newRoleName = userEntity.getRole().getRoleName();

        // Update Email
        updateEmail(userEntity, userDto.getUserEmail());

        if (userDto.getUserEmployeeCode() != null) {
            userEntity.setUserEmployeeCode(userDto.getUserEmployeeCode());
        }

        if (userDto.getUserName() != null) {
            userEntity.setUserName(userDto.getUserName());
        }

        if (userDto.getIsActive() != null) {
            userEntity.setIsActive(userDto.getIsActive());
        }

        userEntity.setModifiedBy(userDto.getModifiedBy());

        UserEntity updatedUser = userRepository.save(userEntity);


        // Case 1:
        // role changed TO BRANCH_USER
        if (!RoleType.BRANCH_USER.name().equals(oldRoleName) && RoleType.BRANCH_USER.name().equals(newRoleName)) {

            branchAssignedService.branchesAssignedToUser(updatedUser, userDto.getBranchIds(), userDto.getModifiedBy());
        }

        // Case 2:
        // role remains BRANCH_USER -> update branches
        else if (RoleType.BRANCH_USER.name().equals(oldRoleName) && RoleType.BRANCH_USER.name().equals(newRoleName)) {

            branchAssignedService.updateUserBranchesAssigned(updatedUser, userDto.getBranchIds(), userDto.getModifiedBy());
        }

        // Case 3:
        // role changed FROM BRANCH_USER to another role
        else if (RoleType.BRANCH_USER.name().equals(oldRoleName) && !RoleType.BRANCH_USER.name().equals(newRoleName)) {
            branchAssignedService.deleteUserBranchAssigned(updatedUser.getUserId());
        }
    }

    @AuditLog(
            action = "DELETE_USER",
            module = "USER_MANAGEMENT",
            entity = "USER"
    )
    @Override
    @Transactional
    public void deleteUser(List<UUID> userIds) {
        branchAssignedService.deleteUsersBranchAssigned(userIds);
        userRepository.deleteAllByIdInBatch(userIds);
    }

    public void handleExistingUser(Optional<UserEntity> optionalUser, String field) {
        optionalUser.ifPresent(existing -> {

            String displayField = "Employee Id".equals(field)
                    ? "System User Name"
                    : field;

            int updated = userRepository.reactivateUser(existing.getUserId());

            String message = updated > 0
                    ? String.format(ResponseMessage.USER_ALREADY_EXISTS_REACTIVATED.getMessage(), displayField)
                    : String.format(ResponseMessage.USER_ALREADY_EXISTS_ACTIVE.getMessage(), displayField);

            throw new UserAlreadyExistsException(message);
        });
    }

    public void updateRole(UserEntity userEntity, UUID roleId) {
        if (!Objects.equals(userEntity.getRole().getRoleId(), roleId)) {
            RoleEntity role = roleRepository.findByRoleId(roleId)
                    .orElseThrow(() -> new IllegalArgumentException(String.format(ResponseMessage.INVALID_ROLE_ID.getMessage(), roleId)));
            userEntity.setRole(role);
        }
    }

    public void updateEmail(UserEntity userEntity, String email) {
        if (!Objects.equals(userEntity.getUserEmail(), email)) {
            userRepository.findByUserEmailIgnoreCase(email)
                    .filter(u -> !u.getUserId().equals(userEntity.getUserId()))
                    .ifPresent(u -> {
                        throw new IllegalArgumentException(String.format(ResponseMessage.EMAIL_ALREADY_IN_USE.getMessage(), email));
                    });
            userEntity.setUserEmail(email);
        }
    }

    public void getTokenFromAuthServer(UserLogInRequestDto logInRequestDto) {

        try {
            MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
            formData.add("grant_type", GRANT_TYPE);
            formData.add("client_id", clientId);
            formData.add("client_secret", clientSecret);
            formData.add(USERNAME, logInRequestDto.getUserEmployeeCode());
            formData.add(GRANT_TYPE, logInRequestDto.getPassword());

            String response = restClient.post()
                    .uri(tokenUrl)
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .body(formData)
                    .retrieve()
                    .onStatus(HttpStatusCode::isError, (req, res) -> {
                        throw new BadCredentialsException(ResponseMessage.INVALID_USERNAME_OR_PASSWORD.getMessage());
                    })
                    .body(String.class);

            if (response == null || response.isBlank()) {
                throw new BadCredentialsException(ResponseMessage.INVALID_USERNAME_OR_PASSWORD.getMessage());
            }

        } catch (BadCredentialsException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException(ResponseMessage.AUTH_SERVER_ERROR.getMessage(), ex);
        }
    }

    public void validateNewUser(UserDto userDto) {

        userRepository.findByUserEmailIgnoreCaseOrUserEmployeeCodeIgnoreCase(userDto.getUserEmail(), userDto.getUserEmployeeCode())
                .ifPresent(user -> {
                    if (user.getUserEmail().equalsIgnoreCase(userDto.getUserEmail())) {
                        throw new ResourceAlreadyExistsException("User Email already exists");
                    }
                    if (user.getUserEmployeeCode().equals(userDto.getUserEmployeeCode())) {
                        throw new ResourceAlreadyExistsException("User Employee Id already exists");
                    }
                });
    }

    public void saveLoginHistory(UserEntity user) {
        LogInHistoryEntity entity = new LogInHistoryEntity();
        entity.setUser(user);
        logInHistoryRepository.save(entity);
    }
}

