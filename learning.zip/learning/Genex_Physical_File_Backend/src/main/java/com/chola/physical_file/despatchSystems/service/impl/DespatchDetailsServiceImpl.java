package com.chola.physical_file.despatchSystems.service.impl;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.exception.ResourceAlreadyExistsException;
import com.chola.physical_file.common.exception.ResourceNotFoundException;
import com.chola.physical_file.common.record.LeapVFAppDetailsResponse;
import com.chola.physical_file.common.service.ExternalApiCallService;
import com.chola.physical_file.despatchSystems.Repository.DespatchDetailsRepository;
import com.chola.physical_file.despatchSystems.Repository.projection.DespatchDetailsProjection;
import com.chola.physical_file.despatchSystems.dto.DespatchDetailsDTO;
import com.chola.physical_file.despatchSystems.entity.DespatchDetailsEntity;
import com.chola.physical_file.despatchSystems.mapper.DespatchDetailsMapper;
import com.chola.physical_file.despatchSystems.projection.DpAgreementNoBasicDetailsProjection;
import com.chola.physical_file.despatchSystems.service.DespatchDetailsService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class DespatchDetailsServiceImpl implements DespatchDetailsService {

    private final DespatchDetailsRepository despatchDetailsRepository;
    private final DespatchDetailsMapper despatchDetailsMapper;
    private final DespatchDetailsProjection despatchDetailsProjection;
    private final ExternalApiCallService externalApiCallService;

    @Override
    @Transactional(readOnly = true)
    public DespatchDetailsDTO getDespatchDetails(String appNoOrBarcode) {

        Optional<DespatchDetailsEntity> despatchDetailsEntityOpt = despatchDetailsRepository.findPendingDespatchDetails(appNoOrBarcode);

        if (despatchDetailsEntityOpt.isEmpty()) {
            throw new ResourceNotFoundException("The item has not yet reached the Inward stage.");
        }
        DespatchDetailsEntity despatchDetailsEntity = despatchDetailsEntityOpt.get();

        if (Boolean.TRUE.equals(despatchDetailsEntity.getIsPhysicalFileProcess())) {
            throw new ResourceAlreadyExistsException("Physical file process is already in progress for the given application number or barcode.");
        }

        List<LeapVFAppDetailsResponse> leapDetails = externalApiCallService.getLeapVFAppNoDetailsByAppNos(despatchDetailsEntity.getDpAppNo());
        if (leapDetails.isEmpty()) {
            throw new ResourceNotFoundException("No details found in Leap for the given application number.");
        }

        return despatchDetailsMapper.convertEntityToDto(despatchDetailsEntity, leapDetails.getFirst());
    }

    @Override
    public PageResponseDto getDespatchDetailsByAgreementNo(Integer pageNumber, Integer pageSize, String agreementNo) {

        PageResponseDto pageResponseDto = new PageResponseDto();

        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(Sort.Direction.DESC, "dpCreatedDate")
        );
        Page<DpAgreementNoBasicDetailsProjection> pageResponse = despatchDetailsProjection.findByDpAgreementNo(agreementNo.trim(), pageable);

        List<DespatchDetailsDTO> dtoList = despatchDetailsMapper.convertProjectionsToDtos(pageResponse.getContent());

        pageResponseDto.setData(dtoList);
        pageResponseDto.setCurrentPage(pageResponse.getNumber() + 1);
        pageResponseDto.setTotalItems((int) pageResponse.getTotalElements());
        pageResponseDto.setTotalPages(pageResponse.getTotalPages());
        pageResponseDto.setHasNextPage(pageResponse.hasNext());
        pageResponseDto.setHasPreviousPage(pageResponse.hasPrevious());

        return pageResponseDto;
    }

    @Override
    @Transactional
    public int updateIsPhysicalFileProcess(List<String> requestAppNos, boolean isPhysicalFileProcess) {
        return despatchDetailsRepository.updateIsPhysicalFileProcess(requestAppNos, isPhysicalFileProcess);
    }

}
