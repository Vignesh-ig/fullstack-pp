package com.chola.physical_file.despatchSystems.records;

import java.math.BigDecimal;

public record GenexPFDetailsResponse(

        String agreementNo,

        String applicationFormNo,

        String branchDesc,

        String branchId,

        BigDecimal financeAmount,

        String fundedCustomerType,

        String rePaymentMode,

        String workflow_no,

        Long lead_id,

        String customername

) { }