package com.chola.physical_file.userManagement.controller;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.ResponseMessage;
import com.chola.physical_file.common.util.CommonResponseUtil;
import com.chola.physical_file.common.util.Create;
import com.chola.physical_file.common.util.ResponseUtil;
import com.chola.physical_file.common.util.Update;
import com.chola.physical_file.userManagement.dto.UserDto;
import com.chola.physical_file.userManagement.dto.UserLogInRequestDto;
import com.chola.physical_file.userManagement.record.GenexUsersResponse;
import com.chola.physical_file.userManagement.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/v1/users")
@RequiredArgsConstructor
@Validated
@Tag(name = "Users", description = "APIs to manage users: list, create, update, delete and login")
public class UserController {
    private final UserService userService;

    @GetMapping
    @Operation(summary = "Get all users", description = "Fetch paginated list of users. Optional searchByName filters by user name.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Users fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = PageResponseDto.class)))
    })
    public ResponseEntity<CommonResponseUtil> getAllUsers(
            @Parameter(description = "Page number (starting from 1)", example = "1") @RequestParam(name = "page", defaultValue = "1")
            @Min(value = 1, message = "The page must be a positive number.")
            Integer pageNumber,
            @Parameter(description = "Page size (max 500)", example = "10") @RequestParam(name = "limit", defaultValue = "10")
            @Min(value = 1, message = "The limit must be a positive number.") @Max(value = 500, message = "Maximum allowed limit is 500.")
            Integer pageSize,
            @Parameter(description = "Optional name to search users by", example = "john") @RequestParam(name = "searchByName", required = false) String searchByName,
            @Parameter(description = "Optional name to search role by", example = "admin") @RequestParam(name = "searchByRole", required = false) List<String> filterByRoles,
            @Parameter(description = "Optional userId to filter users by", example = "123e4567-e89b-12d3-a456-426614174000") @RequestParam(name = "userId", required = false) UUID userId

    ) {
        PageResponseDto pageResponseDto = userService.getAllUsers(pageNumber, pageSize, searchByName, filterByRoles, userId);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.USERS_FETCHED.getMessage(), HttpStatus.OK, pageResponseDto));
    }

    @GetMapping("/genex")
    @Operation(summary = "Get all genex users", description = "Fetch paginated list of genex users. Optional searchByName filters by user name.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Genex users fetched successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = PageResponseDto.class)))
    })
    public ResponseEntity<CommonResponseUtil> getAllGenexUsers() {
        List<GenexUsersResponse> pageResponseDto = userService.getAllGenexUsers();
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.GENEX_USERS_FETCHED.getMessage(), HttpStatus.OK, pageResponseDto));
    }

    @PostMapping("/login")
    @Operation(summary = "User login", description = "Authenticate a user with username and password. Returns user details on success.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "User logged in successfully",
                    content = @Content(mediaType = "application/json",
                            schema = @Schema(implementation = UserDto.class))),
            @ApiResponse(responseCode = "400", description = "Bad request for invalid credentials")
    })
    public ResponseEntity<CommonResponseUtil> loginUser(@Valid @RequestBody UserLogInRequestDto logInRequestDto) {
        UserDto loggedInUser = userService.loginUser(logInRequestDto);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.USER_LOGGED_IN_SUCCESS.getMessage(), HttpStatus.OK, loggedInUser));
    }

    @PostMapping
    @Operation(summary = "Create user", description = "Create a new user with the provided details.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "User created successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or bad request")
    })
    public ResponseEntity<CommonResponseUtil> createUser(@Validated(Create.class) @RequestBody UserDto userDto) {
        userService.createUser(userDto);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ResponseUtil.success(ResponseMessage.USER_CREATED.getMessage(), HttpStatus.CREATED, null));
    }

    @PutMapping
    @Operation(summary = "Update user", description = "Update existing user information.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "User updated successfully"),
            @ApiResponse(responseCode = "400", description = "Validation error or bad request")
    })
    public ResponseEntity<CommonResponseUtil> updateUser(@Validated(Update.class) @Valid @RequestBody UserDto userDto) {
        userService.updateUser(userDto);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.USER_UPDATED.getMessage(), HttpStatus.OK, null));
    }

    @PostMapping("/ids")
    @Operation(summary = "Delete users", description = "Delete one or more users by their UUIDs. Provide user IDs as query param 'UserIds'.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "User deleted successfully"),
            @ApiResponse(responseCode = "400", description = "Bad request when UserIds is empty or invalid")
    })
    public ResponseEntity<CommonResponseUtil> deleteUser(@Parameter(description = "List of user UUIDs to delete", required = true) @RequestParam(name = "UserIds") List<UUID> userIds) {
        if (userIds == null || userIds.isEmpty()) {
            throw new IllegalArgumentException(ResponseMessage.USER_IDS_EMPTY.getMessage());
        }
        userService.deleteUser(userIds);
        return ResponseEntity.status(HttpStatus.OK)
                .body(ResponseUtil.success(ResponseMessage.USER_DELETED.getMessage(), HttpStatus.OK, null));
    }

}