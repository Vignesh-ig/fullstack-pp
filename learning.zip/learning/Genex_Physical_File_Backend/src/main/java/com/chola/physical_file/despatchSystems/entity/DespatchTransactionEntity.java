package com.chola.physical_file.despatchSystems.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "Despatch_Transaction_T", schema = "dbo")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DespatchTransactionEntity {

    @Id
    @Column(name = "dp_ID")
    private Integer dpId;

    @Column(name = "dp_referenceNo", unique = true)
    private String referenceNo;

    @Column(name = "Dp_CourierNo")
    private String courierNo;

    @Column(name = "Dp_Origin")
    private String origin;
}