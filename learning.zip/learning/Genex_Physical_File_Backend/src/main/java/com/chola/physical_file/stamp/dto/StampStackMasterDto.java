package com.chola.physical_file.stamp.dto;

import com.chola.physical_file.common.enums.StatusEnum;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StampStackMasterDto {

    private UUID stampStackMasterId;

    private Integer denominationAmount;

    private String denominationSerialNo;

    private LocalDateTime stampStackDate;

    private String state;

    private StatusEnum status;

    private Integer csvRowNo;

    private UUID createdBy;

    private LocalDateTime createdDate;

    private UUID usedBy;

    private String usedUserName;

    private LocalDateTime usedDate;
}