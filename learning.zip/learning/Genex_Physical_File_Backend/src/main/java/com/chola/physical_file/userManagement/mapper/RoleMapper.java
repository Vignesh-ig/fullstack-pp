package com.chola.physical_file.userManagement.mapper;

import com.chola.physical_file.userManagement.dto.RoleDto;
import com.chola.physical_file.userManagement.entity.RoleEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class RoleMapper {

    private final PermissionMapper permissionMapper;

    public RoleDto entityToDto(RoleEntity entity) {
        if (entity == null) return null;

        return RoleDto.builder()
                .roleId(entity.getRoleId())
                .roleName(entity.getRoleName())
                .description(entity.getDescription())
                .isActive(entity.getIsActive())
                .createdBy(entity.getCreatedBy())
                .modifiedBy(entity.getModifiedBy())
                .permissionDtoList(
                        entity.getPermissions() != null
                                ? permissionMapper.toDtos(entity.getPermissions())
                                : List.of()
                )
                .build();
    }

    public RoleDto toDtoWithoutPermissions(RoleEntity entity) {
        if (entity == null) return null;

        return RoleDto.builder()
                .roleId(entity.getRoleId())
                .roleName(entity.getRoleName())
                .description(entity.getDescription())
                .isActive(entity.getIsActive())
                .createdBy(entity.getCreatedBy())
                .modifiedBy(entity.getModifiedBy())
                .build();
    }

    public RoleEntity dtoToEntity(RoleDto roleDto) {
        if (roleDto == null) return null;

        return RoleEntity.builder()
                .roleId(roleDto.getRoleId())
                .roleName(roleDto.getRoleName())
                .description(roleDto.getDescription())
                .isActive(true)
                .createdBy(roleDto.getCreatedBy())
                .modifiedBy(roleDto.getModifiedBy() != null ? roleDto.getModifiedBy() : roleDto.getCreatedBy())
                .build();
    }

    public List<RoleDto> toDtos(List<RoleEntity> list) {
        return list == null ? List.of() :
                list.stream()
                        .map(this::toDtoWithoutPermissions)
                        .toList();
    }
}
