package com.chola.physical_file.fileTransaction.dto;

import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.query.dto.QueryMasterDto;
import com.chola.physical_file.rackAndUserAssigned.dto.RackDto;
import com.chola.physical_file.stage.dto.StageDto;
import com.chola.physical_file.stamp.dto.StampStackMasterDto;
import com.chola.physical_file.userManagement.dto.UserBasicDetailsDto;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TransactionAppResponseDto {

    private UUID transactionId;
    private String appNo;
    private String aggNo;
    private Long leadId;
    private String customerName;
    private BigDecimal amountFinance;
    private String schemaProduct;
    private String scheme;
    private String state;
    private String branchDesc;

    private String stateDesc;
    private String branchId;

    private String fundedCustomerType;
    private String rePaymentMode;
    private String workflowNo;
    private String eStamp;

    private String stampType;
    private BigDecimal leapStampAmount;
    private BigDecimal discountStampAmount;
    private BigDecimal finalStampAmount;

    private LocalDateTime emiEndDate;

    private String modelNo;
    private String make;
    private String vBarCode;
    private String boxCode;
    private String currentRemarks;
    private UUID dmsId;
    private LocalDateTime handOffDate;
    private String genexFromBranch;
    private StatusEnum transactionStatus;
    private String barcode;
    private String podNo;
    private String missingPodNo;
    private Integer ageingNo;
    private Boolean isESign;
    private Boolean isLocked;
    private String fileType;
    private String loanId;
    private String businessMonth;
    private LocalDate businessDate;
    private LocalDate sourcingDate;
    private Integer tenure;
    private BigDecimal birr;
    private String registrableStatus;
    private String udhayamNumberStatus;
    private BigDecimal pacAmount;
    private String queryCartonBarcode;
    private LocalDateTime createdDate;
    private LocalDateTime modifiedDate;
    private LocalDateTime outwardDate;
    // Rack
    private RackDto rack;

    // Stage
    private StageDto stage;

    // Query
    private QueryMasterDto query;

    // Assigned User
    private UserBasicDetailsDto assignedUser;

    private UserBasicDetailsDto modifiedUser;

    // History
    private List<TransactionsHistoryDto> transactionsHistory;

    private List<StampStackMasterDto> stampStackMasterList;
}