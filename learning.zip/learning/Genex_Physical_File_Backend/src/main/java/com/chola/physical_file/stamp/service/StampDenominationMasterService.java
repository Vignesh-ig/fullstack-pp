package com.chola.physical_file.stamp.service;

import com.chola.physical_file.common.dto.PageResponseDto;

public interface StampDenominationMasterService {
    PageResponseDto getStampDenoMasterRecords(Integer pageNumber, Integer pageSize);
}