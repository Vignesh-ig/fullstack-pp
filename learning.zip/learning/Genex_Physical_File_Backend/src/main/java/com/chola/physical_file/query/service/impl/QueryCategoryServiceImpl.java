package com.chola.physical_file.query.service.impl;

import com.chola.physical_file.common.dto.PageResponseDto;
import com.chola.physical_file.common.enums.StatusEnum;
import com.chola.physical_file.query.dto.QueryCategoryDto;
import com.chola.physical_file.query.entity.QueryCategoryEntity;
import com.chola.physical_file.query.mapper.QueryCategoryMapper;
import com.chola.physical_file.query.repository.QueryCategoryRepository;
import com.chola.physical_file.query.service.QueryCategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class QueryCategoryServiceImpl implements QueryCategoryService {
    private final QueryCategoryRepository queryCategoryRepository;
    private final QueryCategoryMapper queryCategoryMapper;

    @Override
    @Transactional(readOnly = true)
    public PageResponseDto getAllQueryCategories(Integer pageNumber, Integer pageSize, String queryCategoryName) {
        PageResponseDto pageResponseDto = new PageResponseDto();

        Pageable pageable = PageRequest.of(
                Math.max(0, pageNumber - 1),
                Math.max(1, pageSize),
                Sort.by(
                        Sort.Order.asc("queryCategoryName"),
                        Sort.Order.asc("querySubCategoryName")
                )
        );

        Page<QueryCategoryEntity> pageResponse;
        if (queryCategoryName == null || queryCategoryName.isEmpty()) {
            pageResponse = queryCategoryRepository.findAll(pageable);
        } else if (StatusEnum.UNIQUE.name().equals(queryCategoryName)) {
            pageResponse = queryCategoryRepository.findDistinctQueryCategories(pageable);
        } else {
            pageResponse = queryCategoryRepository.findQueryCategories(queryCategoryName, pageable);
        }

        List<QueryCategoryDto> categoryDtoList = queryCategoryMapper.toDtos(pageResponse.getContent());
        pageResponseDto.setData(categoryDtoList);
        pageResponseDto.setCurrentPage(pageResponse.getNumber() + 1);
        pageResponseDto.setTotalItems((int) pageResponse.getTotalElements());
        pageResponseDto.setTotalPages(pageResponse.getTotalPages());
        pageResponseDto.setHasNextPage(pageResponse.hasNext());
        pageResponseDto.setHasPreviousPage(pageResponse.hasPrevious());
        return pageResponseDto;
    }

    @Override
    @Transactional
    public void createQueryCategories(QueryCategoryDto queryCategoryDto) {
        if (queryCategoryRepository.existsByQueryCategoryNameAndQuerySubCategoryName(queryCategoryDto.getQueryCategoryName(), queryCategoryDto.getQueryCategoryDescription())) {
            throw new IllegalArgumentException("Query category with the same name and subcategory already exists.");
        }
        QueryCategoryEntity queryCategoryEntities = queryCategoryMapper.dtoToEntity(queryCategoryDto);
        queryCategoryRepository.save(queryCategoryEntities);
    }

    @Override
    @Transactional
    public void deleteQueryCategory(List<UUID> queryCategoryIds) {
        queryCategoryRepository.deleteAllByIdInBatch(queryCategoryIds);
    }
}