// DBML for Genex Physical File Backend

Table transactions {
  transactions_id uuid [primary key]
  app_no varchar
  agg_no varchar
  barcode varchar
  ageing_no varchar
  pod_no varchar
  is_e_sign boolean
  lead_id int
  customer_name varchar
  amount_finance varchar
  schema_product varchar
  scheme varchar
  branch_desc varchar
  model_no varchar
  make varchar
  file_type varchar
  v_bar_code varchar
  box_code varchar
  current_remarks varchar
  dms_id varchar
  hand_off_date timestamp
  rack_id uuid
  stage_id uuid
  query_id uuid
  doc_admin_id uuid
  vendor_id uuid
  transaction_status varchar
  assigned_user uuid
  genex_from_branch varchar
  is_locked boolean
  state_desc varchar
  funded_customer_type varchar
  re_payment_mode varchar
  e_stamp varchar
  stamp_type varchar
  leap_stamp_amount varchar
  discount_stamp_amount varchar
  final_stamp_amount varchar
  emi_end_date timestamp
  disbursed_date timestamp
  created_by uuid
  created_date timestamp
  modified_by uuid
  modified_date timestamp
}

Table transactions_history {
  transactions_history_id uuid [primary key]
  app_no varchar
  lead_id int
  remarks varchar
  rack_assigned_id uuid
  stage_id uuid
  query_id uuid
  transaction_id uuid
  assigned_to uuid
  created_by uuid
  created_date timestamp
}

Table branch_user_assigned {
  branch_assigned_id uuid [primary key]
  genex_branch_id varchar
  user_id uuid
  status boolean
  created_by uuid
  created_date timestamp
  modified_by uuid
  modified_date timestamp
}

Table roles {
  role_id uuid [primary key]
  role_name varchar
  description varchar
  is_active boolean
  created_date timestamp
  created_by uuid
  modified_date timestamp
  modified_by uuid
}

Table users {
  user_id uuid [primary key]
  user_name varchar
  user_email varchar
  user_employee_code varchar
  is_active boolean
  created_date timestamp
  created_by uuid
  modified_date timestamp
  modified_by uuid
  role_id uuid
}

Table log_in_history {
  log_in_id uuid [primary key]
  log_in_time timestamp
  user_id uuid
}

Table permissions {
  permission_id uuid [primary key]
  permission_name varchar
  description varchar
  created_date timestamp
  created_by uuid
  modified_date timestamp
  modified_by uuid
  role_id uuid
}

Table Despatch_Transaction_T {
  dp_ID int [primary key]
  dp_referenceNo varchar
  Dp_CourierNo varchar
  Dp_Origin varchar
}

Table Despatch_Detail_T {
  dp_ID int [primary key]
  Dp_CourierNo varchar
  is_physical_file_process boolean
  dp_AppNo varchar
  dp_AppName varchar
  dp_AgreementNo varchar
  Dp_Createddate timestamp
  dp_barcode varchar
  dp_schema varchar
  dp_isEsign varchar
  dp_VehicleRegistrability varchar
}

Table Depatch_CourierMaster_Tb {
  Dp_Courier_Id int [primary key]
  Dp_Courier_Name varchar
}

Table stage {
  stage_id uuid [primary key]
  stage_name varchar
  created_by uuid
  created_date timestamp
  modified_by uuid
  modified_date timestamp
}

Table stamp_stack_master {
  stamp_stack_master_id uuid [primary key]
  denomination_amount int
  denomination_serial_no varchar
  stamp_stack_date timestamp
  state varchar
  status varchar
  created_by uuid
  created_date timestamp
  used_by uuid
  used_date timestamp
}

Table stamp_transaction_assigned {
  stamp_transaction_assigned_id uuid [primary key]
  transaction_id uuid
  stamp_stack_master_id uuid
  created_by uuid
  created_date timestamp
}

Table stamp_denomination_master {
  stamp_denomination_master_id uuid [primary key]
  stamp_denomination_no int
  created_by uuid
  created_date timestamp
  modified_by uuid
  modified_date timestamp
}

Table stamp_type_master {
  stamp_type_master_id uuid [primary key]
  stamp_type_name varchar
  created_by uuid
  created_date timestamp
  modified_by uuid
  modified_date timestamp
}

Table stamp_master {
  stamp_master_id uuid [primary key]
  stamp_denomination_master_id uuid
  stamp_type_master_id uuid
  state varchar
  status boolean
  created_by uuid
  created_date timestamp
  modified_by uuid
  modified_date timestamp
}

Table rack {
  rack_id uuid [primary key]
  rack_name varchar
  vault_name varchar
  rack_position varchar
  rack_status boolean
  rack_app_count int
  created_by uuid
  created_date timestamp
  modified_by uuid
  modified_date timestamp
}

Table rack_user_assigned {
  rack_assigned_id uuid [primary key]
  ageing_no varchar
  assigned_user uuid
  app_no varchar
  agg_no varchar
  barcode varchar
  assigned_status varchar
  customer_name varchar
  rack_id uuid
  created_by uuid
  created_date timestamp
  modified_by uuid
  modified_date timestamp
}

Table queries {
  queries_id uuid [primary key]
  query_name varchar
  created_by uuid
  created_date timestamp
  modified_by uuid
  modified_date timestamp
}

Table vendor {
  vendor_id uuid [primary key]
  vendor_name varchar
  v_bar_code varchar
  created_by uuid
  created_date timestamp
  modified_by uuid
  modified_date timestamp
}

Table vault {
  vault_id uuid [primary key]
  vault_name varchar
  created_by uuid
  created_date timestamp
  modified_by uuid
  modified_date timestamp
}

Table audit_log {
  audit_id uuid [primary key]
  module_name varchar
  action_name varchar
  entity_name varchar
  created_by uuid
  created_date timestamp
}


// ----------------------------------------------------
// Relationships
// ----------------------------------------------------

Ref: users.role_id > roles.role_id
Ref: permissions.role_id > roles.role_id
Ref: log_in_history.user_id > users.user_id
Ref: branch_user_assigned.user_id > users.user_id

Ref: transactions.rack_id > rack.rack_id
Ref: transactions.stage_id > stage.stage_id
Ref: transactions.query_id > queries.queries_id
Ref: transactions.vendor_id > vendor.vendor_id
Ref: transactions.created_by > users.user_id

Ref: transactions_history.transaction_id > transactions.transactions_id
Ref: transactions_history.rack_assigned_id > rack_user_assigned.rack_assigned_id
Ref: transactions_history.stage_id > stage.stage_id
Ref: transactions_history.query_id > queries.queries_id

Ref: stamp_transaction_assigned.transaction_id > transactions.transactions_id
Ref: stamp_transaction_assigned.stamp_stack_master_id > stamp_stack_master.stamp_stack_master_id
Ref: stamp_transaction_assigned.created_by > users.user_id

Ref: stamp_master.stamp_denomination_master_id > stamp_denomination_master.stamp_denomination_master_id
Ref: stamp_master.stamp_type_master_id > stamp_type_master.stamp_type_master_id

Ref: rack_user_assigned.rack_id > rack.rack_id
 