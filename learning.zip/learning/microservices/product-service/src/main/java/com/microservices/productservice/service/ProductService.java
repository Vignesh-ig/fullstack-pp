package com.microservices.productservice.service;

import com.microservices.productservice.model.Product;
import com.microservices.productservice.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductService {
    private final ProductRepository repo;

    public Product save(Product product) {
        return repo.save(product);
    }

    public Product getById(Long id) {
        return repo.findById(id).orElseThrow();
    }

    public List<Product> getAll() {
        return repo.findAll();
    }
}