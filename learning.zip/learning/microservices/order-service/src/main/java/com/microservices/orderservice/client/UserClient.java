package com.microservices.orderservice.client;

import com.microservices.orderservice.dto.UserDTO;
import com.microservices.orderservice.exception.ServiceUnavailableException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
@RequiredArgsConstructor
public class UserClient {

    private final RestClient restClient;

    @Value("${services.user.url}")
    private String userServiceUrl;

    @Retry(name = "userService")
    @CircuitBreaker(name = "userService", fallbackMethod = "userFallback")
    public UserDTO getUser(Long userId) {
        return restClient.get()
                .uri(userServiceUrl + "/users/{id}", userId)
                .retrieve()
                .body(UserDTO.class);
    }

    public UserDTO userFallback(Long userId, Throwable t) {
        throw new ServiceUnavailableException("User Service is down. Try later.");
    }
}