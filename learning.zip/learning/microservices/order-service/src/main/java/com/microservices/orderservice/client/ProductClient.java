package com.microservices.orderservice.client;

import com.microservices.orderservice.dto.ProductDTO;
import com.microservices.orderservice.exception.ServiceUnavailableException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
@RequiredArgsConstructor
public class ProductClient {

    private final RestClient restClient;

    @Value("${services.product.url}")
    private String productServiceUrl;

    @Retry(name = "productService")
    @CircuitBreaker(name = "productService", fallbackMethod = "productFallback")
    public ProductDTO getProduct(Long productId) {
        return restClient.get()
                .uri(productServiceUrl + "/products/{id}", productId)
                .retrieve()
                .body(ProductDTO.class);
    }

    public ProductDTO productFallback(Long productId, Throwable t) {
        throw new ServiceUnavailableException("Product Service is down. Try later.");
    }
}