package com.microservices.orderservice.service;

import com.microservices.orderservice.client.ProductClient;
import com.microservices.orderservice.client.UserClient;
import com.microservices.orderservice.dto.ProductDTO;
import com.microservices.orderservice.dto.UserDTO;
import com.microservices.orderservice.model.Order;
import com.microservices.orderservice.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository repo;
    private final UserClient userClient;
    private final ProductClient productClient;

    public Order createOrder(Order order) {
        UserDTO user = userClient.getUser(order.getUserId());
        ProductDTO product = productClient.getProduct(order.getProductId());

        if (product.stock() < order.getQuantity()) {
            throw new RuntimeException("Insufficient stock");
        }

        BigDecimal total = product.price().multiply(BigDecimal.valueOf(order.getQuantity()));
        order.setTotalPrice(total);
        order.setStatus("CREATED");

        return repo.save(order);
    }

    public Order getOrderById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));
    }

    public List<Order> getAllOrders() {
        return repo.findAll();
    }
}