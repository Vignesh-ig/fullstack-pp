package com.microservices.orderservice.dto;

public record UserDTO(
        Long id,
        String name,
        String email
) {}
