package com.microservices.userservice.service;

import com.microservices.userservice.model.User;
import com.microservices.userservice.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository repo;

    public User save(User user) {
        return repo.save(user);
    }

    public User getById(Long id) {
        return repo.findById(id).orElseThrow();
    }

    public List<User> getAll() {
        return repo.findAll();
    }
}
